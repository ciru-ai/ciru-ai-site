# MOSSE Rust profile report

Status: **tracker-only replay profiler implemented and validated on the Pi.**

## Profile identity

- Source: clean exact/default tree at `d21f543`.
- Binary: fresh AArch64 build in `build/clean-d21f543`.
- Host: Raspberry Pi 4 Cortex-A72.
- Workload: the full 4,947-frame video with all 4,946 update attempts.
- Command class: `perf record -e cycles:u -F 999 -g --call-graph dwarf,4096`
  around the normal Rust benchmark command.
- Samples: approximately 37,000 user-cycle samples, with zero reported lost
  samples.
- Diagnostic tracker-only result: 6,266.580 FPS. This run is not a benchmark
  result because sampling and DWARF call-stack collection add overhead.

The entire process was sampled, including video decode. Only about 2.00% of
the recorded cycles were attributed beneath `MosseTracker::update`, yielding
roughly 750 tracker samples. The percentages below are therefore directional,
not precise phase measurements.

## Directional attribution

Inclusive percentages are shown relative to all sampled process cycles:

| Symbol | Inclusive | Self | Approximate share of tracker samples |
|---|---:|---:|---:|
| `MosseTracker::update` | 2.00% | 0.23% | 100% inclusive |
| `Workspace::prepare_hot_spectrum` | 0.51% | 0.51% | 25.5% self |
| `Fft2::inverse_real_reduced` | 0.52% | 0.17% | 26.0% inclusive |
| `Fft2::forward_real` | 0.39% | 0.12% | 19.5% inclusive |
| RustFFT mixed-radix path | 0.57% | 0.40% | 28.5% inclusive |
| RustFFT Good-Thomas path | 0.41% | 0.21% | 20.5% inclusive |

These rows overlap through call relationships and must not be summed.

## Assembly and instruction-level findings

Disassembly invalidated one static-review hypothesis:
`tracker::reconstruct_filter` is already auto-vectorized four lanes at a time.
The retained Pi binary contains `ld2`, four-wide `fmul`/`fadd`, exact
four-wide `fdiv`, predicate masking for invalid divisors, and `st2`. A second
hand-written implementation is not justified.

The fixed 60x36 RealFFT pre/postprocessing passes are genuinely scalar:

- `Fft2::forward_real` uses scalar `s` registers through the 14-twiddle loop.
  In the small 43-sample local annotation, most samples landed in that loop,
  especially its paired loads, arithmetic dependency chain, and strided
  stores.
- `Fft2::inverse_real_reduced` likewise uses scalar arithmetic through the
  fixed-row inverse twiddle loop. Its 64-sample local annotation again placed
  a substantial fraction of samples in that loop and its row-batch stores.

The instruction-level sample counts were too small for a trustworthy speedup
forecast. A follow-up four-wide forward-twiddle candidate changed the
generated code and preserved exact parity, but improved the 300-frame screen
by only 0.130816%, missing its 0.5% gate. The scalar loop was real; arithmetic
vectorization alone was not valuable enough because the column-major output
still required scattered scalar stores.

## Tracker-only replay profile

Commit `86d4084` added a diagnostic-only executable that caches decoded frames
once and replays them through fresh tracker instances. Fifty measured passes
over the first 300 frames produced:

- 14,950 attempted updates.
- 299 successes and zero failures per pass.
- Bit-identical decisions and boxes across every repetition.
- Approximately 7,000 `cycles:u` samples with zero lost samples.
- 34.16% of all process samples beneath `MosseTracker::update`, or roughly
  2,390 tracker samples.
- Diagnostic replay throughput of 6,460.944 FPS under `perf`.

The replay throughput is not a score. Predecoded frames, cache state,
aggregate timing, and profiler overhead differ from the official harness.
Decode and cache checksumming still accounted for substantial one-time sample
share, but the tracker sample count increased by more than threefold over the
first full-process profile.

Normalized against the 34.16% inclusive update attribution:

| Symbol | Process inclusive | Process self | Approx. inclusive share of update |
|---|---:|---:|---:|
| `Workspace::prepare_hot_spectrum` | 9.33% | 9.33% | 27.31% |
| `Fft2::inverse_real_reduced` | 8.86% | 2.48% | 25.94% |
| `Fft2::forward_real` | 6.60% | 1.66% | 19.32% |
| RustFFT mixed-radix path | 10.15% | 0.09% | 29.71% |
| RustFFT Good-Thomas path | 7.40% | 0.03% | 21.66% |

Rows overlap through call relationships and must not be summed. The stronger
sample confirms that preprocessing and the three FFT passes dominate; it also
supports treating isolated twiddle arithmetic as too narrow after its failed
screen.

Artifacts are retained on the Pi at
`results/pi4-profiling/replay-86d4084-300x50/`.

## Next profiling gate

Use the replay profiler for source-to-symbol triage before the next candidate.
Any next fixed-row candidate must address layout costs across both forward and
inverse passes, preserve the arithmetic order of every individual spectrum
bin, and use the current fixed implementation as a bit-exact oracle. A short
Pi parity/speed screen is appropriate only after local tests and AArch64
assembly inspection confirm that the candidate actually changes generated
code.
