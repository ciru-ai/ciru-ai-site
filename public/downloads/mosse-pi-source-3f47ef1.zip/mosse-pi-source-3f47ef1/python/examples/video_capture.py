#!/usr/bin/env python3
from __future__ import annotations

import argparse

import cv2

from mosse_pi import MosseTracker


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Track and draw one MOSSE ROI")
    parser.add_argument("video", help="video path or integer camera index")
    parser.add_argument(
        "--roi",
        type=float,
        nargs=4,
        metavar=("X", "Y", "W", "H"),
        required=True,
    )
    parser.add_argument(
        "--mode", choices=("auto", "single", "multicore"), default="auto"
    )
    parser.add_argument(
        "--max-frames",
        type=int,
        help="stop after this many update frames (useful for smoke tests)",
    )
    parser.add_argument(
        "--no-display",
        action="store_true",
        help="do not open a GUI window; still print the final result",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    source = int(args.video) if args.video.isdecimal() else args.video
    capture = cv2.VideoCapture(source)
    ok, frame = capture.read()
    if not ok:
        raise RuntimeError(f"could not read first frame from {args.video!r}")

    try:
        with MosseTracker(frame, args.roi, mode=args.mode) as tracker:
            print(
                f"requested={tracker.requested_mode} "
                f"selected={tracker.selected_mode} backend={tracker.backend}"
            )
            if tracker.native_library_info is not None:
                print(f"native={tracker.native_library_info}")

            updates = 0
            last_result = None
            while args.max_frames is None or updates < args.max_frames:
                ok, frame = capture.read()
                if not ok:
                    break
                last_result = tracker.update(frame)
                success, (x, y, width, height) = last_result
                updates += 1
                if args.no_display:
                    continue
                color = (0, 255, 0) if success else (0, 0, 255)
                cv2.rectangle(
                    frame,
                    (round(x), round(y)),
                    (round(x + width), round(y + height)),
                    color,
                    2,
                )
                cv2.imshow("mosse-pi preview", frame)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
            print(f"updates={updates} last_result={last_result}")
    finally:
        capture.release()
        if not args.no_display:
            cv2.destroyAllWindows()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
