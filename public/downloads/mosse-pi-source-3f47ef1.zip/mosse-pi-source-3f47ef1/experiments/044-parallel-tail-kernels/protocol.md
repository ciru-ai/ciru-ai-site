# Experiment 044: disjoint tail kernels

## Status

Prepared, isolated, and correctness-gated. Experiments 053 and 054 now consume
these kernels behind default-off tracker features. There is no measured
tracker-speed claim yet.

The integration remained conditional until the whole-layout/four-core tracker
was measured and its phase timings identified preprocessing and correlation
as material tails. Experiment 053 integrates the row-partitioned preprocessing
work. Experiment 054 integrates the same correlation arithmetic into the
existing inverse-column dispatch.

## Question

Can the existing guarded caller-plus-three-worker runtime execute the fixed
60x36 crop/preprocessing and padded-spectrum localization tails without
changing the serial floating-point reductions or allowing tasks to alias?

## Fixed work partition

- Crop-to-log: four tasks, each owning 9 complete output rows.
- Log-value sum: caller only, all 2,160 values in row-major order.
- Squared-deviation sum: caller only, all 2,160 values in row-major order.
- Normalize/Hann: four tasks, each owning the same 9-row partition.
- Localization correlation: eight tasks, each owning one complete
  `[kx_batch][36 ky][4 lanes]` output batch. Static modulo-four dispatch gives
  each core two batches.

The AArch64 crop task retains the existing fixed-point BGR interpolation,
BT.601 conversion, NEON block width, scalar four-pixel row tail, and LUT
lookup. It removes only the dependent reduction from the row workers. The
portable path uses the identical scalar expressions.

Correlation computes `sample * conj(filter)` independently in every valid
bin. The fourth lane in batch seven is padding. Its real and imaginary output
are explicitly restored to `+0.0` after every correlation task, even if input
padding was `-0.0`, NaN, or another poison value.

## Runtime integration shape

The task arrays contain disjoint mutable borrows and are `Send`. Experiment
053's feature-gated tracker integration uses the guarded runtime directly:

```rust
{
    let mut tasks =
        bind_crop_log_rows(frame, origin_x, origin_y, &log_lut, &mut values)?;
    runtime.dispatch(&mut tasks, |_, task| task.run());
}

let reduction = reduce_log_values_row_major(&values, epsilon)?;

{
    let mut tasks = bind_normalize_hann_rows(&mut values, &hann, reduction)?;
    runtime.dispatch(&mut tasks, |_, task| task.run());
}

{
    let mut tasks = bind_correlation_batches(&sample, &filter, &mut response);
    runtime.dispatch(&mut tasks, |_, task| task.run());
}
```

All dispatch and barrier time remains inside the tracker update timer. No
parallel partial sums or cross-core combine order are available through this
API. The inverse-response reduction remains the original serial caller
reduction and is outside this experiment.

## Correctness gates

Release tests cover:

- 32 randomized BGR frames with randomized dimensions, origins, byte
  contents, and non-packed strides;
- concurrent execution of all four crop tasks and all four normalization
  tasks;
- bit-for-bit crop logs, caller reductions, normalization, and Hann output
  against independent row-major oracles;
- an adversarial sequence that proves a four-part reduction can differ from
  the required serial accumulation;
- 24 randomized full padded spectra with concurrent eight-batch correlation;
- valid-bin bit comparisons including signed-zero inputs;
- NaN and signed-zero poison in the invalid lane, followed by exact `+0`
  padding checks;
- invalid frame, stride, storage, origin, and spatial-buffer geometry.

Recorded local gates:

```text
cargo test --release --manifest-path experiments/044-parallel-tail-kernels/Cargo.toml
6 passed; 0 failed

cargo clippy --release --manifest-path experiments/044-parallel-tail-kernels/Cargo.toml \
  --all-targets -- -D warnings
passed

cargo clippy --release --target aarch64-unknown-linux-gnu \
  --manifest-path experiments/044-parallel-tail-kernels/Cargo.toml \
  --lib -- -D warnings
passed
```

The AArch64 command is a compile/lint gate, not a Pi runtime measurement.
Run the oracle tests natively on the Pi only if the measured Amdahl analysis
selects this tail path. If selected, measure each complete staged sequence,
including every dispatch and barrier; an isolated kernel time is only a
ceiling and must not be reported as tracker throughput.

## Non-goals

- No default-on production tracker changes.
- No inverse-response parallel reduction.
- No Parseval substitution.
- No claimed change to tracker FPS, exact replay, PSR decisions, or the final
  OpenCV comparison.
