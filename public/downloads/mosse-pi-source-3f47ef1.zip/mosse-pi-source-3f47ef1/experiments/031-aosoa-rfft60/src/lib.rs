//! Experiment 031: four fixed length-60 real FFTs in four SIMD lanes.
//!
//! `RealBatch4` and `ComplexBatch4` are split-lane AoSoA contracts: the four
//! values at a logical index belong to four independent transforms. AArch64
//! evaluates those lanes in one NEON register. Other architectures compile
//! the exact same arithmetic from a portable four-element scalar source.
//!
//! Forward transforms use the standard unnormalized DFT convention and emit
//! the 31 unique bins, `0..=30`. Inverse transforms assume Hermitian completion
//! outside that half-spectrum, ignore the imaginary components of the DC and
//! Nyquist bins, and are also unnormalized. Consequently,
//! `inverse(forward(x)) == 60 * x`, within floating-point error.

use std::f32::consts::PI;

pub const REAL_LEN: usize = 60;
pub const PACKED_LEN: usize = REAL_LEN / 2;
pub const UNIQUE_LEN: usize = PACKED_LEN + 1;
pub const LANES: usize = 4;

/// Four independent real signals in logical sample order.
#[derive(Clone, Debug, PartialEq)]
#[repr(C)]
pub struct RealBatch4 {
    pub values: [[f32; LANES]; REAL_LEN],
}

impl Default for RealBatch4 {
    fn default() -> Self {
        Self {
            values: [[0.0; LANES]; REAL_LEN],
        }
    }
}

/// Four independent unique half-spectra in logical frequency order.
#[derive(Clone, Debug, PartialEq)]
#[repr(C)]
pub struct ComplexBatch4 {
    pub re: [[f32; LANES]; UNIQUE_LEN],
    pub im: [[f32; LANES]; UNIQUE_LEN],
}

impl Default for ComplexBatch4 {
    fn default() -> Self {
        Self {
            re: [[0.0; LANES]; UNIQUE_LEN],
            im: [[0.0; LANES]; UNIQUE_LEN],
        }
    }
}

#[derive(Clone, Debug, PartialEq)]
#[repr(C)]
struct PackedBatch4 {
    re: [[f32; LANES]; PACKED_LEN],
    im: [[f32; LANES]; PACKED_LEN],
}

impl Default for PackedBatch4 {
    fn default() -> Self {
        Self {
            re: [[0.0; LANES]; PACKED_LEN],
            im: [[0.0; LANES]; PACKED_LEN],
        }
    }
}

/// Fixed kernel with persistent work memory and precomputed real-FFT twiddles.
#[derive(Clone, Debug)]
#[repr(C)]
pub struct Kernel60x4 {
    scratch_a: PackedBatch4,
    scratch_b: PackedBatch4,
    twiddle_cos: [f32; UNIQUE_LEN],
    twiddle_sin: [f32; UNIQUE_LEN],
}

impl Default for Kernel60x4 {
    fn default() -> Self {
        Self::new()
    }
}

impl Kernel60x4 {
    /// Construct persistent state. Twiddle generation happens only here, never
    /// in either hot transform call.
    pub fn new() -> Self {
        let mut twiddle_cos = [0.0; UNIQUE_LEN];
        let mut twiddle_sin = [0.0; UNIQUE_LEN];
        for k in 0..UNIQUE_LEN {
            let angle = 2.0 * PI * k as f32 / REAL_LEN as f32;
            let (sine, cosine) = angle.sin_cos();
            twiddle_cos[k] = cosine;
            twiddle_sin[k] = sine;
        }
        Self {
            scratch_a: PackedBatch4::default(),
            scratch_b: PackedBatch4::default(),
            twiddle_cos,
            twiddle_sin,
        }
    }

    pub const fn backend_name() -> &'static str {
        #[cfg(target_arch = "aarch64")]
        {
            "aarch64-neon"
        }
        #[cfg(not(target_arch = "aarch64"))]
        {
            "portable-scalar-source"
        }
    }

    /// Poison persistent work memory. Validation uses distinct NaN payloads to
    /// prove that every scratch value read by a call was first overwritten.
    pub fn poison_scratch(&mut self, salt: u32) {
        for index in 0..PACKED_LEN {
            for lane in 0..LANES {
                let payload = ((index as u32 * 17 + lane as u32 * 29 + salt) & 0x003f_ffff) | 1;
                let nan = f32::from_bits(0x7fc0_0000 | payload);
                self.scratch_a.re[index][lane] = nan;
                self.scratch_a.im[index][lane] = nan;
                self.scratch_b.re[index][lane] = nan;
                self.scratch_b.im[index][lane] = nan;
            }
        }
    }

    /// Four unnormalized forward real FFTs.
    ///
    /// Even/odd real packing is fused into the Good-Thomas input permutation.
    /// The complete 5x6 complex FFT and real-FFT postprocessing are included.
    #[inline]
    pub fn process_forward(&mut self, input: &RealBatch4, output: &mut ComplexBatch4) {
        // The logical packed value y[n] = x[2n] + i*x[2n+1] is written
        // directly into the Good-Thomas input permutation.
        for (dst, &src) in INPUT_MAP.iter().enumerate() {
            unsafe {
                *self.scratch_a.re.get_unchecked_mut(dst) = *input.values.get_unchecked(src * 2);
                *self.scratch_a.im.get_unchecked_mut(dst) =
                    *input.values.get_unchecked(src * 2 + 1);
            }
        }

        self.process_good_thomas::<false>();

        let y0 = self.load_logical_packed(0);
        lane::store(lane::add(y0.re, y0.im), &mut output.re[0]);
        lane::store(lane::sub(y0.re, y0.im), &mut output.re[PACKED_LEN]);
        output.im[0] = [0.0; LANES];
        output.im[PACKED_LEN] = [0.0; LANES];

        for k in 1..PACKED_LEN {
            let a = self.load_logical_packed(k);
            let b = self.load_logical_packed(PACKED_LEN - k).conj();
            let sum = a.add(b);
            let difference = a.sub(b);
            let rotated = difference
                .mul_twiddle::<false>(self.twiddle_cos[k], self.twiddle_sin[k])
                .rotate_minus_i();
            let result = sum.add(rotated).scale(0.5);
            lane::store(result.re, &mut output.re[k]);
            lane::store(result.im, &mut output.im[k]);
        }
    }

    /// Four unnormalized inverse real FFTs.
    ///
    /// The unique half-spectrum is completed as Hermitian. Imaginary DC and
    /// Nyquist components are intentionally ignored. The pre-arithmetic emits
    /// `2*Y`, so the unnormalized length-30 inverse produces the conventional
    /// length-60 inverse scale without a separate output pass.
    #[inline]
    pub fn process_inverse(&mut self, input: &ComplexBatch4, output: &mut RealBatch4) {
        // Reconstruct the packed spectrum directly into the Good-Thomas input
        // permutation. Every scratch_a element is overwritten.
        for (dst, &k) in INPUT_MAP.iter().enumerate() {
            let reconstructed = if k == 0 {
                let dc = lane::load(&input.re[0]);
                let nyquist = lane::load(&input.re[PACKED_LEN]);
                CReg {
                    re: lane::add(dc, nyquist),
                    im: lane::sub(dc, nyquist),
                }
            } else {
                // SAFETY: INPUT_MAP is const-checked as a permutation of
                // 0..30. This branch excludes zero, so k and 30-k are both
                // valid interior unique-spectrum indices; twiddles have 31
                // entries.
                let (c, d, cosine, sine) = unsafe {
                    (
                        CReg::load_unique_unchecked(input, k),
                        CReg::load_unique_unchecked(input, PACKED_LEN - k).conj(),
                        *self.twiddle_cos.get_unchecked(k),
                        *self.twiddle_sin.get_unchecked(k),
                    )
                };
                let sum = c.add(d);
                let difference = c.sub(d);
                let rotated = difference.mul_twiddle::<true>(cosine, sine).rotate_plus_i();
                sum.add(rotated)
            };
            reconstructed.store_packed(&mut self.scratch_a, dst);
        }

        self.process_good_thomas::<true>();

        // The Good-Thomas output permutation and complex-to-real unpack are
        // fused. scratch_b[src] is logical y[OUTPUT_MAP[src]].
        for (src, &logical) in OUTPUT_MAP.iter().enumerate() {
            let value = CReg::load_packed(&self.scratch_b, src);
            // SAFETY: OUTPUT_MAP is const-checked as a permutation of 0..30,
            // so both real sample indices are in 0..60.
            unsafe {
                lane::store(value.re, output.values.get_unchecked_mut(logical * 2));
                lane::store(value.im, output.values.get_unchecked_mut(logical * 2 + 1));
            }
        }
    }

    #[inline(always)]
    fn process_good_thomas<const INVERSE: bool>(&mut self) {
        // Six independent radix-5 transforms.
        for row in 0..6 {
            radix5_at::<INVERSE>(&mut self.scratch_a, row * 5);
        }

        // 6x5 -> 5x6 transpose. Every scratch_b element is overwritten.
        for y in 0..6 {
            for x in 0..5 {
                let src = y * 5 + x;
                let dst = x * 6 + y;
                unsafe {
                    *self.scratch_b.re.get_unchecked_mut(dst) =
                        *self.scratch_a.re.get_unchecked(src);
                    *self.scratch_b.im.get_unchecked_mut(dst) =
                        *self.scratch_a.im.get_unchecked(src);
                }
            }
        }

        // Five fixed radix-6 transforms.
        for column in 0..5 {
            radix6_at::<INVERSE>(&mut self.scratch_b, column * 6);
        }
    }

    #[inline(always)]
    fn load_logical_packed(&self, logical: usize) -> CReg {
        let stage_index = LOGICAL_TO_STAGE[logical];
        CReg::load_packed(&self.scratch_b, stage_index)
    }
}

/// Good-Thomas 5x6 source permutation into six contiguous radix-5 rows.
const fn make_input_map() -> [usize; PACKED_LEN] {
    let mut map = [0; PACKED_LEN];
    let mut index = 0;
    while index < PACKED_LEN {
        let x = index % 5;
        let y = index / 5;
        map[index] = (x * 6 + y * 5) % PACKED_LEN;
        index += 1;
    }
    map
}

/// Good-Thomas output permutation from five contiguous radix-6 transforms.
const fn make_output_map() -> [usize; PACKED_LEN] {
    let mut map = [0; PACKED_LEN];
    let mut index = 0;
    while index < PACKED_LEN {
        let y = index % 6;
        let x = index / 6;
        // inv(6 mod 5) = 1; inv(5 mod 6) = 5.
        map[index] = (x * 6 + y * 5 * 5) % PACKED_LEN;
        index += 1;
    }
    map
}

const fn invert_permutation(map: &[usize; PACKED_LEN]) -> [usize; PACKED_LEN] {
    let mut inverse = [0; PACKED_LEN];
    let mut index = 0;
    while index < PACKED_LEN {
        inverse[map[index]] = index;
        index += 1;
    }
    inverse
}

const fn is_permutation(map: &[usize; PACKED_LEN]) -> bool {
    let mut seen = [false; PACKED_LEN];
    let mut index = 0;
    while index < PACKED_LEN {
        let value = map[index];
        if value >= PACKED_LEN || seen[value] {
            return false;
        }
        seen[value] = true;
        index += 1;
    }
    true
}

pub const INPUT_MAP: [usize; PACKED_LEN] = make_input_map();
pub const OUTPUT_MAP: [usize; PACKED_LEN] = make_output_map();
pub const LOGICAL_TO_STAGE: [usize; PACKED_LEN] = invert_permutation(&OUTPUT_MAP);

const _: () = {
    assert!(is_permutation(&INPUT_MAP));
    assert!(is_permutation(&OUTPUT_MAP));
};

#[derive(Clone, Copy)]
struct CReg {
    re: lane::Reg,
    im: lane::Reg,
}

impl CReg {
    #[inline(always)]
    fn load_packed(batch: &PackedBatch4, index: usize) -> Self {
        Self {
            re: lane::load(&batch.re[index]),
            im: lane::load(&batch.im[index]),
        }
    }

    #[inline(always)]
    unsafe fn load_unique_unchecked(batch: &ComplexBatch4, index: usize) -> Self {
        Self {
            re: lane::load(batch.re.get_unchecked(index)),
            im: lane::load(batch.im.get_unchecked(index)),
        }
    }

    #[inline(always)]
    fn store_packed(self, batch: &mut PackedBatch4, index: usize) {
        lane::store(self.re, &mut batch.re[index]);
        lane::store(self.im, &mut batch.im[index]);
    }

    #[inline(always)]
    fn add(self, rhs: Self) -> Self {
        Self {
            re: lane::add(self.re, rhs.re),
            im: lane::add(self.im, rhs.im),
        }
    }

    #[inline(always)]
    fn sub(self, rhs: Self) -> Self {
        Self {
            re: lane::sub(self.re, rhs.re),
            im: lane::sub(self.im, rhs.im),
        }
    }

    #[inline(always)]
    fn scale(self, scalar: f32) -> Self {
        Self {
            re: lane::mul_scalar(self.re, scalar),
            im: lane::mul_scalar(self.im, scalar),
        }
    }

    #[inline(always)]
    fn conj(self) -> Self {
        Self {
            re: self.re,
            im: lane::neg(self.im),
        }
    }

    #[inline(always)]
    fn rotate_plus_i(self) -> Self {
        Self {
            re: lane::neg(self.im),
            im: self.re,
        }
    }

    #[inline(always)]
    fn rotate_minus_i(self) -> Self {
        Self {
            re: self.im,
            im: lane::neg(self.re),
        }
    }

    #[inline(always)]
    fn mul_twiddle<const INVERSE: bool>(self, cosine: f32, sine_magnitude: f32) -> Self {
        let sine = if INVERSE {
            sine_magnitude
        } else {
            -sine_magnitude
        };
        Self {
            re: lane::mul_add(lane::mul_scalar(self.re, cosine), self.im, -sine),
            im: lane::mul_add(lane::mul_scalar(self.im, cosine), self.re, sine),
        }
    }
}

#[inline(always)]
fn radix3<const INVERSE: bool>(x0: CReg, x1: CReg, x2: CReg) -> [CReg; 3] {
    const HALF: f32 = 0.5;
    const SQRT_3_OVER_2: f32 = 0.866_025_4;

    let sum12 = x1.add(x2);
    let difference12 = x1.sub(x2);
    let y0 = x0.add(sum12);
    let base = CReg {
        re: lane::mul_add(x0.re, sum12.re, -HALF),
        im: lane::mul_add(x0.im, sum12.im, -HALF),
    };
    let cross_re = lane::mul_scalar(difference12.im, SQRT_3_OVER_2);
    let cross_im = lane::mul_scalar(difference12.re, SQRT_3_OVER_2);

    let (y1, y2) = if INVERSE {
        (
            CReg {
                re: lane::sub(base.re, cross_re),
                im: lane::add(base.im, cross_im),
            },
            CReg {
                re: lane::add(base.re, cross_re),
                im: lane::sub(base.im, cross_im),
            },
        )
    } else {
        (
            CReg {
                re: lane::add(base.re, cross_re),
                im: lane::sub(base.im, cross_im),
            },
            CReg {
                re: lane::sub(base.re, cross_re),
                im: lane::add(base.im, cross_im),
            },
        )
    };
    [y0, y1, y2]
}

#[inline(always)]
fn radix5_at<const INVERSE: bool>(batch: &mut PackedBatch4, base: usize) {
    const COS_2PI_5: f32 = 0.309_016_97;
    const SIN_2PI_5: f32 = 0.951_056_54;
    const COS_4PI_5: f32 = -0.809_017;
    const SIN_4PI_5: f32 = 0.587_785_24;

    let x0 = CReg::load_packed(batch, base);
    let x1 = CReg::load_packed(batch, base + 1);
    let x2 = CReg::load_packed(batch, base + 2);
    let x3 = CReg::load_packed(batch, base + 3);
    let x4 = CReg::load_packed(batch, base + 4);

    let sum14 = x1.add(x4);
    let sum23 = x2.add(x3);
    let difference14 = x1.sub(x4);
    let difference23 = x2.sub(x3);

    let y0 = x0.add(sum14).add(sum23);
    let base1 = x0.add(sum14.scale(COS_2PI_5)).add(sum23.scale(COS_4PI_5));
    let base2 = x0.add(sum14.scale(COS_4PI_5)).add(sum23.scale(COS_2PI_5));
    let cross1 = difference14
        .scale(SIN_2PI_5)
        .add(difference23.scale(SIN_4PI_5));
    let cross2 = difference14
        .scale(SIN_4PI_5)
        .sub(difference23.scale(SIN_2PI_5));

    let rotation1 = if INVERSE {
        cross1.rotate_plus_i()
    } else {
        cross1.rotate_minus_i()
    };
    let rotation2 = if INVERSE {
        cross2.rotate_plus_i()
    } else {
        cross2.rotate_minus_i()
    };

    y0.store_packed(batch, base);
    base1.add(rotation1).store_packed(batch, base + 1);
    base2.add(rotation2).store_packed(batch, base + 2);
    base2.sub(rotation2).store_packed(batch, base + 3);
    base1.sub(rotation1).store_packed(batch, base + 4);
}

#[inline(always)]
fn radix6_at<const INVERSE: bool>(batch: &mut PackedBatch4, base: usize) {
    const HALF: f32 = 0.5;
    const SQRT_3_OVER_2: f32 = 0.866_025_4;

    let x0 = CReg::load_packed(batch, base);
    let x1 = CReg::load_packed(batch, base + 1);
    let x2 = CReg::load_packed(batch, base + 2);
    let x3 = CReg::load_packed(batch, base + 3);
    let x4 = CReg::load_packed(batch, base + 4);
    let x5 = CReg::load_packed(batch, base + 5);

    let even = radix3::<INVERSE>(x0, x2, x4);
    let odd = radix3::<INVERSE>(x1, x3, x5);
    let twiddled0 = odd[0];
    let twiddled1 = odd[1].mul_twiddle::<INVERSE>(HALF, SQRT_3_OVER_2);
    let twiddled2 = odd[2].mul_twiddle::<INVERSE>(-HALF, SQRT_3_OVER_2);

    even[0].add(twiddled0).store_packed(batch, base);
    even[1].add(twiddled1).store_packed(batch, base + 1);
    even[2].add(twiddled2).store_packed(batch, base + 2);
    even[0].sub(twiddled0).store_packed(batch, base + 3);
    even[1].sub(twiddled1).store_packed(batch, base + 4);
    even[2].sub(twiddled2).store_packed(batch, base + 5);
}

/// Stable symbol for Cortex-A72 assembly inspection.
///
/// # Safety
///
/// All pointers must be non-null, aligned, initialized, and obey Rust's
/// aliasing rules for the duration of the call.
#[no_mangle]
pub unsafe extern "C" fn exp031_aosoa_rfft60_forward(
    kernel: *mut Kernel60x4,
    input: *const RealBatch4,
    output: *mut ComplexBatch4,
) {
    (*kernel).process_forward(&*input, &mut *output);
}

/// Stable inverse symbol for Cortex-A72 assembly inspection.
///
/// # Safety
///
/// All pointers must be non-null, aligned, initialized, and obey Rust's
/// aliasing rules for the duration of the call.
#[no_mangle]
pub unsafe extern "C" fn exp031_aosoa_rfft60_inverse(
    kernel: *mut Kernel60x4,
    input: *const ComplexBatch4,
    output: *mut RealBatch4,
) {
    (*kernel).process_inverse(&*input, &mut *output);
}

#[cfg(target_arch = "aarch64")]
mod lane {
    use core::arch::aarch64::{
        float32x4_t, vaddq_f32, vdupq_n_f32, vfmaq_n_f32, vld1q_f32, vmulq_f32, vnegq_f32,
        vst1q_f32, vsubq_f32,
    };

    pub type Reg = float32x4_t;

    #[inline(always)]
    pub fn load(value: &[f32; 4]) -> Reg {
        unsafe { vld1q_f32(value.as_ptr()) }
    }

    #[inline(always)]
    pub fn store(value: Reg, target: &mut [f32; 4]) {
        unsafe { vst1q_f32(target.as_mut_ptr(), value) }
    }

    #[inline(always)]
    pub fn add(lhs: Reg, rhs: Reg) -> Reg {
        unsafe { vaddq_f32(lhs, rhs) }
    }

    #[inline(always)]
    pub fn sub(lhs: Reg, rhs: Reg) -> Reg {
        unsafe { vsubq_f32(lhs, rhs) }
    }

    #[inline(always)]
    pub fn neg(value: Reg) -> Reg {
        unsafe { vnegq_f32(value) }
    }

    #[inline(always)]
    pub fn mul_scalar(lhs: Reg, rhs: f32) -> Reg {
        unsafe { vmulq_f32(lhs, vdupq_n_f32(rhs)) }
    }

    #[inline(always)]
    pub fn mul_add(accumulator: Reg, multiplicand: Reg, scalar: f32) -> Reg {
        unsafe { vfmaq_n_f32(accumulator, multiplicand, scalar) }
    }
}

#[cfg(not(target_arch = "aarch64"))]
mod lane {
    pub type Reg = [f32; 4];

    #[inline(always)]
    pub fn load(value: &[f32; 4]) -> Reg {
        *value
    }

    #[inline(always)]
    pub fn store(value: Reg, target: &mut [f32; 4]) {
        *target = value;
    }

    #[inline(always)]
    pub fn add(lhs: Reg, rhs: Reg) -> Reg {
        [
            lhs[0] + rhs[0],
            lhs[1] + rhs[1],
            lhs[2] + rhs[2],
            lhs[3] + rhs[3],
        ]
    }

    #[inline(always)]
    pub fn sub(lhs: Reg, rhs: Reg) -> Reg {
        [
            lhs[0] - rhs[0],
            lhs[1] - rhs[1],
            lhs[2] - rhs[2],
            lhs[3] - rhs[3],
        ]
    }

    #[inline(always)]
    pub fn neg(value: Reg) -> Reg {
        [-value[0], -value[1], -value[2], -value[3]]
    }

    #[inline(always)]
    pub fn mul_scalar(lhs: Reg, rhs: f32) -> Reg {
        [lhs[0] * rhs, lhs[1] * rhs, lhs[2] * rhs, lhs[3] * rhs]
    }

    #[inline(always)]
    pub fn mul_add(accumulator: Reg, multiplicand: Reg, scalar: f32) -> Reg {
        [
            accumulator[0] + multiplicand[0] * scalar,
            accumulator[1] + multiplicand[1] * scalar,
            accumulator[2] + multiplicand[2] * scalar,
            accumulator[3] + multiplicand[3] * scalar,
        ]
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn good_thomas_maps_are_permutations() {
        let mut input_seen = [false; PACKED_LEN];
        let mut output_seen = [false; PACKED_LEN];
        for &index in &INPUT_MAP {
            assert!(index < PACKED_LEN);
            assert!(!input_seen[index]);
            input_seen[index] = true;
        }
        for (stage, &logical) in OUTPUT_MAP.iter().enumerate() {
            assert!(logical < PACKED_LEN);
            assert!(!output_seen[logical]);
            output_seen[logical] = true;
            assert_eq!(LOGICAL_TO_STAGE[logical], stage);
        }
        assert!(input_seen.into_iter().all(|seen| seen));
        assert!(output_seen.into_iter().all(|seen| seen));
    }

    #[test]
    fn zero_survives_poisoned_scratch() {
        let input = RealBatch4::default();
        let mut spectrum = ComplexBatch4::default();
        let mut output = RealBatch4::default();
        let mut kernel = Kernel60x4::new();
        kernel.poison_scratch(0x1234);
        kernel.process_forward(&input, &mut spectrum);
        assert_eq!(spectrum, ComplexBatch4::default());
        kernel.poison_scratch(0x9876);
        kernel.process_inverse(&spectrum, &mut output);
        assert_eq!(output, RealBatch4::default());
    }
}
