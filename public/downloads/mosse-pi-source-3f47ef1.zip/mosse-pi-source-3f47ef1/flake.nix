{
  description = "Reproducible MOSSE tracker development and profiling shell";

  inputs = {
    # Commit flake.lock after the first `nix flake lock` so every host resolves
    # the same Rust, OpenCV, compiler, and analysis tool versions.
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";
  };

  outputs =
    { nixpkgs, ... }:
    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
      ];
      forAllSystems = nixpkgs.lib.genAttrs supportedSystems;
    in
    {
      devShells = forAllSystems (
        system:
        let
          pkgs = import nixpkgs { inherit system; };

          # OpenCV's Nixpkgs expression enables contrib by default. Keep the
          # override explicit because legacy::TrackerMOSSE lives in the contrib
          # tracking module and is a hard requirement for the baseline.
          opencvContrib = pkgs.opencv4.override {
            enableContrib = true;
            enablePython = false;
            enableFfmpeg = true;
          };
        in
        {
          default = pkgs.mkShell {
            strictDeps = true;

            packages = with pkgs; [
              # Stable Rust from the pinned Nixpkgs revision.
              rustc
              cargo
              rustfmt
              clippy

              # Native C++ build and OpenCV baseline.
              cmake
              ninja
              pkg-config
              opencvContrib
              ffmpeg

              # Compiler diagnostics and profiling.
              llvmPackages.clang
              llvmPackages.lld
              llvmPackages.llvm
              clang-tools
              gdb
              valgrind
              perf
              cargo-flamegraph
              hyperfine
              strace

              # Environment capture, scripting, and result inspection.
              python3
              jq
              git
              which
            ];

            OpenCV_DIR = "${opencvContrib}/lib/cmake/opencv4";
            PKG_CONFIG_PATH = "${opencvContrib}/lib/pkgconfig";
            CARGO_INCREMENTAL = "0";
            RUST_BACKTRACE = "1";

            shellHook = ''
              echo "MOSSE development shell" >&2
              echo "  Rust:  $(rustc --version)" >&2
              echo "  CMake: $(cmake --version | head -n 1)" >&2
              if pkg-config --exists opencv4; then
                echo "  OpenCV: $(pkg-config --modversion opencv4) (contrib enabled)" >&2
              else
                echo "  OpenCV: pkg-config metadata not found" >&2
              fi
              echo "Run: scripts/build_release.sh" >&2
            '';
          };
        }
      );

      formatter = forAllSystems (
        system:
        let
          pkgs = import nixpkgs { inherit system; };
        in
        pkgs.nixfmt-tree
      );
    };
}
