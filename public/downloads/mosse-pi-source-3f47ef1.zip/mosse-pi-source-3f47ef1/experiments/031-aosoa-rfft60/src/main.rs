use mosse_exp031_aosoa_rfft60::{
    ComplexBatch4, Kernel60x4, RealBatch4, LANES, PACKED_LEN, REAL_LEN, UNIQUE_LEN,
};
use realfft::RealFftPlanner;
use rustfft::{num_complex::Complex32, FftDirection, FftPlanner};
use std::{
    hint::black_box,
    process::ExitCode,
    time::{Duration, Instant},
};

const ABS_TOLERANCE: f32 = 2.0e-3;
const REL_TOLERANCE: f32 = 8.0e-5;
const TIMING_BLOCK: usize = 16;
const PRODUCTION_ROWS: usize = 36;

#[derive(Clone, Copy, Debug)]
struct Config {
    correctness_only: bool,
    warmup: usize,
    sample_ms: u64,
    samples: usize,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            correctness_only: false,
            warmup: 1_000,
            sample_ms: 100,
            samples: 5,
        }
    }
}

#[derive(Default)]
struct ErrorMetrics {
    values: u64,
    error_energy: f64,
    reference_energy: f64,
    max_abs: f32,
    max_scaled_ratio: f32,
}

impl ErrorMetrics {
    fn observe(&mut self, actual: f32, expected: f32, context: &str) -> Result<(), String> {
        if !actual.is_finite() {
            return Err(format!("{context}: non-finite actual value {actual:?}"));
        }
        if !expected.is_finite() {
            return Err(format!("{context}: non-finite oracle value {expected:?}"));
        }

        let error = (actual - expected).abs();
        let allowed = ABS_TOLERANCE + REL_TOLERANCE * expected.abs();
        self.values += 1;
        self.error_energy += f64::from(error) * f64::from(error);
        self.reference_energy += f64::from(expected) * f64::from(expected);
        self.max_abs = self.max_abs.max(error);
        self.max_scaled_ratio = self.max_scaled_ratio.max(error / allowed);
        if error > allowed {
            return Err(format!(
                "{context}: actual={actual:.9e} expected={expected:.9e} \
                 abs_error={error:.9e} allowed={allowed:.9e}"
            ));
        }
        Ok(())
    }

    fn rms_relative(&self) -> f64 {
        (self.error_energy / self.reference_energy.max(f64::MIN_POSITIVE)).sqrt()
    }
}

fn main() -> ExitCode {
    match parse_config().and_then(run) {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            eprintln!("error: {error}");
            ExitCode::FAILURE
        }
    }
}

fn parse_config() -> Result<Config, String> {
    let mut config = Config::default();
    let mut args = std::env::args().skip(1);
    while let Some(argument) = args.next() {
        match argument.as_str() {
            "--correctness-only" => config.correctness_only = true,
            "--warmup" => {
                config.warmup = args
                    .next()
                    .ok_or("--warmup requires a value")?
                    .parse()
                    .map_err(|_| "--warmup must be a nonnegative integer")?;
            }
            "--sample-ms" => {
                config.sample_ms = args
                    .next()
                    .ok_or("--sample-ms requires a value")?
                    .parse()
                    .map_err(|_| "--sample-ms must be a positive integer")?;
            }
            "--samples" => {
                config.samples = args
                    .next()
                    .ok_or("--samples requires a value")?
                    .parse()
                    .map_err(|_| "--samples must be a positive integer")?;
            }
            "--help" | "-h" => {
                println!(
                    "aosoa_rfft60_probe [--correctness-only] \
                     [--warmup N] [--sample-ms MS] [--samples N]"
                );
                std::process::exit(0);
            }
            _ => return Err(format!("unknown argument: {argument}")),
        }
    }
    if config.sample_ms == 0 || config.samples == 0 {
        return Err("--sample-ms and --samples must be nonzero".into());
    }
    Ok(config)
}

fn run(config: Config) -> Result<(), String> {
    println!("experiment=031-aosoa-rfft60");
    println!("backend={}", Kernel60x4::backend_name());
    println!(
        "layout=real_or_split_complex_aosoa logical_real_points={} unique_bins={} lanes={}",
        REAL_LEN, UNIQUE_LEN, LANES
    );
    println!(
        "normalization=forward_none,inverse_none roundtrip_scale={} \
         inverse_edge_imaginary=ignored",
        REAL_LEN
    );

    let metrics = correctness_gate()?;
    println!(
        "correctness=pass compared_values={} max_abs={:.9e} \
         rms_relative={:.9e} max_tolerance_fraction={:.6}",
        metrics.values,
        metrics.max_abs,
        metrics.rms_relative(),
        metrics.max_scaled_ratio
    );

    if config.correctness_only {
        return Ok(());
    }

    println!(
        "timing_scope=complete_batch4_real_fft \
         forward_includes=even_odd_pack,gt_input_permute,radix5,transpose,radix6,rfft_post \
         inverse_includes=rfft_pre,gt_input_permute,radix5,transpose,radix6,output_permute_unpack \
         excludes=fixture_construction_or_reset"
    );
    println!(
        "warning=kernel_ceiling_not_tracker_fps_or_end_to_end_prediction \
         warmup={} sample_ms={} samples={} block={}",
        config.warmup, config.sample_ms, config.samples, TIMING_BLOCK
    );

    let forward = time_forward(config);
    let inverse = time_inverse(config);
    print_timing("forward", &forward);
    print_timing("inverse", &inverse);
    println!(
        "production_row_normalization rows={} lanes={} calls={} padded_rows={} \
         forward_ns_for_36={:.3} inverse_ns_for_36={:.3}",
        PRODUCTION_ROWS,
        LANES,
        PRODUCTION_ROWS.div_ceil(LANES),
        PRODUCTION_ROWS.div_ceil(LANES) * LANES - PRODUCTION_ROWS,
        forward.median * PRODUCTION_ROWS.div_ceil(LANES) as f64,
        inverse.median * PRODUCTION_ROWS.div_ceil(LANES) as f64
    );
    Ok(())
}

fn correctness_gate() -> Result<ErrorMetrics, String> {
    let fixtures = deterministic_fixtures();
    let mut metrics = ErrorMetrics::default();
    let mut real_planner = RealFftPlanner::<f32>::new();
    let real_forward = real_planner.plan_fft_forward(REAL_LEN);
    let real_inverse = real_planner.plan_fft_inverse(REAL_LEN);
    let mut complex_planner = FftPlanner::<f32>::new();
    let complex_forward = complex_planner.plan_fft(REAL_LEN, FftDirection::Forward);
    let complex_inverse = complex_planner.plan_fft(REAL_LEN, FftDirection::Inverse);
    let mut forward_kernel = Kernel60x4::new();
    let mut inverse_kernel = Kernel60x4::new();

    for (fixture_index, fixture) in fixtures.iter().enumerate() {
        let expected_realfft = oracle_forward_realfft(fixture, real_forward.as_ref())?;
        let expected_rustfft = oracle_forward_rustfft(fixture, complex_forward.as_ref());
        let mut actual_a = ComplexBatch4::default();
        let mut actual_b = ComplexBatch4::default();

        forward_kernel.poison_scratch(0x1000 + fixture_index as u32);
        forward_kernel.process_forward(fixture, &mut actual_a);
        forward_kernel.poison_scratch(0x9000 + fixture_index as u32 * 13);
        forward_kernel.process_forward(fixture, &mut actual_b);
        require_complex_bit_identical(
            &actual_a,
            &actual_b,
            &format!("fixture={fixture_index} forward_dirty_scratch"),
        )?;
        require_hermitian_edges(&actual_a, fixture_index)?;
        compare_complex(
            &actual_a,
            &expected_realfft,
            &format!("fixture={fixture_index} forward_oracle=realfft"),
            &mut metrics,
        )?;
        compare_complex(
            &actual_a,
            &expected_rustfft,
            &format!("fixture={fixture_index} forward_oracle=rustfft"),
            &mut metrics,
        )?;

        let expected_inverse_realfft =
            oracle_inverse_realfft(&expected_realfft, real_inverse.as_ref())?;
        let expected_inverse_rustfft =
            oracle_inverse_rustfft(&expected_realfft, complex_inverse.as_ref())?;
        let mut inverse_a = RealBatch4::default();
        let mut inverse_b = RealBatch4::default();
        inverse_kernel.poison_scratch(0xa500 + fixture_index as u32);
        inverse_kernel.process_inverse(&expected_realfft, &mut inverse_a);
        inverse_kernel.poison_scratch(0x5a00 + fixture_index as u32 * 7);
        inverse_kernel.process_inverse(&expected_realfft, &mut inverse_b);
        require_real_bit_identical(
            &inverse_a,
            &inverse_b,
            &format!("fixture={fixture_index} inverse_dirty_scratch"),
        )?;
        compare_real(
            &inverse_a,
            &expected_inverse_realfft,
            &format!("fixture={fixture_index} inverse_oracle=realfft"),
            &mut metrics,
        )?;
        compare_real(
            &inverse_a,
            &expected_inverse_rustfft,
            &format!("fixture={fixture_index} inverse_oracle=rustfft"),
            &mut metrics,
        )?;

        let mut round_trip_spectrum = ComplexBatch4::default();
        let mut round_trip = RealBatch4::default();
        forward_kernel.poison_scratch(0x3100 + fixture_index as u32);
        forward_kernel.process_forward(fixture, &mut round_trip_spectrum);
        inverse_kernel.poison_scratch(0x1300 + fixture_index as u32);
        inverse_kernel.process_inverse(&round_trip_spectrum, &mut round_trip);
        let mut expected_round_trip = fixture.clone();
        scale_real(&mut expected_round_trip, REAL_LEN as f32);
        compare_real(
            &round_trip,
            &expected_round_trip,
            &format!("fixture={fixture_index} kernel_round_trip"),
            &mut metrics,
        )?;
    }

    verify_edge_imaginary_ignored(&fixtures[3], &mut forward_kernel, &mut inverse_kernel)?;
    Ok(metrics)
}

fn oracle_forward_realfft(
    input: &RealBatch4,
    oracle: &dyn realfft::RealToComplex<f32>,
) -> Result<ComplexBatch4, String> {
    let mut output = ComplexBatch4::default();
    for lane in 0..LANES {
        let mut values: Vec<f32> = (0..REAL_LEN)
            .map(|index| input.values[index][lane])
            .collect();
        let mut spectrum = oracle.make_output_vec();
        oracle
            .process(&mut values, &mut spectrum)
            .map_err(|error| format!("realfft forward lane={lane}: {error}"))?;
        for (index, value) in spectrum.into_iter().enumerate() {
            output.re[index][lane] = value.re;
            output.im[index][lane] = value.im;
        }
    }
    Ok(output)
}

fn oracle_forward_rustfft(input: &RealBatch4, oracle: &dyn rustfft::Fft<f32>) -> ComplexBatch4 {
    let mut output = ComplexBatch4::default();
    for lane in 0..LANES {
        let mut values: Vec<Complex32> = (0..REAL_LEN)
            .map(|index| Complex32::new(input.values[index][lane], 0.0))
            .collect();
        oracle.process(&mut values);
        for (index, value) in values.iter().take(UNIQUE_LEN).enumerate() {
            output.re[index][lane] = value.re;
            output.im[index][lane] = value.im;
        }
    }
    output
}

fn oracle_inverse_realfft(
    input: &ComplexBatch4,
    oracle: &dyn realfft::ComplexToReal<f32>,
) -> Result<RealBatch4, String> {
    let mut output = RealBatch4::default();
    for lane in 0..LANES {
        let mut spectrum: Vec<Complex32> = (0..UNIQUE_LEN)
            .map(|index| Complex32::new(input.re[index][lane], input.im[index][lane]))
            .collect();
        spectrum[0].im = 0.0;
        spectrum[PACKED_LEN].im = 0.0;
        let mut values = oracle.make_output_vec();
        oracle
            .process(&mut spectrum, &mut values)
            .map_err(|error| format!("realfft inverse lane={lane}: {error}"))?;
        for (index, value) in values.into_iter().enumerate() {
            output.values[index][lane] = value;
        }
    }
    Ok(output)
}

fn oracle_inverse_rustfft(
    input: &ComplexBatch4,
    oracle: &dyn rustfft::Fft<f32>,
) -> Result<RealBatch4, String> {
    let mut output = RealBatch4::default();
    for lane in 0..LANES {
        let mut spectrum = vec![Complex32::new(0.0, 0.0); REAL_LEN];
        spectrum[0] = Complex32::new(input.re[0][lane], 0.0);
        spectrum[PACKED_LEN] = Complex32::new(input.re[PACKED_LEN][lane], 0.0);
        for k in 1..PACKED_LEN {
            let value = Complex32::new(input.re[k][lane], input.im[k][lane]);
            spectrum[k] = value;
            spectrum[REAL_LEN - k] = value.conj();
        }
        oracle.process(&mut spectrum);
        for (index, value) in spectrum.into_iter().enumerate() {
            if value.im.abs() > ABS_TOLERANCE + REL_TOLERANCE * value.re.abs() {
                return Err(format!(
                    "rustfft inverse lost Hermitian reality lane={lane} index={index} \
                     imaginary={:.9e}",
                    value.im
                ));
            }
            output.values[index][lane] = value.re;
        }
    }
    Ok(output)
}

fn compare_complex(
    actual: &ComplexBatch4,
    expected: &ComplexBatch4,
    prefix: &str,
    metrics: &mut ErrorMetrics,
) -> Result<(), String> {
    for index in 0..UNIQUE_LEN {
        for lane in 0..LANES {
            metrics.observe(
                actual.re[index][lane],
                expected.re[index][lane],
                &format!("{prefix} index={index} lane={lane} component=re"),
            )?;
            metrics.observe(
                actual.im[index][lane],
                expected.im[index][lane],
                &format!("{prefix} index={index} lane={lane} component=im"),
            )?;
        }
    }
    Ok(())
}

fn compare_real(
    actual: &RealBatch4,
    expected: &RealBatch4,
    prefix: &str,
    metrics: &mut ErrorMetrics,
) -> Result<(), String> {
    for index in 0..REAL_LEN {
        for lane in 0..LANES {
            metrics.observe(
                actual.values[index][lane],
                expected.values[index][lane],
                &format!("{prefix} index={index} lane={lane}"),
            )?;
        }
    }
    Ok(())
}

fn require_complex_bit_identical(
    lhs: &ComplexBatch4,
    rhs: &ComplexBatch4,
    context: &str,
) -> Result<(), String> {
    for index in 0..UNIQUE_LEN {
        for lane in 0..LANES {
            for (component, left, right) in [
                ("re", lhs.re[index][lane], rhs.re[index][lane]),
                ("im", lhs.im[index][lane], rhs.im[index][lane]),
            ] {
                if left.to_bits() != right.to_bits() {
                    return Err(format!(
                        "{context}: index={index} lane={lane} component={component}: \
                         {left:?} != {right:?}"
                    ));
                }
            }
        }
    }
    Ok(())
}

fn require_real_bit_identical(
    lhs: &RealBatch4,
    rhs: &RealBatch4,
    context: &str,
) -> Result<(), String> {
    for index in 0..REAL_LEN {
        for lane in 0..LANES {
            let left = lhs.values[index][lane];
            let right = rhs.values[index][lane];
            if left.to_bits() != right.to_bits() {
                return Err(format!(
                    "{context}: index={index} lane={lane}: {left:?} != {right:?}"
                ));
            }
        }
    }
    Ok(())
}

fn require_hermitian_edges(spectrum: &ComplexBatch4, fixture: usize) -> Result<(), String> {
    for lane in 0..LANES {
        for &index in &[0, PACKED_LEN] {
            if spectrum.im[index][lane].to_bits() != 0.0_f32.to_bits() {
                return Err(format!(
                    "fixture={fixture} forward Hermitian edge index={index} lane={lane} \
                     imaginary={:?}",
                    spectrum.im[index][lane]
                ));
            }
        }
    }
    Ok(())
}

fn verify_edge_imaginary_ignored(
    fixture: &RealBatch4,
    forward_kernel: &mut Kernel60x4,
    inverse_kernel: &mut Kernel60x4,
) -> Result<(), String> {
    let mut clean = ComplexBatch4::default();
    forward_kernel.process_forward(fixture, &mut clean);
    let mut dirty = clean.clone();
    for lane in 0..LANES {
        dirty.im[0][lane] = f32::from_bits(0x7fc0_1001 + lane as u32);
        dirty.im[PACKED_LEN][lane] = f32::from_bits(0x7fc0_2001 + lane as u32);
    }
    let mut clean_output = RealBatch4::default();
    let mut dirty_output = RealBatch4::default();
    inverse_kernel.poison_scratch(0x7777);
    inverse_kernel.process_inverse(&clean, &mut clean_output);
    inverse_kernel.poison_scratch(0x3333);
    inverse_kernel.process_inverse(&dirty, &mut dirty_output);
    require_real_bit_identical(
        &clean_output,
        &dirty_output,
        "inverse imaginary DC/Nyquist values must be ignored",
    )
}

fn scale_real(batch: &mut RealBatch4, scale: f32) {
    for index in 0..REAL_LEN {
        for lane in 0..LANES {
            batch.values[index][lane] *= scale;
        }
    }
}

fn deterministic_fixtures() -> Vec<RealBatch4> {
    let mut fixtures = Vec::new();
    fixtures.push(RealBatch4::default());

    let mut impulses = RealBatch4::default();
    for lane in 0..LANES {
        let index = [0, 1, 30, 59][lane];
        impulses.values[index][lane] = 0.75 + lane as f32 * 0.375;
    }
    fixtures.push(impulses);

    let mut structured = RealBatch4::default();
    for index in 0..REAL_LEN {
        for lane in 0..LANES {
            let alternating = if (index + lane) & 1 == 0 { 1.0 } else { -1.0 };
            structured.values[index][lane] =
                (lane as f32 + 1.0) * 0.125 + alternating * (index as f32 + 1.0) * 0.01;
        }
    }
    fixtures.push(structured);

    let mut tones = RealBatch4::default();
    for index in 0..REAL_LEN {
        let theta = 2.0 * std::f32::consts::PI * index as f32 / REAL_LEN as f32;
        tones.values[index][0] = 1.25;
        tones.values[index][1] = (theta + 0.31).cos() * 1.1;
        tones.values[index][2] = (15.0 * theta - 0.27).sin() * 0.8;
        tones.values[index][3] = if index & 1 == 0 { 1.4 } else { -1.4 };
    }
    fixtures.push(tones);

    fixtures.push(random_batch(0x4d4f_5353_4530_3101, 1.0));
    fixtures.push(random_batch(0x4d4f_5353_4530_3102, 1.0e-3));
    fixtures.push(random_batch(0x4d4f_5353_4530_3103, 1.0e3));

    let mut chirp = RealBatch4::default();
    for index in 0..REAL_LEN {
        for lane in 0..LANES {
            let x = index as f32 + 0.37 * lane as f32;
            let angle = 0.017 * x * x + 0.13 * x + lane as f32 * 0.23;
            chirp.values[index][lane] =
                angle.cos() * (1.0 + x * 0.015) + angle.sin() * (0.35 - x * 0.002);
        }
    }
    fixtures.push(chirp);
    fixtures
}

fn random_batch(mut state: u64, scale: f32) -> RealBatch4 {
    let mut batch = RealBatch4::default();
    for index in 0..REAL_LEN {
        for lane in 0..LANES {
            state = splitmix64(state);
            batch.values[index][lane] = unit_signed(state) * scale;
        }
    }
    batch
}

fn splitmix64(mut value: u64) -> u64 {
    value = value.wrapping_add(0x9e37_79b9_7f4a_7c15);
    value = (value ^ (value >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
    value = (value ^ (value >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
    value ^ (value >> 31)
}

fn unit_signed(bits: u64) -> f32 {
    let fraction = ((bits >> 40) as u32) as f32 * (1.0 / 16_777_216.0);
    fraction * 2.0 - 1.0
}

struct TimingResult {
    median: f64,
    minimum: f64,
    maximum: f64,
    checksum: f64,
    samples: Vec<f64>,
}

fn time_forward(config: Config) -> TimingResult {
    let inputs: Vec<RealBatch4> = (0..TIMING_BLOCK)
        .map(|index| random_batch(0x031f_0000_0000_0000 + index as u64, 0.25))
        .collect();
    let mut outputs = vec![ComplexBatch4::default(); TIMING_BLOCK];
    let mut kernel = Kernel60x4::new();

    for iteration in 0..config.warmup {
        let slot = iteration % TIMING_BLOCK;
        kernel.process_forward(black_box(&inputs[slot]), black_box(&mut outputs[slot]));
    }

    measure(config, |sample, calls| {
        let started = Instant::now();
        for slot in 0..TIMING_BLOCK {
            kernel.process_forward(black_box(&inputs[slot]), black_box(&mut outputs[slot]));
        }
        let elapsed = started.elapsed();
        let probe = &outputs[(sample + calls as usize) % TIMING_BLOCK];
        let index = (sample * 7 + calls as usize) % UNIQUE_LEN;
        let checksum = f64::from(black_box(probe.re[index][sample % LANES]))
            + f64::from(black_box(probe.im[index][(sample + 1) % LANES]));
        (elapsed, checksum)
    })
}

fn time_inverse(config: Config) -> TimingResult {
    let real_inputs: Vec<RealBatch4> = (0..TIMING_BLOCK)
        .map(|index| random_batch(0x0311_0000_0000_0000 + index as u64, 0.25))
        .collect();
    let mut spectra = vec![ComplexBatch4::default(); TIMING_BLOCK];
    let mut preparation_kernel = Kernel60x4::new();
    for slot in 0..TIMING_BLOCK {
        preparation_kernel.process_forward(&real_inputs[slot], &mut spectra[slot]);
    }
    let mut outputs = vec![RealBatch4::default(); TIMING_BLOCK];
    let mut kernel = Kernel60x4::new();

    for iteration in 0..config.warmup {
        let slot = iteration % TIMING_BLOCK;
        kernel.process_inverse(black_box(&spectra[slot]), black_box(&mut outputs[slot]));
    }

    measure(config, |sample, calls| {
        let started = Instant::now();
        for slot in 0..TIMING_BLOCK {
            kernel.process_inverse(black_box(&spectra[slot]), black_box(&mut outputs[slot]));
        }
        let elapsed = started.elapsed();
        let probe = &outputs[(sample + calls as usize) % TIMING_BLOCK];
        let index = (sample * 11 + calls as usize) % REAL_LEN;
        let checksum = f64::from(black_box(probe.values[index][sample % LANES]))
            + f64::from(black_box(
                probe.values[(index + 17) % REAL_LEN][(sample + 1) % LANES],
            ));
        (elapsed, checksum)
    })
}

fn measure(config: Config, mut block: impl FnMut(usize, u64) -> (Duration, f64)) -> TimingResult {
    let target = Duration::from_millis(config.sample_ms);
    let mut samples = Vec::with_capacity(config.samples);
    let mut checksum = 0.0_f64;
    for sample in 0..config.samples {
        let mut measured = Duration::ZERO;
        let mut calls = 0_u64;
        while measured < target {
            let (elapsed, contribution) = block(sample, calls);
            measured += elapsed;
            calls += TIMING_BLOCK as u64;
            checksum += contribution;
        }
        samples.push(measured.as_secs_f64() * 1.0e9 / calls as f64);
    }
    samples.sort_by(f64::total_cmp);
    TimingResult {
        median: samples[samples.len() / 2],
        minimum: samples[0],
        maximum: samples[samples.len() - 1],
        checksum,
        samples,
    }
}

fn print_timing(direction: &str, result: &TimingResult) {
    println!(
        "direction={} median_ns_per_batch4={:.3} min_ns={:.3} max_ns={:.3} \
         transforms_per_call={} checksum={:.9e} samples_ns={:?}",
        direction,
        result.median,
        result.minimum,
        result.maximum,
        LANES,
        result.checksum,
        result.samples
    );
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn full_deterministic_correctness_gate() {
        let metrics = correctness_gate().expect("AoSoA RFFT must match both oracles");
        assert!(metrics.values >= 8 * 1_200);
        assert!(metrics.max_scaled_ratio <= 1.0);
    }
}
