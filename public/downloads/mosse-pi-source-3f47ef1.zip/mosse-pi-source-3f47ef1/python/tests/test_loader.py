from __future__ import annotations

import json

import pytest

from mosse_pi import NativeLibraryError, NativeLibraryNotFoundError
from mosse_pi._native import (
    ABI_VERSION,
    NativeBindings,
    _normalized_architecture,
    _read_build_info,
)


class _FakeFunction:
    def __init__(self, result: int = 0) -> None:
        self.result = result
        self.argtypes = None
        self.restype = None

    def __call__(self, *args) -> int:
        return self.result


class _FakeLibrary:
    def __init__(self, abi_version: int = ABI_VERSION) -> None:
        self.mosse_abi_version = _FakeFunction(abi_version)
        self.mosse_create_with_mode = _FakeFunction()
        self.mosse_init = _FakeFunction()
        self.mosse_update = _FakeFunction()
        self.mosse_get_backend_status = _FakeFunction()
        self.mosse_destroy = _FakeFunction()


@pytest.mark.parametrize("value", ["x86_64", "AMD64"])
def test_x86_architecture_aliases(value: str) -> None:
    assert _normalized_architecture(value) == "x86_64"


@pytest.mark.parametrize("value", ["aarch64", "ARM64"])
def test_arm_architecture_aliases(value: str) -> None:
    assert _normalized_architecture(value) == "aarch64"


def test_unsupported_architecture_is_explicit() -> None:
    with pytest.raises(NativeLibraryNotFoundError, match="unsupported"):
        _normalized_architecture("riscv64")


def test_optional_build_info_is_read_from_library_sibling(tmp_path) -> None:
    library = tmp_path / "libmosse_core.so"
    library.write_bytes(b"not loaded in this unit test")
    (tmp_path / "build_info.json").write_text(
        json.dumps(
            {
                "source_commit": "abc123",
                "features": ["parallel-whole-layout-60x36", "", 7],
                "rustc": "rustc 1.88.0",
                "glibc": "2.36",
                "minimum_glibc": "2.28",
                "wheel_platform": "manylinux_2_28_x86_64",
            }
        ),
        encoding="utf-8",
    )

    assert _read_build_info(library) == {
        "source_commit": "abc123",
        "package_source_commit": "abc123",
        "native_rust_tree": None,
        "native_library_supplied": False,
        "features": ("parallel-whole-layout-60x36",),
        "rustc": "rustc 1.88.0",
        "glibc": "2.36",
        "minimum_glibc": "2.28",
        "wheel_platform": "manylinux_2_28_x86_64",
    }


def test_native_build_identity_is_distinct_from_package_identity(tmp_path) -> None:
    library = tmp_path / "libmosse_core.so"
    library.write_bytes(b"not loaded in this unit test")
    (tmp_path / "build_info.json").write_text(
        json.dumps(
            {
                "source_commit": "package-commit",
                "native_source_commit": "qualified-native-commit",
                "native_rust_tree": "rust-tree",
                "native_library_supplied": True,
            }
        ),
        encoding="utf-8",
    )

    info = _read_build_info(library)
    assert info["source_commit"] == "qualified-native-commit"
    assert info["package_source_commit"] == "package-commit"
    assert info["native_rust_tree"] == "rust-tree"
    assert info["native_library_supplied"] is True


@pytest.mark.parametrize("contents", [None, "{broken", "[]"])
def test_optional_build_info_has_safe_defaults(tmp_path, contents) -> None:
    library = tmp_path / "libmosse_core.so"
    if contents is not None:
        (tmp_path / "build_info.json").write_text(contents, encoding="utf-8")
    assert _read_build_info(library) == {}


def test_native_loader_accepts_exact_abi_version(tmp_path) -> None:
    path = tmp_path / "libmosse_core.so"
    path.write_bytes(b"identity fixture")
    bindings = NativeBindings(_FakeLibrary(), path, "x86_64")
    assert bindings.info.path == str(path)
    assert bindings._abi_version.restype is not None


@pytest.mark.parametrize("actual", [0, ABI_VERSION + 1, 0xFFFFFFFF])
def test_native_loader_rejects_mismatched_abi_version(tmp_path, actual) -> None:
    path = tmp_path / "libmosse_core.so"
    path.write_bytes(b"identity fixture")
    with pytest.raises(
        NativeLibraryError,
        match=rf"expected={ABI_VERSION}, actual={actual}",
    ):
        NativeBindings(_FakeLibrary(actual), path, "x86_64")


def test_native_loader_requires_abi_symbol(tmp_path) -> None:
    path = tmp_path / "libmosse_core.so"
    path.write_bytes(b"identity fixture")
    library = _FakeLibrary()
    del library.mosse_abi_version
    with pytest.raises(NativeLibraryError, match="complete preview ABI"):
        NativeBindings(library, path, "x86_64")
