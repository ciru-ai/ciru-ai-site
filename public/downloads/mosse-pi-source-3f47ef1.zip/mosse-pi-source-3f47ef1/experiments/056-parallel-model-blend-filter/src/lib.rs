//! Experiment 056: disjoint fixed-padded MOSSE model blend/filter tasks.
//!
//! The retained 60x36 tracker stores its 31-column half spectrum as eight
//! four-lane padded batches. Model blending and filter reconstruction have no
//! dependency between spectral bins, so each task owns one complete batch:
//!
//! 1. update numerator and denominator with the production `f32` expressions;
//! 2. reload those updated values; and
//! 3. reconstruct the filter with the production divisor and fallback rules.
//!
//! Eight tasks are suitable for the existing static modulo-four executor:
//! task `i` owns batch `i`, so every lane processes two batches without
//! mutable aliasing. This crate intentionally uses scalar per-lane
//! [`Complex32`] operations. It exposes no reduction or cross-task combine.

use mosse_exp028_aosoa_cfft36::Batch4 as ColumnBatch4;
pub use mosse_exp034_whole_layout_fft2::PaddedSpectrum;
use mosse_exp034_whole_layout_fft2::{COLUMN_BATCHES, HEIGHT, LANES, PADDED_SPECTRUM_WIDTH, WIDTH};
use rustfft::num_complex::Complex32;

pub const BATCH_TASK_COUNT: usize = COLUMN_BATCHES;
pub const PADDED_WIDTH: usize = PADDED_SPECTRUM_WIDTH;
pub const SPECTRUM_HEIGHT: usize = HEIGHT;
pub const SPECTRUM_LANES: usize = LANES;

const _: () = {
    assert!(WIDTH == 60);
    assert!(HEIGHT == 36);
    assert!(LANES == 4);
    assert!(COLUMN_BATCHES == 8);
    assert!(PADDED_SPECTRUM_WIDTH == 32);
};

/// One disjoint padded-spectrum model blend and filter task.
///
/// The tracker validates its learning rate before converting it to `f32`.
/// This low-level experiment deliberately accepts that already-validated
/// value without applying a different policy.
#[derive(Debug)]
pub struct BlendFilterBatchTask<'inputs, 'state> {
    goal: &'inputs ColumnBatch4,
    sample: &'inputs ColumnBatch4,
    numerator: &'state mut ColumnBatch4,
    denominator: &'state mut ColumnBatch4,
    filter: &'state mut ColumnBatch4,
    rate: f32,
    keep: f32,
    batch: usize,
}

impl BlendFilterBatchTask<'_, '_> {
    /// Update every bin in this task's batch exactly once.
    #[inline]
    pub fn run(&mut self) {
        for ky in 0..HEIGHT {
            for lane in 0..LANES {
                let sample = batch_value(self.sample, ky, lane);
                let goal = batch_value(self.goal, ky, lane);
                let numerator_new = goal * sample.conj();
                let denominator_new = sample * sample.conj();
                let numerator = batch_value(self.numerator, ky, lane);
                let denominator = batch_value(self.denominator, ky, lane);

                batch_store(
                    self.numerator,
                    ky,
                    lane,
                    numerator * self.keep + numerator_new * self.rate,
                );
                batch_store(
                    self.denominator,
                    ky,
                    lane,
                    denominator * self.keep + denominator_new * self.rate,
                );

                // Match the production composition's second pass by reloading
                // the values that were just published to persistent state.
                let lhs = batch_value(self.numerator, ky, lane);
                let rhs = batch_value(self.denominator, ky, lane);
                let divisor = rhs.re * rhs.re + rhs.im * rhs.im;
                let value = if divisor > 0.0 && divisor.is_finite() {
                    Complex32::new(
                        (lhs.re * rhs.re + lhs.im * rhs.im) / divisor,
                        -(lhs.im * rhs.re + lhs.re * rhs.im) / divisor,
                    )
                } else {
                    Complex32::new(0.0, 0.0)
                };
                batch_store(self.filter, ky, lane, value);
            }
        }
    }

    pub const fn batch(&self) -> usize {
        self.batch
    }
}

/// Bind eight non-aliasing model tasks without allocation.
///
/// With the retained runtime's static assignment, tasks `0` and `4` run on
/// lane zero, `1` and `5` on lane one, and so forth.
pub fn bind_blend_filter_batches<'inputs, 'state>(
    goal: &'inputs PaddedSpectrum,
    sample: &'inputs PaddedSpectrum,
    numerator: &'state mut PaddedSpectrum,
    denominator: &'state mut PaddedSpectrum,
    filter: &'state mut PaddedSpectrum,
    rate: f32,
) -> [BlendFilterBatchTask<'inputs, 'state>; BATCH_TASK_COUNT] {
    let keep = 1.0 - rate;
    let goal_batches = goal.batches.each_ref();
    let sample_batches = sample.batches.each_ref();
    let numerator_batches = numerator.batches.each_mut();
    let denominator_batches = denominator.batches.each_mut();
    let filter_batches = filter.batches.each_mut();
    let mut batches = goal_batches
        .into_iter()
        .zip(sample_batches)
        .zip(numerator_batches)
        .zip(denominator_batches)
        .zip(filter_batches);

    std::array::from_fn(|batch| {
        let ((((goal, sample), numerator), denominator), filter) =
            batches.next().expect("fixed model batch count");
        BlendFilterBatchTask {
            goal,
            sample,
            numerator,
            denominator,
            filter,
            rate,
            keep,
            batch,
        }
    })
}

#[inline(always)]
fn batch_value(batch: &ColumnBatch4, ky: usize, lane: usize) -> Complex32 {
    Complex32::new(batch.re[ky][lane], batch.im[ky][lane])
}

#[inline(always)]
fn batch_store(batch: &mut ColumnBatch4, ky: usize, lane: usize, value: Complex32) {
    batch.re[ky][lane] = value.re;
    batch.im[ky][lane] = value.im;
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::thread;

    const DEFAULT_RATE: f32 = 0.2;

    #[derive(Clone, Copy)]
    struct Lcg(u64);

    impl Lcg {
        fn new(seed: u64) -> Self {
            Self(seed)
        }

        fn next_u32(&mut self) -> u32 {
            self.0 = self
                .0
                .wrapping_mul(6_364_136_223_846_793_005)
                .wrapping_add(1_442_695_040_888_963_407);
            (self.0 >> 32) as u32
        }

        fn bounded_f32(&mut self, scale: f32) -> f32 {
            let fraction = (self.next_u32() >> 8) as f32 * (1.0 / 16_777_216.0);
            (fraction * 2.0 - 1.0) * scale
        }
    }

    #[test]
    fn randomized_modulo_four_tasks_match_production_serial_composition() {
        for case in 0..32u64 {
            let goal = random_spectrum(0x5601_0000_0000_0000 ^ case, 3.0);
            let sample = random_spectrum(0x5602_0000_0000_0000 ^ case, 2.0);
            let numerator_seed = random_spectrum(0x5603_0000_0000_0000 ^ case, 5.0);
            let denominator_seed = random_spectrum(0x5604_0000_0000_0000 ^ case, 1.5);
            let mut expected_numerator = numerator_seed.clone();
            let mut expected_denominator = denominator_seed.clone();
            let mut expected_filter = PaddedSpectrum::default();
            let mut actual_numerator = numerator_seed;
            let mut actual_denominator = denominator_seed;
            let mut actual_filter = PaddedSpectrum::default();
            actual_filter.poison_all(0xa560_0000 ^ case as u32);

            serial_production_composition(
                &goal,
                &sample,
                &mut expected_numerator,
                &mut expected_denominator,
                &mut expected_filter,
                DEFAULT_RATE,
            );
            let mut tasks = bind_blend_filter_batches(
                &goal,
                &sample,
                &mut actual_numerator,
                &mut actual_denominator,
                &mut actual_filter,
                DEFAULT_RATE,
            );
            assert_eq!(
                std::array::from_fn(|index| tasks[index].batch()),
                [0, 1, 2, 3, 4, 5, 6, 7]
            );
            run_static_modulo_four(&mut tasks);

            assert_spectrum_bits(
                &actual_numerator,
                &expected_numerator,
                &format!("case={case} numerator"),
            );
            assert_spectrum_bits(
                &actual_denominator,
                &expected_denominator,
                &format!("case={case} denominator"),
            );
            assert_spectrum_bits(
                &actual_filter,
                &expected_filter,
                &format!("case={case} filter"),
            );
        }
    }

    #[test]
    fn validated_edge_rates_match_production_serial_composition() {
        let rates = [
            -0.0,
            0.0,
            f32::MIN_POSITIVE,
            DEFAULT_RATE,
            f32::from_bits(1.0f32.to_bits() - 1),
            1.0,
        ];
        let goal = random_spectrum(0x56e1_1800_dead_beef, 7.0);
        let sample = random_spectrum(0x56e2_1800_cafe_babe, 0.75);
        let numerator_seed = random_spectrum(0x56e3_1800_fade_feed, 11.0);
        let denominator_seed = random_spectrum(0x56e4_1800_f00d_f00d, 2.0);

        for rate in rates {
            compare_task_and_serial(
                &goal,
                &sample,
                &numerator_seed,
                &denominator_seed,
                rate,
                &format!("rate_bits=0x{:08x}", rate.to_bits()),
            );
        }
    }

    #[test]
    fn signed_zero_nan_and_infinity_bins_match_every_mutated_bit() {
        let mut goal = random_spectrum(0x56a1_0bad_dead_beef, 1.0);
        let mut sample = random_spectrum(0x56a2_0bad_cafe_babe, 1.0);
        let mut numerator = random_spectrum(0x56a3_0bad_fade_feed, 1.0);
        let mut denominator = random_spectrum(0x56a4_0bad_f00d_f00d, 1.0);

        set_bin(
            &mut sample,
            0,
            0,
            Complex32::new(0.0, f32::from_bits(0x8000_0000)),
        );
        set_bin(
            &mut goal,
            3,
            7,
            Complex32::new(f32::from_bits(0x8000_0000), 0.0),
        );
        set_bin(
            &mut numerator,
            17,
            23,
            Complex32::new(f32::from_bits(0x7fc1_2345), f32::from_bits(0xffc2_3456)),
        );
        set_bin(
            &mut denominator,
            21,
            11,
            Complex32::new(f32::INFINITY, f32::NEG_INFINITY),
        );
        set_bin(
            &mut sample,
            27,
            31,
            Complex32::new(f32::from_bits(0x7fc3_4567), -0.0),
        );
        set_bin(
            &mut goal,
            30,
            35,
            Complex32::new(f32::NEG_INFINITY, f32::from_bits(0x7fc4_5678)),
        );

        for rate in [0.0, DEFAULT_RATE, 1.0] {
            compare_task_and_serial(
                &goal,
                &sample,
                &numerator,
                &denominator,
                rate,
                &format!("special rate_bits=0x{:08x}", rate.to_bits()),
            );
        }
    }

    #[test]
    fn poisoned_filter_storage_is_fully_overwritten() {
        let goal = random_spectrum(0x56b1_0000_dead_beef, 2.0);
        let sample = random_spectrum(0x56b2_0000_cafe_babe, 2.0);
        let numerator_seed = random_spectrum(0x56b3_0000_fade_feed, 3.0);
        let denominator_seed = random_spectrum(0x56b4_0000_f00d_f00d, 3.0);
        let mut expected_numerator = numerator_seed.clone();
        let mut expected_denominator = denominator_seed.clone();
        let mut expected_filter = PaddedSpectrum::default();
        let mut actual_numerator = numerator_seed;
        let mut actual_denominator = denominator_seed;
        let mut actual_filter = PaddedSpectrum::default();
        actual_filter.poison_all(0x56ff_a5a5);

        serial_production_composition(
            &goal,
            &sample,
            &mut expected_numerator,
            &mut expected_denominator,
            &mut expected_filter,
            DEFAULT_RATE,
        );
        let mut tasks = bind_blend_filter_batches(
            &goal,
            &sample,
            &mut actual_numerator,
            &mut actual_denominator,
            &mut actual_filter,
            DEFAULT_RATE,
        );
        for task in &mut tasks {
            task.run();
        }

        assert_spectrum_bits(&actual_numerator, &expected_numerator, "poison numerator");
        assert_spectrum_bits(
            &actual_denominator,
            &expected_denominator,
            "poison denominator",
        );
        assert_spectrum_bits(&actual_filter, &expected_filter, "poison filter");
        assert!(actual_filter
            .batches
            .iter()
            .flat_map(|batch| batch.re.iter().chain(&batch.im))
            .flatten()
            .all(|value| !value.is_nan()));
    }

    #[test]
    fn valid_positive_zero_padding_remains_positive_zero_at_all_edge_rates() {
        let rates = [
            -0.0,
            0.0,
            f32::MIN_POSITIVE,
            DEFAULT_RATE,
            f32::from_bits(1.0f32.to_bits() - 1),
            1.0,
        ];
        let mut goal = random_spectrum(0x56c1_0000_dead_beef, 2.0);
        let mut sample = random_spectrum(0x56c2_0000_cafe_babe, 2.0);
        let mut numerator_seed = random_spectrum(0x56c3_0000_fade_feed, 2.0);
        let mut denominator_seed = random_spectrum(0x56c4_0000_f00d_f00d, 2.0);
        for spectrum in [
            &mut goal,
            &mut sample,
            &mut numerator_seed,
            &mut denominator_seed,
        ] {
            clear_padding(spectrum);
            assert!(spectrum.padding_is_positive_zero());
        }

        for rate in rates {
            let mut numerator = numerator_seed.clone();
            let mut denominator = denominator_seed.clone();
            let mut filter = PaddedSpectrum::default();
            filter.poison_all(0x56cc_0000 ^ rate.to_bits());
            let mut tasks = bind_blend_filter_batches(
                &goal,
                &sample,
                &mut numerator,
                &mut denominator,
                &mut filter,
                rate,
            );
            run_static_modulo_four(&mut tasks);

            assert!(
                numerator.padding_is_positive_zero(),
                "numerator padding changed at rate_bits=0x{:08x}",
                rate.to_bits()
            );
            assert!(
                denominator.padding_is_positive_zero(),
                "denominator padding changed at rate_bits=0x{:08x}",
                rate.to_bits()
            );
            assert!(
                filter.padding_is_positive_zero(),
                "filter padding changed at rate_bits=0x{:08x}",
                rate.to_bits()
            );
        }
    }

    #[test]
    fn task_type_is_send_for_scoped_runtime_publication() {
        fn assert_send<T: Send>() {}
        assert_send::<BlendFilterBatchTask<'static, 'static>>();
    }

    fn compare_task_and_serial(
        goal: &PaddedSpectrum,
        sample: &PaddedSpectrum,
        numerator_seed: &PaddedSpectrum,
        denominator_seed: &PaddedSpectrum,
        rate: f32,
        context: &str,
    ) {
        let mut expected_numerator = numerator_seed.clone();
        let mut expected_denominator = denominator_seed.clone();
        let mut expected_filter = PaddedSpectrum::default();
        expected_filter.poison_all(0x5611_a5a5 ^ rate.to_bits());
        let mut actual_numerator = numerator_seed.clone();
        let mut actual_denominator = denominator_seed.clone();
        let mut actual_filter = PaddedSpectrum::default();
        actual_filter.poison_all(0x5622_5a5a ^ rate.to_bits());

        serial_production_composition(
            goal,
            sample,
            &mut expected_numerator,
            &mut expected_denominator,
            &mut expected_filter,
            rate,
        );
        let mut tasks = bind_blend_filter_batches(
            goal,
            sample,
            &mut actual_numerator,
            &mut actual_denominator,
            &mut actual_filter,
            rate,
        );
        run_static_modulo_four(&mut tasks);

        assert_spectrum_bits(
            &actual_numerator,
            &expected_numerator,
            &format!("{context} numerator"),
        );
        assert_spectrum_bits(
            &actual_denominator,
            &expected_denominator,
            &format!("{context} denominator"),
        );
        assert_spectrum_bits(
            &actual_filter,
            &expected_filter,
            &format!("{context} filter"),
        );
    }

    fn serial_production_composition(
        goal: &PaddedSpectrum,
        sample: &PaddedSpectrum,
        numerator: &mut PaddedSpectrum,
        denominator: &mut PaddedSpectrum,
        filter: &mut PaddedSpectrum,
        rate: f32,
    ) {
        let keep = 1.0 - rate;
        for batch in 0..COLUMN_BATCHES {
            for ky in 0..HEIGHT {
                for lane in 0..LANES {
                    let sample_value = spectrum_value(sample, batch, ky, lane);
                    let goal_value = spectrum_value(goal, batch, ky, lane);
                    let numerator_new = goal_value * sample_value.conj();
                    let denominator_new = sample_value * sample_value.conj();
                    let numerator_value = spectrum_value(numerator, batch, ky, lane);
                    let denominator_value = spectrum_value(denominator, batch, ky, lane);
                    spectrum_store(
                        numerator,
                        batch,
                        ky,
                        lane,
                        numerator_value * keep + numerator_new * rate,
                    );
                    spectrum_store(
                        denominator,
                        batch,
                        ky,
                        lane,
                        denominator_value * keep + denominator_new * rate,
                    );
                }
            }
        }

        for batch in 0..COLUMN_BATCHES {
            for ky in 0..HEIGHT {
                for lane in 0..LANES {
                    let lhs = spectrum_value(numerator, batch, ky, lane);
                    let rhs = spectrum_value(denominator, batch, ky, lane);
                    let divisor = rhs.re * rhs.re + rhs.im * rhs.im;
                    let value = if divisor > 0.0 && divisor.is_finite() {
                        Complex32::new(
                            (lhs.re * rhs.re + lhs.im * rhs.im) / divisor,
                            -(lhs.im * rhs.re + lhs.re * rhs.im) / divisor,
                        )
                    } else {
                        Complex32::new(0.0, 0.0)
                    };
                    spectrum_store(filter, batch, ky, lane, value);
                }
            }
        }
    }

    fn run_static_modulo_four(tasks: &mut [BlendFilterBatchTask<'_, '_>; BATCH_TASK_COUNT]) {
        let (first_round, second_round) = tasks.split_at_mut(4);
        thread::scope(|scope| {
            for (first, second) in first_round.iter_mut().zip(second_round) {
                scope.spawn(move || {
                    first.run();
                    second.run();
                });
            }
        });
    }

    fn random_spectrum(seed: u64, scale: f32) -> PaddedSpectrum {
        let mut rng = Lcg::new(seed);
        let mut spectrum = PaddedSpectrum::default();
        for batch in 0..COLUMN_BATCHES {
            for ky in 0..HEIGHT {
                for lane in 0..LANES {
                    spectrum.batches[batch].re[ky][lane] = rng.bounded_f32(scale);
                    spectrum.batches[batch].im[ky][lane] = rng.bounded_f32(scale);
                }
            }
        }
        spectrum
    }

    fn clear_padding(spectrum: &mut PaddedSpectrum) {
        let last = COLUMN_BATCHES - 1;
        let padding = LANES - 1;
        for ky in 0..HEIGHT {
            spectrum.batches[last].re[ky][padding] = 0.0;
            spectrum.batches[last].im[ky][padding] = 0.0;
        }
    }

    fn set_bin(spectrum: &mut PaddedSpectrum, kx: usize, ky: usize, value: Complex32) {
        assert!(kx < PADDED_SPECTRUM_WIDTH);
        assert!(ky < HEIGHT);
        let batch = kx / LANES;
        let lane = kx % LANES;
        spectrum.batches[batch].re[ky][lane] = value.re;
        spectrum.batches[batch].im[ky][lane] = value.im;
    }

    fn spectrum_value(
        spectrum: &PaddedSpectrum,
        batch: usize,
        ky: usize,
        lane: usize,
    ) -> Complex32 {
        Complex32::new(
            spectrum.batches[batch].re[ky][lane],
            spectrum.batches[batch].im[ky][lane],
        )
    }

    fn spectrum_store(
        spectrum: &mut PaddedSpectrum,
        batch: usize,
        ky: usize,
        lane: usize,
        value: Complex32,
    ) {
        spectrum.batches[batch].re[ky][lane] = value.re;
        spectrum.batches[batch].im[ky][lane] = value.im;
    }

    fn assert_spectrum_bits(actual: &PaddedSpectrum, expected: &PaddedSpectrum, context: &str) {
        for batch in 0..COLUMN_BATCHES {
            for ky in 0..HEIGHT {
                for lane in 0..LANES {
                    for (component, actual, expected) in [
                        (
                            "re",
                            actual.batches[batch].re[ky][lane],
                            expected.batches[batch].re[ky][lane],
                        ),
                        (
                            "im",
                            actual.batches[batch].im[ky][lane],
                            expected.batches[batch].im[ky][lane],
                        ),
                    ] {
                        assert_eq!(
                            actual.to_bits(),
                            expected.to_bits(),
                            "{context}: batch={batch} ky={ky} lane={lane} \
                             component={component} actual={actual:?} expected={expected:?}"
                        );
                    }
                }
            }
        }
    }
}
