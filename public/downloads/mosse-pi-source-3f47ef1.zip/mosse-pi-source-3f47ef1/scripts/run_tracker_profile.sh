#!/usr/bin/env bash
#
# Profile repeated tracker updates over an in-memory decoded frame cache.
# This diagnostic never writes official scoring artifacts.

set -euo pipefail

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
repo_root="$(cd -- "${script_dir}/.." && pwd -P)"

benchmark="${repo_root}/build/release/mosse_tracker_replay"
config="${repo_root}/config/benchmark.yml"
output_root="${repo_root}/results/pi4-profiling"
run_id=""
cached_frames=300
repetitions=50
warmups=1
max_cache_mib=512
opencv_threads=1
cpu=0
frequency=999

usage() {
    cat <<'EOF'
Usage: run_tracker_profile.sh --run-id ID [options]

Runs perf over the diagnostic tracker-only replay executable. Frames are
decoded once and then replayed from memory with a fresh tracker per pass.
Nothing produced by this script is an official scoring result.

Options:
  --run-id ID              Required safe output-directory name
  --benchmark PATH         Replay executable
  --config PATH            Benchmark config
  --output-root PATH       Artifact parent directory
  --cached-frames COUNT    Cached frames including frame 0 (default: 300)
  --repetitions COUNT      Measured replays (default: 50)
  --warmups COUNT          Untimed replays (default: 1)
  --max-cache-mib COUNT    Decoded-cache memory limit (default: 512)
  --opencv-threads COUNT   OpenCV thread count (default: 1)
  --cpu COUNT              CPU affinity (default: 0)
  --frequency COUNT        perf sampling frequency (default: 999)
  --help                   Show this help
EOF
}

require_value() {
    local option="$1"
    local value="${2:-}"
    if [[ -z "$value" ]]; then
        echo "error: missing value after ${option}" >&2
        exit 2
    fi
}

require_positive_integer() {
    local option="$1"
    local value="$2"
    if [[ ! "$value" =~ ^[1-9][0-9]*$ ]]; then
        echo "error: ${option} must be a positive integer" >&2
        exit 2
    fi
}

while (($# > 0)); do
    case "$1" in
        --run-id)
            require_value "$1" "${2:-}"
            run_id="$2"
            shift 2
            ;;
        --benchmark)
            require_value "$1" "${2:-}"
            benchmark="$2"
            shift 2
            ;;
        --config)
            require_value "$1" "${2:-}"
            config="$2"
            shift 2
            ;;
        --output-root)
            require_value "$1" "${2:-}"
            output_root="$2"
            shift 2
            ;;
        --cached-frames)
            require_value "$1" "${2:-}"
            cached_frames="$2"
            shift 2
            ;;
        --repetitions)
            require_value "$1" "${2:-}"
            repetitions="$2"
            shift 2
            ;;
        --warmups)
            require_value "$1" "${2:-}"
            warmups="$2"
            shift 2
            ;;
        --max-cache-mib)
            require_value "$1" "${2:-}"
            max_cache_mib="$2"
            shift 2
            ;;
        --opencv-threads)
            require_value "$1" "${2:-}"
            opencv_threads="$2"
            shift 2
            ;;
        --cpu)
            require_value "$1" "${2:-}"
            cpu="$2"
            shift 2
            ;;
        --frequency)
            require_value "$1" "${2:-}"
            frequency="$2"
            shift 2
            ;;
        --help|-h)
            usage
            exit 0
            ;;
        *)
            echo "error: unknown option: $1" >&2
            usage >&2
            exit 2
            ;;
    esac
done

if [[ -z "$run_id" ]]; then
    echo "error: --run-id is required" >&2
    exit 2
fi
if [[ ! "$run_id" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]]; then
    echo "error: --run-id contains unsafe characters" >&2
    exit 2
fi
require_positive_integer --cached-frames "$cached_frames"
require_positive_integer --repetitions "$repetitions"
if [[ ! "$warmups" =~ ^[0-9]+$ ]]; then
    echo "error: --warmups must be a non-negative integer" >&2
    exit 2
fi
require_positive_integer --max-cache-mib "$max_cache_mib"
if [[ ! "$opencv_threads" =~ ^-?[0-9]+$ ]]; then
    echo "error: --opencv-threads must be an integer" >&2
    exit 2
fi
if [[ ! "$cpu" =~ ^[0-9]+$ ]]; then
    echo "error: --cpu must be a non-negative integer" >&2
    exit 2
fi
require_positive_integer --frequency "$frequency"

for required_command in perf taskset git; do
    if ! command -v "$required_command" >/dev/null 2>&1; then
        echo "error: required command is unavailable: ${required_command}" >&2
        exit 1
    fi
done
if [[ ! -x "$benchmark" ]]; then
    echo "error: replay executable is unavailable: ${benchmark}" >&2
    exit 1
fi
if [[ ! -f "$config" ]]; then
    echo "error: benchmark config is unavailable: ${config}" >&2
    exit 1
fi

output_directory="${output_root}/${run_id}"
if [[ -e "$output_directory" ]]; then
    echo "error: output directory already exists: ${output_directory}" >&2
    exit 1
fi
mkdir -p "$output_directory"

perf_data="${output_directory}/perf.data"
replay_log="${output_directory}/replay.log"
report="${output_directory}/perf-report.txt"
tracker_report="${output_directory}/tracker-symbols.txt"
phase_summary="${output_directory}/phase-summary.txt"
metadata="${output_directory}/metadata.txt"

{
    printf 'diagnostic_only=1\n'
    printf 'repository=%s\n' "$repo_root"
    printf 'commit=%s\n' "$(git -C "$repo_root" rev-parse HEAD)"
    printf 'benchmark=%s\n' "$benchmark"
    printf 'config=%s\n' "$config"
    printf 'cached_frames=%s\n' "$cached_frames"
    printf 'repetitions=%s\n' "$repetitions"
    printf 'warmups=%s\n' "$warmups"
    printf 'max_cache_mib=%s\n' "$max_cache_mib"
    printf 'opencv_threads=%s\n' "$opencv_threads"
    printf 'cpu=%s\n' "$cpu"
    printf 'frequency=%s\n' "$frequency"
    printf 'started_utc=%s\n' "$(date --utc +%Y-%m-%dT%H:%M:%SZ)"
} >"$metadata"

replay_command=(
    "$benchmark"
    --config "$config"
    --tracker rust
    --cached-frames "$cached_frames"
    --repetitions "$repetitions"
    --warmups "$warmups"
    --max-cache-mib "$max_cache_mib"
    --opencv-threads "$opencv_threads"
)

taskset --cpu-list "$cpu" \
    perf record \
    -q \
    -e cycles:u \
    -F "$frequency" \
    -g \
    --call-graph dwarf,4096 \
    -o "$perf_data" \
    -- "${replay_command[@]}" |
    tee "$replay_log"

perf report \
    -i "$perf_data" \
    --stdio \
    --children \
    -g none \
    --sort dso,symbol \
    --percent-limit 0.01 \
    >"$report"

grep -E \
    'mosse_tracker_replay.*(mosse_core|rustfft|RustMosseBackend|TrackerBackend)' \
    "$report" >"$tracker_report" || true

extract_percentages() {
    local pattern="$1"
    local line
    line="$(grep -F -m 1 "$pattern" "$tracker_report" || true)"
    if [[ -z "$line" ]]; then
        printf '0 0\n'
        return
    fi
    awk '{
        children=$1
        self=$2
        gsub(/%/, "", children)
        gsub(/%/, "", self)
        printf "%s %s\n", children, self
    }' <<<"$line"
}

read -r update_children update_self < <(
    extract_percentages 'mosse_core::tracker::MosseTracker::update'
)

{
    printf 'diagnostic_only=1\n'
    printf 'basis=perf cycles:u sampled replay\n'
    printf 'update_inclusive_process_percent=%s\n' "$update_children"
    printf 'update_self_process_percent=%s\n' "$update_self"
    printf '\n'
    printf '%-30s %12s %12s %16s\n' \
        phase inclusive self inclusive_of_update
    for phase_spec in \
        'prepare_hot|mosse_core::tracker::Workspace::prepare_hot_spectrum' \
        'inverse_real|mosse_core::fft2::Fft2::inverse_real_reduced' \
        'forward_real|mosse_core::fft2::Fft2::forward_real' \
        'rustfft_mixed|rustfft::algorithm::mixed_radix::MixedRadixSmall<T> as rustfft::Fft<T>>::process_with_scratch' \
        'rustfft_good_thomas|rustfft::algorithm::good_thomas_algorithm::GoodThomasAlgorithmSmall<T> as rustfft::Fft<T>>::process_outofplace_with_scratch'
    do
        phase_name="${phase_spec%%|*}"
        phase_pattern="${phase_spec#*|}"
        read -r phase_children phase_self < <(
            extract_percentages "$phase_pattern"
        )
        phase_of_update="$(
            awk -v phase="$phase_children" -v update="$update_children" \
                'BEGIN {
                    if (update == 0) {
                        printf "0.00%%"
                    } else {
                        printf "%.2f%%", phase * 100.0 / update
                    }
                }'
        )"
        printf '%-30s %11s%% %11s%% %16s\n' \
            "$phase_name" "$phase_children" "$phase_self" "$phase_of_update"
    done
    printf '\n'
    printf '%s\n' \
        'Rows overlap through call relationships and must not be summed.'
} >"$phase_summary"

printf 'completed_utc=%s\n' \
    "$(date --utc +%Y-%m-%dT%H:%M:%SZ)" >>"$metadata"

echo "Tracker profile complete: ${output_directory}"
echo "Replay log: ${replay_log}"
echo "Tracker symbols: ${tracker_report}"
echo "Phase summary: ${phase_summary}"
