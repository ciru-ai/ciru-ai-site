//! C-compatible wrapper around [`crate::MosseTracker`].
//!
//! Calls using the same handle must never overlap, including diagnostics and destruction.
//! If initialization selects [`MosseBackendStatus::FixedMulticore`], every subsequent update,
//! query, and destruction call must run on the same OS thread that initialized the handle.
//! Other backends have no thread-affinity requirement beyond non-overlap. Frame pointers must
//! remain immutable for the duration of a call and address one live, contiguous allocation
//! containing at least `stride * (height - 1) + width * 3` initialized bytes. This includes
//! every padding byte spanned between active rows.

use std::{
    panic::{catch_unwind, AssertUnwindSafe},
    ptr, slice,
};

use crate::{
    BgrFrame, Diagnostics, MosseConfig, MosseTracker, Rect, TrackerBackendStatus, TrackerError,
    TrackerMode,
};

pub const MOSSE_ABI_VERSION: u32 = 1;

#[repr(i32)]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum MosseStatus {
    Ok = 0,
    NullPointer = -1,
    InvalidConfig = -2,
    InvalidFrame = -3,
    InvalidBoundingBox = -4,
    WindowTooLarge = -5,
    NotInitialized = -6,
    InvalidMode = -7,
    Panic = -127,
}

#[repr(i32)]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum MosseMode {
    Auto = 0,
    Single = 1,
    Multicore = 2,
}

impl TryFrom<i32> for MosseMode {
    type Error = MosseStatus;

    fn try_from(value: i32) -> Result<Self, Self::Error> {
        match value {
            value if value == Self::Auto as i32 => Ok(Self::Auto),
            value if value == Self::Single as i32 => Ok(Self::Single),
            value if value == Self::Multicore as i32 => Ok(Self::Multicore),
            _ => Err(MosseStatus::InvalidMode),
        }
    }
}

impl From<MosseMode> for TrackerMode {
    fn from(mode: MosseMode) -> Self {
        match mode {
            MosseMode::Auto => Self::Auto,
            MosseMode::Single => Self::Single,
            MosseMode::Multicore => Self::Multicore,
        }
    }
}

#[repr(i32)]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum MosseBackendStatus {
    Uninitialized = 0,
    GenericSingle = 1,
    FixedSingle = 2,
    FixedMulticore = 3,
}

impl From<TrackerBackendStatus> for MosseBackendStatus {
    fn from(status: TrackerBackendStatus) -> Self {
        match status {
            TrackerBackendStatus::Uninitialized => Self::Uninitialized,
            TrackerBackendStatus::GenericSingleThread => Self::GenericSingle,
            TrackerBackendStatus::FixedPaddedSingleThread => Self::FixedSingle,
            TrackerBackendStatus::FixedPaddedFourCore => Self::FixedMulticore,
        }
    }
}

pub struct MosseHandle {
    tracker: MosseTracker,
}

fn tracker_error_status(error: TrackerError) -> MosseStatus {
    match error {
        TrackerError::InvalidConfig => MosseStatus::InvalidConfig,
        TrackerError::InvalidFrame => MosseStatus::InvalidFrame,
        TrackerError::InvalidBoundingBox => MosseStatus::InvalidBoundingBox,
        TrackerError::WindowTooLarge => MosseStatus::WindowTooLarge,
        TrackerError::NotInitialized => MosseStatus::NotInitialized,
    }
}

fn ffi_boundary(function: impl FnOnce() -> Result<(), MosseStatus>) -> MosseStatus {
    match catch_unwind(AssertUnwindSafe(function)) {
        Ok(Ok(())) => MosseStatus::Ok,
        Ok(Err(status)) => status,
        Err(_) => MosseStatus::Panic,
    }
}

unsafe fn frame_from_raw<'a>(
    data: *const u8,
    width: usize,
    height: usize,
    stride: usize,
) -> Result<BgrFrame<'a>, MosseStatus> {
    if data.is_null() {
        return Err(MosseStatus::NullPointer);
    }
    let row_bytes = width.checked_mul(3).ok_or(MosseStatus::InvalidFrame)?;
    if width == 0 || height == 0 || stride < row_bytes {
        return Err(MosseStatus::InvalidFrame);
    }
    let storage_len = stride
        .checked_mul(height - 1)
        .and_then(|prefix| prefix.checked_add(row_bytes))
        .ok_or(MosseStatus::InvalidFrame)?;
    if storage_len > isize::MAX as usize {
        return Err(MosseStatus::InvalidFrame);
    }
    // SAFETY: The C API contract requires `data` to reference `storage_len` readable bytes.
    let storage = unsafe { slice::from_raw_parts(data, storage_len) };
    BgrFrame::new(storage, width, height, stride).map_err(tracker_error_status)
}

/// Returns the C ABI version implemented by this library.
///
/// This function is infallible and does not access tracker state.
#[no_mangle]
pub extern "C" fn mosse_abi_version() -> u32 {
    MOSSE_ABI_VERSION
}

/// Writes the default OpenCV-compatible scalar configuration.
///
/// # Safety
///
/// `output` must be non-null, properly aligned, and writable for one
/// [`MosseConfig`].
#[no_mangle]
pub unsafe extern "C" fn mosse_default_config(output: *mut MosseConfig) -> MosseStatus {
    if output.is_null() {
        return MosseStatus::NullPointer;
    }
    ffi_boundary(|| {
        // SAFETY: Non-null output storage is guaranteed by the caller.
        unsafe { output.write(MosseConfig::default()) };
        Ok(())
    })
}

/// Allocates a tracker. A null `config` selects [`MosseConfig::default`].
///
/// # Safety
///
/// A non-null `config` must point to one readable [`MosseConfig`].
/// `output_handle` must be non-null, properly aligned, and writable for one pointer.
#[no_mangle]
pub unsafe extern "C" fn mosse_create(
    config: *const MosseConfig,
    output_handle: *mut *mut MosseHandle,
) -> MosseStatus {
    if output_handle.is_null() {
        return MosseStatus::NullPointer;
    }
    // Leave a deterministic null output on any recoverable error.
    // SAFETY: Non-null output storage is guaranteed by the caller.
    unsafe { output_handle.write(ptr::null_mut()) };
    ffi_boundary(|| {
        let config = if config.is_null() {
            MosseConfig::default()
        } else {
            // SAFETY: A non-null config pointer must reference one readable MosseConfig.
            unsafe { config.read() }
        };
        let tracker = MosseTracker::new(config).map_err(tracker_error_status)?;
        let handle = Box::into_raw(Box::new(MosseHandle { tracker }));
        // SAFETY: Non-null output storage was checked before entering the boundary.
        unsafe { output_handle.write(handle) };
        Ok(())
    })
}

/// Allocates a tracker with an explicit per-handle execution mode.
///
/// Unlike [`mosse_create`], this function never reads or modifies
/// `MOSSE_RUST_CORES`. A null `config` selects [`MosseConfig::default`].
///
/// # Safety
///
/// A non-null `config` must point to one readable [`MosseConfig`].
/// `output_handle` must be non-null, properly aligned, and writable for one pointer.
#[no_mangle]
pub unsafe extern "C" fn mosse_create_with_mode(
    config: *const MosseConfig,
    mode: i32,
    output_handle: *mut *mut MosseHandle,
) -> MosseStatus {
    if output_handle.is_null() {
        return MosseStatus::NullPointer;
    }
    // Leave a deterministic null output on any recoverable error.
    // SAFETY: Non-null output storage is guaranteed by the caller.
    unsafe { output_handle.write(ptr::null_mut()) };
    ffi_boundary(|| {
        let mode = MosseMode::try_from(mode)?;
        let config = if config.is_null() {
            MosseConfig::default()
        } else {
            // SAFETY: A non-null config pointer must reference one readable MosseConfig.
            unsafe { config.read() }
        };
        let tracker =
            MosseTracker::new_with_mode(config, mode.into()).map_err(tracker_error_status)?;
        let handle = Box::into_raw(Box::new(MosseHandle { tracker }));
        // SAFETY: Non-null output storage was checked before entering the boundary.
        unsafe { output_handle.write(handle) };
        Ok(())
    })
}

/// Initializes from a BGR8 frame and an initial rectangle.
///
/// # Safety
///
/// `handle` must be a live handle returned by [`mosse_create`] and must be exclusively
/// accessed for the duration of the call. `bgr_data` must point to at least
/// `stride * (height - 1) + width * 3` readable bytes.
#[no_mangle]
pub unsafe extern "C" fn mosse_init(
    handle: *mut MosseHandle,
    bgr_data: *const u8,
    width: usize,
    height: usize,
    stride: usize,
    bounding_box: Rect,
) -> MosseStatus {
    if handle.is_null() {
        return MosseStatus::NullPointer;
    }
    ffi_boundary(|| {
        // SAFETY: The caller owns a live, uniquely accessed handle.
        let handle = unsafe { &mut *handle };
        // SAFETY: Pointer validity and storage extent are part of this function's C contract.
        let frame = unsafe { frame_from_raw(bgr_data, width, height, stride) }?;
        handle
            .tracker
            .init(frame, bounding_box)
            .map_err(tracker_error_status)?;
        Ok(())
    })
}

/// Runs one tracker update.
///
/// Tracker failure is a valid call: the function returns `MOSSE_STATUS_OK`, writes zero to
/// `output_success`, and returns the unchanged current rectangle.
///
/// # Safety
///
/// `handle` must be live and exclusively accessed. `bgr_data` must point to the BGR8
/// storage described by the dimensions and stride. Both output pointers must be non-null,
/// properly aligned, and writable.
#[no_mangle]
pub unsafe extern "C" fn mosse_update(
    handle: *mut MosseHandle,
    bgr_data: *const u8,
    width: usize,
    height: usize,
    stride: usize,
    output_bounding_box: *mut Rect,
    output_success: *mut u8,
) -> MosseStatus {
    if handle.is_null() || output_bounding_box.is_null() || output_success.is_null() {
        return MosseStatus::NullPointer;
    }
    ffi_boundary(|| {
        // Validate all outputs and frame storage before mutating tracker state.
        // SAFETY: Pointer validity and storage extent are part of this function's C contract.
        let frame = unsafe { frame_from_raw(bgr_data, width, height, stride) }?;
        // SAFETY: The caller owns a live, uniquely accessed handle.
        let handle = unsafe { &mut *handle };
        let result = handle.tracker.update(frame).map_err(tracker_error_status)?;
        // SAFETY: Non-null output pointers must each reference writable storage.
        unsafe {
            output_bounding_box.write(result.bounding_box);
            output_success.write(u8::from(result.success));
        }
        Ok(())
    })
}

/// Copies the latest diagnostics without advancing the tracker.
///
/// # Safety
///
/// `handle` must be a live, immutably accessible handle and `output` must be non-null,
/// properly aligned, and writable for one [`Diagnostics`].
#[no_mangle]
pub unsafe extern "C" fn mosse_get_diagnostics(
    handle: *const MosseHandle,
    output: *mut Diagnostics,
) -> MosseStatus {
    if handle.is_null() || output.is_null() {
        return MosseStatus::NullPointer;
    }
    ffi_boundary(|| {
        // SAFETY: The caller owns a live handle and writable diagnostics storage.
        let diagnostics = unsafe { (&*handle).tracker.diagnostics() };
        // SAFETY: Non-null output storage is guaranteed by the caller.
        unsafe { output.write(diagnostics) };
        Ok(())
    })
}

/// Reports the effective backend selected after initialization.
///
/// Before initialization this writes [`MosseBackendStatus::Uninitialized`].
///
/// # Safety
///
/// `handle` must be a live, immutably accessible handle and `output` must be non-null,
/// properly aligned, and writable for one `i32`.
#[no_mangle]
pub unsafe extern "C" fn mosse_get_backend_status(
    handle: *const MosseHandle,
    output: *mut i32,
) -> MosseStatus {
    if handle.is_null() || output.is_null() {
        return MosseStatus::NullPointer;
    }
    ffi_boundary(|| {
        // SAFETY: The caller owns a live handle and writable status storage.
        let status = unsafe { (&*handle).tracker.backend_status() };
        // SAFETY: Non-null output storage is guaranteed by the caller.
        unsafe { output.write(MosseBackendStatus::from(status) as i32) };
        Ok(())
    })
}

/// Releases a tracker. Destroying a null handle is a no-op.
///
/// # Safety
///
/// A non-null `handle` must have been returned by [`mosse_create`] and not previously
/// destroyed. No other thread may access it during or after this call.
#[no_mangle]
pub unsafe extern "C" fn mosse_destroy(handle: *mut MosseHandle) -> MosseStatus {
    if handle.is_null() {
        return MosseStatus::Ok;
    }
    ffi_boundary(|| {
        // SAFETY: The C API contract permits exactly one destroy for a handle from mosse_create.
        drop(unsafe { Box::from_raw(handle) });
        Ok(())
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ffi_reports_abi_version() {
        assert_eq!(MOSSE_ABI_VERSION, 1);
        assert_eq!(mosse_abi_version(), MOSSE_ABI_VERSION);
    }

    #[test]
    fn ffi_rejects_null_and_bad_inputs() {
        let mut handle = ptr::null_mut();
        assert_eq!(
            unsafe { mosse_create(ptr::null(), &mut handle) },
            MosseStatus::Ok
        );
        assert!(!handle.is_null());

        let bad_box = Rect {
            x: 0.0,
            y: 0.0,
            width: 8.0,
            height: 8.0,
        };
        assert_eq!(
            unsafe { mosse_init(handle, ptr::null(), 16, 16, 48, bad_box) },
            MosseStatus::NullPointer
        );

        let pixels = vec![0u8; 16 * 16 * 3];
        let mut output_box = Rect::default();
        let mut success = 0;
        assert_eq!(
            unsafe {
                mosse_update(
                    handle,
                    pixels.as_ptr(),
                    16,
                    16,
                    48,
                    &mut output_box,
                    &mut success,
                )
            },
            MosseStatus::NotInitialized
        );

        assert_eq!(unsafe { mosse_destroy(handle) }, MosseStatus::Ok);
        assert_eq!(unsafe { mosse_destroy(ptr::null_mut()) }, MosseStatus::Ok);
    }

    #[test]
    fn ffi_rejects_storage_larger_than_rust_slice_limit() {
        let byte = 0u8;
        assert_eq!(
            unsafe { frame_from_raw(&byte, 1, 2, isize::MAX as usize,) }.unwrap_err(),
            MosseStatus::InvalidFrame
        );
    }

    #[test]
    fn explicit_mode_creation_rejects_invalid_values_and_nulls_output() {
        let mut handle = ptr::null_mut();
        assert_eq!(
            unsafe { mosse_create(ptr::null(), &mut handle) },
            MosseStatus::Ok
        );
        assert_eq!(unsafe { mosse_destroy(handle) }, MosseStatus::Ok);
        assert!(!handle.is_null());

        assert_eq!(
            unsafe { mosse_create_with_mode(ptr::null(), 99, &mut handle) },
            MosseStatus::InvalidMode
        );
        assert!(handle.is_null());
        assert_eq!(
            unsafe { mosse_create_with_mode(ptr::null(), MosseMode::Auto as i32, ptr::null_mut()) },
            MosseStatus::NullPointer
        );
    }

    #[test]
    fn explicit_modes_report_uninitialized_then_generic_backend() {
        let pixels = vec![127u8; 32 * 32 * 3];
        for mode in [MosseMode::Auto, MosseMode::Single, MosseMode::Multicore] {
            let mut handle = ptr::null_mut();
            assert_eq!(
                unsafe { mosse_create_with_mode(ptr::null(), mode as i32, &mut handle) },
                MosseStatus::Ok
            );
            assert!(!handle.is_null());

            let mut backend_status = -1;
            assert_eq!(
                unsafe { mosse_get_backend_status(handle, &mut backend_status) },
                MosseStatus::Ok
            );
            assert_eq!(
                backend_status,
                MosseBackendStatus::Uninitialized as i32,
                "{mode:?}"
            );

            assert_eq!(
                unsafe {
                    mosse_init(
                        handle,
                        pixels.as_ptr(),
                        32,
                        32,
                        32 * 3,
                        Rect {
                            x: 8.0,
                            y: 8.0,
                            width: 16.0,
                            height: 16.0,
                        },
                    )
                },
                MosseStatus::Ok
            );
            assert_eq!(
                unsafe { mosse_get_backend_status(handle, &mut backend_status) },
                MosseStatus::Ok
            );
            assert_eq!(
                backend_status,
                MosseBackendStatus::GenericSingle as i32,
                "{mode:?}"
            );
            assert_eq!(unsafe { mosse_destroy(handle) }, MosseStatus::Ok);
        }

        let mut backend_status = -1;
        assert_eq!(
            unsafe { mosse_get_backend_status(ptr::null(), &mut backend_status) },
            MosseStatus::NullPointer
        );
    }

    #[test]
    fn c_backend_status_values_cover_every_rust_backend() {
        for (rust_status, c_status) in [
            (
                TrackerBackendStatus::Uninitialized,
                MosseBackendStatus::Uninitialized,
            ),
            (
                TrackerBackendStatus::GenericSingleThread,
                MosseBackendStatus::GenericSingle,
            ),
            (
                TrackerBackendStatus::FixedPaddedSingleThread,
                MosseBackendStatus::FixedSingle,
            ),
            (
                TrackerBackendStatus::FixedPaddedFourCore,
                MosseBackendStatus::FixedMulticore,
            ),
        ] {
            assert_eq!(MosseBackendStatus::from(rust_status), c_status);
        }
    }

    #[test]
    fn explicit_single_mode_reports_fixed_serial_where_available() {
        let config = MosseConfig {
            training_warps: 1,
            ..MosseConfig::default()
        };
        let pixels = vec![127u8; 96 * 96 * 3];
        let mut handle = ptr::null_mut();
        assert_eq!(
            unsafe { mosse_create_with_mode(&config, MosseMode::Single as i32, &mut handle,) },
            MosseStatus::Ok
        );
        assert_eq!(
            unsafe {
                mosse_init(
                    handle,
                    pixels.as_ptr(),
                    96,
                    96,
                    96 * 3,
                    Rect {
                        x: 18.0,
                        y: 24.0,
                        width: 60.0,
                        height: 36.0,
                    },
                )
            },
            MosseStatus::Ok
        );

        let mut backend_status = -1;
        assert_eq!(
            unsafe { mosse_get_backend_status(handle, &mut backend_status) },
            MosseStatus::Ok
        );
        #[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
        assert_eq!(backend_status, MosseBackendStatus::FixedSingle as i32);
        #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
        assert_eq!(backend_status, MosseBackendStatus::GenericSingle as i32);
        assert_eq!(unsafe { mosse_destroy(handle) }, MosseStatus::Ok);
    }

    #[test]
    fn ffi_lifecycle_exposes_diagnostics_and_failure() {
        let pixels = vec![127u8; 32 * 32 * 3];
        let mut handle = ptr::null_mut();
        assert_eq!(
            unsafe { mosse_create(ptr::null(), &mut handle) },
            MosseStatus::Ok
        );
        assert_eq!(
            unsafe {
                mosse_init(
                    handle,
                    pixels.as_ptr(),
                    32,
                    32,
                    32 * 3,
                    Rect {
                        x: 8.0,
                        y: 8.0,
                        width: 16.0,
                        height: 16.0,
                    },
                )
            },
            MosseStatus::Ok
        );

        let mut output_box = Rect::default();
        let mut success = 1;
        assert_eq!(
            unsafe {
                mosse_update(
                    handle,
                    pixels.as_ptr(),
                    32,
                    32,
                    32 * 3,
                    &mut output_box,
                    &mut success,
                )
            },
            MosseStatus::Ok
        );
        assert_eq!(success, 0);

        let mut diagnostics = Diagnostics::default();
        assert_eq!(
            unsafe { mosse_get_diagnostics(handle, &mut diagnostics) },
            MosseStatus::Ok
        );
        assert_eq!(diagnostics.initialized, 1);
        assert_eq!(diagnostics.updates, 1);
        assert_eq!(diagnostics.last_success, 0);
        assert_eq!(unsafe { mosse_destroy(handle) }, MosseStatus::Ok);
    }
}
