# Four-times MOSSE research roadmap

Status: research and exact experiments are active. The Pi hot path remains
Experiment 026 commit `4f9dd19`; its preferred Pi build is Rust 1.97.1 with
one release codegen unit, the exact Experiment 032 result below. The shared
source additionally retains Experiment 036's compile-time x86-only
preprocessing gain. No 4x result is claimed.

## The actual gap

The preferred exact Rust result is now 6,747.28275355185 tracker-only FPS, or
2.9085779202x the official 2,319.787518 FPS one-thread OpenCV median. It uses
unchanged production Experiment 026 source compiled with Rust 1.97.1 and the
Pi-only Experiment 032 one-codegen-unit release setting. The user-designated
target is 4x, not merely 3x.

| Quantity | Value |
|---|---:|
| 4x target | 9,279.150072 FPS |
| Current mean update time | 148.207810 us |
| Target mean update time | 107.768491 us |
| Time that must be removed | 40.439319 us/update |
| Required throughput relative to the preferred Rust build | 1.375242510x |
| Required reduction in preferred-build update time | 27.285552% |

The production objective permits Rust to use all four Pi cores while the
denominator remains the default one-core OpenCV result. Core counts must be
disclosed but need not match. Consequently a four-core Rust candidate must
still exceed the **9,279.150072 FPS** target above, not a lower
matched-four-core threshold. Dispatch, barriers, worker computation, and
completion waits all remain inside each timed update.

This changes the optimization strategy. The remaining work cannot be closed by
another isolated twiddle loop or quality-of-life change.

The existing full-video class timing also rules out a success-only solution.
These class means were measured before the compiler-only Experiments 029/032
rebuild, so they remain structural evidence rather than a phase attribution
for the new binary:

| Update class | Count | Mean latency |
|---|---:|---:|
| Successful update with motion | 1,716 | 201.838 us |
| Successful update with zero displacement | 503 | 142.693 us |
| Failed localization | 2,727 | 123.932 us |

Even the 123.932 us failure/localization-only path is slower than the
107.768491 us target.
Skipping failed work, ending timing after loss, or changing the attempted
update count is forbidden and would not be an optimization.

## What the profile permits

The tracker-replay sample attributes approximately 27.31% of update work to
preprocessing and approximately 45.26% to the forward and inverse FFT phases.
These sampled percentages are directional and contain inclusive attribution;
they are not additive cycle-accurate phase timers.

They nevertheless impose a useful Amdahl constraint:

- If only the FFT phases change, they must become about 2.73x faster to close
  the whole 4x gap.
- A 2x FFT-phase gain projects to roughly 3.69x versus OpenCV before
  preprocessing/dataflow fusion.
- After that 2x FFT-phase gain, another roughly 9.1 us/update of real fused
  work must still be removed to cross 4x.

Those projections combine the prior sampled phase share with the newer
compiler-only total and are feasibility calculations, not performance claims.
Complete Pi phase timing must replace them as candidates become executable.

## Research findings

### 1. Remove normalization divisions from the spatial loop

OpenCV MOSSE preprocesses a log-intensity patch by subtracting its mean,
dividing by its standard deviation plus epsilon, and applying the Hann window.
For log patch `l`, mean `mu`, positive denominator `d`, and window `w`:

```text
f = ((l - mu) / d) * w
U = FFT((l - mu) * w)
FFT(f) = U / d
```

The scalar `1/d` can therefore be carried into later spectral coefficients
instead of dividing all 2,160 spatial values.

- Localization can inverse-transform the unnormalized response. Its positive
  scale does not change the maximum position.
- PSR can be recovered without changing its mathematical definition:
  `(peak_u - mean_u) / (std_u + epsilon * d)`.
- Model terms can use `rate/d` for `G * conj(U)` and `rate/d^2` for
  `U * conj(U)`.

The measured trace prepares 6,662 timed patches, so this can remove
14,389,920 per-pixel `f32` divisions from the replay. Arm's Cortex-A72 guide
lists vector `FDIV` as an iterative, low-throughput instruction, while vector
multiplication can issue every cycle. This is a high-value mathematical
equivalence, not an approximation.

The operation order changes finite-precision results, so this candidate is
**numerically equivalent, not bit-identical** until proven. It must retain all
4,946 decisions and boxes on the official trace before it can become the
default result.

The standalone implementation passed every parity gate and improved the
300-frame Pi screen by 4.493523%, but its complete replay reached
6,517.920671 FPS versus the retained 6,471.500559 FPS: only 0.717301%. It
missed the locked 1.0% retention threshold and was reverted. The algebra
remains a useful fusion opportunity for a future fixed FFT input stage; it is
not a retained optimization by itself.

Related preprocessing candidates:

- Accumulate log sum and log sum-of-squares in the fused crop, matching
  OpenCV's `meanStdDev` formulation, and remove the separate
  squared-deviation pass.
- Fuse `(log - mean) * Hann` directly into fixed-row FFT packing so the
  normalized spatial array is never written and reread.

Experiment 033 evaluated the first bullet independently. It passed exact
local/AArch64 tests and an exact +1.973467% Pi short screen, but the complete
replay reached only **6,633.198083 FPS**, **+0.190649%** versus Experiment
029, so it is rejected on Pi. The initial Dunamis screen was invalid because
it compared a generic candidate with a native-tuned reference. A corrected
native/native complete pair was exact and reached **64,130.793833 versus
62,322.801821 FPS**, **+2.901012%**. Experiment 036 then integrated the
compile-time x86_64 selection in the final production-shaped source. Its
complete Dunamis replay was exact at **64,014.111371 versus 62,322.801821
FPS**, **+2.713789%**; its AArch64 compile-out screen was exact and showed no
material regression. On Pi, sum-of-squares accumulation may be reconsidered
only when the subsequent normalization/Hann pass is fused into Experiment
031's row-kernel loads, so one new reduction replaces multiple memory passes
rather than one.

Primary evidence:

- [Original MOSSE paper](https://www.cs.colostate.edu/~draper/papers/bolme_cvpr10.pdf)
- [OpenCV 4.10 MOSSE source](https://github.com/opencv/opencv_contrib/blob/4.10.0/modules/tracking/src/mosseTracker.cpp)
- [OpenCV mean/stddev implementation](https://github.com/opencv/opencv/blob/4.x/modules/core/src/mean.dispatch.cpp)
- [Arm Cortex-A72 Software Optimization Guide](https://documentation-service.arm.com/static/5ed75eeeca06a95ce53f93c7)

### 2. Measure external FFT ceilings instead of assuming RustFFT is the limit

RustFFT 6.4.1 is already current and automatically uses NEON on AArch64. A
version bump is not a lead. Its generic planner and the current scalar
scatter/gather layout remain testable limits.

Two current external implementations are now provisioned for direct Pi
measurement:

1. **FFTW 3.3.11**: single-precision, NEON, direct 36x60 real 2-D plans,
   `PATIENT`/`EXHAUSTIVE` planning, aligned persistent buffers, and saved
   wisdom. Plan creation and allocation remain outside update timing. FFTW is
   also a planning/codelet oracle if its GPL license makes final integration
   undesirable.
2. **CMSIS-DSP 1.17.1**: Arm's July 16, 2026 release. Its Cortex-A NEON dynamic
   complex FFT explicitly supports factors 3 and 5 for lengths divisible by
   four, covering both 36 and 60. The honest probe packs two real rows into
   each CFFT60, unpacks their half-spectra, and then runs 31 CFFT36 columns.
   Direct dynamic RFFT60 is ruled out: the NEON RFFT first stage handles only
   radix 4 or 8, while `60/4=15` requires radix 3/5. Initialization returning
   a pointer is not evidence that this unsupported RFFT executes correctly.

The benchmark must include every pack, transpose, layout conversion, scale,
pointwise operation, and FFI boundary required by a tracker update. A
transform-only win that disappears in the complete phase is rejected.

Before writing a new kernel, the current RustFFT backend will also screen
explicit fixed factorizations:

- length 30: default Good-Thomas 5x6 versus 2x15 and 3x10;
- length 36: default mixed-radix 6x6 versus Good-Thomas 4x9 and 3x12.

Those ceiling screens are now complete:

- FFTW's best direct plan was slower than retained RustFFT.
- CMSIS-DSP's complete pair-packed CFFT proxy reached a 1.307341x FFT-phase
  speedup but missed its 1.75x integration gate.
- On the Pi, explicit Good-Thomas 4x9 beat RustFFT's isolated length-36 NEON
  batch by about 1.72x. On Dunamis, however, forcing the same factorization
  was about 4.29x slower than RustFFT's direct AVX Butterfly36.
- Applying 4x9 to every fixed forward/inverse column transform produced a
  positive short Pi screen but regressed the complete tracker by 0.353350%;
  Experiment 025 is rejected.
- The context-specific Experiment 026 keeps planner forwards for
  initialization/model state and uses 4x9 only for AArch64 localization
  forward and response inverse columns. Its Rust 1.85.0 complete exact trace
  reached 6,541.536862 FPS, +1.082227%, and the production implementation is
  commit `4f9dd19`.
- The final configuration compiles the AArch64-only context path completely
  out on x86, removing the redundant runtime branch and extra plan `Arc`.
  A lean exact Dunamis screen was directionally +0.92305% versus its baseline,
  but is classified as neutral with no stable x86 speedup claim. A lean exact
  Pi Rust 1.97.1 screen was +0.86727% versus the pre-compile-out Rust 1.97.1
  build. These short screens are not stacked onto any full-video result.

This is direct evidence that a transform plan cannot be selected from an
isolated batch alone. Predecessor data, downstream consumers, and persistent
model-state arithmetic are part of the optimization context.

Primary evidence:

- [FFTW 3.3.11](https://www.fftw.org/)
- [FFTW planner flags](https://www.fftw.org/fftw3_doc/Planner-Flags.html)
- [FFTW generated codelets](https://fftw.org/fftw3_doc/Generating-your-own-code.html)
- [CMSIS-DSP 1.17.1 release](https://github.com/ARM-software/CMSIS-DSP/releases/tag/v1.17.1)
- [CMSIS-DSP dynamic NEON CFFT](https://arm-software.github.io/CMSIS-DSP/latest/group__ComplexFFTF32.html)
- [CMSIS-DSP transform documentation](https://arm-software.github.io/CMSIS-DSP/main/group__groupTransforms.html)
- [RustFFT](https://github.com/ejmahler/RustFFT)

### 3. If libraries fall short, generate a fixed 60x36 dataflow

The credible custom architecture is a four-lane, padded array-of-structures-
of-arrays pipeline:

- Pad the 31 unique horizontal spectrum columns to 32. The dummy column costs
  36 complex values, about 3.2% of the half-spectrum, and removes vector tails.
- Process four independent rows in NEON lanes through the packed length-30
  real transform.
- Fuse the real-FFT postprocess with a 4x4 register transpose so it emits four
  adjacent frequency columns rather than scattering scalar values.
- Process four length-36 column transforms at once with contiguous
  real/imaginary planes.
- Keep localization multiplication and model arithmetic in that layout.
- Reverse the tiled layout in the inverse path and reduce outputs as the last
  row codelet produces them.
- Use fixed Good-Thomas 5x6 and 4x9 candidates to eliminate top-level twiddles,
  but select the actual factor order by Pi measurement.

This is deliberately a whole-pipeline layout. Converting to and from SoA only
around the existing generic FFT would likely spend the gain on deinterleaving
and copying.

Experiment 028 now supplies the first measured AArch64 kernel ceiling for this
path. Its four-lane AoSoA length-36 codelet passed deterministic local,
Dunamis, and Pi correctness gates. On the Pi it measured:

| Direction | Median ns per batch of four |
|---|---:|
| Forward | 700.394 |
| Inverse | 703.752 |

Eight calls process the padded 32-column layout, including the dummy column
that removes the 31-column tail:

| Direction | AoSoA padded 32 columns | Retained GT4x9, 31 columns | Ceiling ratio |
|---|---:|---:|---:|
| Forward | 5,603.152 ns | 12,099.105 ns | **2.159339x** |
| Inverse | 5,630.016 ns | 12,076.210 ns | **2.144969x** |

This is a **kernel ceiling, not tracker FPS**. It includes the codelet's CRT
permutations, transpose, radix stages, and scratch traffic, but excludes any
tracker-side AoS/AoSoA conversion. The result clears the kernel stop gate and
makes whole-layout integration the next exact experiment. It does not justify
wrapping the isolated call in conversions; the tracker must produce, retain,
and consume the layout directly so downstream fusion can share it.

Experiment 030 tested that warning rather than assuming it. It packed the
current 31-column `Complex32` spectrum into eight AoSoA batches, ran the fast
kernel, and unpacked it—all inside the normal update timer. The 299-update Pi
screen remained output-exact but regressed from `5,562.626458` to
`5,264.722298 FPS`, or `-5.355458643%`. It added `10.172 us/update` despite
the isolated kernel's roughly `12.94 us` forward-plus-inverse ceiling saving.
Directionally, the conversion and surrounding overhead consumed about
`23 us/update`. The wrapper was rejected without a repeat or full replay.

This makes the fused row/transpose stage a prerequisite rather than a later
polish: it must create the column AoSoA contract directly, and the inverse
rows must consume it directly. There is no profitable intermediate
pack/unpack integration.

Experiment 031 now supplies the matching fixed row-kernel ceiling. Its
four-lane RFFT60 includes real packing, Good-Thomas 5x6 stages,
postprocessing, inverse preprocessing, and output unpacking. All 9,728 Pi
oracle/round-trip/dirty-scratch comparisons passed. At 1.8 GHz with no
throttling, nine calls covering all 36 rows measured:

| Direction | Complete four-lane RFFT60 rows | Experiment 024 inner-CFFT context | Contextual ratio |
|---|---:|---:|---:|
| Forward | `8,939.268 ns` | `13,535.793 ns` | **1.514195x** |
| Inverse | `8,972.395 ns` | `13,529.328 ns` | **1.507884x** |

This is again a kernel ceiling, not tracker FPS, but it clears the
preregistered Pi gate in both directions even though the new side includes
more of the complete real transform. Dunamis transfer was mixed: forward was
contextually 1.187123x faster while inverse latency regressed 9.135895%.
Therefore the custom row+column layout is an AArch64 candidate; the x86
planner stays unchanged.

The concrete whole-layout contract is now 32 padded horizontal bins arranged
as eight groups of four. Each RFFT60 row batch produces four frequency-bin
vectors across four rows. A fused 4x4 register transpose stores them directly
as four adjacent column lanes. The tracker can keep these padded groups
through filter/model pointwise arithmetic, reverse the transpose after the
inverse column kernels, and avoid every separate AoS/AoSoA conversion measured
in Experiment 030.

Experiment 034 implemented that complete transform contract and compared it
against the current `Fft2` under production-relevant Pi compiler settings.
All gather/scatter, fused transposes, padded work, nine row batches, eight
column batches, and production-style inverse reduction were timed:

| Complete single-core chain | Whole layout | Current `Fft2` | Ratio |
|---|---:|---:|---:|
| Forward | `18,683.620 ns` | `28,612.666 ns` | **1.531431x** |
| Inverse plus reduction | `26,363.651 ns` | `36,069.502 ns` | **1.368153x** |
| Workload-weighted proxy | `51,529.497 ns` | `74,609.247 ns` | **1.447894x** |

This removes **30.934168%** of the matched transform-chain latency and passes
the structural stop gate. It remains a transform ceiling rather than tracker
FPS, because the real tracker still has to retain all six spectra in this
layout and perform its filter/model arithmetic directly on them.

The same portable path was only `0.674270x` as fast as Dunamis's native AVX
implementation. Whole-layout integration is therefore AArch64-specific;
Dunamis keeps the existing x86 path and remains a transfer screen for
architecture-neutral surrounding changes.

The April 2026 *Shortest-Path FFT* paper provides the most useful new process:
benchmark legal fused stage schedules in their real predecessor/cache context
and solve for the fastest path, rather than assuming the largest radix is
best. On Apple M1 NEON it reports a context-aware schedule 34% faster than its
context-free search. Its transform is power-of-two and its CPU is not a
Cortex-A72, so the reported speedup is not transferable; the empirical search
method is.

SPIRAL and FFTW's `genfft` provide established ways to generate and simplify
fixed arithmetic DAGs. Their output can act as an oracle and schedule source,
with the retained scalar Rust implementation verifying every generated
kernel.

Primary evidence:

- [Shortest-Path FFT, April 2026](https://arxiv.org/abs/2604.04311)
- [Implementing FFTs in Practice](https://arxiv.org/abs/2602.23525)
- [FFTW3 design and implementation](https://fftw.org/fftw-paper-ieee.pdf)
- [SPIRAL: Extreme Performance Portability](https://www.spiral.net/doc/papers/08510983_Spiral_IEEE_Final.pdf)
- [SPIRAL source](https://github.com/spiral-software/spiral-software)

### 4. Reuse the overlapping model crop exactly

On 1,716 successful moving updates, the second model patch is an
integer-shifted view of the localization patch. The retained trace averages
`|dx|=1.618881` and `|dy|=1.014569`. The entering-pixel count is:

```text
60*|dy| + 36*|dx| - |dx*dy|
```

It averages 117.183566 of 2,160 pixels, so 94.574835% of the second crop can
reuse the already sampled grayscale bytes. Only entering strips require the
current BGR half-pixel sampler. This avoids approximately 3,505,473 BGR sample
calculations over the full replay. All recorded patches are interior and all
movements overlap.

This preserves the same sample bytes, log lookup, accumulation order,
preprocessing, FFT, and model update. It is an **exact common-subexpression
optimization**, expected to contribute a supporting few percent rather than
the whole gap.

The implemented candidate passed exhaustive bit-for-bit and Pi AArch64 tests,
but its single preregistered 300-frame screen reached 5,405.693696 FPS versus
the retained 5,458.034 FPS reference, a 0.958959% regression. Storing the
localization grayscale cache on every attempt cost more than the reused model
sampling saved. It was rejected without a repeated or full-video run.

The whole-pipeline kernel creates a materially different opportunity: retain
the raw log patch that the fused row FFT already consumes out of place, then
shift/reuse those values only after a moving success. This avoids adding a
cache store to every localization/failure, reuses 94.57% of moving model-patch
logs, samples only entering strips, and feeds the result directly into the
fused row kernel. The combined design must be measured; Experiment 022 alone
remains rejected.

### 5. Fuse response statistics with the inverse tail

The response mean follows from the DC coefficient, and its energy/variance
follows from Parseval's identity with the proper Hermitian half-spectrum
weights. The inverse transform is still required for the peak location, but a
fixed inverse tail can:

- compare unscaled outputs for the first maximum;
- avoid a materialized 2,160-float response write/read;
- scale only the selected peak and diagnostics;
- obtain mean and variance while the response spectrum is already hot.

This is mathematically equivalent but changes floating reduction order. It is
a **numerically equivalent candidate** subject to the complete decision/box
gate. It is most useful when fused into the custom inverse kernel, not as
another standalone pass.

The phase-disjoint preprocessed and response-spectrum buffers can also share
one aligned scratch allocation. With the materialized response removed, the
active localization set can fall to roughly 26.8 KiB, within the A72's 32 KiB
L1 data cache.

Primary evidence:

- [FFTW real-data half-spectrum format](https://www.fftw.org/fftw3_doc/Real_002ddata-DFT-Array-Format.html)
- [FFTW multidimensional real transforms](https://www.fftw.org/fftw3_doc/Multi_002dDimensional-DFTs-of-Real-Data.html)

### 6. Use current compiler technology as a multiplier, not the strategy

Experiment 029 completed the isolated old-versus-new compiler screen. The
unchanged production Experiment 026 source was rebuilt with generic Rust
1.97.1/LLVM 22.1.6 and no target-CPU, LTO, PGO, codegen-unit, or opt-level
override.

- The lean Pi screen was exact and +1.799774% versus Rust 1.85.0.
- The single complete exact replay reached **6,620.5759995355 FPS** at
  **151.044260 us** mean latency.
- That is **+1.2082655608%** versus the Experiment 026 Rust 1.85.0 gate and
  **2.8539579375x** the official OpenCV median.

Generic Rust 1.97.1 is therefore the preferred Pi build toolchain. This is one
complete candidate gate, not a multi-run median, and the compiler gain must
not be stacked with the separate +0.86727% compile-out screen because their
references overlap.

Experiment 032 then isolated codegen count and LTO on the unchanged source:

- `CARGO_PROFILE_RELEASE_CODEGEN_UNITS=1` completed the exact Pi replay at
  **6,747.28275355185 FPS**, **148.207810 us**, and **+1.9138327847%** versus
  Experiment 029. It is the preferred Pi-specific build setting.
- Fat LTO plus one codegen unit passed a short exact screen but was weaker and
  did not receive a complete replay.
- The same one-codegen-unit setting regressed the exact Dunamis x86_64 screen
  by **1.555223%**, so it is rejected on x86 and must not be applied globally.

Experiment 038 subsequently isolated the remaining CPU-selection question:
Rust 1.97.1 plus one codegen unit and safely masked
`target-cpu=cortex-a72`, without LTO. Its exact Pi screen reached
**4,511.100234 versus 4,891.180397 FPS**, a **7.770725% regression**. The
candidate failed its locked gate decisively, so generic AArch64 CPU selection
remains the preferred Pi setting.

Experiment 037 then isolated architecture-specific LLVM PGO after one complete
ordinary training workload on each host. Both exact 300-frame gates failed:
PGO was **−0.583267%** on Dunamis and **−1.126254%** on Pi. No full candidate
or retry was justified. PGO is rejected for the current source and is not
stacked with any retained compiler setting.

### 7. Use four Pi cores through a persistent bounded-latency executor

Experiment 035 implemented the required caller-plus-three-worker executor with
fixed task ownership, CPU affinity, epoch atomics, and no per-dispatch
allocation, queues, locks, parking, thread creation, or joins. It was exact,
but ordinary Pi `SCHED_OTHER` scheduling produced a `15.310 us` empty median
and multi-millisecond tails, so every small parallel batch regressed. Dunamis
measured a `219.986 ns` empty median, isolating the failure to Pi scheduling.

Experiment 040 kept the exact Pi binary and changed only the bounded runtime:
caller and workers pinned to CPUs 0–3 under `SCHED_FIFO` priority 50, with a
higher-priority watchdog and deliberate RT-bandwidth restoration. Empty
dispatch fell to **`288.133 ns`**. The eight CFFT36 batches accelerated
**2.825549–2.831502x**, and the nine RFFT60 batches accelerated
**3.002169–3.047150x**. Every dispatch, worker task, barrier, and wait was
inside the timer.

These are kernel/executor ceilings, not tracker FPS. The production comparison
is nevertheless intentionally asymmetric and real: Rust may use all four Pi
cores while the denominator is default one-core OpenCV. The configuration and
capability requirements must be disclosed, and the tracker must retain a
single-thread fallback when bounded real-time scheduling is unavailable.

The current Pi PMU evidence makes allocator replacement and BOLT poor
priorities: branch misprediction is about 0.77%, L1D refill/access about 1.28%,
and L1I refill/access about 0.00445%. The path is dominated by arithmetic,
passes, and dataflow rather than general code placement.

Primary evidence:

- [Rust 1.97.1 releases](https://blog.rust-lang.org/releases/)
- [Rust code-generation options](https://doc.rust-lang.org/rustc/codegen-options/index.html)
- [Rust PGO workflow](https://doc.rust-lang.org/rustc/profile-guided-optimization.html)

### 8. Challenge mode: displaced localization update, evaluated and rejected

The original MOSSE formulation permits a training image in which the target
is not centered, provided the desired response peak is moved to the target
location. On a successful moving update, the retained tracker already owns
the localization spectrum for exactly such a sample. A separately labeled
challenge mode can therefore update on every success without performing the
second recentered crop:

```text
G_delta(kx,ky) =
    G0(kx,ky) * exp(-i*2*pi*(kx*dx/60 + ky*dy/36))

A' = keep*A + rate*G_delta*conj(F_local)
B' = keep*B + rate*F_local*conj(F_local)
```

The phase sign must be calibrated against the implementation's transform and
correlation convention. Compact one-dimensional x/y phase tables can be
precomputed at initialization and fused into the existing model-bin loop, so
there is no timed trigonometry or allocation.

This is not an omitted update: localization still runs on every attempted
frame, failures remain timed, and every successful frame still supplies a
complete MOSSE training sample. It is nevertheless not OpenCV-exact because
the recentered patch has different Hann weights, normalization, and entering
pixels.

Experiment 027 completed this evaluation with the challenge feature explicitly
enabled while the default remained off. Its 300-frame screen was +20.0447%
with excellent early quality, but the full trace exposed accumulated drift.
The complete Pi challenge processed all 4,947 frames and 4,946 update attempts
with the unchanged 2,219-success/2,727-failure split:

| Metric | Full challenge result |
|---|---:|
| Tracker-only FPS | 7,205.37386514342 |
| Mean update latency | 138.785304 us |
| Gain versus exact Rust 1.97.1 | +8.8330360629% |
| Ratio to official OpenCV | 3.1060490713x |

All 4,946 success/failure decisions and all frame checksums matched. Box
quality did not:

- center error mean / median / p95 / maximum:
  `2.050657 / 2.236068 / 3.605551 / 13.341664 px`;
- centers within two pixels: `48.445246%`;
- IoU mean / median / p05 / minimum:
  `0.893018 / 0.886463 / 0.795511 / 0.560130`.

Experiment 027 is therefore **rejected for the exact headline and remains
feature-gated off by default**. Its 3.106x figure is challenge evidence only:
it is not retained and must not be stacked with the exact Experiment 029
result. It does provide a measured ceiling for the cost of the second
model-patch path. Because the current formulation drifts, whole-layout AoSoA
integration remains the priority exact route.

Primary evidence:

- [`experiments/027-shifted-goal-model-update/protocol.md`](experiments/027-shifted-goal-model-update/protocol.md)
- [Original MOSSE paper](https://www.cs.colostate.edu/~draper/papers/bolme_cvpr10.pdf)
- [KCF cyclic-shift formulation](https://arxiv.org/abs/1404.7584)

### 9. Independent read-only review

The [`QWEN38_MAX_BL_4X_REVIEW.md`](QWEN38_MAX_BL_4X_REVIEW.md) Qwen 3.8 Max audit
through Bailian inspected a repository snapshot read-only. It ran no
benchmarks and generated no profiler data, so it is not measurement evidence.
Its actionable conclusion nevertheless independently agrees with the current
measured roadmap:

- the failure/localization path is binding because it already exceeds the
  107.768491 us target mean, so success-only work cannot close 4x;
- the most credible exact path is whole-layout AoSoA integration with fused
  preprocessing, transforms, and downstream consumers, not an isolated
  twiddle or conversion-wrapped codelet.

The review's statement that `FINAL_REPORT.md` was stale referred to its
snapshot. It is obsolete because the local report was updated after that
review. The preserved review remains advisory and must not supersede later Pi
measurements or the negative-result record.

## Provisioned research environment

No system package is being treated as a boundary.

- Dunamis:
  - Rust 1.97.1 in `/srv/ssd/intel/research/mosse-tooling`;
  - SPIRAL source;
  - FFTW 3.3.11 source and `genfft`;
  - CMSIS-DSP 1.17.1 source;
  - LLVM 21 tools, including `llvm-mca`, through the repository Nix shell;
  - the 2026 schedule-search paper retained with the tooling.
- Raspberry Pi 4:
  - Rust 1.97.1 in `/home/crown/.local/share/mosse-tooling`;
  - Cortex-A72/NEON FFTW 3.3.11 build;
  - Cortex-A72/NEON CMSIS-DSP 1.17.1 build.

All external code remains outside the repository until a measured candidate
justifies a minimal, reviewable integration.

## Experiment order and stop rules

Early screening is intentionally lean:

1. Use production Experiment 026 commit `4f9dd19`, Rust 1.97.1, and the
   Pi-only Experiment 032 one-codegen-unit setting as the exact Pi baseline.
   Keep ordinary native codegen units on Dunamis; architecture-specific gains
   are reported rather than silently generalized.
2. Keep Experiment 030's AoS/AoSoA wrapper rejected. Experiment 034 has
   already validated the complete transform layout; Experiment 039 must now
   keep all six tracker spectra padded end-to-end and run pointwise operations
   directly on them.
3. In parallel, combine Experiment 034's full forward/inverse chains with
   Experiment 040's persistent four-core executor. Measure all transposes,
   padding, dispatches, barriers, and inverse reduction in the combined chain.
4. After exact single-thread integration, add the four-core runtime and run one
   normal full replay if the lean screen clears its gate. The production
   headline is four-core Rust versus default one-core OpenCV, with both core
   counts disclosed.
5. Use measured phase timings from that first combined tracker to apply
   Amdahl's law. If the 4x margin is thin, send disjoint crop/preprocessing
   rows and correlation-bin groups through the existing executor. Roughly
   4.7x and 5.3x remain planning projections, never measured claims.
6. Keep the first parallel inverse's final scale/maximum/`f64` reduction on
   the caller in original row-major order. Do not replace it with fixed-order
   cross-core partial sums merely because they are repeatable: floating-point
   addition is non-associative. If reduction later becomes necessary, add
   near-threshold PSR stress fixtures and a full-trace behavior gate.
7. Deprioritize Parseval after the disjoint tails. Retain it only as a possible
   response-buffer/cache-traffic optimization, not as proof of serial
   reduction equivalence.
8. Fuse raw-log FFT input and exact overlap reuse into the winning dataflow if
   measured Amdahl analysis still justifies them.
9. Keep the current Experiment 027 shifted-goal challenge off and rejected.
   Use its measured second-model-path ceiling only for planning; any successor
   challenge requires a new protocol and full quality gate.
10. Keep Experiment 037 PGO and the ordinary-priority Experiment 035 Pi runtime
   rejected. Retain Experiment 040's watchdog, narrow scheduling capability,
   and safe fallback requirements.
11. Before the rigorous matrix, run both one exact complete replay and a
   sustained RT/live-style soak. Check decode starvation, dropped/late frames,
   temperature, throttling, watchdog behavior, and before/after restoration of
   RT settings.
12. Run the rigorous alternating multi-pair Pi benchmark only after the
   qualified full-trace candidate exceeds 9,279.150072 FPS. Record
   single-thread Rust as a companion metric; the production target is the
   four-core result.

Every screen includes all normal frames, attempted updates, failures, model
updates, packing, and layout costs appropriate to what it measures. No
candidate may derive a speed result by omitting work that the reference
tracker performs.

## Retention classes

| Class | Meaning | Required gate |
|---|---|---|
| Bit-exact | Same relevant floating values/state as the retained oracle | Unit/intermediate oracle plus exact full trace |
| Output-exact numerical | Mathematical MOSSE equivalence with different floating order | All 4,946 decisions and boxes exact; diagnostics documented |
| Quality-equivalent challenge | Deliberately changes tracker behavior | Separately labeled quality metrics and annotated review; never merged into the exact headline silently |

The headline exact path uses the first two classes. Shifted-goal training was
evaluated in the separately labeled third class, failed its full box-quality
gate, and remains off. Skipped failure work, stopped timers, omitted updates,
and reduced attempted-frame counts are outside all retention classes.
