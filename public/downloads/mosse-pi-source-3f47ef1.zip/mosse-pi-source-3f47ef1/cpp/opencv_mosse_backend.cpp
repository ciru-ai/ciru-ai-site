#include "mosse/tracker_backend.hpp"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <stdexcept>
#include <string>

#include <opencv2/tracking.hpp>
#include <opencv2/tracking/tracking_legacy.hpp>

#ifndef MOSSE_HAS_RUST_BACKEND
#define MOSSE_HAS_RUST_BACKEND 0
#endif

namespace mosse {

#if MOSSE_HAS_RUST_BACKEND
std::unique_ptr<TrackerBackend> create_rust_mosse_backend();
#endif

namespace {

bool valid_bbox(const cv::Rect2d &bbox) {
  return std::isfinite(bbox.x) && std::isfinite(bbox.y) &&
         std::isfinite(bbox.width) && std::isfinite(bbox.height) &&
         bbox.width > 0.0 && bbox.height > 0.0;
}

class OpenCvMosseBackend final : public TrackerBackend {
public:
  [[nodiscard]] std::string name() const override {
    return "opencv_legacy_mosse";
  }

  bool initialize(const cv::Mat &first_frame,
                  const cv::Rect2d &initial_roi) override {
    if (first_frame.empty()) {
      throw std::runtime_error(
          "Cannot initialize OpenCV MOSSE with an empty frame");
    }
    if (!valid_bbox(initial_roi)) {
      throw std::runtime_error(
          "Cannot initialize OpenCV MOSSE with an invalid ROI");
    }

    tracker_ = cv::legacy::TrackerMOSSE::create();
    if (tracker_.empty()) {
      throw std::runtime_error(
          "cv::legacy::TrackerMOSSE::create returned an empty tracker");
    }

    bbox_ = initial_roi;
    initialized_ = tracker_->init(first_frame, bbox_);
    return initialized_;
  }

  TrackerUpdate update(const cv::Mat &frame) override {
    if (!initialized_ || tracker_.empty()) {
      throw std::runtime_error(
          "OpenCV MOSSE update called before initialization");
    }
    if (frame.empty()) {
      throw std::runtime_error("OpenCV MOSSE update received an empty frame");
    }

    cv::Rect2d candidate = bbox_;
    const bool success = tracker_->update(frame, candidate);
    if (valid_bbox(candidate)) {
      bbox_ = candidate;
    } else if (success) {
      throw std::runtime_error(
          "OpenCV MOSSE returned success with an invalid bounding box");
    }

    return {success, bbox_};
  }

private:
  cv::Ptr<cv::legacy::TrackerMOSSE> tracker_;
  cv::Rect2d bbox_;
  bool initialized_{false};
};

std::string normalized_name(std::string name) {
  std::transform(name.begin(), name.end(), name.begin(),
                 [](const unsigned char character) {
                   return static_cast<char>(std::tolower(character));
                 });
  return name;
}

} // namespace

std::unique_ptr<TrackerBackend>
create_tracker_backend(const std::string &tracker_name) {
  const std::string name = normalized_name(tracker_name);
  if (name == "opencv" || name == "opencv_mosse" ||
      name == "opencv_legacy_mosse") {
    return std::make_unique<OpenCvMosseBackend>();
  }
  if (name == "rust" || name == "rust_mosse" || name == "rust_mosse_scalar") {
#if MOSSE_HAS_RUST_BACKEND
    return create_rust_mosse_backend();
#else
    throw std::runtime_error(
        "Rust MOSSE backend is unavailable in this build. Reconfigure with "
        "-DMOSSE_ENABLE_RUST_BACKEND=ON and provide MOSSE_RUST_STATICLIB.");
#endif
  }

  throw std::runtime_error("Unsupported tracker backend '" + tracker_name +
                           "'. Expected 'opencv' or 'rust'.");
}

} // namespace mosse
