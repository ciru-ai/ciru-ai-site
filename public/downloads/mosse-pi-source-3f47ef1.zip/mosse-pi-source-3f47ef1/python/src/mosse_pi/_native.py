"""ctypes binding and platform-specific shared-library loader."""

from __future__ import annotations

import ctypes
import hashlib
import json
import os
import platform
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Optional, Tuple

from ._errors import NativeLibraryError, NativeLibraryNotFoundError, NativeStatusError
from ._version import __version__

LIBRARY_OVERRIDE_ENV = "MOSSE_CORE_LIBRARY"
ABI_VERSION = 1

MODE_AUTO = 0
MODE_SINGLE = 1
MODE_MULTICORE = 2

BACKEND_UNINITIALIZED = 0
BACKEND_GENERIC_SINGLE = 1
BACKEND_FIXED_SINGLE = 2
BACKEND_FIXED_MULTICORE = 3

STATUS_OK = 0

_STATUS_DETAILS = {
    -1: "null pointer",
    -2: "invalid tracker configuration",
    -3: "invalid frame",
    -4: "invalid bounding box",
    -5: "tracking window is too large",
    -6: "tracker is not initialized",
    -7: "invalid execution mode",
    -127: "panic contained at the native ABI boundary",
}


class Rect(ctypes.Structure):
    _fields_ = [
        ("x", ctypes.c_double),
        ("y", ctypes.c_double),
        ("width", ctypes.c_double),
        ("height", ctypes.c_double),
    ]

    def as_tuple(self) -> Tuple[float, float, float, float]:
        return (float(self.x), float(self.y), float(self.width), float(self.height))


@dataclass(frozen=True)
class NativeLibraryInfo:
    """Reproducible identity for the loaded native binary."""

    path: str
    architecture: str
    sha256: str
    package_version: str = __version__
    source_commit: Optional[str] = None
    package_source_commit: Optional[str] = None
    native_rust_tree: Optional[str] = None
    native_library_supplied: bool = False
    features: tuple[str, ...] = ()
    rustc: Optional[str] = None
    glibc: Optional[str] = None
    minimum_glibc: Optional[str] = None
    wheel_platform: Optional[str] = None


def _optional_string(value: object) -> Optional[str]:
    return value.strip() if isinstance(value, str) and value.strip() else None


def _read_build_info(library_path: Path) -> dict[str, object]:
    """Read optional sibling build metadata without making loading fragile."""

    path = library_path.with_name("build_info.json")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return {}
    if not isinstance(payload, dict):
        return {}

    raw_features = payload.get("features")
    if isinstance(raw_features, str):
        features = tuple(
            feature.strip() for feature in raw_features.split(",") if feature.strip()
        )
    elif isinstance(raw_features, list):
        features = tuple(
            feature.strip()
            for feature in raw_features
            if isinstance(feature, str) and feature.strip()
        )
    else:
        features = ()

    package_source_commit = _optional_string(payload.get("source_commit"))
    native_source_commit = (
        _optional_string(payload.get("native_source_commit"))
        or package_source_commit
    )
    supplied = payload.get("native_library_supplied")
    return {
        "source_commit": native_source_commit,
        "package_source_commit": package_source_commit,
        "native_rust_tree": _optional_string(payload.get("native_rust_tree")),
        "native_library_supplied": supplied if isinstance(supplied, bool) else False,
        "features": features,
        "rustc": _optional_string(payload.get("rustc")),
        "glibc": _optional_string(payload.get("glibc")),
        "minimum_glibc": _optional_string(payload.get("minimum_glibc")),
        "wheel_platform": _optional_string(payload.get("wheel_platform")),
    }


def check_status(operation: str, status: int) -> None:
    status = int(status)
    if status != STATUS_OK:
        detail = _STATUS_DETAILS.get(status, "unknown native status")
        raise NativeStatusError(operation, status, detail)


def _normalized_architecture(machine: Optional[str] = None) -> str:
    value = (machine or platform.machine()).lower()
    if value in {"x86_64", "amd64"}:
        return "x86_64"
    if value in {"aarch64", "arm64"}:
        return "aarch64"
    raise NativeLibraryNotFoundError(
        f"unsupported Linux architecture {value!r}; expected x86_64 or aarch64"
    )


def _library_path() -> tuple[Path, str]:
    override = os.environ.get(LIBRARY_OVERRIDE_ENV)
    if override:
        path = Path(os.path.expandvars(os.path.expanduser(override))).resolve()
        if not path.is_file():
            raise NativeLibraryNotFoundError(
                f"{LIBRARY_OVERRIDE_ENV} points to a missing file: {path}"
            )
        architecture = _normalized_architecture()
        return path, architecture

    if platform.system() != "Linux":
        raise NativeLibraryNotFoundError(
            "mosse-pi preview binaries support Linux only; set "
            f"{LIBRARY_OVERRIDE_ENV} to an explicitly compatible library"
        )
    architecture = _normalized_architecture()
    path = (
        Path(__file__).resolve().parent
        / "native"
        / f"linux-{architecture}"
        / "libmosse_core.so"
    )
    if not path.is_file():
        raise NativeLibraryNotFoundError(
            f"bundled native library is absent for linux-{architecture}: {path}. "
            f"Set {LIBRARY_OVERRIDE_ENV} to a compatible libmosse_core.so."
        )
    return path, architecture


class NativeBindings:
    """High-level calls over the additive preview C ABI.

    ``ctypes.CDLL`` is intentional: unlike ``ctypes.PyDLL``, native function
    calls release the Python GIL.
    """

    def __init__(self, library: ctypes.CDLL, path: Path, architecture: str) -> None:
        self._library = library
        try:
            self._abi_version = library.mosse_abi_version
            self._create = library.mosse_create_with_mode
            self._init = library.mosse_init
            self._update = library.mosse_update
            self._backend = library.mosse_get_backend_status
            self._destroy = library.mosse_destroy
        except AttributeError as error:
            raise NativeLibraryError(
                "libmosse_core does not expose the complete preview ABI"
            ) from error

        self._abi_version.argtypes = []
        self._abi_version.restype = ctypes.c_uint32
        try:
            actual_abi_version = int(self._abi_version())
        except Exception as error:
            raise NativeLibraryError(
                "failed to query libmosse_core ABI version"
            ) from error
        if actual_abi_version != ABI_VERSION:
            raise NativeLibraryError(
                "incompatible libmosse_core ABI version: "
                f"expected={ABI_VERSION}, actual={actual_abi_version}"
            )

        self._create.argtypes = [
            ctypes.c_void_p,
            ctypes.c_int32,
            ctypes.POINTER(ctypes.c_void_p),
        ]
        self._create.restype = ctypes.c_int32
        self._init.argtypes = [
            ctypes.c_void_p,
            ctypes.c_void_p,
            ctypes.c_size_t,
            ctypes.c_size_t,
            ctypes.c_size_t,
            Rect,
        ]
        self._init.restype = ctypes.c_int32
        self._update.argtypes = [
            ctypes.c_void_p,
            ctypes.c_void_p,
            ctypes.c_size_t,
            ctypes.c_size_t,
            ctypes.c_size_t,
            ctypes.POINTER(Rect),
            ctypes.POINTER(ctypes.c_uint8),
        ]
        self._update.restype = ctypes.c_int32
        self._backend.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_int32)]
        self._backend.restype = ctypes.c_int32
        self._destroy.argtypes = [ctypes.c_void_p]
        self._destroy.restype = ctypes.c_int32

        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        build_info = _read_build_info(path)
        self.info = NativeLibraryInfo(
            path=str(path),
            architecture=architecture,
            sha256=digest,
            **build_info,
        )

    def create(self, mode: int) -> ctypes.c_void_p:
        handle = ctypes.c_void_p()
        check_status(
            "mosse_create_with_mode",
            self._create(None, ctypes.c_int32(mode), ctypes.byref(handle)),
        )
        if not handle.value:
            raise NativeLibraryError(
                "native create returned success with a null handle"
            )
        return handle

    def init(self, handle: ctypes.c_void_p, frame: object, rect: Rect) -> None:
        check_status(
            "mosse_init",
            self._init(
                handle,
                frame.pointer,
                frame.width,
                frame.height,
                frame.row_stride,
                rect,
            ),
        )

    def update(self, handle: ctypes.c_void_p, frame: object) -> tuple[bool, Rect]:
        rect = Rect()
        success = ctypes.c_uint8()
        check_status(
            "mosse_update",
            self._update(
                handle,
                frame.pointer,
                frame.width,
                frame.height,
                frame.row_stride,
                ctypes.byref(rect),
                ctypes.byref(success),
            ),
        )
        return bool(success.value), rect

    def backend_status(self, handle: ctypes.c_void_p) -> int:
        backend = ctypes.c_int32()
        check_status(
            "mosse_get_backend_status",
            self._backend(handle, ctypes.byref(backend)),
        )
        return int(backend.value)

    def destroy(self, handle: ctypes.c_void_p) -> None:
        check_status("mosse_destroy", self._destroy(handle))


@lru_cache(maxsize=1)
def load_bindings() -> NativeBindings:
    path, architecture = _library_path()
    try:
        library = ctypes.CDLL(str(path))
    except OSError as error:
        raise NativeLibraryError(
            f"failed to load native library {path}: {error}"
        ) from error
    return NativeBindings(library, path, architecture)
