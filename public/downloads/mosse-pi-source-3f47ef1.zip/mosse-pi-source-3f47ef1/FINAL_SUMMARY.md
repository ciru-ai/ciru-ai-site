# Final MOSSE Pi 4 result

## Outcome

The exact production Rust tracker passed the final Raspberry Pi 4
qualification at **11,632.121609 tracker-only FPS median**. Against the frozen
one-core OpenCV baseline of 2,319.787518 FPS, that is **5.014304767×**—25.3576%
above the required 4× target.

The same-suite OpenCV runs were 1.67% faster than the frozen baseline, so the
contemporaneous paired median is **4.938477642×**. The frozen-baseline 5×
margin is thin: 0.2861%, with four of five Rust runs above 5×. The accurate
claim is therefore “5.014× median versus the frozen baseline,” not a
guaranteed 5× floor or a 5× same-suite result.

| Metric | OpenCV1 | Rust4 production |
|---|---:|---:|
| Five-run mean FPS | 2,356.421867 | 11,626.625991 |
| Five-run median FPS | 2,358.526332 | **11,632.121609** |
| Median per-run latency median | 301.570 µs | 73.296 µs |
| Median per-run p95 | 614.954 µs | 107.499 µs |
| Measured temperature | 56.4–65.731 °C | 55.504–67.679 °C |
| Firmware throttling | none | none |

The median-FPS Rust run averaged 85.968840 µs/update, 21.799651 µs below the
107.768491-µs 4× ceiling.

## Integrity and production qualification

- One complete warm-up per implementation, then five globally alternating
  full-video measured pairs.
- Exact video SHA-256
  `17293ee5158b5f41d2920bbb1ba835f96050ab2813942ff29008dffab10857b5`.
- Every run decoded 4,947 frames and timed all 4,946 updates, including all
  2,727 failures; no clock stopping, skipped tail, or lost-target exclusion.
- All five 4,947-row comparisons were literal-exact over frame identity,
  initialization/update flags, decisions, boxes, and checksums.
- Stable 2,219-success/2,727-failure split; zero center/size delta; IoU 1.0.
- Complete Rust process launched on CPU 0; three normal-priority, nice-0
  workers self-pinned to CPUs 1–3. No root, FIFO, `CAP_SYS_NICE`, or RT-runtime
  change is required by the tracker.
- Governor wrapper changed `ondemand` to `performance` only for scoring,
  restored it afterward, and preserved boot ID, watchdog, RT settings, and
  throttle state. No post-launch SSH observer or lingering benchmark was
  found.
- The paced source-rate OpenCV/Python soak completed the same 4,947 frames
  with exact output, zero dropped/late frames, zero decode starvation, a live
  external watchdog, no throttle, and deterministic cleanup.

The current-build one-core Rust companion measured **7,071.160241 FPS median**
(3.048193072× the frozen baseline) in a separate exact five-pair governed
suite. It is not the production headline.

## Why the final reduction stayed serial

After whole-layout/four-core integration, the caller-side row-major inverse
response reduction measured 8.044877 µs/update, 9.188% of the 87.555026-µs
isolated replay. Parallelizing only that phase projected approximately
5.288× under idealized Amdahl assumptions. It was not needed for the 4×
objective and could not reproduce the original serial `f64` accumulation
merely by using a deterministic cross-core combine, so it remained serial.
The 5.288× figure is a projection, never a measured score.

## Native and Python deliverables

Final native identity:

- source `60bdb90776ab5eb30a835a2ad35020b605f41c9e`
- Rust tree `b057110badaf5f94d63f557bfd869268f8f3fe4c`
- benchmark SHA-256
  `de88c190b751707521e2d991ed41a108e5ca81b0c3e8efb84df243f558e01288`
- AArch64 `libmosse_core.so` SHA-256
  `7aa6a3b8cae990503187d9f65b9dd47715f6209e51226d7ec61b988746eb9201`

The stable Python API is:

```python
from mosse_pi import MosseTracker

with MosseTracker(initial_frame, (x, y, w, h), mode="auto") as tracker:
    success, (x, y, w, h) = tracker.update(frame)
    print(tracker.selected_mode, tracker.backend)
```

Both `0.1.0.dev5` downloads contain a wheel, raw shared library, C header,
install/reproduction/smoke documentation, and runnable NumPy,
`cv2.VideoCapture`, and latency examples. Both were installed and
runtime-smoked after fresh archive extraction on their target architecture.

| Download | SHA-256 | Runtime |
|---|---|---|
| `mosse-pi-0.1.0.dev5-linux-aarch64-preview.tar.gz` | `3e5652668e2981c60dba8847482cfd9305c40c10af9d8a0c22fdf8b9b8dd12cc` | glibc ≥2.34; qualified multicore for internal 60×36, safe single fallback |
| `mosse-pi-0.1.0.dev5-linux-x86_64-preview.tar.gz` | `7cc3d26b2a016f9ef6b11b5f243ee9f4064d52a9136c4ad618b0a91b2f1b61a6` | manylinux 2.28; portable single-thread backend |

The Python wrapper-call and decode timings remain separate from the native
tracker-only score.

## Evidence

- [Final four-core aggregate](experiments/066-final-composite-qualification/results/pi4/four-core-performance-v1/aggregate.md)
- [Single-thread companion](experiments/066-final-composite-qualification/results/pi4/single-thread-companion-v1/aggregate.md)
- [Final qualification protocol](experiments/066-final-composite-qualification/protocol.md)
- [Python downloads](artifacts/python-preview/160c68016303)
- [Exact annotated comparison video](experiments/066-final-composite-qualification/results/pi4/final-exact-annotated-video-v1/opencv-rust-exact-side-by-side-h264.mp4),
  SHA-256
  `ba9667090a388d39a4c726fb7ef6849f488c932bbd2b3714b8a57fa6383687d1`

The annotated video was rendered only after timing from an exact saved pair;
the renderer did not execute either tracker and validated all 4,947 output
frames.
