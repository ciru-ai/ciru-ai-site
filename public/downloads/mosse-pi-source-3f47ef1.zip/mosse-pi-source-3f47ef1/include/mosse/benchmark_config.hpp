#pragma once

#include <cstdint>
#include <filesystem>
#include <optional>

#include <opencv2/core/types.hpp>

namespace mosse {

struct BenchmarkConfig {
  std::filesystem::path config_path;
  std::filesystem::path video_path;
  std::optional<std::filesystem::path> roi_file_path;
  cv::Rect2d initial_roi;
  std::string expected_video_sha256;
  int expected_width{0};
  int expected_height{0};
  std::uint64_t expected_decoded_frames{0};
  std::filesystem::path frames_csv;
  std::filesystem::path summary_json;
  std::uint64_t max_frames{0};
  int opencv_threads{-1};
  bool compute_frame_checksums{true};
};

struct ConfigOverrides {
  std::optional<std::filesystem::path> frames_csv;
  std::optional<std::filesystem::path> summary_json;
  std::optional<std::uint64_t> max_frames;
  std::optional<int> opencv_threads;
  std::optional<bool> compute_frame_checksums;
};

BenchmarkConfig load_benchmark_config(const std::filesystem::path &config_path);

void apply_config_overrides(BenchmarkConfig &config,
                            const ConfigOverrides &overrides);

void validate_config(const BenchmarkConfig &config);

void validate_roi_for_frame(const cv::Rect2d &roi, const cv::Size &frame_size);

} // namespace mosse
