use std::mem::{align_of, size_of};
use std::sync::Arc;

use realfft::{ComplexToReal, RealFftPlanner, RealToComplex};
#[cfg(target_arch = "aarch64")]
use rustfft::algorithm::GoodThomasAlgorithmSmall;
#[cfg(target_arch = "aarch64")]
use rustfft::FftDirection;
use rustfft::{num_complex::Complex32, Fft, FftPlanner};

const FIXED_WIDTH: usize = 60;
const FIXED_HEIGHT: usize = 36;
const FIXED_INNER_ROW_LEN: usize = FIXED_WIDTH / 2;
const FIXED_SPECTRUM_WIDTH: usize = FIXED_INNER_ROW_LEN + 1;
const FIXED_ROW_BATCH_LEN: usize = FIXED_INNER_ROW_LEN * FIXED_HEIGHT;

/// Fixed-size RealFFT 3.5-compatible row processing for the challenge shape.
///
/// RealFFT's even-length transform packs each pair of real values into one
/// complex value, runs an N/2 complex FFT, and applies a small real-spectrum
/// pre/postprocessing pass. RustFFT accepts a whole-number multiple of a plan
/// length, so the 36 independent length-30 transforms can be submitted in one
/// call while retaining RealFFT's arithmetic within each row.
struct FixedRealRows {
    forward: Arc<dyn Fft<f32>>,
    inverse: Arc<dyn Fft<f32>>,
    forward_twiddles: Vec<Complex32>,
    inverse_twiddles: Vec<Complex32>,
    row_batch: Vec<Complex32>,
    scratch: Vec<Complex32>,
}

impl FixedRealRows {
    fn new(planner: &mut FftPlanner<f32>) -> Self {
        let forward = planner.plan_fft_forward(FIXED_INNER_ROW_LEN);
        let inverse = planner.plan_fft_inverse(FIXED_INNER_ROW_LEN);
        let scratch_len = forward
            .get_outofplace_scratch_len()
            .max(inverse.get_outofplace_scratch_len());
        let twiddle_count = FIXED_WIDTH / 4;
        let forward_twiddles = (1..twiddle_count)
            .map(|index| realfft_twiddle(index, FIXED_WIDTH) * 0.5)
            .collect();
        let inverse_twiddles = (1..twiddle_count)
            .map(|index| realfft_twiddle(index, FIXED_WIDTH).conj())
            .collect();

        Self {
            forward,
            inverse,
            forward_twiddles,
            inverse_twiddles,
            row_batch: vec![Complex32::new(0.0, 0.0); FIXED_ROW_BATCH_LEN],
            scratch: vec![Complex32::new(0.0, 0.0); scratch_len],
        }
    }

    fn forward_real(&mut self, input: &mut [f32], output: &mut [Complex32]) {
        assert_eq!(input.len(), FIXED_WIDTH * FIXED_HEIGHT);
        assert_eq!(output.len(), FIXED_SPECTRUM_WIDTH * FIXED_HEIGHT);

        let packed_input = packed_complex_view_mut(input, FIXED_ROW_BATCH_LEN);
        self.forward.process_outofplace_with_scratch(
            packed_input,
            &mut self.row_batch,
            &mut self.scratch,
        );

        for (y, raw_row) in self.row_batch.chunks_exact(FIXED_INNER_ROW_LEN).enumerate() {
            // This is RealFFT 3.5's RealToComplexEven postprocessing, with
            // each completed bin written directly to the retained
            // column-major spectrum.
            let first_value = raw_row[0];
            output[y] = Complex32 {
                re: first_value.re + first_value.im,
                im: 0.0,
            };
            output[FIXED_INNER_ROW_LEN * FIXED_HEIGHT + y] = Complex32 {
                re: first_value.re - first_value.im,
                im: 0.0,
            };

            for (index, &twiddle) in self.forward_twiddles.iter().enumerate() {
                let left_index = index + 1;
                let right_index = FIXED_INNER_ROW_LEN - left_index;
                let out = raw_row[left_index];
                let out_rev = raw_row[right_index];
                let sum = out + out_rev;
                let diff = out - out_rev;
                let half = 0.5f32;
                let twiddled_re_sum = sum * twiddle.re;
                let twiddled_im_sum = sum * twiddle.im;
                let twiddled_re_diff = diff * twiddle.re;
                let twiddled_im_diff = diff * twiddle.im;
                let half_sum_re = half * sum.re;
                let half_diff_im = half * diff.im;

                let output_twiddled_real = twiddled_re_sum.im + twiddled_im_diff.re;
                let output_twiddled_im = twiddled_im_sum.im - twiddled_re_diff.re;

                output[left_index * FIXED_HEIGHT + y] = Complex32 {
                    re: half_sum_re + output_twiddled_real,
                    im: half_diff_im + output_twiddled_im,
                };
                output[right_index * FIXED_HEIGHT + y] = Complex32 {
                    re: half_sum_re - output_twiddled_real,
                    im: output_twiddled_im - half_diff_im,
                };
            }

            // The 31-bin real spectrum is odd-length, so RealFFT handles its
            // unpaired center bin separately.
            let mut center = raw_row[FIXED_INNER_ROW_LEN / 2];
            center.im = -center.im;
            output[(FIXED_INNER_ROW_LEN / 2) * FIXED_HEIGHT + y] = center;
        }
    }

    fn inverse_real(&mut self, spectrum: &[Complex32], output: &mut [f32]) {
        assert_eq!(spectrum.len(), FIXED_SPECTRUM_WIDTH * FIXED_HEIGHT);
        assert_eq!(output.len(), FIXED_WIDTH * FIXED_HEIGHT);

        for (y, packed_row) in self
            .row_batch
            .chunks_exact_mut(FIXED_INNER_ROW_LEN)
            .enumerate()
        {
            // Gather and preprocess in exactly the order used by RealFFT
            // 3.5's ComplexToRealEven implementation. The endpoint imaginary
            // components are explicitly zeroed before entering this chain.
            let mut first_input = spectrum[y];
            let mut last_input = spectrum[FIXED_INNER_ROW_LEN * FIXED_HEIGHT + y];
            first_input.im = 0.0;
            last_input.im = 0.0;
            let first_sum = first_input + last_input;
            let first_diff = first_input - last_input;
            packed_row[0] = Complex32 {
                re: first_sum.re - first_sum.im,
                im: first_diff.re - first_diff.im,
            };

            for (index, &twiddle) in self.inverse_twiddles.iter().enumerate() {
                let left_index = index + 1;
                let right_index = FIXED_INNER_ROW_LEN - left_index;
                let fft_input = spectrum[left_index * FIXED_HEIGHT + y];
                let fft_input_rev = spectrum[right_index * FIXED_HEIGHT + y];
                let sum = fft_input + fft_input_rev;
                let diff = fft_input - fft_input_rev;

                let twiddled_re_sum = sum * twiddle.re;
                let twiddled_im_sum = sum * twiddle.im;
                let twiddled_re_diff = diff * twiddle.re;
                let twiddled_im_diff = diff * twiddle.im;

                let output_twiddled_real = twiddled_re_sum.im + twiddled_im_diff.re;
                let output_twiddled_im = twiddled_im_sum.im - twiddled_re_diff.re;

                packed_row[left_index] = Complex32 {
                    re: sum.re - output_twiddled_real,
                    im: diff.im - output_twiddled_im,
                };
                packed_row[right_index] = Complex32 {
                    re: sum.re + output_twiddled_real,
                    im: -output_twiddled_im - diff.im,
                };
            }

            let center = spectrum[(FIXED_INNER_ROW_LEN / 2) * FIXED_HEIGHT + y];
            let doubled = center + center;
            packed_row[FIXED_INNER_ROW_LEN / 2] = doubled.conj();
        }

        let packed_output = packed_complex_view_mut(output, FIXED_ROW_BATCH_LEN);
        self.inverse.process_outofplace_with_scratch(
            &mut self.row_batch,
            packed_output,
            &mut self.scratch,
        );
    }
}

#[inline]
fn realfft_twiddle(index: usize, fft_len: usize) -> Complex32 {
    // Keep this expression identical to RealFFT 3.5's compute_twiddle
    // implementation before its generic f64-to-f32 conversion.
    let constant = -2f64 * std::f64::consts::PI / fft_len as f64;
    let angle = constant * index as f64;
    Complex32 {
        re: angle.cos() as f32,
        im: angle.sin() as f32,
    }
}

#[inline]
fn packed_complex_view_mut(real: &mut [f32], expected_complex_len: usize) -> &mut [Complex32] {
    assert_eq!(real.len(), expected_complex_len * 2);
    assert_eq!(size_of::<Complex32>(), size_of::<f32>() * 2);
    let pointer = real.as_mut_ptr();
    assert_eq!(pointer.align_offset(align_of::<Complex32>()), 0);

    // SAFETY: The exact element count is checked above; Complex32 is verified
    // to occupy exactly two f32 values and num_complex declares Complex<T> as
    // repr(C) with `re` followed by `im`; and the source pointer is checked
    // for Complex32 alignment. The returned mutable view has the same
    // lifetime and covers exactly the same initialized allocation as `real`.
    unsafe { std::slice::from_raw_parts_mut(pointer.cast::<Complex32>(), expected_complex_len) }
}

#[cfg(target_arch = "aarch64")]
fn plan_fixed_column_fft(
    planner: &mut FftPlanner<f32>,
    direction: FftDirection,
) -> Arc<dyn Fft<f32>> {
    let length_four = planner.plan_fft(4, direction);
    let length_nine = planner.plan_fft(9, direction);
    Arc::new(GoodThomasAlgorithmSmall::new(length_four, length_nine))
}

/// Cached real-row and complex-column plans for a column-major
/// unique-half-spectrum 2-D FFT.
pub(crate) struct Fft2 {
    width: usize,
    height: usize,
    spectrum_width: usize,
    row_forward: Arc<dyn RealToComplex<f32>>,
    row_inverse: Arc<dyn ComplexToReal<f32>>,
    fixed_real_rows: Option<FixedRealRows>,
    column_forward: Arc<dyn Fft<f32>>,
    #[cfg(target_arch = "aarch64")]
    localization_column_forward: Arc<dyn Fft<f32>>,
    column_inverse: Arc<dyn Fft<f32>>,
    row_spectrum: Vec<Complex32>,
    row_scratch: Vec<Complex32>,
    column_scratch: Vec<Complex32>,
}

#[derive(Clone, Copy, Debug)]
pub(crate) struct InverseReduction {
    pub(crate) maximum: f32,
    pub(crate) maximum_index: usize,
    pub(crate) sum: f64,
    pub(crate) sum_of_squares: f64,
}

impl Fft2 {
    pub(crate) fn new(width: usize, height: usize) -> Self {
        let mut real_planner = RealFftPlanner::<f32>::new();
        let row_forward = real_planner.plan_fft_forward(width);
        let row_inverse = real_planner.plan_fft_inverse(width);

        let mut complex_planner = FftPlanner::<f32>::new();
        let fixed_real_rows = if width == FIXED_WIDTH && height == FIXED_HEIGHT {
            Some(FixedRealRows::new(&mut complex_planner))
        } else {
            None
        };
        let column_forward = complex_planner.plan_fft_forward(height);
        let planned_column_inverse = complex_planner.plan_fft_inverse(height);
        #[cfg(target_arch = "aarch64")]
        let (localization_column_forward, column_inverse) =
            if width == FIXED_WIDTH && height == FIXED_HEIGHT {
                (
                    plan_fixed_column_fft(&mut complex_planner, FftDirection::Forward),
                    plan_fixed_column_fft(&mut complex_planner, FftDirection::Inverse),
                )
            } else {
                (Arc::clone(&column_forward), planned_column_inverse)
            };
        #[cfg(not(target_arch = "aarch64"))]
        let column_inverse = planned_column_inverse;
        let spectrum_width = row_forward.complex_len();

        let row_scratch_len = row_forward
            .get_scratch_len()
            .max(row_inverse.get_scratch_len());
        let column_scratch_len = column_forward
            .get_inplace_scratch_len()
            .max(column_inverse.get_inplace_scratch_len());
        #[cfg(target_arch = "aarch64")]
        let column_scratch_len =
            column_scratch_len.max(localization_column_forward.get_inplace_scratch_len());

        Self {
            width,
            height,
            spectrum_width,
            row_forward,
            row_inverse,
            fixed_real_rows,
            column_forward,
            #[cfg(target_arch = "aarch64")]
            localization_column_forward,
            column_inverse,
            row_spectrum: vec![Complex32::new(0.0, 0.0); spectrum_width],
            row_scratch: vec![Complex32::new(0.0, 0.0); row_scratch_len],
            column_scratch: vec![Complex32::new(0.0, 0.0); column_scratch_len],
        }
    }

    pub(crate) fn spatial_len(&self) -> usize {
        self.width * self.height
    }

    pub(crate) fn spectrum_width(&self) -> usize {
        self.spectrum_width
    }

    pub(crate) fn spectrum_len(&self) -> usize {
        self.spectrum_width * self.height
    }

    /// Transforms a row-major real image into a column-major half-spectrum.
    ///
    /// `input` is used as RealFFT scratch and its contents are unspecified
    /// after this call.
    pub(crate) fn forward_real(&mut self, input: &mut [f32], output: &mut [Complex32]) {
        debug_assert_eq!(input.len(), self.spatial_len());
        debug_assert_eq!(output.len(), self.spectrum_len());

        self.forward_real_rows(input, output);
        self.column_forward
            .process_with_scratch(output, &mut self.column_scratch);
    }

    /// Uses the fixed-column plan selected for localization without changing
    /// model-training and model-update transform ordering.
    #[cfg(target_arch = "aarch64")]
    pub(crate) fn forward_real_localization(
        &mut self,
        input: &mut [f32],
        output: &mut [Complex32],
    ) {
        debug_assert_eq!(input.len(), self.spatial_len());
        debug_assert_eq!(output.len(), self.spectrum_len());

        self.forward_real_rows(input, output);
        self.localization_column_forward
            .process_with_scratch(output, &mut self.column_scratch);
    }

    fn forward_real_rows(&mut self, input: &mut [f32], output: &mut [Complex32]) {
        if let Some(fixed_real_rows) = &mut self.fixed_real_rows {
            fixed_real_rows.forward_real(input, output);
        } else {
            for (y, input_row) in input.chunks_exact_mut(self.width).enumerate() {
                self.row_forward
                    .process_with_scratch(input_row, &mut self.row_spectrum, &mut self.row_scratch)
                    .expect("prevalidated real forward FFT buffers");
                for (output_column, &value) in
                    output.chunks_exact_mut(self.height).zip(&self.row_spectrum)
                {
                    output_column[y] = value;
                }
            }
        }
    }

    fn inverse_real_unscaled(&mut self, spectrum: &mut [Complex32], output: &mut [f32]) {
        debug_assert_eq!(spectrum.len(), self.spectrum_len());
        debug_assert_eq!(output.len(), self.spatial_len());

        self.column_inverse
            .process_with_scratch(spectrum, &mut self.column_scratch);
        if let Some(fixed_real_rows) = &mut self.fixed_real_rows {
            fixed_real_rows.inverse_real(spectrum, output);
        } else {
            // Use a bit test rather than usize::is_multiple_of so the source
            // stays compatible with the Raspberry Pi's Rust 1.85 toolchain.
            let even_width = (self.width & 1) == 0;
            for (y, output_row) in output.chunks_exact_mut(self.width).enumerate() {
                for (spectrum_column, row_value) in spectrum
                    .chunks_exact(self.height)
                    .zip(&mut self.row_spectrum)
                {
                    *row_value = spectrum_column[y];
                }
                // After the inverse column transforms these are
                // one-dimensional real-row spectra. Roundoff can leave noise
                // in the components that are mathematically required to be
                // real.
                self.row_spectrum[0].im = 0.0;
                if even_width {
                    self.row_spectrum[self.spectrum_width - 1].im = 0.0;
                }
                self.row_inverse
                    .process_with_scratch(&mut self.row_spectrum, output_row, &mut self.row_scratch)
                    .expect("prevalidated real inverse FFT buffers");
            }
        }
    }

    // Retain the normalized inverse contract for general callers even though
    // the current production tracker uses the reduced response path.
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) fn inverse_real(&mut self, spectrum: &mut [Complex32], output: &mut [f32]) {
        self.inverse_real_unscaled(spectrum, output);
        let scale = 1.0 / self.spatial_len() as f32;
        for value in output {
            *value *= scale;
        }
    }

    #[cfg_attr(feature = "phase-profile", allow(dead_code))]
    pub(crate) fn inverse_real_reduced(
        &mut self,
        spectrum: &mut [Complex32],
        output: &mut [f32],
    ) -> InverseReduction {
        self.inverse_real_unscaled(spectrum, output);
        reduce_scaled_inverse_output(output, 1.0 / self.spatial_len() as f32)
    }

    #[cfg(feature = "phase-profile")]
    #[allow(dead_code)]
    pub(crate) fn profile_inverse_real_unscaled(
        &mut self,
        spectrum: &mut [Complex32],
        output: &mut [f32],
    ) {
        self.inverse_real_unscaled(spectrum, output);
    }

    #[cfg(feature = "phase-profile")]
    #[allow(dead_code)]
    pub(crate) fn profile_reduce_inverse_output(&self, output: &[f32]) -> InverseReduction {
        reduce_scaled_inverse_output(output, 1.0 / self.spatial_len() as f32)
    }
}

fn reduce_scaled_inverse_output(unscaled: &[f32], scale: f32) -> InverseReduction {
    let mut maximum = f32::NEG_INFINITY;
    let mut maximum_index = 0usize;
    let mut sum = 0.0f64;
    let mut sum_of_squares = 0.0f64;
    for (index, &value) in unscaled.iter().enumerate() {
        let value = value * scale;
        if value > maximum {
            maximum = value;
            maximum_index = index;
        }
        let value = value as f64;
        sum += value;
        sum_of_squares += value * value;
    }
    InverseReduction {
        maximum,
        maximum_index,
        sum,
        sum_of_squares,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const ABS_TOLERANCE: f32 = 3.0e-4;
    const REL_TOLERANCE: f32 = 3.0e-5;
    const INTERMEDIATE_ABSOLUTE_FLOOR: f32 = 5.0e-7;
    const INTERMEDIATE_PEAK_RELATIVE_TOLERANCE: f32 = 5.0e-6;

    struct FullComplexFft2 {
        width: usize,
        row_forward: Arc<dyn Fft<f32>>,
        row_inverse: Arc<dyn Fft<f32>>,
        column_forward: Arc<dyn Fft<f32>>,
        column_inverse: Arc<dyn Fft<f32>>,
        row_scratch: Vec<Complex32>,
        column: Vec<Complex32>,
        column_scratch: Vec<Complex32>,
    }

    impl FullComplexFft2 {
        fn new(width: usize, height: usize) -> Self {
            let mut planner = FftPlanner::<f32>::new();
            let row_forward = planner.plan_fft_forward(width);
            let row_inverse = planner.plan_fft_inverse(width);
            let column_forward = planner.plan_fft_forward(height);
            let column_inverse = planner.plan_fft_inverse(height);
            let row_scratch_len = row_forward
                .get_inplace_scratch_len()
                .max(row_inverse.get_inplace_scratch_len());
            let column_scratch_len = column_forward
                .get_inplace_scratch_len()
                .max(column_inverse.get_inplace_scratch_len());
            Self {
                width,
                row_forward,
                row_inverse,
                column_forward,
                column_inverse,
                row_scratch: vec![Complex32::new(0.0, 0.0); row_scratch_len],
                column: vec![Complex32::new(0.0, 0.0); height],
                column_scratch: vec![Complex32::new(0.0, 0.0); column_scratch_len],
            }
        }

        fn forward_real(&mut self, input: &[f32]) -> Vec<Complex32> {
            let mut output: Vec<_> = input
                .iter()
                .map(|&value| Complex32::new(value, 0.0))
                .collect();
            self.transform(&mut output, false);
            output
        }

        fn inverse_real(&mut self, spectrum: &mut [Complex32]) -> Vec<f32> {
            self.transform(spectrum, true);
            let scale = 1.0 / spectrum.len() as f32;
            spectrum.iter().map(|value| value.re * scale).collect()
        }

        fn transform(&mut self, data: &mut [Complex32], inverse: bool) {
            let row_plan = if inverse {
                &self.row_inverse
            } else {
                &self.row_forward
            };
            for row in data.chunks_exact_mut(self.width) {
                row_plan.process_with_scratch(row, &mut self.row_scratch);
            }

            let column_plan = if inverse {
                &self.column_inverse
            } else {
                &self.column_forward
            };
            for x in 0..self.width {
                for (y, slot) in self.column.iter_mut().enumerate() {
                    *slot = data[y * self.width + x];
                }
                column_plan.process_with_scratch(&mut self.column, &mut self.column_scratch);
                for (y, &value) in self.column.iter().enumerate() {
                    data[y * self.width + x] = value;
                }
            }
        }
    }

    /// Experiment 006's row-major half-spectrum implementation, retained
    /// here only as a bitwise mapping reference for Experiment 009.
    struct LegacyRowMajorFft2 {
        width: usize,
        height: usize,
        spectrum_width: usize,
        row_forward: Arc<dyn RealToComplex<f32>>,
        row_inverse: Arc<dyn ComplexToReal<f32>>,
        column_forward: Arc<dyn Fft<f32>>,
        column_inverse: Arc<dyn Fft<f32>>,
        row_real: Vec<f32>,
        row_scratch: Vec<Complex32>,
        column: Vec<Complex32>,
        column_scratch: Vec<Complex32>,
    }

    impl LegacyRowMajorFft2 {
        fn new(width: usize, height: usize) -> Self {
            let mut real_planner = RealFftPlanner::<f32>::new();
            let row_forward = real_planner.plan_fft_forward(width);
            let row_inverse = real_planner.plan_fft_inverse(width);

            let mut complex_planner = FftPlanner::<f32>::new();
            let column_forward = complex_planner.plan_fft_forward(height);
            let column_inverse = complex_planner.plan_fft_inverse(height);
            let spectrum_width = row_forward.complex_len();

            let row_scratch_len = row_forward
                .get_scratch_len()
                .max(row_inverse.get_scratch_len());
            let column_scratch_len = column_forward
                .get_inplace_scratch_len()
                .max(column_inverse.get_inplace_scratch_len());

            Self {
                width,
                height,
                spectrum_width,
                row_forward,
                row_inverse,
                column_forward,
                column_inverse,
                row_real: vec![0.0; width],
                row_scratch: vec![Complex32::new(0.0, 0.0); row_scratch_len],
                column: vec![Complex32::new(0.0, 0.0); height],
                column_scratch: vec![Complex32::new(0.0, 0.0); column_scratch_len],
            }
        }

        fn spectrum_len(&self) -> usize {
            self.spectrum_width * self.height
        }

        fn forward_real(&mut self, input: &[f32]) -> Vec<Complex32> {
            let mut output = vec![Complex32::new(0.0, 0.0); self.spectrum_len()];
            for (input_row, output_row) in input
                .chunks_exact(self.width)
                .zip(output.chunks_exact_mut(self.spectrum_width))
            {
                self.row_real.copy_from_slice(input_row);
                self.row_forward
                    .process_with_scratch(&mut self.row_real, output_row, &mut self.row_scratch)
                    .expect("prevalidated legacy real forward FFT buffers");
            }
            self.transform_columns(&mut output, false);
            output
        }

        fn inverse_real(&mut self, spectrum: &mut [Complex32]) -> Vec<f32> {
            self.transform_columns(spectrum, true);
            let mut output = vec![0.0; self.width * self.height];
            let scale = 1.0 / output.len() as f32;
            let even_width = (self.width & 1) == 0;
            for (spectrum_row, output_row) in spectrum
                .chunks_exact_mut(self.spectrum_width)
                .zip(output.chunks_exact_mut(self.width))
            {
                spectrum_row[0].im = 0.0;
                if even_width {
                    spectrum_row[self.spectrum_width - 1].im = 0.0;
                }
                self.row_inverse
                    .process_with_scratch(spectrum_row, output_row, &mut self.row_scratch)
                    .expect("prevalidated legacy real inverse FFT buffers");
                for value in output_row {
                    *value *= scale;
                }
            }
            output
        }

        fn transform_columns(&mut self, data: &mut [Complex32], inverse: bool) {
            let column_plan = if inverse {
                &self.column_inverse
            } else {
                &self.column_forward
            };
            for x in 0..self.spectrum_width {
                for (y, slot) in self.column.iter_mut().enumerate() {
                    *slot = data[y * self.spectrum_width + x];
                }
                column_plan.process_with_scratch(&mut self.column, &mut self.column_scratch);
                for (y, &value) in self.column.iter().enumerate() {
                    data[y * self.spectrum_width + x] = value;
                }
            }
        }
    }

    #[inline]
    fn half_index(kx: usize, ky: usize, height: usize) -> usize {
        kx * height + ky
    }

    fn deterministic_input(width: usize, height: usize) -> Vec<f32> {
        deterministic_input_with_seed(width, height, 0)
    }

    fn deterministic_input_with_seed(width: usize, height: usize, seed: usize) -> Vec<f32> {
        (0..width * height)
            .map(|i| {
                let integer = ((i * (73 + seed * 2)
                    + (i / width) * (29 + seed * 3)
                    + 17
                    + seed * seed)
                    % 251) as f32;
                (integer - 125.0) / 37.0
            })
            .collect()
    }

    #[derive(Clone, Copy, Debug)]
    struct TestResponseStats {
        peak: f64,
        mean: f64,
        stddev: f64,
        psr: f64,
        delta_x: i32,
        delta_y: i32,
    }

    fn calculate_response_stats(
        response: &[f32],
        width: usize,
        height: usize,
        epsilon: f64,
    ) -> TestResponseStats {
        assert_eq!(response.len(), width * height);
        let mut maximum = f32::NEG_INFINITY;
        let mut maximum_index = 0usize;
        let mut sum = 0.0f64;
        let mut sum_of_squares = 0.0f64;
        for (index, &value) in response.iter().enumerate() {
            if value > maximum {
                maximum = value;
                maximum_index = index;
            }
            let value = value as f64;
            sum += value;
            sum_of_squares += value * value;
        }
        let count = response.len() as f64;
        let mean = sum / count;
        let variance = (sum_of_squares / count - mean * mean).max(0.0);
        let stddev = variance.sqrt();
        let peak = maximum as f64;
        let maximum_x = maximum_index % width;
        let maximum_y = maximum_index / width;
        TestResponseStats {
            peak,
            mean,
            stddev,
            psr: (peak - mean) / (stddev + epsilon),
            delta_x: maximum_x as i32 - (width / 2) as i32,
            delta_y: maximum_y as i32 - (height / 2) as i32,
        }
    }

    fn calculate_reduction(response: &[f32]) -> InverseReduction {
        let mut maximum = f32::NEG_INFINITY;
        let mut maximum_index = 0usize;
        let mut sum = 0.0f64;
        let mut sum_of_squares = 0.0f64;
        for (index, &value) in response.iter().enumerate() {
            if value > maximum {
                maximum = value;
                maximum_index = index;
            }
            let value = value as f64;
            sum += value;
            sum_of_squares += value * value;
        }
        InverseReduction {
            maximum,
            maximum_index,
            sum,
            sum_of_squares,
        }
    }

    fn assert_reduction_bits_eq(
        actual: InverseReduction,
        expected: InverseReduction,
        context: &str,
    ) {
        assert_eq!(
            actual.maximum.to_bits(),
            expected.maximum.to_bits(),
            "{context} maximum"
        );
        assert_eq!(
            actual.maximum_index, expected.maximum_index,
            "{context} maximum index"
        );
        assert_eq!(
            actual.sum.to_bits(),
            expected.sum.to_bits(),
            "{context} sum"
        );
        assert_eq!(
            actual.sum_of_squares.to_bits(),
            expected.sum_of_squares.to_bits(),
            "{context} sum of squares"
        );
    }

    fn assert_f64_close(actual: f64, expected: f64, context: &str) {
        let error = (actual - expected).abs();
        let limit = 1.0e-6 + 1.0e-4 * expected.abs();
        assert!(
            error <= limit,
            "{context}: actual={actual:?}, expected={expected:?}, error={error}, limit={limit}"
        );
    }

    fn assert_float_close(actual: f32, expected: f32, context: &str) {
        let error = (actual - expected).abs();
        let limit = ABS_TOLERANCE + REL_TOLERANCE * expected.abs();
        assert!(
            error <= limit,
            "{context}: actual={actual:?}, expected={expected:?}, error={error}, limit={limit}"
        );
    }

    fn assert_complex_close(actual: Complex32, expected: Complex32, context: &str) {
        assert_float_close(actual.re, expected.re, &format!("{context}.re"));
        assert_float_close(actual.im, expected.im, &format!("{context}.im"));
    }

    fn assert_complex_bits_eq(actual: Complex32, expected: Complex32, context: &str) {
        assert_eq!(
            actual.re.to_bits(),
            expected.re.to_bits(),
            "{context}.re: actual={:?}, expected={:?}",
            actual.re,
            expected.re
        );
        assert_eq!(
            actual.im.to_bits(),
            expected.im.to_bits(),
            "{context}.im: actual={:?}, expected={:?}",
            actual.im,
            expected.im
        );
    }

    #[derive(Clone, Copy, Debug)]
    struct DeltaMetrics {
        reference_peak: f32,
        max_absolute: f32,
        max_conditioned_relative: f32,
    }

    fn complex_delta_metrics(actual: &[Complex32], expected: &[Complex32]) -> DeltaMetrics {
        assert_eq!(actual.len(), expected.len());
        let reference_peak = expected
            .iter()
            .map(|value| value.norm())
            .fold(0.0f32, f32::max);
        let conditioning_floor = reference_peak * 1.0e-6;
        let mut max_absolute = 0.0f32;
        let mut max_conditioned_relative = 0.0f32;
        for (&actual, &expected) in actual.iter().zip(expected) {
            let error = (actual - expected).norm();
            max_absolute = max_absolute.max(error);
            let magnitude = expected.norm();
            if magnitude > conditioning_floor {
                max_conditioned_relative = max_conditioned_relative.max(error / magnitude);
            }
        }
        DeltaMetrics {
            reference_peak,
            max_absolute,
            max_conditioned_relative,
        }
    }

    fn float_delta_metrics(actual: &[f32], expected: &[f32]) -> DeltaMetrics {
        assert_eq!(actual.len(), expected.len());
        let reference_peak = expected
            .iter()
            .map(|value| value.abs())
            .fold(0.0f32, f32::max);
        let conditioning_floor = reference_peak * 1.0e-6;
        let mut max_absolute = 0.0f32;
        let mut max_conditioned_relative = 0.0f32;
        for (&actual, &expected) in actual.iter().zip(expected) {
            let error = (actual - expected).abs();
            max_absolute = max_absolute.max(error);
            if expected.abs() > conditioning_floor {
                max_conditioned_relative = max_conditioned_relative.max(error / expected.abs());
            }
        }
        DeltaMetrics {
            reference_peak,
            max_absolute,
            max_conditioned_relative,
        }
    }

    fn assert_measured_delta(label: &str, metrics: DeltaMetrics) {
        // Across goal, accumulated A/B, conditioned H, response spectrum, and
        // spatial response, the measured maximum error was 2.8e-6 of the
        // corresponding family's peak. Keep a single conservative 5e-6 gate.
        let limit = INTERMEDIATE_ABSOLUTE_FLOOR
            + INTERMEDIATE_PEAK_RELATIVE_TOLERANCE * metrics.reference_peak;
        assert!(
            metrics.max_absolute <= limit,
            "{label}: peak={}, max_abs={}, max_conditioned_rel={}, limit={limit}",
            metrics.reference_peak,
            metrics.max_absolute,
            metrics.max_conditioned_relative
        );
    }

    fn assert_round_trip(width: usize, height: usize, input: &[f32]) {
        let mut fft = Fft2::new(width, height);
        let mut spectrum = vec![Complex32::new(0.0, 0.0); fft.spectrum_len()];
        let mut restored = vec![0.0; fft.spatial_len()];
        let mut consumed = input.to_vec();
        fft.forward_real(&mut consumed, &mut spectrum);
        fft.inverse_real(&mut spectrum, &mut restored);
        for (index, (&expected, &actual)) in input.iter().zip(&restored).enumerate() {
            assert_float_close(actual, expected, &format!("round trip index {index}"));
        }
    }

    fn expand_half_spectrum(half: &[Complex32], width: usize, height: usize) -> Vec<Complex32> {
        let spectrum_width = width / 2 + 1;
        assert_eq!(half.len(), spectrum_width * height);
        let mut full = vec![Complex32::new(0.0, 0.0); width * height];
        for ky in 0..height {
            for kx in 0..spectrum_width {
                full[ky * width + kx] = half[half_index(kx, ky, height)];
            }
            for kx in spectrum_width..width {
                let source_y = (height - ky) % height;
                let source_x = width - kx;
                full[ky * width + kx] = half[half_index(source_x, source_y, height)].conj();
            }
        }
        full
    }

    fn reconstruct_filter_value(numerator: Complex32, denominator: Complex32) -> Complex32 {
        let divisor = denominator.re * denominator.re + denominator.im * denominator.im;
        if divisor > 0.0 && divisor.is_finite() {
            Complex32::new(
                (numerator.re * denominator.re + numerator.im * denominator.im) / divisor,
                -(numerator.im * denominator.re + numerator.re * denominator.im) / divisor,
            )
        } else {
            Complex32::new(0.0, 0.0)
        }
    }

    #[test]
    fn fixed_geometry_has_expected_spatial_and_spectrum_lengths() {
        let fft = Fft2::new(60, 36);
        assert_eq!(fft.spatial_len(), 2_160);
        assert_eq!(fft.spectrum_width(), 31);
        assert_eq!(fft.spectrum_len(), 1_116);
        assert!(fft.fixed_real_rows.is_some());
    }

    #[test]
    #[cfg(target_arch = "aarch64")]
    fn localization_column_plan_matches_model_plan() {
        let input = deterministic_input(FIXED_WIDTH, FIXED_HEIGHT);
        let mut localization_input = input.clone();
        let mut model_input = input;
        let mut localization_fft = Fft2::new(FIXED_WIDTH, FIXED_HEIGHT);
        let mut model_fft = Fft2::new(FIXED_WIDTH, FIXED_HEIGHT);
        let mut localization = vec![Complex32::new(0.0, 0.0); localization_fft.spectrum_len()];
        let mut model = vec![Complex32::new(0.0, 0.0); model_fft.spectrum_len()];

        localization_fft.forward_real_localization(&mut localization_input, &mut localization);
        model_fft.forward_real(&mut model_input, &mut model);

        for (index, (&actual, &expected)) in localization.iter().zip(&model).enumerate() {
            let label = format!("localization plan bin {index}");
            assert_complex_close(actual, expected, &label);
        }
    }

    #[test]
    fn scaled_inverse_reduction_preserves_operation_order_ties_and_signed_zero() {
        let scale = 1.0 / (FIXED_WIDTH * FIXED_HEIGHT) as f32;
        let deterministic: Vec<f32> = (0..FIXED_WIDTH * FIXED_HEIGHT)
            .map(|index| {
                let magnitude = ((index * 73 + index / FIXED_WIDTH * 29 + 17) % 251) as f32;
                (magnitude - 125.0) * 37.25
            })
            .collect();
        let cases = [
            ("deterministic", deterministic),
            ("first maximum tie", vec![-3.0, 11.0, 4.0, 11.0, -8.0]),
            (
                "negative zero first",
                vec![f32::NEG_INFINITY, -0.0, 0.0, -1.0, -0.0],
            ),
            ("positive zero first", vec![0.0, -0.0, -1.0, 0.0]),
        ];

        for (label, unscaled) in cases {
            let normalized: Vec<_> = unscaled.iter().map(|&value| value * scale).collect();
            let expected = calculate_reduction(&normalized);
            let actual = reduce_scaled_inverse_output(&unscaled, scale);
            assert_reduction_bits_eq(actual, expected, label);
        }
    }

    #[test]
    fn reduced_inverse_matches_normalized_composition_across_dirty_consecutive_calls() {
        let width = FIXED_WIDTH;
        let height = FIXED_HEIGHT;
        let mut impulse = vec![0.0; width * height];
        impulse[17 * width + 29] = 1.0;
        let checkerboard: Vec<f32> = (0..width * height)
            .map(|index| {
                if ((index + index / width) & 1) == 0 {
                    -1.0
                } else {
                    1.0
                }
            })
            .collect();
        let signals = [
            ("deterministic", deterministic_input(width, height)),
            ("impulse", impulse),
            ("checkerboard", checkerboard),
        ];
        let mut forward = Fft2::new(width, height);
        let mut normalized_inverse = Fft2::new(width, height);
        let mut reduced_inverse = Fft2::new(width, height);
        let dirty = f32::from_bits(0x7fa1_2345);
        let mut normalized_output = vec![dirty; width * height];
        let mut unscaled_output = vec![-dirty; width * height];
        let scale = 1.0 / (width * height) as f32;

        for (call_index, (label, mut signal)) in signals.into_iter().enumerate() {
            let mut spectrum = vec![Complex32::new(dirty, -dirty); forward.spectrum_len()];
            forward.forward_real(&mut signal, &mut spectrum);
            let mut normalized_spectrum = spectrum.clone();
            let mut reduced_spectrum = spectrum;
            normalized_output.fill(f32::from_bits(0x7f91_0000 + call_index as u32));
            unscaled_output.fill(f32::from_bits(0xff91_0100 + call_index as u32));

            normalized_inverse.inverse_real(&mut normalized_spectrum, &mut normalized_output);
            let actual =
                reduced_inverse.inverse_real_reduced(&mut reduced_spectrum, &mut unscaled_output);
            let expected = calculate_reduction(&normalized_output);
            assert_reduction_bits_eq(actual, expected, label);

            for (index, (&unscaled, &normalized)) in
                unscaled_output.iter().zip(&normalized_output).enumerate()
            {
                assert_eq!(
                    (unscaled * scale).to_bits(),
                    normalized.to_bits(),
                    "{label} normalized output {index}"
                );
            }
        }
    }

    #[test]
    fn fixed_real_row_batch_matches_generic_path_bit_for_bit() {
        let width = FIXED_WIDTH;
        let height = FIXED_HEIGHT;
        let mut impulse = vec![0.0; width * height];
        impulse[17 * width + 29] = 1.0;
        let checkerboard: Vec<f32> = (0..width * height)
            .map(|index| {
                if ((index + index / width) & 1) == 0 {
                    -1.0
                } else {
                    1.0
                }
            })
            .collect();
        let signals = [
            ("impulse", impulse),
            ("constant", vec![3.25; width * height]),
            ("checkerboard", checkerboard),
            ("deterministic", deterministic_input(width, height)),
        ];

        let mut specialized = Fft2::new(width, height);
        let mut generic = Fft2::new(width, height);
        generic.fixed_real_rows = None;

        for (call_index, (label, input)) in signals.into_iter().enumerate() {
            let fixed_rows = specialized
                .fixed_real_rows
                .as_mut()
                .expect("fixed geometry must use the batched row path");
            for (index, value) in fixed_rows.row_batch.iter_mut().enumerate() {
                *value = Complex32::new(
                    index as f32 + call_index as f32 + 0.25,
                    -(index as f32) - call_index as f32 - 0.5,
                );
            }
            for (index, value) in fixed_rows.scratch.iter_mut().enumerate() {
                *value = Complex32::new(
                    index as f32 + call_index as f32 + 11.0,
                    index as f32 - call_index as f32 - 17.0,
                );
            }

            let mut specialized_input = input.clone();
            let mut generic_input = input;
            let mut specialized_spectrum =
                vec![Complex32::new(101.0, -103.0); specialized.spectrum_len()];
            let mut generic_spectrum = vec![Complex32::new(-107.0, 109.0); generic.spectrum_len()];
            specialized.forward_real(&mut specialized_input, &mut specialized_spectrum);
            generic.forward_real(&mut generic_input, &mut generic_spectrum);

            for (index, (&actual, &expected)) in specialized_spectrum
                .iter()
                .zip(&generic_spectrum)
                .enumerate()
            {
                assert_complex_bits_eq(
                    actual,
                    expected,
                    &format!("{label} consecutive forward bin {index}"),
                );
            }

            let fixed_rows = specialized
                .fixed_real_rows
                .as_mut()
                .expect("fixed geometry must use the batched row path");
            fixed_rows
                .row_batch
                .fill(Complex32::new(113.0 + call_index as f32, -127.0));
            fixed_rows
                .scratch
                .fill(Complex32::new(-131.0, 137.0 + call_index as f32));

            let mut specialized_spatial = vec![139.0; specialized.spatial_len()];
            let mut generic_spatial = vec![-149.0; generic.spatial_len()];
            specialized.inverse_real(&mut specialized_spectrum, &mut specialized_spatial);
            generic.inverse_real(&mut generic_spectrum, &mut generic_spatial);

            for (index, (&actual, &expected)) in
                specialized_spatial.iter().zip(&generic_spatial).enumerate()
            {
                assert_eq!(
                    actual.to_bits(),
                    expected.to_bits(),
                    "{label} consecutive inverse value {index}: \
                     actual={actual:?}, expected={expected:?}"
                );
            }
        }
    }

    #[test]
    fn batched_columns_match_separate_transforms_bit_for_bit() {
        let height = 36;
        let spectrum_width = 31;
        let input: Vec<_> = (0..height * spectrum_width)
            .map(|index| {
                let real = ((index * 41 + index / height * 17 + 13) % 257) as f32 / 19.0;
                let imaginary = ((index * 67 + index / height * 23 + 29) % 263) as f32 / -31.0;
                Complex32::new(real, imaginary)
            })
            .collect();

        let mut planner = FftPlanner::<f32>::new();
        let plans = [
            ("forward", planner.plan_fft_forward(height)),
            ("inverse", planner.plan_fft_inverse(height)),
        ];
        for (label, plan) in plans {
            let scratch_len = plan.get_inplace_scratch_len();
            let initial_scratch: Vec<_> = (0..scratch_len)
                .map(|index| Complex32::new(index as f32 + 0.5, -(index as f32) - 0.25))
                .collect();
            let mut batched = input.clone();
            let mut batched_scratch = initial_scratch.clone();
            plan.process_with_scratch(&mut batched, &mut batched_scratch);

            let mut separate = input.clone();
            let mut separate_scratch = initial_scratch;
            for column in separate.chunks_exact_mut(height) {
                plan.process_with_scratch(column, &mut separate_scratch);
            }

            for (index, (&actual, &expected)) in batched.iter().zip(&separate).enumerate() {
                assert_complex_bits_eq(
                    actual,
                    expected,
                    &format!("{label} batched column value {index}"),
                );
            }
        }
    }

    #[test]
    fn column_major_pipeline_matches_legacy_row_major() {
        for (width, height) in [(60, 36), (12, 10), (5, 7)] {
            let input = deterministic_input(width, height);
            let mut legacy = LegacyRowMajorFft2::new(width, height);
            let legacy_spectrum = legacy.forward_real(&input);

            let mut current = Fft2::new(width, height);
            assert_eq!(
                current.fixed_real_rows.is_some(),
                (width, height) == (FIXED_WIDTH, FIXED_HEIGHT)
            );
            let mut consumed = input;
            let mut current_spectrum = vec![Complex32::new(0.0, 0.0); current.spectrum_len()];
            current.forward_real(&mut consumed, &mut current_spectrum);

            for ky in 0..height {
                for kx in 0..current.spectrum_width() {
                    let actual = current_spectrum[half_index(kx, ky, height)];
                    let expected = legacy_spectrum[ky * current.spectrum_width() + kx];
                    let label = format!("{width}x{height} mapped bin ({kx}, {ky})");
                    if cfg!(target_arch = "aarch64")
                        && (width, height) == (FIXED_WIDTH, FIXED_HEIGHT)
                    {
                        // The fixed AArch64 column plan uses a faster
                        // Good-Thomas 4x9 factorization. It is mathematically
                        // equivalent but has a different floating operation
                        // order than RustFFT's generic 6x6 planner choice.
                        assert_complex_close(actual, expected, &label);
                    } else {
                        assert_complex_bits_eq(actual, expected, &label);
                    }
                }
            }

            let mut legacy_for_inverse = legacy_spectrum;
            let legacy_spatial = legacy.inverse_real(&mut legacy_for_inverse);
            let mut current_spatial = vec![0.0; current.spatial_len()];
            current.inverse_real(&mut current_spectrum, &mut current_spatial);
            for (index, (&actual, &expected)) in
                current_spatial.iter().zip(&legacy_spatial).enumerate()
            {
                let label = format!("{width}x{height} inverse value {index}");
                if cfg!(target_arch = "aarch64") && (width, height) == (FIXED_WIDTH, FIXED_HEIGHT) {
                    assert_float_close(actual, expected, &label);
                } else {
                    assert_eq!(
                        actual.to_bits(),
                        expected.to_bits(),
                        "{label}: actual={actual:?}, expected={expected:?}"
                    );
                }
            }
        }
    }

    #[test]
    fn round_trips_fixed_geometry_signal_families() {
        let width = 60;
        let height = 36;
        let mut impulse = vec![0.0; width * height];
        impulse[17 * width + 29] = 1.0;
        assert_round_trip(width, height, &impulse);
        assert_round_trip(width, height, &vec![3.25; width * height]);
        let checkerboard: Vec<f32> = (0..width * height)
            .map(|i| if (i + i / width) % 2 == 0 { -1.0 } else { 1.0 })
            .collect();
        assert_round_trip(width, height, &checkerboard);
        assert_round_trip(width, height, &deterministic_input(width, height));
    }

    #[test]
    fn odd_width_round_trip_preserves_non_nyquist_last_bin() {
        let width = 5;
        let height = 7;
        assert_round_trip(width, height, &deterministic_input(width, height));
    }

    #[test]
    fn unique_bins_match_full_complex_reference() {
        let width = 60;
        let height = 36;
        let input = deterministic_input(width, height);
        let mut half_fft = Fft2::new(width, height);
        let mut half = vec![Complex32::new(0.0, 0.0); half_fft.spectrum_len()];
        let mut consumed = input.clone();
        half_fft.forward_real(&mut consumed, &mut half);

        let mut full_fft = FullComplexFft2::new(width, height);
        let full = full_fft.forward_real(&input);
        for ky in 0..height {
            for kx in 0..half_fft.spectrum_width() {
                assert_complex_close(
                    half[half_index(kx, ky, height)],
                    full[ky * width + kx],
                    &format!("bin ({ky}, {kx})"),
                );
            }
        }
    }

    #[test]
    fn half_expansion_and_inverse_match_full_complex_response() {
        let width = 60;
        let height = 36;
        let input = deterministic_input(width, height);
        let mut half_fft = Fft2::new(width, height);
        let mut half = vec![Complex32::new(0.0, 0.0); half_fft.spectrum_len()];
        let mut consumed = input.clone();
        half_fft.forward_real(&mut consumed, &mut half);

        let mut half_for_inverse = half.clone();
        let mut half_response = vec![0.0; width * height];
        half_fft.inverse_real(&mut half_for_inverse, &mut half_response);

        let mut full = expand_half_spectrum(&half, width, height);
        let mut full_fft = FullComplexFft2::new(width, height);
        let full_response = full_fft.inverse_real(&mut full);
        for (index, (&expected, &actual)) in full_response.iter().zip(&half_response).enumerate() {
            assert_float_close(actual, expected, &format!("inverse index {index}"));
        }
    }

    #[test]
    fn dc_and_nyquist_columns_obey_vertical_hermitian_symmetry() {
        let width = 60;
        let height = 36;
        let input = deterministic_input(width, height);
        let mut fft = Fft2::new(width, height);
        let spectrum_width = fft.spectrum_width();
        let mut spectrum = vec![Complex32::new(0.0, 0.0); fft.spectrum_len()];
        let mut consumed = input;
        fft.forward_real(&mut consumed, &mut spectrum);

        for &kx in &[0, spectrum_width - 1] {
            assert_float_close(
                spectrum[half_index(kx, 0, height)].im,
                0.0,
                "ky=0 endpoint imaginary",
            );
            assert_float_close(
                spectrum[half_index(kx, height / 2, height)].im,
                0.0,
                "ky=H/2 endpoint imaginary",
            );
            for ky in 1..height {
                let mirrored_y = (height - ky) % height;
                assert_complex_close(
                    spectrum[half_index(kx, ky, height)],
                    spectrum[half_index(kx, mirrored_y, height)].conj(),
                    &format!("endpoint ({ky}, {kx})"),
                );
            }
        }
    }

    #[test]
    fn dirty_reusable_scratch_does_not_change_results() {
        let width = 60;
        let height = 36;
        let input = deterministic_input(width, height);
        let mut clean = Fft2::new(width, height);
        let mut dirty = Fft2::new(width, height);
        for (index, value) in dirty.row_scratch.iter_mut().enumerate() {
            *value = Complex32::new(index as f32 + 0.25, -(index as f32) - 0.5);
        }
        for (index, value) in dirty.row_spectrum.iter_mut().enumerate() {
            *value = Complex32::new(index as f32 * 3.0, index as f32 * -7.0);
        }
        for (index, value) in dirty.column_scratch.iter_mut().enumerate() {
            *value = Complex32::new(index as f32 + 13.0, index as f32 - 19.0);
        }

        let mut expected = vec![Complex32::new(0.0, 0.0); clean.spectrum_len()];
        let mut actual = vec![Complex32::new(0.0, 0.0); dirty.spectrum_len()];
        let mut clean_input = input.clone();
        let mut dirty_input = input;
        clean.forward_real(&mut clean_input, &mut expected);
        dirty.forward_real(&mut dirty_input, &mut actual);
        for (index, (&expected, &actual)) in expected.iter().zip(&actual).enumerate() {
            assert_eq!(
                actual.re.to_bits(),
                expected.re.to_bits(),
                "forward real bin {index}"
            );
            assert_eq!(
                actual.im.to_bits(),
                expected.im.to_bits(),
                "forward imaginary bin {index}"
            );
        }

        dirty.row_scratch.fill(Complex32::new(43.0, -17.0));
        dirty.row_spectrum.fill(Complex32::new(-23.0, 61.0));
        dirty.column_scratch.fill(Complex32::new(29.0, -31.0));
        let mut expected_response = vec![0.0; clean.spatial_len()];
        let mut actual_response = vec![0.0; dirty.spatial_len()];
        clean.inverse_real(&mut expected, &mut expected_response);
        dirty.inverse_real(&mut actual, &mut actual_response);
        for (index, (&expected, &actual)) in
            expected_response.iter().zip(&actual_response).enumerate()
        {
            assert_eq!(
                actual.to_bits(),
                expected.to_bits(),
                "inverse sample {index}"
            );
        }
    }

    #[test]
    fn half_spectrum_mosse_intermediates_match_full_complex_reference() {
        let width = 60;
        let height = 36;
        let training_samples: Vec<_> = [3, 11, 29, 47]
            .into_iter()
            .map(|seed| deterministic_input_with_seed(width, height, seed))
            .collect();
        let localization_sample = deterministic_input_with_seed(width, height, 71);
        let goal_spatial: Vec<f32> = (0..width * height)
            .map(|i| {
                let x = (i % width) as f32 - width as f32 * 0.5;
                let y = (i / width) as f32 - height as f32 * 0.5;
                (-(x * x + y * y) / 18.0).exp()
            })
            .collect();

        let mut half_fft = Fft2::new(width, height);
        let mut goal_half = vec![Complex32::new(0.0, 0.0); half_fft.spectrum_len()];
        let mut goal_for_half = goal_spatial.clone();
        half_fft.forward_real(&mut goal_for_half, &mut goal_half);
        let mut full_fft = FullComplexFft2::new(width, height);
        let goal_full = full_fft.forward_real(&goal_spatial);

        let mut numerator_half = vec![Complex32::new(0.0, 0.0); half_fft.spectrum_len()];
        let mut denominator_half = vec![Complex32::new(0.0, 0.0); half_fft.spectrum_len()];
        let mut numerator_full = vec![Complex32::new(0.0, 0.0); width * height];
        let mut denominator_full = vec![Complex32::new(0.0, 0.0); width * height];
        for sample_spatial in &training_samples {
            let mut sample_half = vec![Complex32::new(0.0, 0.0); half_fft.spectrum_len()];
            let mut sample_for_half = sample_spatial.clone();
            half_fft.forward_real(&mut sample_for_half, &mut sample_half);
            let sample_full = full_fft.forward_real(sample_spatial);
            for index in 0..half_fft.spectrum_len() {
                numerator_half[index] += goal_half[index] * sample_half[index].conj();
                denominator_half[index] += sample_half[index] * sample_half[index].conj();
            }
            for index in 0..width * height {
                numerator_full[index] += goal_full[index] * sample_full[index].conj();
                denominator_full[index] += sample_full[index] * sample_full[index].conj();
            }
        }

        let mut localization_half = vec![Complex32::new(0.0, 0.0); half_fft.spectrum_len()];
        let mut localization_for_half = localization_sample.clone();
        half_fft.forward_real(&mut localization_for_half, &mut localization_half);
        let localization_full = full_fft.forward_real(&localization_sample);
        let mut response_half = vec![Complex32::new(0.0, 0.0); half_fft.spectrum_len()];
        let mut response_full = vec![Complex32::new(0.0, 0.0); width * height];

        let maximum_denominator = denominator_full
            .iter()
            .map(|value| value.re.abs())
            .fold(0.0f32, f32::max);
        let conditioned_floor = maximum_denominator * 1.0e-7;
        let mut compared_filters = 0usize;
        let mut goal_full_unique = vec![Complex32::new(0.0, 0.0); half_fft.spectrum_len()];
        let mut numerator_full_unique = vec![Complex32::new(0.0, 0.0); half_fft.spectrum_len()];
        let mut denominator_full_unique = vec![Complex32::new(0.0, 0.0); half_fft.spectrum_len()];
        let mut filter_half_conditioned = Vec::with_capacity(half_fft.spectrum_len());
        let mut filter_full_conditioned = Vec::with_capacity(half_fft.spectrum_len());
        let mut response_full_unique = vec![Complex32::new(0.0, 0.0); half_fft.spectrum_len()];
        for ky in 0..height {
            for kx in 0..half_fft.spectrum_width() {
                let half_index = half_index(kx, ky, height);
                let full_index = ky * width + kx;
                goal_full_unique[half_index] = goal_full[full_index];
                numerator_full_unique[half_index] = numerator_full[full_index];
                denominator_full_unique[half_index] = denominator_full[full_index];

                let h_half = reconstruct_filter_value(
                    numerator_half[half_index],
                    denominator_half[half_index],
                );
                let h_full = reconstruct_filter_value(
                    numerator_full[full_index],
                    denominator_full[full_index],
                );
                response_half[half_index] = localization_half[half_index] * h_half.conj();
                response_full[full_index] = localization_full[full_index] * h_full.conj();

                if denominator_full[full_index].re.abs() > conditioned_floor {
                    compared_filters += 1;
                    filter_half_conditioned.push(h_half);
                    filter_full_conditioned.push(h_full);
                }
                response_full_unique[half_index] = response_full[full_index];
            }
        }
        assert!(
            compared_filters * 100 >= half_fft.spectrum_len() * 99,
            "only {compared_filters}/{} H bins were safely conditioned",
            half_fft.spectrum_len()
        );
        for (label, actual, expected) in [
            ("goal", goal_half.as_slice(), goal_full_unique.as_slice()),
            (
                "A",
                numerator_half.as_slice(),
                numerator_full_unique.as_slice(),
            ),
            (
                "B",
                denominator_half.as_slice(),
                denominator_full_unique.as_slice(),
            ),
            (
                "conditioned H",
                filter_half_conditioned.as_slice(),
                filter_full_conditioned.as_slice(),
            ),
            (
                "response spectrum",
                response_half.as_slice(),
                response_full_unique.as_slice(),
            ),
        ] {
            assert_measured_delta(label, complex_delta_metrics(actual, expected));
        }

        for ky in 0..height {
            for kx in half_fft.spectrum_width()..width {
                let index = ky * width + kx;
                let h_full =
                    reconstruct_filter_value(numerator_full[index], denominator_full[index]);
                response_full[index] = localization_full[index] * h_full.conj();
            }
        }

        let mut half_spatial = vec![0.0; width * height];
        half_fft.inverse_real(&mut response_half, &mut half_spatial);
        let full_spatial = full_fft.inverse_real(&mut response_full);
        assert_measured_delta(
            "spatial response",
            float_delta_metrics(&half_spatial, &full_spatial),
        );
        for (index, (&expected, &actual)) in full_spatial.iter().zip(&half_spatial).enumerate() {
            assert_float_close(actual, expected, &format!("MOSSE response {index}"));
        }

        let epsilon = 1.0e-5;
        let half_stats = calculate_response_stats(&half_spatial, width, height, epsilon);
        let full_stats = calculate_response_stats(&full_spatial, width, height, epsilon);
        assert_f64_close(half_stats.peak, full_stats.peak, "response peak");
        assert_f64_close(half_stats.mean, full_stats.mean, "response mean");
        assert_f64_close(
            half_stats.stddev,
            full_stats.stddev,
            "response standard deviation",
        );
        assert_f64_close(half_stats.psr, full_stats.psr, "response PSR");
        assert_eq!(half_stats.delta_x, full_stats.delta_x);
        assert_eq!(half_stats.delta_y, full_stats.delta_y);
        assert_eq!(half_stats.psr >= 5.7, full_stats.psr >= 5.7);
    }
}
