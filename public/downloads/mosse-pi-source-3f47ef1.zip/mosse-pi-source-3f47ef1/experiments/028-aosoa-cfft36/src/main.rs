use mosse_exp028_aosoa_cfft36::{Batch4, Direction, Kernel36x4, FFT_LEN, LANES};
use rustfft::{num_complex::Complex32, FftDirection, FftPlanner};
use std::{
    hint::black_box,
    process::ExitCode,
    time::{Duration, Instant},
};

const ABS_TOLERANCE: f32 = 5.0e-4;
const REL_TOLERANCE: f32 = 5.0e-5;
const TIMING_BLOCK: usize = 16;

#[derive(Clone, Copy, Debug)]
struct Config {
    correctness_only: bool,
    warmup: usize,
    sample_ms: u64,
    samples: usize,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            correctness_only: false,
            warmup: 1_000,
            sample_ms: 100,
            samples: 5,
        }
    }
}

#[derive(Default)]
struct ErrorMetrics {
    values: u64,
    error_energy: f64,
    reference_energy: f64,
    max_abs: f32,
    max_scaled_ratio: f32,
}

impl ErrorMetrics {
    fn observe(&mut self, actual: f32, expected: f32, context: &str) -> Result<(), String> {
        if !actual.is_finite() {
            return Err(format!("{context}: non-finite actual value {actual:?}"));
        }
        if !expected.is_finite() {
            return Err(format!("{context}: non-finite oracle value {expected:?}"));
        }

        let error = (actual - expected).abs();
        let allowed = ABS_TOLERANCE + REL_TOLERANCE * expected.abs();
        self.values += 1;
        self.error_energy += f64::from(error) * f64::from(error);
        self.reference_energy += f64::from(expected) * f64::from(expected);
        self.max_abs = self.max_abs.max(error);
        self.max_scaled_ratio = self.max_scaled_ratio.max(error / allowed);

        if error > allowed {
            return Err(format!(
                "{context}: actual={actual:.9e} expected={expected:.9e} \
                 abs_error={error:.9e} allowed={allowed:.9e}"
            ));
        }
        Ok(())
    }

    fn rms_relative(&self) -> f64 {
        (self.error_energy / self.reference_energy.max(f64::MIN_POSITIVE)).sqrt()
    }
}

fn main() -> ExitCode {
    match parse_config().and_then(run) {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            eprintln!("error: {error}");
            ExitCode::FAILURE
        }
    }
}

fn parse_config() -> Result<Config, String> {
    let mut config = Config::default();
    let mut args = std::env::args().skip(1);
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "--correctness-only" => config.correctness_only = true,
            "--warmup" => {
                config.warmup = args
                    .next()
                    .ok_or("--warmup requires a value")?
                    .parse()
                    .map_err(|_| "--warmup must be a positive integer")?;
            }
            "--sample-ms" => {
                config.sample_ms = args
                    .next()
                    .ok_or("--sample-ms requires a value")?
                    .parse()
                    .map_err(|_| "--sample-ms must be a positive integer")?;
            }
            "--samples" => {
                config.samples = args
                    .next()
                    .ok_or("--samples requires a value")?
                    .parse()
                    .map_err(|_| "--samples must be a positive integer")?;
            }
            "--help" | "-h" => {
                println!(
                    "aosoa_cfft36_probe [--correctness-only] \
                     [--warmup N] [--sample-ms MS] [--samples N]"
                );
                std::process::exit(0);
            }
            _ => return Err(format!("unknown argument: {arg}")),
        }
    }
    if config.sample_ms == 0 || config.samples == 0 {
        return Err("--sample-ms and --samples must be nonzero".into());
    }
    Ok(config)
}

fn run(config: Config) -> Result<(), String> {
    println!("experiment=028-aosoa-cfft36");
    println!("backend={}", Kernel36x4::backend_name());
    println!("layout=split-complex-aosoa logical_points=36 lanes=4");
    println!("normalization=none");

    let metrics = correctness_gate()?;
    println!(
        "correctness=pass compared_components={} max_abs={:.9e} \
         rms_relative={:.9e} max_tolerance_fraction={:.6}",
        metrics.values,
        metrics.max_abs,
        metrics.rms_relative(),
        metrics.max_scaled_ratio
    );

    if config.correctness_only {
        return Ok(());
    }

    println!(
        "timing_scope=complete_kernel_call includes=crt_input_permute,radix4,transpose,\
         radix9,crt_output_permute excludes=aosoa_construction_or_external_layout_conversion"
    );
    println!(
        "warning=codelet_ceiling_not_tracker_fps_or_end_to_end_prediction \
         warmup={} sample_ms={} samples={} block={}",
        config.warmup, config.sample_ms, config.samples, TIMING_BLOCK
    );

    for direction in [Direction::Forward, Direction::Inverse] {
        let result = time_direction(direction, config);
        println!(
            "direction={} median_ns_per_batch4={:.3} min_ns={:.3} max_ns={:.3} \
             transforms_per_call=4 checksum={:.9e} samples_ns={:?}",
            direction_name(direction),
            result.median,
            result.minimum,
            result.maximum,
            result.checksum,
            result.samples
        );
    }
    Ok(())
}

fn correctness_gate() -> Result<ErrorMetrics, String> {
    let fixtures = deterministic_fixtures();
    let mut metrics = ErrorMetrics::default();
    let mut planner = FftPlanner::<f32>::new();
    let forward = planner.plan_fft(FFT_LEN, FftDirection::Forward);
    let inverse = planner.plan_fft(FFT_LEN, FftDirection::Inverse);
    let mut forward_kernel = Kernel36x4::new();
    let mut inverse_kernel = Kernel36x4::new();

    for (fixture_index, fixture) in fixtures.iter().enumerate() {
        for (direction, oracle) in [
            (Direction::Forward, forward.as_ref()),
            (Direction::Inverse, inverse.as_ref()),
        ] {
            let expected = oracle_batch(fixture, oracle);
            let mut actual_a = fixture.clone();
            let mut actual_b = fixture.clone();

            let kernel = match direction {
                Direction::Forward => &mut forward_kernel,
                Direction::Inverse => &mut inverse_kernel,
            };
            kernel.poison_scratch(0x1000 + fixture_index as u32);
            kernel.process(&mut actual_a, direction);
            kernel.poison_scratch(0x9000 + fixture_index as u32 * 13);
            kernel.process(&mut actual_b, direction);

            require_bit_identical(
                &actual_a,
                &actual_b,
                &format!(
                    "fixture={fixture_index} direction={}",
                    direction_name(direction)
                ),
            )?;
            compare_batch(
                &actual_a,
                &expected,
                &format!(
                    "fixture={fixture_index} direction={}",
                    direction_name(direction)
                ),
                &mut metrics,
            )?;
        }

        let mut round_trip = fixture.clone();
        forward_kernel.poison_scratch(0xa500 + fixture_index as u32);
        forward_kernel.process_forward(&mut round_trip);
        inverse_kernel.poison_scratch(0x5a00 + fixture_index as u32);
        inverse_kernel.process_inverse(&mut round_trip);
        let mut expected_round_trip = fixture.clone();
        scale_batch(&mut expected_round_trip, FFT_LEN as f32);
        compare_batch(
            &round_trip,
            &expected_round_trip,
            &format!("fixture={fixture_index} round_trip"),
            &mut metrics,
        )?;
    }

    Ok(metrics)
}

fn oracle_batch(input: &Batch4, oracle: &dyn rustfft::Fft<f32>) -> Batch4 {
    let mut output = Batch4::default();
    for lane in 0..LANES {
        let mut values: Vec<Complex32> = (0..FFT_LEN)
            .map(|index| Complex32::new(input.re[index][lane], input.im[index][lane]))
            .collect();
        oracle.process(&mut values);
        for (index, value) in values.into_iter().enumerate() {
            output.re[index][lane] = value.re;
            output.im[index][lane] = value.im;
        }
    }
    output
}

fn compare_batch(
    actual: &Batch4,
    expected: &Batch4,
    prefix: &str,
    metrics: &mut ErrorMetrics,
) -> Result<(), String> {
    for index in 0..FFT_LEN {
        for lane in 0..LANES {
            metrics.observe(
                actual.re[index][lane],
                expected.re[index][lane],
                &format!("{prefix} index={index} lane={lane} component=re"),
            )?;
            metrics.observe(
                actual.im[index][lane],
                expected.im[index][lane],
                &format!("{prefix} index={index} lane={lane} component=im"),
            )?;
        }
    }
    Ok(())
}

fn require_bit_identical(lhs: &Batch4, rhs: &Batch4, context: &str) -> Result<(), String> {
    for index in 0..FFT_LEN {
        for lane in 0..LANES {
            for (component, left, right) in [
                ("re", lhs.re[index][lane], rhs.re[index][lane]),
                ("im", lhs.im[index][lane], rhs.im[index][lane]),
            ] {
                if left.to_bits() != right.to_bits() {
                    return Err(format!(
                        "{context}: dirty scratch affected index={index} lane={lane} \
                         component={component}: {left:?} != {right:?}"
                    ));
                }
            }
        }
    }
    Ok(())
}

fn scale_batch(batch: &mut Batch4, scale: f32) {
    for index in 0..FFT_LEN {
        for lane in 0..LANES {
            batch.re[index][lane] *= scale;
            batch.im[index][lane] *= scale;
        }
    }
}

fn deterministic_fixtures() -> Vec<Batch4> {
    let mut fixtures = Vec::new();

    // All-zero proves poisoned scratch is not consumed.
    fixtures.push(Batch4::default());

    // Lane-specific complex impulses, including boundary indices.
    let mut impulses = Batch4::default();
    for lane in 0..LANES {
        let index = [0, 1, 17, 35][lane];
        impulses.re[index][lane] = 0.75 + lane as f32 * 0.375;
        impulses.im[index][lane] = -0.5 + lane as f32 * 0.2;
    }
    fixtures.push(impulses);

    // Constant and alternating signals exercise exact DC/Nyquist-like paths.
    let mut structured = Batch4::default();
    for index in 0..FFT_LEN {
        for lane in 0..LANES {
            let alternating = if (index + lane) & 1 == 0 { 1.0 } else { -1.0 };
            structured.re[index][lane] =
                (lane as f32 + 1.0) * 0.125 + alternating * (index as f32 + 1.0) * 0.01;
            structured.im[index][lane] = (index as f32 - 17.5) * (lane as f32 + 0.5) * 0.0075;
        }
    }
    fixtures.push(structured);

    // Exact-bin complex tones with different bins and phases in each lane.
    let mut tones = Batch4::default();
    for index in 0..FFT_LEN {
        for lane in 0..LANES {
            let bin = [1.0_f32, 4.0, 9.0, 17.0][lane];
            let phase = 0.19 * lane as f32;
            let angle = 2.0 * std::f32::consts::PI * bin * index as f32 / FFT_LEN as f32 + phase;
            tones.re[index][lane] = angle.cos() * (1.0 + 0.1 * lane as f32);
            tones.im[index][lane] = angle.sin() * (0.8 + 0.15 * lane as f32);
        }
    }
    fixtures.push(tones);

    fixtures.push(random_batch(0x4d4f_5353_4528_0001, 1.0));
    fixtures.push(random_batch(0x4d4f_5353_4528_0002, 1.0e-3));
    fixtures.push(random_batch(0x4d4f_5353_4528_0003, 1.0e3));

    // A nonperiodic chirp catches swapped output bins that pure tones can hide.
    let mut chirp = Batch4::default();
    for index in 0..FFT_LEN {
        for lane in 0..LANES {
            let x = index as f32 + 0.37 * lane as f32;
            let angle = 0.031 * x * x + 0.17 * x + lane as f32 * 0.23;
            chirp.re[index][lane] = angle.cos() * (1.0 + x * 0.02);
            chirp.im[index][lane] = angle.sin() * (0.7 - x * 0.006);
        }
    }
    fixtures.push(chirp);

    fixtures
}

fn random_batch(mut state: u64, scale: f32) -> Batch4 {
    let mut batch = Batch4::default();
    for index in 0..FFT_LEN {
        for lane in 0..LANES {
            state = splitmix64(state);
            batch.re[index][lane] = unit_signed(state) * scale;
            state = splitmix64(state);
            batch.im[index][lane] = unit_signed(state) * scale;
        }
    }
    batch
}

fn splitmix64(mut value: u64) -> u64 {
    value = value.wrapping_add(0x9e37_79b9_7f4a_7c15);
    value = (value ^ (value >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
    value = (value ^ (value >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
    value ^ (value >> 31)
}

fn unit_signed(bits: u64) -> f32 {
    let fraction = ((bits >> 40) as u32) as f32 * (1.0 / 16_777_216.0);
    fraction * 2.0 - 1.0
}

struct TimingResult {
    median: f64,
    minimum: f64,
    maximum: f64,
    checksum: f64,
    samples: Vec<f64>,
}

fn time_direction(direction: Direction, config: Config) -> TimingResult {
    let templates: Vec<Batch4> = (0..TIMING_BLOCK)
        .map(|index| random_batch(0x0280_0000_0000_0000 + index as u64, 0.25))
        .collect();
    let mut work = templates.clone();
    let mut kernel = Kernel36x4::new();

    for iteration in 0..config.warmup {
        let slot = iteration % TIMING_BLOCK;
        work[slot] = templates[slot].clone();
        kernel.process(black_box(&mut work[slot]), direction);
    }

    let target = Duration::from_millis(config.sample_ms);
    let mut samples = Vec::with_capacity(config.samples);
    let mut checksum = 0.0_f64;

    for sample in 0..config.samples {
        let mut measured = Duration::ZERO;
        let mut calls = 0_u64;
        while measured < target {
            work.clone_from_slice(&templates);
            let started = Instant::now();
            for batch in &mut work {
                kernel.process(black_box(batch), direction);
            }
            measured += started.elapsed();
            calls += TIMING_BLOCK as u64;

            let probe = &work[(sample + calls as usize) % TIMING_BLOCK];
            let index = (sample * 7 + calls as usize) % FFT_LEN;
            checksum += f64::from(black_box(probe.re[index][sample % LANES]));
            checksum += f64::from(black_box(probe.im[index][(sample + 1) % LANES]));
        }
        samples.push(measured.as_secs_f64() * 1.0e9 / calls as f64);
    }

    samples.sort_by(f64::total_cmp);
    TimingResult {
        median: samples[samples.len() / 2],
        minimum: samples[0],
        maximum: samples[samples.len() - 1],
        checksum,
        samples,
    }
}

fn direction_name(direction: Direction) -> &'static str {
    match direction {
        Direction::Forward => "forward",
        Direction::Inverse => "inverse",
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn full_deterministic_correctness_gate() {
        let metrics = correctness_gate().expect("AoSoA kernel must match RustFFT");
        assert!(metrics.values >= 8 * 3 * FFT_LEN as u64 * LANES as u64 * 2);
        assert!(metrics.max_scaled_ratio <= 1.0);
    }
}
