#pragma once

#include <cstdint>
#include <string>

#include <opencv2/core/mat.hpp>

namespace mosse {

inline constexpr const char *kFrameChecksumAlgorithm = "fnv1a64-mat-v1";

std::uint64_t frame_checksum_fnv1a64(const cv::Mat &frame);

std::string checksum_hex(std::uint64_t checksum);

class FrameSequenceChecksum {
public:
  void add(std::uint64_t frame_index, std::uint64_t frame_checksum);
  [[nodiscard]] std::uint64_t value() const noexcept;

private:
  std::uint64_t hash_{14695981039346656037ULL};
};

} // namespace mosse
