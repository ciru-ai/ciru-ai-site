# Experiment 066: final composite qualification

## Purpose

Qualify the retained exact four-core composite tracker as the production
result without changing the tracker, timer boundary, video, ROI, or OpenCV
baseline. The primary result is the median of five alternating full-video
OpenCV-one-core/Rust-four-core pairs after one full warm-up per
implementation. A current-build single-thread result remains a companion
measurement, not the production target.

The final visual artifact is rendered only after timing from one exact saved
pair. The renderer never executes either tracker.

## Frozen candidate

| Identity | Value |
|---|---|
| Native source commit | `60bdb90776ab5eb30a835a2ad35020b605f41c9e` |
| Native Rust tree | `b057110badaf5f94d63f557bfd869268f8f3fe4c` |
| Source bundle SHA-256 | `6559e252fbcc7f15e23fdb2d9b4f177d343b2198b41b9bf8500c1b55814964ee` |
| Benchmark SHA-256 | `de88c190b751707521e2d991ed41a108e5ca81b0c3e8efb84df243f558e01288` |
| Shared library SHA-256 | `7aa6a3b8cae990503187d9f65b9dd47715f6209e51226d7ec61b988746eb9201` |
| Static library SHA-256 | `75f411d15bb8335a462ffd2d21994e4bd77c4b900236616db49f03c122633f67` |
| Cargo features | `shared-activity-futex-wake,normal-spin-four-core-runtime,fused-correlated-inverse-cfft36-60x36,composite-preprocess-forward-60x36,parallel-model-blend-filter-60x36` |
| Video SHA-256 | `17293ee5158b5f41d2920bbb1ba835f96050ab2813942ff29008dffab10857b5` |
| ROI | `(281, 193, 55, 36)` on frame 0 |

The benchmark is statically linked to the Rust core. The shared library is
the same native build packaged for Python and is bound to the safety and
production-soak evidence.

## Prerequisite gates

The following gates must pass before the paired matrix:

1. Experiment 064 idle/watchdog safety with caller CPU 0 and workers CPUs
   1–3.
2. Experiment 064 exact isolated full replay: 4,947 decoded frames, all 4,946
   updates timed, exact checksums/decisions/boxes, and no observer login.
3. The source-rate Python/OpenCV production soak in
   `experiments/064-composite-preprocess-forward/results/pi4/paced-live-python-cpu0-v2`.

The paced soak passed all 4,947 frames and 4,946 updates with 2,219
successes, 2,727 failures, zero reference mismatches, zero copies, zero
dropped frames, zero decode-starvation events, and zero late frame
deadlines. It observed the qualified CPU topology, a live external progress
watchdog, temperatures and firmware throttling, unchanged boot/watchdog/RT
settings, zero observer logins, and deterministic cleanup.

## Official four-core matrix

The exact runner is `scripts/run_pi4_scoring.sh` from harness commit
`e531a06`. It is launched from the clean `771eafa` qualification checkout.
The runner:

- launches both complete processes on CPU 0;
- requests four Rust cores, whose three workers self-pin to CPUs 1–3;
- requires the exact qualified backend/activity/topology diagnostics;
- hashes the benchmark before and after every run;
- applies a 180-second per-run termination boundary;
- checks boot, governor, throttling, RT settings, and cleanup on every run;
- requires literal equality of the nine non-timing CSV fields for all 4,947
  rows;
- requires 4,946 updates, 2,219 successes, and 2,727 failures in every
  measured summary;
- fails the original quality gates as well as the stronger exact gate.

The entire suite runs under
`experiments/066-final-composite-qualification/run_governed_matrix.sh`.
That root wrapper changes the single Pi cpufreq policy from the captured
`ondemand` state to `performance`, runs the benchmark child as unprivileged
user `crown`, then restores the exact original governor on every exit path.
It also verifies boot, firmware throttle state, RT settings, hardware
watchdog configuration, and the absence of additional SSH observers.

The production invocation is equivalent to:

```bash
flock -w 120 /tmp/mosse-pi4-benchmark.lock \
  scripts/run_pi4_scoring.sh \
  --benchmark /absolute/path/to/mosse_benchmark \
  --config /absolute/path/to/benchmark.yml \
  --output-root /absolute/path/to/final-matrices \
  --run-id four-core-performance-v1 \
  --warmups 1 \
  --runs 5 \
  --opencv-threads 1 \
  --threads 4 \
  --max-frames 0 \
  --pause-seconds 2 \
  --required-governor performance \
  --rust-caller-cpus 0 \
  --run-timeout-seconds 180 \
  --expected-benchmark-sha256 \
    de88c190b751707521e2d991ed41a108e5ca81b0c3e8efb84df243f558e01288 \
  --require-exact-parity
```

## Result

### Production four-core matrix

Status: **PASS**

| Metric | Result |
|---|---:|
| Rust four-core mean FPS | `11,626.62599098288` |
| Rust four-core median FPS | `11,632.1216094711` |
| Mean latency of median-FPS run | `85.9688398706025 us` |
| Frozen OpenCV baseline | `2,319.78751774436 FPS` |
| Headline median / frozen baseline | `5.014304767352817x` |
| Margin above the 4× target | `25.3576191838%` |
| Final-suite OpenCV median | `2,358.52633243484 FPS` |
| Ratio of tracker medians | `4.931944769708212x` |
| Median paired ratio | `4.9384776424927965x` |

All five measured pairs contained 4,947 rows, 4,946 timed updates, 2,219
successes, and 2,727 failures. Literal comparison of the nine non-timing
fields found zero mismatches: all checksums, decisions, and boxes were exact.
All attempted failure updates had positive timing values.

The five Rust runs ranged from 11,585.0545095319 to 11,659.5149867129 FPS.
The median is 0.286095% above the exact 5× frozen-baseline threshold; four of
five runs exceeded that threshold. The result is therefore stated as a
5.014305× median, not a guaranteed 5× floor. The same-suite paired result is
reported separately because its OpenCV runs were faster than the frozen
baseline.

Measured Rust temperatures were 55.504–67.679 °C with firmware throttle mask
`0x0`. The governed wrapper passed, restored `ondemand`, and preserved the
boot ID, RT period/runtime, runtime watchdog, and throttle state. Its
post-launch SSH observer log was empty, and the runner's cleanup gate found no
lingering benchmark.

Evidence:

- [`aggregate.md`](results/pi4/four-core-performance-v1/aggregate.md)
- [`manifest.json`](results/pi4/four-core-performance-v1/manifest.json),
  SHA-256
  `6ccfe92b27abdd5c82e813f59f5417c515c47d464e0069f95c52832a21ef7a11`
- [`aggregate.json`](results/pi4/four-core-performance-v1/aggregate.json),
  SHA-256
  `cc758ca5645a5e6577b236814210718de212b793e4c61c7591b0c38845b5362a`
- suite checksum list SHA-256
  `2959f54bb27341d35acd4fed3176c788dc3fb0aeca780e8d8183210cdeeaecfb`
- all 81 suite entries and all six governor-wrapper entries reverified after
  transfer with zero hash mismatches.

### Current-build single-thread companion

Status: **PASS** (companion only; not the production target)

The separately governed one-warm-up/five-pair exact suite measured
7,073.822948 FPS mean and 7,071.160241 FPS median for Rust. That is
3.048193× the frozen OpenCV baseline, 3.008102× the contemporaneous OpenCV
median, and a 3.010242× median paired ratio. All five traces were exact.
Rust temperatures were 54.5–56.0 °C without throttling; the wrapper restored
the governor and preserved the same host invariants.

Evidence:

- [`aggregate.md`](results/pi4/single-thread-companion-v1/aggregate.md)
- suite manifest SHA-256
  `fc526eebc6069c5de0edcd830bb25946f440f4ee2a22aac937108493a8182612`
- aggregate SHA-256
  `45419e0e8a4d2d77e4bcd4a65c10fc761dfef4294ef418e92bb7b3880d7002c5`
- suite checksum-list SHA-256
  `8b9538f59a42611e7be20cda57adce3e90a712d359db24e95d51232768e5c327`
- all 81 suite entries and all six wrapper entries reverified after transfer.

### Post-timing annotated comparison

Status: **PASS**

The renderer consumed measured pair 1 only after scoring was complete. It
verified literal equality of all nine trace fields across 4,947 rows before
drawing, never executed a tracker, and decoded all 4,947 frames from its
output during validation. The delivery video is H.264, 1,696×480, 4,947
frames:

- [`opencv-rust-exact-side-by-side-h264.mp4`](results/pi4/final-exact-annotated-video-v1/opencv-rust-exact-side-by-side-h264.mp4)
- SHA-256
  `ba9667090a388d39a4c726fb7ef6849f488c932bbd2b3714b8a57fa6383687d1`
- [`delivery-manifest.json`](results/pi4/final-exact-annotated-video-v1/delivery-manifest.json)
