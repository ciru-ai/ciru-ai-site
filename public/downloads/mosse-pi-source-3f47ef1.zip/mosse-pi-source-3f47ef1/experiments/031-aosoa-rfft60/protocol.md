# Experiment 031: four-lane AoSoA fixed RFFT60 ceiling

## Scope and non-claim

This experiment isolates four independent fixed length-60 real FFTs in four
AoSoA lanes. It is a **kernel ceiling only**. It does not change the tracker,
does not change the replay timing boundary, and must never be reported as
tracker FPS or an end-to-end optimization.

The crate is self-contained under `experiments/031-aosoa-rfft60/`. Production
source, Cargo configuration, reports, and benchmark result files remain out of
scope.

## Locked hypothesis

The Cortex-A72 can execute four row transforms in NEON lanes more efficiently
than calling RustFFT/RealFFT's length-30 inner transform for each row
independently, provided the whole pipeline produces and consumes the AoSoA
layout directly.

The fixed algorithm is:

1. pack `y[n] = x[2n] + i*x[2n+1]`;
2. compute an unnormalized CFFT30 with Good-Thomas 5x6, the winning length-30
   factorization measured in Experiment 024;
3. fuse the real-FFT forward postprocessing or inverse preprocessing;
4. retain persistent scratch and precomputed twiddles so hot calls perform no
   allocation or planning.

Forward produces the 31 unique bins `0..=30` with no normalization. Inverse
assumes Hermitian completion, ignores imaginary DC and Nyquist components,
and also has no normalization. The locked round-trip convention is therefore
`inverse(forward(x)) = 60*x`.

## Layout

- forward input: `RealBatch4`, `[60][4]`;
- forward output / inverse input: split-complex `ComplexBatch4`,
  real and imaginary `[31][4]`;
- inverse output: `RealBatch4`, `[60][4]`;
- AArch64 lane backend: one `float32x4_t` NEON register;
- other targets: portable four-element scalar-source fallback.

Packing is fused into the Good-Thomas input permutation. Inverse unpacking is
fused with the Good-Thomas output permutation. The two 30-point complex work
buffers and 31 real-FFT twiddles live in `Kernel60x4`.

## Correctness gate

Before timing, compare both directions independently against RealFFT and a
full Hermitian RustFFT oracle on:

- all zero;
- impulses at the first, interior, midpoint, and final samples;
- structured constant and alternating data;
- exact-bin tones including DC and Nyquist;
- deterministic random data at scales `1e-3`, `1`, and `1e3`;
- a nonperiodic chirp.

Also require:

- forward DC and Nyquist imaginary components are exactly positive zero;
- imaginary DC/Nyquist inverse inputs are ignored, including distinct NaN
  payloads;
- forward plus inverse equals `60*x` within the locked mixed tolerance;
- every output is unchanged after poisoning persistent scratch with two
  distinct NaN patterns;
- no non-finite actual or oracle output;
- report maximum absolute error, RMS-relative error, and maximum consumed
  fraction of `2e-3 + 8e-5*abs(reference)`.

## Timing

Time complete batch-of-four forward and inverse calls. The timed forward call
includes packing, the Good-Thomas input permutation, radix-5 stage, transpose,
radix-6 stage, and real-FFT postprocessing. The timed inverse call includes
real-FFT preprocessing, the Good-Thomas input permutation, both transform
stages and transpose, and fused output permutation/unpacking.

Only deterministic fixture construction/reset is outside the measured
interval. Planning, allocation, and layout conversion do not occur in the hot
calls. Report five 100 ms samples after 1,000 warmup calls, their median,
range, and a data-dependent checksum.

The tracker has 36 row transforms, so honest row-batch normalization is nine
batch-of-four calls with **zero padded rows**. Compare `9 * median` only
directionally with Experiment 024's retained same-host row-batch context:

- Pi Cortex-A72, 36 CFFT30 calls: `13,535.793 ns` forward and `13,529.328 ns`
  inverse;
- Dunamis x86 AVX, 36 CFFT30 calls: `954.232 ns` forward and `954.325 ns`
  inverse.

Those Experiment 024 values measure the inner CFFT30 batch, while this
experiment measures a complete RFFT60 kernel. Cross-run ratios are contextual,
not tracker predictions.

## Commands

```sh
cargo fmt --manifest-path experiments/031-aosoa-rfft60/Cargo.toml -- --check
cargo clippy --manifest-path experiments/031-aosoa-rfft60/Cargo.toml \
  --all-targets -- -D warnings
cargo test --manifest-path experiments/031-aosoa-rfft60/Cargo.toml --release
cargo run --manifest-path experiments/031-aosoa-rfft60/Cargo.toml --release -- \
  --correctness-only
cargo run --manifest-path experiments/031-aosoa-rfft60/Cargo.toml --release -- \
  --warmup 1000 --sample-ms 100 --samples 5
```

On Dunamis, run the native screen with `RUSTFLAGS="-C target-cpu=native"`,
`taskset -c 0`, and `flock /tmp/mosse-dunamis-benchmark.lock`.

Cross-compile the library on Dunamis for code generation only:

```sh
cargo rustc --manifest-path experiments/031-aosoa-rfft60/Cargo.toml \
  --target aarch64-unknown-linux-gnu --release --lib -- \
  -C target-cpu=cortex-a72 --emit=asm
```

The stable forward and inverse symbols must contain four-wide vector
floating-point arithmetic and no residual bounds-check calls.

## Preregistered Pi runtime stop gate

The initial isolated implementation stopped before a Pi run. A later
explicitly authorized Pi ceiling screen could proceed only with the identical
source and had to stop before whole-layout integration if any condition held:

1. either direction fails any oracle, round-trip, Hermitian-edge, or
   dirty-scratch check;
2. emitted Cortex-A72 code scalarizes the four transform lanes or retains
   bounds-check calls;
3. nine complete batch-of-four calls do not directionally beat Experiment
   024's retained matching Pi row-batch CFFT30 time in both directions;
4. thermal, clock, or throttling telemetry invalidates the serialized screen.

Passing this gate would justify only a separate integration experiment.

## Whole-layout integration requirement

This kernel accepts and emits AoSoA. A production candidate must fuse the
row-to-column **4x4 transpose** into the surrounding 2D-FFT layout so that
neither an AoS-to-AoSoA conversion nor a transpose-only pass is charged around
the codelet. Column padding and the 31-bin tail must remain honestly included.
Only full trace equivalence followed by all 4,946 replay attempts can establish
a tracker optimization.

## Results

### Locked source and validation

The final isolated source hashes are:

- `Cargo.toml`:
  `4236d0c2ed19df34bdcec323b390990aed1de498547b5d11412e2050debd2a83`;
- `Cargo.lock`:
  `426cf3c8709be71a13a0b3aa11a2197a16246f3507fbe49e182f7c5772f8fda6`;
- `src/lib.rs`:
  `74123dfb1b38e51b1f9db0ef2b3c38f3525414aded45d984d3b4f0cca89fc27b`;
- `src/main.rs`:
  `8ffee3315e1a2e7b89e0d9f9211ee2c98a887f00e45645f544f9e0bfeae83356`.

Formatting, `clippy --all-targets -- -D warnings`, release tests, executable
correctness, and `git diff --check` passed locally. The same source passed
formatting, clippy, release tests, and executable correctness on Dunamis.

The eight locked fixtures produced 9,728 comparisons across the two
independent forward oracles, two independent inverse oracles, and kernel
round trips:

| Host | Maximum absolute error | RMS-relative error | Maximum tolerance fraction |
|---|---:|---:|---:|
| Windows development host | `1.367187500e-2` | `1.252347484e-7` | `0.467840` |
| Dunamis | `1.367187500e-2` | `1.252347362e-7` | `0.467840` |

The maximum absolute error is from the `1e3`-scale unnormalized round trip.
There were no non-finite results. Distinct NaN scratch payloads did not change
an output bit. Forward DC/Nyquist imaginary values were exact positive zero,
and changing the ignored inverse edge imaginary values to distinct NaN
payloads did not change an output bit.

### Local development screen

One final-source directional screen on the Windows development host used
1,000 warmup calls and five 100 ms samples. It was not pinned or
frequency-controlled, so it is retained only as a working-host sanity check:

| Direction | Median ns/batch of four | Sample range (ns) | Nine-call 36-row normalization |
|---|---:|---:|---:|
| Forward | `124.954` | `113.005`–`129.334` | `1,124.582 ns` |
| Inverse | `106.712` | `104.998`–`114.128` | `960.410 ns` |

### Dunamis transfer screen

The locked-source Dunamis screen ran from `2026-07-26T06:46:11Z` through
`06:46:12Z` on the Intel Core i9-14900KF with Linux 7.1.0. The native build
used Rust/Cargo 1.97.0, release mode, and
`RUSTFLAGS="-C target-cpu=native"`. Its binary SHA-256 was
`2cb667aa19da21e1ae3b3c96ba77f71909e6adf7cbcfe148435a80b501e77c5f`.

Timing was serialized with `flock /tmp/mosse-dunamis-benchmark.lock` and
pinned to CPU0. Intel P-state reported governor `powersave`,
energy-performance preference `performance`, and turbo enabled. The sampled
CPU0 frequency moved from `5,697,928` to `4,982,924 kHz`, so this is not a
fixed-clock claim. Package temperature moved from 43 C to 50 C.

| Direction | Median ns/batch of four | Min ns | Max ns | Nine calls / 36 rows |
|---|---:|---:|---:|---:|
| Forward | `89.313` | `89.051` | `89.441` | `803.819 ns` |
| Inverse | `115.723` | `115.385` | `115.952` | `1,041.511 ns` |

Complete sample vectors were:

- forward:
  `[89.051404, 89.187530, 89.313238, 89.345809, 89.441215]`;
- inverse:
  `[115.384885, 115.447478, 115.723459, 115.766832, 115.951600]`.

Against Experiment 024's separate same-host AVX CFFT30 row-batch context,
the nine-call forward ceiling is `1.187123x` faster, or 15.762714% lower
latency, even though this kernel includes real packing and postprocessing.
The inverse ceiling is instead `0.916289x` baseline throughput, or 9.135895%
higher latency. This is a **mixed x86 transfer result**, not a whole-tracker
win: the forward direction is promising, while the inverse direction does not
justify replacing the native AVX path. The comparisons remain contextual
because they come from separate screens and Experiment 024 measured only the
inner complex FFT batch.

### Cortex-A72 code-generation gate

Dunamis cross-compiled the final library for
`aarch64-unknown-linux-gnu` with Rust 1.97.1 and
`target-cpu=cortex-a72`. The assembly SHA-256 was
`03e95b03ded7645a72fefd2fbbe75011f09bd2e8986e116648f850412e093e6a`.

Static inspection of each stable symbol found:

| Symbol | Lines | Four-wide FP | Scalar FP | Calls | Bounds mentions | Vector loads/stores |
|---|---:|---:|---:|---:|---:|---:|
| Forward | 311 | 109 | 0 | 0 | 0 | 129 |
| Inverse | 495 | 107 | 0 | 0 | 0 | 211 |

The forward vector arithmetic consists of 40 `fadd`, 32 `fsub`, 28 `fmul`,
and 9 `fmla` instructions on `.4s` lanes. Inverse contains 40 `fadd`, 32
`fsub`, 26 `fmul`, and 9 `fmla`. This passes the compile-time NEON and
no-residual-bounds-call gates.

### Pi4 runtime gate

The subsequently authorized runtime gate used the identical four locked
source files and therefore the source SHA-256 values already listed above. It
ran on `raspi-node` with Rust 1.97.1, release mode, and
`RUSTFLAGS="-C target-cpu=cortex-a72"`. The resulting executable SHA-256 was
`f5e4c7f895713af0a2a997e1465b909503ad0bff24c0d0cf3c1314bf1e626fba`.

The native AArch64 correctness executable completed all 9,728 locked
comparisons:

- maximum absolute error: `1.171875000e-2`;
- RMS-relative error: `1.166838757e-7`;
- maximum consumed tolerance fraction: `0.400293`;
- no non-finite result or dirty-scratch mismatch;
- forward DC and Nyquist imaginary components remained exact positive zero;
- distinct NaN payloads in the ignored inverse DC/Nyquist imaginary
  components did not change an output bit.

One serialized screen used the shared Pi benchmark lock, pinned execution to
CPU0, and ran 1,000 warmup calls followed by five 100 ms timing samples. CPU0
used the `performance` governor and remained at `1,800,000 kHz` before and
after the screen. Temperature moved from `55.0 C` to `56.4 C`, and firmware
throttling remained `0x0`.

| Direction | Median ns/batch of four | Min ns | Max ns | Nine calls / 36 rows |
|---|---:|---:|---:|---:|
| Forward | `993.252` | `992.695` | `993.658` | `8,939.268 ns` |
| Inverse | `996.933` | `996.531` | `997.235` | `8,972.395 ns` |

The complete sample vectors and data-dependent checksums were:

- forward:
  `[992.6949650571792, 992.975258141382, 993.2519764023518,`
  `993.2794275385348, 993.6580286168521]`,
  checksum `4.388552019e3`;
- inverse:
  `[996.531419403699, 996.8137559808613, 996.9327850877193,`
  `997.1082110384432, 997.2354319559668]`,
  checksum `3.615156987e4`.

Against Experiment 024's separate same-host 36-call CFFT30 row-batch context,
the complete nine-call RFFT60 ceiling is `1.514194786x` faster forward and
`1.507883681x` faster inverse:

| Direction | Experiment 031 nine-call RFFT60 | Experiment 024 36-call CFFT30 | Throughput ratio | Latency reduction |
|---|---:|---:|---:|---:|
| Forward | `8,939.268 ns` | `13,535.793 ns` | `1.514194786x` | `33.958299%` |
| Inverse | `8,972.395 ns` | `13,529.328 ns` | `1.507883681x` | `33.681887%` |

Both runtime directions pass the preregistered Pi gate and justify a separate
whole-layout integration experiment. These are cross-run, contextual kernel
ceilings: Experiment 024 timed only the inner CFFT30 batch, while this
experiment includes packing and real-FFT pre/postprocessing but still excludes
the tracker's complete 2D layout, column transforms, model work, and replay
boundary. The values are **not tracker FPS** and establish no retained
end-to-end optimization.
