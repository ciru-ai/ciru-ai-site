#!/usr/bin/env bash
#
# Finalize one smoke-tested architecture directory as a deterministic download.

set -euo pipefail

usage() {
    cat >&2 <<'EOF'
Usage: python/finalize_preview.sh ARTIFACT_DIR

ARTIFACT_DIR must be a linux-aarch64 or linux-x86_64 directory produced by
python/build_preview.sh. Add a non-empty SMOKE_TEST.md after running the staged
wheel and both staged examples on the target architecture. This script then
regenerates the recursive manifest and checksums, creates a deterministic
tar.gz beside the architecture directory, and verifies a fresh extraction.

Set SOURCE_DATE_EPOCH to override the build-recorded archive timestamp.
EOF
}

if (($# != 1)); then
    usage
    exit 2
fi

for command_name in find gzip mktemp python3 sha256sum tar; do
    if ! command -v "$command_name" >/dev/null 2>&1; then
        echo "error: required command is unavailable: $command_name" >&2
        exit 1
    fi
done

artifact_argument="$1"
if [[ ! -d "$artifact_argument" ]]; then
    echo "error: artifact directory does not exist: $artifact_argument" >&2
    exit 1
fi
artifact_dir="$(cd -- "$artifact_argument" && pwd -P)"
artifact_name="$(basename -- "$artifact_dir")"
artifact_parent="$(dirname -- "$artifact_dir")"

case "$artifact_name" in
    linux-aarch64)
        architecture="aarch64"
        ;;
    linux-x86_64)
        architecture="x86_64"
        ;;
    *)
        echo "error: expected linux-aarch64 or linux-x86_64, got: $artifact_name" >&2
        exit 1
        ;;
esac

required_files=(
    build_info.json
    libmosse_core.so
    LICENSE
    manifest.json
    mosse.h
    README.md
    REPRODUCE.md
    SMOKE_TEST.md
    examples/numpy_api.py
    examples/video_capture.py
    examples/measure_wrapper_latency.py
)
for relative_path in "${required_files[@]}"; do
    if [[ ! -f "${artifact_dir}/${relative_path}" ]]; then
        echo "error: staged bundle is missing ${relative_path}" >&2
        exit 1
    fi
done
if [[ ! -s "${artifact_dir}/SMOKE_TEST.md" ]]; then
    echo "error: SMOKE_TEST.md exists but is empty" >&2
    exit 1
fi

mapfile -t wheels < <(
    find "$artifact_dir" -maxdepth 1 -type f -name '*.whl' -print
)
if ((${#wheels[@]} != 1)); then
    echo "error: expected exactly one staged wheel, found ${#wheels[@]}" >&2
    exit 1
fi

if [[ -n "${SOURCE_DATE_EPOCH:-}" ]]; then
    source_date_epoch="$SOURCE_DATE_EPOCH"
else
    source_date_epoch="$(
        python3 - "${artifact_dir}/manifest.json" <<'PY'
import json
import pathlib
import sys

manifest = json.loads(pathlib.Path(sys.argv[1]).read_text(encoding="utf-8"))
value = manifest.get("source_date_epoch")
if not isinstance(value, int):
    raise SystemExit(
        "error: manifest has no integer source_date_epoch; set SOURCE_DATE_EPOCH"
    )
print(value)
PY
    )"
fi
if [[ ! "$source_date_epoch" =~ ^[0-9]+$ ]]; then
    echo "error: SOURCE_DATE_EPOCH must be a non-negative integer" >&2
    exit 1
fi

python3 - \
    "$artifact_dir" \
    "$architecture" \
    "$source_date_epoch" <<'PY'
import hashlib
import json
import os
import pathlib
import sys
import tempfile

root = pathlib.Path(sys.argv[1])
architecture = sys.argv[2]
source_date_epoch = int(sys.argv[3])
manifest_path = root / "manifest.json"
checksum_path = root / "SHA256SUMS"


def regular_files(*, include_manifest: bool) -> list[pathlib.Path]:
    files = []
    for path in root.rglob("*"):
        if path.is_symlink():
            raise SystemExit(f"error: staged bundle contains a symlink: {path}")
        if not path.is_file():
            continue
        relative = path.relative_to(root).as_posix()
        if relative == "SHA256SUMS":
            continue
        if not include_manifest and relative == "manifest.json":
            continue
        files.append(path)
    return sorted(files, key=lambda path: path.relative_to(root).as_posix())


def sha256(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
if manifest.get("architecture") != architecture:
    raise SystemExit(
        "error: artifact directory architecture disagrees with manifest: "
        f"{architecture!r} != {manifest.get('architecture')!r}"
    )
manifest["bundle_finalized"] = True
manifest["source_date_epoch"] = source_date_epoch
manifest["smoke_record"] = "SMOKE_TEST.md"
# manifest.json and SHA256SUMS are intentionally excluded to avoid
# self-referential hashes. SHA256SUMS below covers manifest.json.
manifest["files"] = {
    path.relative_to(root).as_posix(): sha256(path)
    for path in regular_files(include_manifest=False)
}

with tempfile.NamedTemporaryFile(
    mode="w",
    encoding="utf-8",
    dir=root.parent,
    prefix=f".{root.name}.manifest.",
    delete=False,
) as stream:
    json.dump(manifest, stream, indent=2, sort_keys=True)
    stream.write("\n")
    manifest_temp = pathlib.Path(stream.name)
os.replace(manifest_temp, manifest_path)

checksum_lines = [
    f"{sha256(path)}  {path.relative_to(root).as_posix()}\n"
    for path in regular_files(include_manifest=True)
]
with tempfile.NamedTemporaryFile(
    mode="w",
    encoding="utf-8",
    dir=root.parent,
    prefix=f".{root.name}.checksums.",
    delete=False,
) as stream:
    stream.writelines(checksum_lines)
    checksum_temp = pathlib.Path(stream.name)
os.replace(checksum_temp, checksum_path)
PY

echo "Verifying finalized staged directory..."
(
    cd "$artifact_dir"
    sha256sum -c SHA256SUMS
)

wheel_name="$(basename -- "${wheels[0]}")"
wheel_stem="${wheel_name%.whl}"
package_prefix="${wheel_stem%%-py3-*}"
if [[ "$package_prefix" == "$wheel_stem" ]]; then
    echo "error: cannot determine package version from wheel: $wheel_name" >&2
    exit 1
fi
package_version="${package_prefix#mosse_pi-}"
if [[ -z "$package_version" || "$package_version" == "$package_prefix" ]]; then
    echo "error: unexpected wheel distribution name: $wheel_name" >&2
    exit 1
fi

archive_path="${artifact_parent}/mosse-pi-${package_version}-${artifact_name}-preview.tar.gz"
archive_temp="$(mktemp "${archive_path}.tmp.XXXXXX")"
extract_root="$(mktemp -d)"
cleanup() {
    if [[ -n "${archive_temp:-}" && -f "$archive_temp" \
        && "$archive_temp" != "/" && ${#archive_temp} -ge 8 ]]; then
        rm -f -- "$archive_temp"
    fi
    if [[ -n "${extract_root:-}" && -d "$extract_root" \
        && "$extract_root" != "/" && "$extract_root" != "$artifact_dir" \
        && ${#extract_root} -ge 8 ]]; then
        rm -rf -- "$extract_root"
    fi
}
trap cleanup EXIT

echo "Creating deterministic archive..."
tar \
    --sort=name \
    --mtime="@${source_date_epoch}" \
    --owner=0 \
    --group=0 \
    --numeric-owner \
    --format=gnu \
    -C "$artifact_parent" \
    -cf - \
    "$artifact_name" \
    | gzip -n -9 > "$archive_temp"
mv -f -- "$archive_temp" "$archive_path"
archive_temp=""

echo "Verifying fresh archive extraction..."
tar -xzf "$archive_path" -C "$extract_root"
extracted_dir="${extract_root}/${artifact_name}"
for relative_path in "${required_files[@]}" SHA256SUMS; do
    if [[ ! -f "${extracted_dir}/${relative_path}" ]]; then
        echo "error: extracted bundle is missing ${relative_path}" >&2
        exit 1
    fi
done
(
    cd "$extracted_dir"
    sha256sum -c SHA256SUMS
)

python3 - "$artifact_parent" <<'PY'
import hashlib
import os
import pathlib
import tempfile
import sys

root = pathlib.Path(sys.argv[1])
archives = sorted(root.glob("mosse-pi-*-linux-*-preview.tar.gz"))
if not archives:
    raise SystemExit("error: no preview archives found for top-level checksums")


def sha256(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


with tempfile.NamedTemporaryFile(
    mode="w",
    encoding="utf-8",
    dir=root,
    prefix=".preview-archive-checksums.",
    delete=False,
) as stream:
    for archive in archives:
        stream.write(f"{sha256(archive)}  {archive.name}\n")
    temporary = pathlib.Path(stream.name)
os.replace(temporary, root / "SHA256SUMS")
PY
(
    cd "$artifact_parent"
    sha256sum -c SHA256SUMS
)

echo "Final bundle: $archive_path"
sha256sum "$archive_path"
