# Benchmark asset

Place the challenge video at `assets/test-video.mp4`.

Required SHA-256:

```text
17293ee5158b5f41d2920bbb1ba835f96050ab2813942ff29008dffab10857b5
```

The video is deliberately excluded from Git. The benchmark must stop before
recording an official result if this hash does not match.

## Annotated comparison video

After both timed tracker runs finish, render their per-frame results without
polluting benchmark timing:

```bash
python3 tools/render_comparison_video.py \
  --video assets/test-video.mp4 \
  --opencv-csv results/opencv-frames.csv \
  --rust-csv results/rust-frames.csv \
  --output results/opencv-rust-comparison.mp4
```

The renderer accepts any pair of per-frame CSVs produced by the benchmark
harness. It requires identical frame rows and checksums, preserves recorded
boxes on failed updates, and displays latency and running tracker-only FPS from
the already-recorded `update_ns` values. Decoding, drawing, and MP4 encoding
therefore remain outside the timed tracker boundary. Use `--opencv-label` and
`--rust-label` when comparing two Rust modes, such as Exact and Challenge.
