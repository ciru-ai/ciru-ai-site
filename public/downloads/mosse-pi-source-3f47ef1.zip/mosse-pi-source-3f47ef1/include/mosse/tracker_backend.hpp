#pragma once

#include <memory>
#include <string>

#include <opencv2/core/mat.hpp>
#include <opencv2/core/types.hpp>

namespace mosse {

struct TrackerUpdate {
  bool success{false};
  cv::Rect2d bbox;
};

class TrackerBackend {
public:
  virtual ~TrackerBackend() = default;

  [[nodiscard]] virtual std::string name() const = 0;

  virtual bool initialize(const cv::Mat &first_frame,
                          const cv::Rect2d &initial_roi) = 0;

  virtual TrackerUpdate update(const cv::Mat &frame) = 0;
};

// Keeping backend creation behind this factory ensures OpenCV and Rust use
// identical frame delivery and timing code. A build configured without the
// Rust static library reports a clear error when "rust" is requested.
std::unique_ptr<TrackerBackend>
create_tracker_backend(const std::string &tracker_name);

} // namespace mosse
