#include "mosse/benchmark_config.hpp"
#include "mosse/frame_checksum.hpp"
#include "mosse/tracker_backend.hpp"

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include <opencv2/core/ocl.hpp>
#include <opencv2/core/utility.hpp>
#include <opencv2/videoio.hpp>

namespace {

using Clock = std::chrono::steady_clock;

struct CliOptions {
  std::filesystem::path config_path;
  std::string tracker{"rust"};
  std::uint64_t cached_frames{300U};
  std::uint64_t repetitions{20U};
  std::uint64_t warmups{1U};
  std::uint64_t max_cache_mib{512U};
  int opencv_threads{1};
  bool show_help{false};
};

struct ReplayTraceEntry {
  bool success{false};
  cv::Rect2d bbox;
};

struct ReplayResult {
  std::uint64_t initialization_ns{0U};
  std::uint64_t update_ns{0U};
  std::uint64_t attempted_updates{0U};
  std::uint64_t successful_updates{0U};
  std::uint64_t failed_updates{0U};
  std::vector<ReplayTraceEntry> trace;
};

std::string usage() {
  return "Usage: mosse_tracker_replay --config <config.yml> [options]\n"
         "\n"
         "Diagnostic-only tracker replay. Frames are decoded and cached once,\n"
         "then fresh tracker instances replay the identical cache repeatedly.\n"
         "This executable is not part of official scoring.\n"
         "\n"
         "Options:\n"
         "  --tracker <opencv|rust>  Tracker backend (default: rust)\n"
         "  --cached-frames <count>  Frames cached from the video, including\n"
         "                           frame 0 (default: 300, minimum: 2)\n"
         "  --repetitions <count>    Measured replay passes (default: 20)\n"
         "  --warmups <count>        Untimed replay passes (default: 1)\n"
         "  --max-cache-mib <count>  Hard decoded-frame memory limit\n"
         "                           (default: 512)\n"
         "  --opencv-threads <count> OpenCV threads; -1 leaves the default\n"
         "  --help                   Show this help\n";
}

std::string require_value(const int argc, char **argv, int &index,
                          const std::string &option) {
  if ((index + 1) >= argc) {
    throw std::runtime_error("Missing value after command-line option " +
                             option);
  }
  ++index;
  return argv[index];
}

std::uint64_t parse_u64(const std::string &value, const std::string &option) {
  std::size_t parsed = 0U;
  unsigned long long converted = 0U;
  try {
    converted = std::stoull(value, &parsed, 10);
  } catch (const std::exception &) {
    throw std::runtime_error("Invalid non-negative integer for " + option +
                             ": " + value);
  }
  if (parsed != value.size() || (!value.empty() && value.front() == '-')) {
    throw std::runtime_error("Invalid non-negative integer for " + option +
                             ": " + value);
  }
  return static_cast<std::uint64_t>(converted);
}

int parse_int(const std::string &value, const std::string &option) {
  std::size_t parsed = 0U;
  long long converted = 0;
  try {
    converted = std::stoll(value, &parsed, 10);
  } catch (const std::exception &) {
    throw std::runtime_error("Invalid integer for " + option + ": " + value);
  }
  if (parsed != value.size() ||
      converted < static_cast<long long>(std::numeric_limits<int>::min()) ||
      converted > static_cast<long long>(std::numeric_limits<int>::max())) {
    throw std::runtime_error("Invalid integer for " + option + ": " + value);
  }
  return static_cast<int>(converted);
}

CliOptions parse_cli(const int argc, char **argv) {
  CliOptions options;
  for (int index = 1; index < argc; ++index) {
    const std::string argument = argv[index];
    if (argument == "--help" || argument == "-h") {
      options.show_help = true;
    } else if (argument == "--config") {
      options.config_path = require_value(argc, argv, index, argument);
    } else if (argument == "--tracker") {
      options.tracker = require_value(argc, argv, index, argument);
    } else if (argument == "--cached-frames") {
      options.cached_frames =
          parse_u64(require_value(argc, argv, index, argument), argument);
    } else if (argument == "--repetitions") {
      options.repetitions =
          parse_u64(require_value(argc, argv, index, argument), argument);
    } else if (argument == "--warmups") {
      options.warmups =
          parse_u64(require_value(argc, argv, index, argument), argument);
    } else if (argument == "--max-cache-mib") {
      options.max_cache_mib =
          parse_u64(require_value(argc, argv, index, argument), argument);
    } else if (argument == "--opencv-threads") {
      options.opencv_threads =
          parse_int(require_value(argc, argv, index, argument), argument);
    } else {
      throw std::runtime_error("Unknown command-line option: " + argument);
    }
  }

  if (!options.show_help && options.config_path.empty()) {
    throw std::runtime_error("--config is required\n\n" + usage());
  }
  if (!options.show_help && options.cached_frames < 2U) {
    throw std::runtime_error("--cached-frames must be at least 2");
  }
  if (!options.show_help && options.repetitions == 0U) {
    throw std::runtime_error("--repetitions must be positive");
  }
  if (!options.show_help && options.max_cache_mib == 0U) {
    throw std::runtime_error("--max-cache-mib must be positive");
  }
  return options;
}

std::uint64_t elapsed_ns(const Clock::time_point start,
                         const Clock::time_point end) {
  return static_cast<std::uint64_t>(
      std::chrono::duration_cast<std::chrono::nanoseconds>(end - start)
          .count());
}

bool same_double_bits(const double left, const double right) {
  static_assert(sizeof(double) == sizeof(std::uint64_t));
  std::uint64_t left_bits = 0U;
  std::uint64_t right_bits = 0U;
  std::memcpy(&left_bits, &left, sizeof(left));
  std::memcpy(&right_bits, &right, sizeof(right));
  return left_bits == right_bits;
}

bool same_trace_entry(const ReplayTraceEntry &left,
                      const ReplayTraceEntry &right) {
  return left.success == right.success &&
         same_double_bits(left.bbox.x, right.bbox.x) &&
         same_double_bits(left.bbox.y, right.bbox.y) &&
         same_double_bits(left.bbox.width, right.bbox.width) &&
         same_double_bits(left.bbox.height, right.bbox.height);
}

void require_stable_frame_layout(const cv::Mat &frame,
                                 const cv::Size &expected_size,
                                 const int expected_type,
                                 const std::uint64_t frame_index) {
  if (frame.empty()) {
    throw std::runtime_error("Decoder returned an empty frame at index " +
                             std::to_string(frame_index));
  }
  if (frame.size() != expected_size || frame.type() != expected_type) {
    throw std::runtime_error(
        "Decoded frame layout changed at index " + std::to_string(frame_index));
  }
}

std::vector<cv::Mat> decode_cache(const mosse::BenchmarkConfig &config,
                                  const CliOptions &options,
                                  std::uint64_t &decode_ns,
                                  std::uint64_t &cache_bytes,
                                  std::uint64_t &sequence_checksum) {
  const Clock::time_point decode_start = Clock::now();
  cv::VideoCapture capture(config.video_path.string(), cv::CAP_ANY);
  if (!capture.isOpened()) {
    throw std::runtime_error("Unable to open video: " +
                             config.video_path.string());
  }

  cv::Mat first_frame;
  if (!capture.read(first_frame) || first_frame.empty()) {
    throw std::runtime_error("Video contains no decodable first frame");
  }
  if (first_frame.type() != CV_8UC3) {
    throw std::runtime_error(
        "Decoder did not produce the required CV_8UC3 frame type");
  }

  const cv::Size expected_size = first_frame.size();
  const int expected_type = first_frame.type();
  if (config.expected_width > 0 &&
      (expected_size.width != config.expected_width ||
       expected_size.height != config.expected_height)) {
    throw std::runtime_error(
        "Decoded dimensions do not match the benchmark configuration");
  }
  mosse::validate_roi_for_frame(config.initial_roi, expected_size);

  const std::uint64_t frame_bytes =
      static_cast<std::uint64_t>(first_frame.total()) *
      static_cast<std::uint64_t>(first_frame.elemSize());
  const std::uint64_t cache_limit =
      options.max_cache_mib * 1024U * 1024U;
  if (frame_bytes > 0U &&
      options.cached_frames > cache_limit / frame_bytes) {
    throw std::runtime_error(
        "Requested decoded cache exceeds --max-cache-mib: need " +
        std::to_string(options.cached_frames * frame_bytes) + " bytes");
  }

  std::vector<cv::Mat> frames;
  frames.reserve(static_cast<std::size_t>(options.cached_frames));
  mosse::FrameSequenceChecksum checksum;
  checksum.add(0U, mosse::frame_checksum_fnv1a64(first_frame));
  frames.push_back(first_frame.clone());

  while (frames.size() <
         static_cast<std::size_t>(options.cached_frames)) {
    cv::Mat frame;
    if (!capture.read(frame)) {
      break;
    }
    const std::uint64_t frame_index =
        static_cast<std::uint64_t>(frames.size());
    require_stable_frame_layout(frame, expected_size, expected_type,
                                frame_index);
    checksum.add(frame_index, mosse::frame_checksum_fnv1a64(frame));
    frames.push_back(frame.clone());
  }

  if (frames.size() != static_cast<std::size_t>(options.cached_frames)) {
    throw std::runtime_error(
        "Video ended before the requested cache was filled: decoded " +
        std::to_string(frames.size()) + " frames");
  }

  cache_bytes = static_cast<std::uint64_t>(frames.size()) * frame_bytes;
  sequence_checksum = checksum.value();
  decode_ns = elapsed_ns(decode_start, Clock::now());
  return frames;
}

ReplayResult replay_once(const CliOptions &options,
                         const mosse::BenchmarkConfig &config,
                         const std::vector<cv::Mat> &frames) {
  std::unique_ptr<mosse::TrackerBackend> tracker =
      mosse::create_tracker_backend(options.tracker);

  const Clock::time_point initialization_start = Clock::now();
  const bool initialized =
      tracker->initialize(frames.front(), config.initial_roi);
  const Clock::time_point initialization_end = Clock::now();
  if (!initialized) {
    throw std::runtime_error("Tracker failed to initialize during replay");
  }

  ReplayResult result;
  result.initialization_ns =
      elapsed_ns(initialization_start, initialization_end);
  result.trace.reserve(frames.size() - 1U);

  const Clock::time_point updates_start = Clock::now();
  for (std::size_t index = 1U; index < frames.size(); ++index) {
    const mosse::TrackerUpdate update = tracker->update(frames[index]);
    result.trace.push_back({update.success, update.bbox});
    ++result.attempted_updates;
    if (update.success) {
      ++result.successful_updates;
    } else {
      ++result.failed_updates;
    }
  }
  result.update_ns = elapsed_ns(updates_start, Clock::now());
  return result;
}

void require_same_trace(const std::vector<ReplayTraceEntry> &reference,
                        const std::vector<ReplayTraceEntry> &candidate,
                        const std::uint64_t repetition) {
  if (candidate.size() != reference.size()) {
    throw std::runtime_error("Replay trace length changed at repetition " +
                             std::to_string(repetition));
  }
  for (std::size_t index = 0U; index < reference.size(); ++index) {
    if (!same_trace_entry(reference[index], candidate[index])) {
      throw std::runtime_error(
          "Replay trace changed at repetition " +
          std::to_string(repetition) + ", update " +
          std::to_string(index));
    }
  }
}

int run(const CliOptions &options) {
  mosse::BenchmarkConfig config =
      mosse::load_benchmark_config(options.config_path);
  if (options.opencv_threads >= 0) {
    cv::setNumThreads(options.opencv_threads);
  }
  cv::ocl::setUseOpenCL(false);

  std::uint64_t decode_ns = 0U;
  std::uint64_t cache_bytes = 0U;
  std::uint64_t sequence_checksum = 0U;
  const std::vector<cv::Mat> frames =
      decode_cache(config, options, decode_ns, cache_bytes, sequence_checksum);

  for (std::uint64_t warmup = 0U; warmup < options.warmups; ++warmup) {
    static_cast<void>(replay_once(options, config, frames));
  }

  std::uint64_t total_initialization_ns = 0U;
  std::uint64_t total_update_ns = 0U;
  std::uint64_t total_attempted_updates = 0U;
  std::uint64_t successful_updates_per_repetition = 0U;
  std::uint64_t failed_updates_per_repetition = 0U;
  std::vector<ReplayTraceEntry> reference_trace;

  for (std::uint64_t repetition = 0U;
       repetition < options.repetitions; ++repetition) {
    ReplayResult result = replay_once(options, config, frames);
    if (repetition == 0U) {
      reference_trace = result.trace;
      successful_updates_per_repetition = result.successful_updates;
      failed_updates_per_repetition = result.failed_updates;
    } else {
      require_same_trace(reference_trace, result.trace, repetition);
    }
    total_initialization_ns += result.initialization_ns;
    total_update_ns += result.update_ns;
    total_attempted_updates += result.attempted_updates;
  }

  const double replay_fps =
      total_update_ns == 0U
          ? 0.0
          : static_cast<double>(total_attempted_updates) * 1.0e9 /
                static_cast<double>(total_update_ns);
  const double mean_initialization_us =
      static_cast<double>(total_initialization_ns) /
      static_cast<double>(options.repetitions) / 1.0e3;

  std::cout << "diagnostic_only=1"
            << " tracker=" << options.tracker
            << " cached_frames=" << frames.size()
            << " repetitions=" << options.repetitions
            << " warmups=" << options.warmups
            << " attempted_updates=" << total_attempted_updates
            << " successes_per_repetition="
            << successful_updates_per_repetition
            << " failures_per_repetition=" << failed_updates_per_repetition
            << " replay_trace_stable=1"
            << " replay_tracker_fps=" << std::fixed << std::setprecision(3)
            << replay_fps << '\n'
            << "decode_ms=" << std::fixed << std::setprecision(3)
            << static_cast<double>(decode_ns) / 1.0e6
            << " cache_mib="
            << static_cast<double>(cache_bytes) / (1024.0 * 1024.0)
            << " mean_initialization_us=" << mean_initialization_us << '\n'
            << "frame_sequence_checksum="
            << mosse::checksum_hex(sequence_checksum) << '\n';

  return EXIT_SUCCESS;
}

} // namespace

int main(const int argc, char **argv) {
  try {
    const CliOptions options = parse_cli(argc, argv);
    if (options.show_help) {
      std::cout << usage();
      return EXIT_SUCCESS;
    }
    return run(options);
  } catch (const cv::Exception &error) {
    std::cerr << "OpenCV error: " << error.what() << '\n';
  } catch (const std::exception &error) {
    std::cerr << "Error: " << error.what() << '\n';
  }
  return EXIT_FAILURE;
}
