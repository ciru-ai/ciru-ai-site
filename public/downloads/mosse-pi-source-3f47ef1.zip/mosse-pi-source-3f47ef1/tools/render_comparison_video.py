#!/usr/bin/env python3
"""Render an annotated comparison from two MOSSE benchmark CSV files.

The tracker timings displayed by this tool are read from the benchmark CSVs.
Video decoding, annotation, and encoding happen later and are never included
in tracker-only FPS.
"""

from __future__ import annotations

import argparse
import csv
import math
import re
import sys
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any


CHECKSUM_PATTERN = re.compile(r"^[0-9a-f]{16}$")
LEFT_COLOR = (0, 200, 255)
RIGHT_COLOR = (255, 110, 70)
WHITE = (245, 245, 245)
MUTED = (185, 185, 185)


@dataclass(frozen=True)
class Box:
    x: float
    y: float
    width: float
    height: float

    @property
    def center(self) -> tuple[float, float]:
        return (self.x + self.width * 0.5, self.y + self.height * 0.5)


@dataclass(frozen=True)
class FrameRecord:
    frame_index: int
    is_initialization: bool
    update_attempted: bool
    success: bool
    box: Box
    update_ns: int
    checksum: str

    @property
    def update_us(self) -> float:
        return self.update_ns / 1_000.0


@dataclass(frozen=True)
class FrameMetrics:
    center_distance: float
    iou: float


@dataclass
class RunningTrackerTiming:
    attempted_updates: int = 0
    total_update_ns: int = 0

    def add(self, record: FrameRecord) -> float | None:
        if record.update_attempted:
            self.attempted_updates += 1
            self.total_update_ns += record.update_ns
        if self.attempted_updates == 0 or self.total_update_ns == 0:
            return None
        return self.attempted_updates * 1_000_000_000.0 / self.total_update_ns


def _parse_bool(value: str, field: str, path: Path, row_number: int) -> bool:
    if value == "0":
        return False
    if value == "1":
        return True
    raise ValueError(
        f"{path}:{row_number}: {field} must be 0 or 1, got {value!r}"
    )


def read_records(path: Path) -> list[FrameRecord]:
    """Read and strictly validate one benchmark per-frame CSV."""

    required = {
        "frame_index",
        "is_initialization",
        "update_attempted",
        "success",
        "bbox_x",
        "bbox_y",
        "bbox_width",
        "bbox_height",
        "update_ns",
        "frame_checksum_fnv1a64",
    }
    records: list[FrameRecord] = []
    try:
        stream = path.open(newline="", encoding="utf-8")
    except OSError as error:
        raise ValueError(f"cannot open CSV {path}: {error}") from error

    with stream:
        reader = csv.DictReader(stream)
        missing = required.difference(reader.fieldnames or ())
        if missing:
            raise ValueError(f"{path}: missing CSV columns: {sorted(missing)}")

        for row_number, row in enumerate(reader, start=2):
            try:
                record = FrameRecord(
                    frame_index=int(row["frame_index"]),
                    is_initialization=_parse_bool(
                        row["is_initialization"],
                        "is_initialization",
                        path,
                        row_number,
                    ),
                    update_attempted=_parse_bool(
                        row["update_attempted"],
                        "update_attempted",
                        path,
                        row_number,
                    ),
                    success=_parse_bool(
                        row["success"], "success", path, row_number
                    ),
                    box=Box(
                        x=float(row["bbox_x"]),
                        y=float(row["bbox_y"]),
                        width=float(row["bbox_width"]),
                        height=float(row["bbox_height"]),
                    ),
                    update_ns=int(row["update_ns"]),
                    checksum=row["frame_checksum_fnv1a64"].strip().lower(),
                )
            except (TypeError, ValueError) as error:
                if isinstance(error, ValueError) and str(error).startswith(
                    str(path)
                ):
                    raise
                raise ValueError(f"{path}:{row_number}: {error}") from error

            expected_index = len(records)
            if record.frame_index != expected_index:
                raise ValueError(
                    f"{path}:{row_number}: expected contiguous frame index "
                    f"{expected_index}, got {record.frame_index}"
                )
            if record.is_initialization != (record.frame_index == 0):
                raise ValueError(
                    f"{path}:{row_number}: only frame 0 may be initialization"
                )
            if record.update_attempted == record.is_initialization:
                raise ValueError(
                    f"{path}:{row_number}: initialization must not be an update "
                    "and every later frame must attempt an update"
                )
            if record.update_ns < 0:
                raise ValueError(f"{path}:{row_number}: update_ns must be non-negative")
            if not record.update_attempted and record.update_ns != 0:
                raise ValueError(
                    f"{path}:{row_number}: a non-update row must have update_ns=0"
                )
            box_values = (
                record.box.x,
                record.box.y,
                record.box.width,
                record.box.height,
            )
            if not all(math.isfinite(value) for value in box_values):
                raise ValueError(f"{path}:{row_number}: non-finite bounding box")
            if record.box.width <= 0.0 or record.box.height <= 0.0:
                raise ValueError(f"{path}:{row_number}: non-positive bounding box")
            if not CHECKSUM_PATTERN.fullmatch(record.checksum):
                raise ValueError(
                    f"{path}:{row_number}: frame checksum must be 16 hexadecimal "
                    "characters"
                )
            records.append(record)

    if not records:
        raise ValueError(f"{path}: CSV contains no frame rows")
    return records


def validate_matching_records(
    left_records: list[FrameRecord],
    right_records: list[FrameRecord],
) -> None:
    """Enforce that both CSVs describe the exact same decoded frame sequence."""

    if len(left_records) != len(right_records):
        raise ValueError(
            "CSV row count differs: "
            f"left={len(left_records)}, right={len(right_records)}"
        )

    for left, right in zip(left_records, right_records):
        if left.frame_index != right.frame_index:
            raise ValueError(
                f"frame index differs: left={left.frame_index}, "
                f"right={right.frame_index}"
            )
        if left.is_initialization != right.is_initialization:
            raise ValueError(
                f"initialization flag differs at frame {left.frame_index}"
            )
        if left.update_attempted != right.update_attempted:
            raise ValueError(
                f"update_attempted differs at frame {left.frame_index}"
            )
        if left.checksum != right.checksum:
            raise ValueError(
                f"decoded frame checksum differs at frame {left.frame_index}: "
                f"{left.checksum} != {right.checksum}"
            )


def box_iou(left: Box, right: Box) -> float:
    intersection_width = max(
        0.0,
        min(left.x + left.width, right.x + right.width) - max(left.x, right.x),
    )
    intersection_height = max(
        0.0,
        min(left.y + left.height, right.y + right.height) - max(left.y, right.y),
    )
    intersection = intersection_width * intersection_height
    union = left.width * left.height + right.width * right.height - intersection
    return intersection / union if union > 0.0 else 0.0


def frame_metrics(left: FrameRecord, right: FrameRecord) -> FrameMetrics:
    left_center = left.box.center
    right_center = right.box.center
    return FrameMetrics(
        center_distance=math.hypot(
            left_center[0] - right_center[0],
            left_center[1] - right_center[1],
        ),
        iou=box_iou(left.box, right.box),
    )


def _format_latency(record: FrameRecord) -> str:
    if not record.update_attempted:
        return "initialization"
    return f"{record.update_us:.3f} us"


def _format_fps(value: float | None) -> str:
    return "n/a" if value is None else f"{value:.2f}"


def _validate_label(value: str, option: str) -> str:
    label = value.strip()
    if not label:
        raise ValueError(f"{option} must not be empty")
    if "\n" in label or "\r" in label:
        raise ValueError(f"{option} must be a single line")
    if len(label) > 24:
        raise ValueError(f"{option} must not exceed 24 characters")
    return label


def _rectangle_points(
    box: Box, frame_width: int, frame_height: int
) -> tuple[tuple[int, int], tuple[int, int]]:
    x1 = min(frame_width - 1, max(0, round(box.x)))
    y1 = min(frame_height - 1, max(0, round(box.y)))
    x2 = min(frame_width - 1, max(0, round(box.x + box.width)))
    y2 = min(frame_height - 1, max(0, round(box.y + box.height)))
    return (x1, y1), (x2, y2)


def annotate_frame(
    cv2: Any,
    frame: Any,
    left: FrameRecord,
    right: FrameRecord,
    metrics: FrameMetrics,
    left_fps: float | None,
    right_fps: float | None,
    frame_count: int,
    left_label: str,
    right_label: str,
) -> None:
    """Annotate a decoded frame in place."""

    frame_height, frame_width = frame.shape[:2]
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = max(0.38, min(0.65, frame_width / 1_200.0))
    line_height = max(19, round(30 * font_scale))
    panel_height = min(frame_height, 12 + line_height * 4)

    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (frame_width, panel_height), (8, 8, 8), -1)
    cv2.addWeighted(overlay, 0.72, frame, 0.28, 0.0, frame)

    left_points = _rectangle_points(left.box, frame_width, frame_height)
    right_points = _rectangle_points(right.box, frame_width, frame_height)
    cv2.rectangle(frame, *left_points, LEFT_COLOR, 5, cv2.LINE_AA)
    cv2.rectangle(frame, *right_points, RIGHT_COLOR, 2, cv2.LINE_AA)

    for record, color, radius in (
        (left, LEFT_COLOR, 5),
        (right, RIGHT_COLOR, 3),
    ):
        center = record.box.center
        point = (
            min(frame_width - 1, max(0, round(center[0]))),
            min(frame_height - 1, max(0, round(center[1]))),
        )
        cv2.circle(frame, point, radius, color, -1, cv2.LINE_AA)

    status_left = "OK" if left.success else "FAIL"
    status_right = "OK" if right.success else "FAIL"
    lines = (
        (
            f"Frame {left.frame_index}/{frame_count - 1}  "
            f"center delta {metrics.center_distance:.3f} px  "
            f"IoU {metrics.iou:.4f}",
            WHITE,
        ),
        (
            f"{left_label} [{status_left}]  update {_format_latency(left)}  "
            f"running tracker FPS {_format_fps(left_fps)}",
            LEFT_COLOR,
        ),
        (
            f"{right_label} [{status_right}]  update {_format_latency(right)}  "
            f"running tracker FPS {_format_fps(right_fps)}",
            RIGHT_COLOR,
        ),
        ("Recorded CSV timing; annotation and encoding excluded", MUTED),
    )
    for line_index, (text, color) in enumerate(lines):
        baseline = 8 + line_height * (line_index + 1)
        cv2.putText(
            frame,
            text,
            (10, baseline),
            font,
            font_scale,
            color,
            1,
            cv2.LINE_AA,
        )


def _load_cv2() -> Any:
    try:
        import cv2  # type: ignore[import-not-found]
    except ImportError as error:
        raise RuntimeError(
            "OpenCV Python bindings are required (import name: cv2)"
        ) from error
    return cv2


def _check_distinct_paths(
    video_path: Path,
    left_csv: Path,
    right_csv: Path,
    output_path: Path,
) -> None:
    output = output_path.resolve(strict=False)
    for label, input_path in (
        ("source video", video_path),
        ("left CSV", left_csv),
        ("right CSV", right_csv),
    ):
        if output == input_path.resolve(strict=False):
            raise ValueError(f"output path must differ from {label}")
    if output_path.suffix.lower() != ".mp4":
        raise ValueError("--output must use the .mp4 extension")


def render_comparison(
    video_path: Path,
    left_csv: Path,
    right_csv: Path,
    output_path: Path,
    left_label: str = "OpenCV",
    right_label: str = "Rust",
) -> int:
    """Render and atomically publish a comparison MP4."""

    _check_distinct_paths(video_path, left_csv, right_csv, output_path)
    left_label = _validate_label(left_label, "--opencv-label")
    right_label = _validate_label(right_label, "--rust-label")
    left_records = read_records(left_csv)
    right_records = read_records(right_csv)
    validate_matching_records(left_records, right_records)

    if not video_path.is_file():
        raise ValueError(f"video does not exist or is not a file: {video_path}")

    cv2 = _load_cv2()
    capture = cv2.VideoCapture(str(video_path))
    if not capture.isOpened():
        capture.release()
        raise RuntimeError(f"cannot open video: {video_path}")

    source_fps = float(capture.get(cv2.CAP_PROP_FPS))
    if not math.isfinite(source_fps) or source_fps <= 0.0:
        capture.release()
        raise RuntimeError(f"video reports invalid source FPS: {source_fps!r}")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    temporary_output = output_path.with_name(
        f".{output_path.stem}.{uuid.uuid4().hex}.rendering.mp4"
    )
    writer = None
    published = False
    rendered = 0
    try:
        decoded, frame = capture.read()
        if not decoded or frame is None:
            raise RuntimeError(f"video contains no decodable frames: {video_path}")
        if len(frame.shape) != 3 or frame.shape[2] != 3:
            raise RuntimeError(
                "decoded video frames must be three-channel BGR images"
            )
        frame_height, frame_width = frame.shape[:2]
        if frame_width <= 0 or frame_height <= 0:
            raise RuntimeError("decoded video has invalid frame dimensions")

        writer = cv2.VideoWriter(
            str(temporary_output),
            cv2.VideoWriter_fourcc(*"mp4v"),
            source_fps,
            (frame_width, frame_height),
        )
        if not writer.isOpened():
            raise RuntimeError(
                "cannot create MP4 output with the OpenCV mp4v encoder: "
                f"{temporary_output}"
            )

        left_timing = RunningTrackerTiming()
        right_timing = RunningTrackerTiming()
        frame_count = len(left_records)
        progress_every = max(1, min(250, frame_count // 20 or 1))

        for position, (left, right) in enumerate(
            zip(left_records, right_records)
        ):
            if position > 0:
                decoded, frame = capture.read()
                if not decoded or frame is None:
                    raise RuntimeError(
                        "video ended before CSV rows: "
                        f"decoded={position}, CSV rows={frame_count}"
                    )
            if (
                len(frame.shape) != 3
                or frame.shape[2] != 3
                or frame.shape[:2] != (frame_height, frame_width)
            ):
                shape = tuple(frame.shape)
                raise RuntimeError(
                    f"decoded frame {position} changed layout; "
                    f"expected {frame_width}x{frame_height} BGR, got {shape}"
                )

            metrics = frame_metrics(left, right)
            left_fps = left_timing.add(left)
            right_fps = right_timing.add(right)
            annotate_frame(
                cv2,
                frame,
                left,
                right,
                metrics,
                left_fps,
                right_fps,
                frame_count,
                left_label,
                right_label,
            )
            writer.write(frame)
            rendered += 1

            if rendered % progress_every == 0 or rendered == frame_count:
                print(
                    f"Rendered {rendered}/{frame_count} frames...",
                    file=sys.stderr,
                    flush=True,
                )

        extra_decoded, _ = capture.read()
        if extra_decoded:
            raise RuntimeError(
                "video contains more decoded frames than the CSV files: "
                f"CSV rows={frame_count}"
            )

        writer.release()
        writer = None
        temporary_output.replace(output_path)
        published = True
        print(
            f"Wrote {rendered} annotated frames to {output_path} "
            f"({frame_width}x{frame_height} at {source_fps:.6f} fps)."
        )
        print(
            "Displayed tracker FPS uses recorded update_ns only; "
            "decoding, annotation, and encoding are excluded."
        )
        return rendered
    finally:
        capture.release()
        if writer is not None:
            writer.release()
        if not published:
            temporary_output.unlink(missing_ok=True)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Render an annotated OpenCV-versus-Rust MOSSE MP4 from matching "
            "benchmark CSV files. Recorded tracker timing is displayed; this "
            "post-processing tool never contributes to benchmark timing."
        )
    )
    parser.add_argument("--video", required=True, type=Path, help="Source MP4")
    parser.add_argument(
        "--opencv-csv",
        required=True,
        type=Path,
        help="Left-side benchmark per-frame CSV",
    )
    parser.add_argument(
        "--rust-csv",
        required=True,
        type=Path,
        help="Right-side benchmark per-frame CSV",
    )
    parser.add_argument(
        "--output",
        required=True,
        type=Path,
        help="Destination comparison MP4",
    )
    parser.add_argument(
        "--opencv-label",
        default="OpenCV",
        help="Display label for --opencv-csv (default: OpenCV)",
    )
    parser.add_argument(
        "--rust-label",
        default="Rust",
        help="Display label for --rust-csv (default: Rust)",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        render_comparison(
            args.video,
            args.opencv_csv,
            args.rust_csv,
            args.output,
            args.opencv_label,
            args.rust_label,
        )
    except (OSError, RuntimeError, ValueError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
