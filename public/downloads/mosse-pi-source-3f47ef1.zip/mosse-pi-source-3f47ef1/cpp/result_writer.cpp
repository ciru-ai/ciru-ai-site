#include "mosse/result_writer.hpp"

#include "mosse/frame_checksum.hpp"

#include <algorithm>
#include <cmath>
#include <iomanip>
#include <limits>
#include <sstream>
#include <stdexcept>

namespace mosse {
namespace {

void create_parent_directory(const std::filesystem::path &path) {
  const std::filesystem::path parent = path.parent_path();
  if (!parent.empty()) {
    std::error_code error;
    std::filesystem::create_directories(parent, error);
    if (error) {
      throw std::runtime_error("Unable to create output directory '" +
                               parent.string() + "': " + error.message());
    }
  }
}

std::string json_escape(const std::string &value) {
  std::ostringstream escaped;
  for (const unsigned char character : value) {
    switch (character) {
    case '"':
      escaped << "\\\"";
      break;
    case '\\':
      escaped << "\\\\";
      break;
    case '\b':
      escaped << "\\b";
      break;
    case '\f':
      escaped << "\\f";
      break;
    case '\n':
      escaped << "\\n";
      break;
    case '\r':
      escaped << "\\r";
      break;
    case '\t':
      escaped << "\\t";
      break;
    default:
      if (character < 0x20U) {
        escaped << "\\u" << std::hex << std::setfill('0') << std::setw(4)
                << static_cast<unsigned int>(character) << std::dec;
      } else {
        escaped << static_cast<char>(character);
      }
    }
  }
  return escaped.str();
}

std::uint64_t nearest_rank(const std::vector<std::uint64_t> &sorted,
                           const double percentile) {
  const double raw_rank =
      std::ceil(percentile * static_cast<double>(sorted.size()));
  const std::size_t rank = static_cast<std::size_t>(std::max(1.0, raw_rank));
  return sorted[rank - 1U];
}

double median(const std::vector<std::uint64_t> &sorted) {
  const std::size_t count = sorted.size();
  const std::size_t middle = count / 2U;
  if ((count % 2U) != 0U) {
    return static_cast<double>(sorted[middle]);
  }
  return (static_cast<double>(sorted[middle - 1U]) +
          static_cast<double>(sorted[middle])) /
         2.0;
}

void write_json_number_or_null(std::ostream &output, const double value) {
  if (std::isfinite(value)) {
    output << std::setprecision(15) << value;
  } else {
    output << "null";
  }
}

double rate(const std::uint64_t items, const std::uint64_t duration_ns) {
  if (items == 0U || duration_ns == 0U) {
    return std::numeric_limits<double>::quiet_NaN();
  }
  return static_cast<double>(items) * 1.0e9 / static_cast<double>(duration_ns);
}

} // namespace

CsvFrameWriter::CsvFrameWriter(const std::filesystem::path &path) {
  create_parent_directory(path);
  output_.open(path, std::ios::out | std::ios::trunc);
  if (!output_.is_open()) {
    throw std::runtime_error("Unable to open per-frame CSV output: " +
                             path.string());
  }

  output_ << "frame_index,is_initialization,update_attempted,success,"
          << "bbox_x,bbox_y,bbox_width,bbox_height,"
          << "update_ns,update_us,frame_checksum_fnv1a64\n";
}

void CsvFrameWriter::write(const FrameRecord &record) {
  output_ << record.frame_index << ',' << (record.is_initialization ? 1 : 0)
          << ',' << (record.update_attempted ? 1 : 0) << ','
          << (record.success ? 1 : 0) << ',' << std::fixed
          << std::setprecision(6) << record.bbox.x << ',' << record.bbox.y
          << ',' << record.bbox.width << ',' << record.bbox.height << ','
          << record.update_ns << ','
          << (static_cast<double>(record.update_ns) / 1000.0) << ',';
  if (record.frame_checksum.has_value()) {
    output_ << checksum_hex(*record.frame_checksum);
  }
  output_ << '\n';

  if (!output_) {
    throw std::runtime_error("Failed while writing per-frame CSV output");
  }
}

void CsvFrameWriter::flush() {
  output_.flush();
  if (!output_) {
    throw std::runtime_error("Failed while flushing per-frame CSV output");
  }
}

void write_summary_json(const std::filesystem::path &path,
                        const BenchmarkSummary &summary) {
  create_parent_directory(path);
  std::ofstream output(path, std::ios::out | std::ios::trunc);
  if (!output.is_open()) {
    throw std::runtime_error("Unable to open JSON summary output: " +
                             path.string());
  }

  std::vector<std::uint64_t> sorted = summary.update_latencies_ns;
  std::sort(sorted.begin(), sorted.end());

  long double latency_sum = 0.0L;
  for (const std::uint64_t latency : sorted) {
    latency_sum += static_cast<long double>(latency);
  }

  const bool has_latencies = !sorted.empty();
  const double mean_latency =
      has_latencies ? static_cast<double>(
                          latency_sum / static_cast<long double>(sorted.size()))
                    : std::numeric_limits<double>::quiet_NaN();
  const double median_latency =
      has_latencies ? median(sorted) : std::numeric_limits<double>::quiet_NaN();

  output << "{\n"
         << "  \"schema_version\": 1,\n"
         << "  \"tracker\": \"" << json_escape(summary.tracker_name) << "\",\n"
         << "  \"opencv_version\": \"" << json_escape(summary.opencv_version)
         << "\",\n"
         << "  \"config_path\": \"" << json_escape(summary.config_path.string())
         << "\",\n"
         << "  \"video_path\": \"" << json_escape(summary.video_path.string())
         << "\",\n"
         << "  \"frames_csv\": \"" << json_escape(summary.frames_csv.string())
         << "\",\n"
         << "  \"expected_video_sha256\": ";
  if (summary.expected_video_sha256.empty()) {
    output << "null,\n";
  } else {
    output << '"' << json_escape(summary.expected_video_sha256) << "\",\n";
  }
  output << "  \"frame_checksum_algorithm\": ";
  if (summary.checksum_algorithm.empty()) {
    output << "null,\n";
  } else {
    output << '"' << json_escape(summary.checksum_algorithm) << "\",\n";
  }
  output << "  \"frame_sequence_checksum\": ";
  if (summary.frame_sequence_checksum.has_value()) {
    output << '"' << checksum_hex(*summary.frame_sequence_checksum) << "\",\n";
  } else {
    output << "null,\n";
  }
  output << "  \"initial_roi\": {\n"
         << "    \"x\": " << std::setprecision(15) << summary.initial_roi.x
         << ",\n"
         << "    \"y\": " << summary.initial_roi.y << ",\n"
         << "    \"width\": " << summary.initial_roi.width << ",\n"
         << "    \"height\": " << summary.initial_roi.height << "\n"
         << "  },\n"
         << "  \"max_frames\": " << summary.max_frames << ",\n"
         << "  \"expected_width\": " << summary.expected_width << ",\n"
         << "  \"expected_height\": " << summary.expected_height << ",\n"
         << "  \"expected_decoded_frames\": " << summary.expected_decoded_frames
         << ",\n"
         << "  \"frame_width\": " << summary.frame_width << ",\n"
         << "  \"frame_height\": " << summary.frame_height << ",\n"
         << "  \"frame_type\": " << summary.frame_type << ",\n"
         << "  \"source_fps\": ";
  write_json_number_or_null(output, summary.source_fps);
  output << ",\n"
         << "  \"source_reported_frame_count\": "
         << summary.source_reported_frame_count << ",\n"
         << "  \"opencv_threads_requested\": "
         << summary.opencv_threads_requested << ",\n"
         << "  \"opencv_threads_effective\": "
         << summary.opencv_threads_effective << ",\n"
         << "  \"opencv_use_optimized\": "
         << (summary.opencv_use_optimized ? "true" : "false") << ",\n"
         << "  \"decoded_frames\": " << summary.decoded_frames << ",\n"
         << "  \"attempted_updates\": " << summary.attempted_updates << ",\n"
         << "  \"successful_updates\": " << summary.successful_updates << ",\n"
         << "  \"failed_updates\": " << summary.failed_updates << ",\n"
         << "  \"frame_limit_reached\": "
         << (summary.frame_limit_reached ? "true" : "false") << ",\n"
         << "  \"end_of_stream_reached\": "
         << (summary.end_of_stream_reached ? "true" : "false") << ",\n"
         << "  \"full_video_processed\": "
         << (summary.full_video_processed ? "true" : "false") << ",\n"
         << "  \"initialization_ns\": " << summary.initialization_ns << ",\n"
         << "  \"total_update_ns\": " << summary.total_update_ns << ",\n"
         << "  \"tracker_only_fps\": ";
  write_json_number_or_null(
      output, rate(summary.attempted_updates, summary.total_update_ns));
  output << ",\n"
         << "  \"end_to_end_ns\": " << summary.end_to_end_ns << ",\n"
         << "  \"end_to_end_fps\": ";
  write_json_number_or_null(
      output, rate(summary.decoded_frames, summary.end_to_end_ns));
  output << ",\n"
         << "  \"latency_percentile_method\": \"nearest-rank\",\n"
         << "  \"latency_ns\": {\n"
         << "    \"mean\": ";
  write_json_number_or_null(output, mean_latency);
  output << ",\n"
         << "    \"median\": ";
  write_json_number_or_null(output, median_latency);
  output << ",\n"
         << "    \"p95\": ";
  if (has_latencies) {
    output << nearest_rank(sorted, 0.95);
  } else {
    output << "null";
  }
  output << ",\n"
         << "    \"p99\": ";
  if (has_latencies) {
    output << nearest_rank(sorted, 0.99);
  } else {
    output << "null";
  }
  output << ",\n"
         << "    \"min\": ";
  if (has_latencies) {
    output << sorted.front();
  } else {
    output << "null";
  }
  output << ",\n"
         << "    \"max\": ";
  if (has_latencies) {
    output << sorted.back();
  } else {
    output << "null";
  }
  output << "\n"
         << "  }\n"
         << "}\n";

  output.flush();
  if (!output) {
    throw std::runtime_error("Failed while writing JSON summary output: " +
                             path.string());
  }
}

} // namespace mosse
