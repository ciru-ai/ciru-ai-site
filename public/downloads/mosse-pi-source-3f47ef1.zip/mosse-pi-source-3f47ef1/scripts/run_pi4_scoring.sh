#!/usr/bin/env bash
#
# Run the authoritative paired MOSSE scoring matrix without changing host state.

set -Eeuo pipefail

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
repo_root="$(cd -- "${script_dir}/.." && pwd -P)"

benchmark="${repo_root}/build/release/mosse_benchmark"
config="${repo_root}/config/benchmark.yml"
compare_tool="${repo_root}/tools/compare_tracks.py"
environment_capture="${repo_root}/scripts/capture_environment.sh"
output_root="${repo_root}/results/pi4-scoring"
run_id=""

warmups=1
measured_pairs=5
opencv_threads=1
threads_spec="4"
max_frames=0
pause_seconds="0"
required_governor="performance"
use_taskset=1
verify_video_hash=1
quick_mode=0
rust_caller_cpus=""
run_timeout_seconds="0"
expected_benchmark_sha256=""
require_exact_parity=0

measured_pairs_set=0
threads_set=0
max_frames_set=0
governor_set=0

usage() {
    cat <<'EOF'
Usage: run_pi4_scoring.sh [options]

Runs paired OpenCV and Rust MOSSE benchmarks in alternating order. Every
tracker call gets unique CSV/JSON/log files, pre/post runtime-state captures,
and a parity comparison. A manifest.json is updated throughout the suite.

Official defaults:
  1 warm-up per tracker/core configuration
  5 measured pairs per core configuration
  OpenCV 1 thread paired with Rust 4 cores
  full video, performance governor, and taskset CPU affinity

Options:
  --benchmark PATH          Harness executable (default: build/release/mosse_benchmark).
  --config PATH             Benchmark config (default: config/benchmark.yml).
  --output-root PATH        Parent directory for unique suites.
  --run-id ID               Safe unique directory name; fails if it exists.
  --warmups COUNT           Warm-ups per tracker/configuration (default: 1).
  --runs COUNT              Measured pairs per configuration (default: 5).
  --opencv-threads COUNT    OpenCV thread count in every pair (default: 1).
  --threads LIST            Rust core counts, comma-separated (default: 4).
  --max-frames COUNT        0 means full video (default: 0).
  --pause-seconds SECONDS   Delay before each run after the first (default: 0).
  --required-governor NAME  Required governor, or 'any' (default: performance).
  --rust-caller-cpus LIST   taskset CPU list for Rust caller processes. Workers
                            may expand/pin themselves (official normal-spin: 0).
  --run-timeout-seconds N   Per-process wall timeout; 0 disables (default: 0).
  --expected-benchmark-sha256 SHA256
                            Require this exact executable before/after every run.
  --require-exact-parity    Require literal equality of the nine non-timing CSV
                            fields plus the official 4947/4946 full replay.
  --no-taskset              Do not constrain the benchmark process CPU affinity.
  --skip-video-hash         Do not hash-check the configured source video.
  --quick                   Smoke defaults: 1 pair, Rust 1 core, 120 frames,
                            and no governor requirement. Explicit options win.
  --help                    Show this help.

The runner is read-only with respect to system configuration. It never invokes
sudo and never changes governors, affinity outside child processes, cooling,
services, or throttling state. Configure the Pi before starting an official run.
EOF
}

die() {
    echo "error: $*" >&2
    exit 1
}

require_value() {
    local option="$1"
    local remaining="$2"
    if ((remaining < 2)); then
        die "${option} requires a value"
    fi
}

resolve_repo_path() {
    local path="$1"
    if [[ "$path" == /* ]]; then
        printf '%s\n' "$path"
    else
        printf '%s/%s\n' "$repo_root" "$path"
    fi
}

is_non_negative_integer() {
    [[ "$1" =~ ^[0-9]+$ ]]
}

while (($# > 0)); do
    case "$1" in
        --benchmark)
            require_value "$1" "$#"
            benchmark="$2"
            shift 2
            ;;
        --config)
            require_value "$1" "$#"
            config="$2"
            shift 2
            ;;
        --output-root)
            require_value "$1" "$#"
            output_root="$2"
            shift 2
            ;;
        --run-id)
            require_value "$1" "$#"
            run_id="$2"
            shift 2
            ;;
        --warmups)
            require_value "$1" "$#"
            warmups="$2"
            shift 2
            ;;
        --runs)
            require_value "$1" "$#"
            measured_pairs="$2"
            measured_pairs_set=1
            shift 2
            ;;
        --opencv-threads)
            require_value "$1" "$#"
            opencv_threads="$2"
            shift 2
            ;;
        --threads)
            require_value "$1" "$#"
            threads_spec="$2"
            threads_set=1
            shift 2
            ;;
        --max-frames)
            require_value "$1" "$#"
            max_frames="$2"
            max_frames_set=1
            shift 2
            ;;
        --pause-seconds)
            require_value "$1" "$#"
            pause_seconds="$2"
            shift 2
            ;;
        --required-governor)
            require_value "$1" "$#"
            required_governor="$2"
            governor_set=1
            shift 2
            ;;
        --rust-caller-cpus)
            require_value "$1" "$#"
            rust_caller_cpus="$2"
            shift 2
            ;;
        --run-timeout-seconds)
            require_value "$1" "$#"
            run_timeout_seconds="$2"
            shift 2
            ;;
        --expected-benchmark-sha256)
            require_value "$1" "$#"
            expected_benchmark_sha256="${2,,}"
            shift 2
            ;;
        --require-exact-parity)
            require_exact_parity=1
            shift
            ;;
        --no-taskset)
            use_taskset=0
            shift
            ;;
        --skip-video-hash)
            verify_video_hash=0
            shift
            ;;
        --quick)
            quick_mode=1
            shift
            ;;
        --help|-h)
            usage
            exit 0
            ;;
        *)
            echo "error: unknown argument: $1" >&2
            usage >&2
            exit 2
            ;;
    esac
done

if ((quick_mode == 1)); then
    if ((measured_pairs_set == 0)); then
        measured_pairs=1
    fi
    if ((threads_set == 0)); then
        threads_spec="1"
    fi
    if ((max_frames_set == 0)); then
        max_frames=120
    fi
    if ((governor_set == 0)); then
        required_governor="any"
    fi
fi

is_non_negative_integer "$warmups" ||
    die "--warmups must be a non-negative integer"
is_non_negative_integer "$measured_pairs" ||
    die "--runs must be a positive integer"
((measured_pairs > 0)) || die "--runs must be greater than zero"
[[ "$opencv_threads" =~ ^[1-9][0-9]*$ ]] ||
    die "--opencv-threads must be a positive integer"
is_non_negative_integer "$max_frames" ||
    die "--max-frames must be a non-negative integer"
[[ "$pause_seconds" =~ ^[0-9]+([.][0-9]+)?$ ]] ||
    die "--pause-seconds must be a non-negative number"
[[ "$run_timeout_seconds" =~ ^[0-9]+([.][0-9]+)?$ ]] ||
    die "--run-timeout-seconds must be a non-negative number"
[[ -n "$required_governor" ]] ||
    die "--required-governor must not be empty"
if [[ -n "$rust_caller_cpus" ]]; then
    [[ "$rust_caller_cpus" =~ ^[0-9]+([,-][0-9]+)*$ ]] ||
        die "--rust-caller-cpus must be a taskset CPU list such as 0 or 0,2-3"
    ((use_taskset == 1)) ||
        die "--rust-caller-cpus cannot be combined with --no-taskset"
fi
if [[ -n "$expected_benchmark_sha256" ]]; then
    [[ "$expected_benchmark_sha256" =~ ^[0-9a-f]{64}$ ]] ||
        die "--expected-benchmark-sha256 must be 64 hexadecimal characters"
fi
if ((require_exact_parity == 1)); then
    ((max_frames == 0)) ||
        die "--require-exact-parity requires --max-frames 0"
    ((verify_video_hash == 1)) ||
        die "--require-exact-parity cannot be combined with --skip-video-hash"
fi

benchmark="$(resolve_repo_path "$benchmark")"
config="$(resolve_repo_path "$config")"
output_root="$(resolve_repo_path "$output_root")"

[[ -x "$benchmark" ]] || die "benchmark executable is missing: $benchmark"
[[ -r "$config" ]] || die "benchmark config is unreadable: $config"
[[ -r "$compare_tool" ]] || die "comparison tool is unreadable: $compare_tool"
[[ -r "$environment_capture" ]] ||
    die "environment capture script is unreadable: $environment_capture"

for command_name in python3 date hostname tee getconf; do
    command -v "$command_name" >/dev/null 2>&1 ||
        die "required command is unavailable: $command_name"
done
if ((use_taskset == 1)); then
    command -v taskset >/dev/null 2>&1 ||
        die "taskset is required unless --no-taskset is used"
fi
if [[ "$run_timeout_seconds" != "0" ]]; then
    command -v timeout >/dev/null 2>&1 ||
        die "timeout is required when --run-timeout-seconds is non-zero"
fi

calculate_benchmark_sha256() {
    python3 - "$benchmark" <<'PY'
import hashlib
import sys

digest = hashlib.sha256()
with open(sys.argv[1], "rb") as stream:
    for block in iter(lambda: stream.read(1024 * 1024), b""):
        digest.update(block)
print(digest.hexdigest())
PY
}

benchmark_sha256_initial="$(calculate_benchmark_sha256)" ||
    die "failed to hash benchmark executable: $benchmark"
benchmark_sha256_last_verified="$benchmark_sha256_initial"
benchmark_sha256_final=""
if [[ -n "$expected_benchmark_sha256" ]] &&
    [[ "$benchmark_sha256_initial" != "$expected_benchmark_sha256" ]]; then
    die "benchmark SHA-256 mismatch: expected ${expected_benchmark_sha256}, got ${benchmark_sha256_initial}"
fi

IFS=',' read -r -a requested_threads <<<"$threads_spec"
thread_counts=()
declare -A seen_thread_counts=()
for value in "${requested_threads[@]}"; do
    value="${value//[[:space:]]/}"
    [[ "$value" =~ ^[1-9][0-9]*$ ]] ||
        die "--threads must contain comma-separated positive integers"
    [[ -z "${seen_thread_counts[$value]:-}" ]] ||
        die "duplicate thread count: $value"
    seen_thread_counts[$value]=1
    thread_counts+=("$value")
done
((${#thread_counts[@]} > 0)) || die "--threads did not contain a value"

online_cpus="$(getconf _NPROCESSORS_ONLN)"
[[ "$online_cpus" =~ ^[1-9][0-9]*$ ]] ||
    die "unable to determine online CPU count"
((opencv_threads <= online_cpus)) ||
    die "OpenCV thread count ${opencv_threads} exceeds ${online_cpus} online CPUs"
for rust_thread_count in "${thread_counts[@]}"; do
    ((rust_thread_count <= online_cpus)) ||
        die "Rust core count ${rust_thread_count} exceeds ${online_cpus} online CPUs"
done

if [[ -z "$run_id" ]]; then
    host_label="$(hostname -s 2>/dev/null || hostname)"
    host_label="$(printf '%s' "$host_label" | tr -c 'A-Za-z0-9._-' '_')"
    run_id="$(date -u +%Y%m%dT%H%M%SZ)-${host_label}-$$"
fi
[[ "$run_id" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] ||
    die "--run-id must contain only letters, digits, dot, underscore, or dash"
[[ "$run_id" != "." && "$run_id" != ".." ]] ||
    die "--run-id cannot be '.' or '..'"

mkdir -p -- "$output_root"
suite_dir="${output_root}/${run_id}"
if ! mkdir -- "$suite_dir"; then
    die "suite directory already exists or cannot be created: $suite_dir"
fi

manifest_path="${suite_dir}/manifest.json"
runs_tsv="${suite_dir}/.runs.tsv"
parity_tsv="${suite_dir}/.parity.tsv"
config_identity_path="${suite_dir}/config-identity.json"
environment_pre_path="${suite_dir}/environment-pre.json"
environment_post_path="${suite_dir}/environment-post.json"
suite_state_pre_path="${suite_dir}/runtime-state-pre.json"
suite_state_post_path="${suite_dir}/runtime-state-post.json"

printf '%s\n' \
    $'sequence\tphase\topencv_thread_count\trust_thread_count\ttracker_thread_count\tpair_index\tglobal_pair_index\torder_in_pair\ttracker\tstarted_at\tended_at\texit_code\tcpu_list\tbenchmark_sha256_pre\tbenchmark_sha256_post\tcsv\tsummary\tlog\tpre_state\tpost_state' \
    >"$runs_tsv"
printf '%s\n' \
    $'opencv_thread_count\trust_thread_count\tpair_index\tglobal_pair_index\texit_code\tall_gates_pass\topencv_csv\trust_csv\tcomparison\tlog' \
    >"$parity_tsv"

suite_started_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
suite_status="running"
failure_context="initializing suite"
suite_ready=1
runs_started=0
run_sequence=0

capture_runtime_state() {
    local output_path="$1"
    local label="$2"
    [[ ! -e "$output_path" ]] ||
        die "refusing to overwrite runtime state: $output_path"

    python3 - "$output_path" "$label" <<'PY'
from __future__ import annotations

import datetime as dt
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any


output = Path(sys.argv[1])
label = sys.argv[2]


def read_text(path: Path) -> str | None:
    try:
        return path.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return None


def read_int(path: Path) -> int | None:
    text = read_text(path)
    if text is None:
        return None
    try:
        return int(text)
    except ValueError:
        return None


def run(command: list[str]) -> dict[str, Any]:
    try:
        completed = subprocess.run(
            command,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=5,
            check=False,
        )
        return {
            "available": True,
            "exit_code": completed.returncode,
            "output": completed.stdout.strip() or None,
        }
    except FileNotFoundError:
        return {"available": False, "exit_code": None, "output": None}
    except (OSError, subprocess.SubprocessError) as error:
        return {
            "available": True,
            "exit_code": None,
            "output": f"{type(error).__name__}: {error}",
        }


policies: list[dict[str, Any]] = []
for policy in sorted(Path("/sys/devices/system/cpu/cpufreq").glob("policy*")):
    policies.append(
        {
            "policy": policy.name,
            "affected_cpus": read_text(policy / "affected_cpus"),
            "governor": read_text(policy / "scaling_governor"),
            "min_khz": read_int(policy / "scaling_min_freq"),
            "max_khz": read_int(policy / "scaling_max_freq"),
            "current_khz": read_int(policy / "scaling_cur_freq"),
        }
    )

thermal_zones: list[dict[str, Any]] = []
for zone in sorted(Path("/sys/class/thermal").glob("thermal_zone*")):
    millidegrees = read_int(zone / "temp")
    thermal_zones.append(
        {
            "zone": zone.name,
            "type": read_text(zone / "type"),
            "millidegrees_celsius": millidegrees,
            "celsius": (
                round(millidegrees / 1000.0, 3)
                if millidegrees is not None
                else None
            ),
        }
    )

try:
    affinity = sorted(os.sched_getaffinity(0))
except (AttributeError, OSError):
    affinity = None

payload = {
    "schema_version": 1,
    "label": label,
    "captured_at": dt.datetime.now(dt.timezone.utc).isoformat(),
    "load_average": list(os.getloadavg()) if hasattr(os, "getloadavg") else None,
    "process_affinity": affinity,
    "boot_id": read_text(Path("/proc/sys/kernel/random/boot_id")),
    "cpu_online": read_text(Path("/sys/devices/system/cpu/online")),
    "process_scheduler_policy": (
        os.sched_getscheduler(0) if hasattr(os, "sched_getscheduler") else None
    ),
    "process_scheduler_priority": (
        os.sched_getparam(0).sched_priority
        if hasattr(os, "sched_getparam")
        else None
    ),
    "process_nice": os.nice(0),
    "sched_rt_period_us": read_int(Path("/proc/sys/kernel/sched_rt_period_us")),
    "sched_rt_runtime_us": read_int(Path("/proc/sys/kernel/sched_rt_runtime_us")),
    "cpufreq_policies": policies,
    "thermal_zones": thermal_zones,
    "vcgencmd_measure_temp": run(["vcgencmd", "measure_temp"]),
    "vcgencmd_get_throttled": run(["vcgencmd", "get_throttled"]),
}

with output.open("x", encoding="utf-8") as stream:
    json.dump(payload, stream, indent=2, sort_keys=True)
    stream.write("\n")
PY
}

capture_full_environment() {
    local output_path="$1"
    local temporary="${output_path}.tmp.$$"
    [[ ! -e "$output_path" && ! -e "$temporary" ]] ||
        die "refusing to overwrite environment capture: $output_path"

    if ! bash "$environment_capture" --format json >"$temporary"; then
        rm -f -- "$temporary"
        return 1
    fi
    mv -- "$temporary" "$output_path"
}

verify_governor_state() {
    if [[ "$required_governor" == "any" ]]; then
        return 0
    fi

    local governor_paths=()
    local path
    local current
    shopt -s nullglob
    governor_paths=(
        /sys/devices/system/cpu/cpufreq/policy*/scaling_governor
    )
    shopt -u nullglob
    ((${#governor_paths[@]} > 0)) || {
        echo "error: no readable CPU governor policies were found" >&2
        return 1
    }

    for path in "${governor_paths[@]}"; do
        if [[ ! -r "$path" ]]; then
            echo "error: CPU governor is unreadable: $path" >&2
            return 1
        fi
        current="$(<"$path")"
        if [[ "$current" != "$required_governor" ]]; then
            echo \
                "error: ${path} is '${current}', expected '${required_governor}'; configure it before running" \
                >&2
            return 1
        fi
    done
}

verify_benchmark_identity() {
    local stage="$1"
    local actual

    benchmark_sha256_last_verified=""
    if ! actual="$(calculate_benchmark_sha256)"; then
        echo "error: failed to hash benchmark executable during ${stage}: $benchmark" >&2
        return 1
    fi
    benchmark_sha256_last_verified="$actual"
    if [[ "$actual" != "$benchmark_sha256_initial" ]]; then
        echo \
            "error: benchmark executable changed during the suite (${stage}): initial ${benchmark_sha256_initial}, got ${actual}" \
            >&2
        return 1
    fi
    if [[ -n "$expected_benchmark_sha256" ]] &&
        [[ "$actual" != "$expected_benchmark_sha256" ]]; then
        echo \
            "error: benchmark SHA-256 mismatch during ${stage}: expected ${expected_benchmark_sha256}, got ${actual}" \
            >&2
        return 1
    fi
}

validate_runtime_state_transition() {
    local pre_path="$1"
    local post_path="$2"
    local label="$3"
    local strict=0
    if [[ "$required_governor" != "any" ]]; then
        strict=1
    fi

    python3 - \
        "$pre_path" \
        "$post_path" \
        "$label" \
        "$required_governor" \
        "$strict" <<'PY'
from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Any

pre_path = Path(sys.argv[1])
post_path = Path(sys.argv[2])
label = sys.argv[3]
required_governor = sys.argv[4]
strict = sys.argv[5] == "1"


def load(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as stream:
        value = json.load(stream)
    if not isinstance(value, dict):
        raise SystemExit(f"{label}: {path} is not a JSON object")
    return value


def fail(message: str) -> None:
    raise SystemExit(f"{label}: {message}")


def throttled_value(state: dict[str, Any]) -> int | None:
    command = state.get("vcgencmd_get_throttled")
    if not isinstance(command, dict):
        return None
    if command.get("available") is not True or command.get("exit_code") != 0:
        return None
    output = command.get("output")
    if not isinstance(output, str):
        return None
    match = re.fullmatch(r"throttled=(0x[0-9a-fA-F]+)", output.strip())
    return int(match.group(1), 16) if match else None


pre = load(pre_path)
post = load(post_path)

pre_boot = pre.get("boot_id")
post_boot = post.get("boot_id")
if not isinstance(pre_boot, str) or not pre_boot:
    fail("pre-state boot ID is unavailable")
if pre_boot != post_boot:
    fail(f"boot ID changed ({pre_boot!r} -> {post_boot!r})")
if pre.get("cpu_online") != post.get("cpu_online"):
    fail(
        "online CPU set changed "
        f"({pre.get('cpu_online')!r} -> {post.get('cpu_online')!r})"
    )

for field in ("sched_rt_period_us", "sched_rt_runtime_us"):
    before = pre.get(field)
    after = post.get(field)
    if strict and (not isinstance(before, int) or not isinstance(after, int)):
        fail(f"{field} is unavailable")
    if before != after:
        fail(f"{field} changed ({before!r} -> {after!r})")

if strict:
    for state_name, state in (("pre", pre), ("post", post)):
        if state.get("process_scheduler_policy") != 0:
            fail(
                f"{state_name}-state scheduler policy is "
                f"{state.get('process_scheduler_policy')!r}, expected SCHED_OTHER (0)"
            )
        if state.get("process_scheduler_priority") != 0:
            fail(
                f"{state_name}-state scheduler priority is "
                f"{state.get('process_scheduler_priority')!r}, expected 0"
            )
        if state.get("process_nice") != 0:
            fail(
                f"{state_name}-state nice is {state.get('process_nice')!r}, expected 0"
            )

pre_policies = {
    item.get("policy"): item.get("governor")
    for item in pre.get("cpufreq_policies", [])
    if isinstance(item, dict)
}
post_policies = {
    item.get("policy"): item.get("governor")
    for item in post.get("cpufreq_policies", [])
    if isinstance(item, dict)
}
if pre_policies != post_policies:
    fail(f"CPU governor map changed ({pre_policies!r} -> {post_policies!r})")
if required_governor != "any":
    if not pre_policies:
        fail("no CPU governor policies were captured")
    unexpected = {
        policy: governor
        for policy, governor in pre_policies.items()
        if governor != required_governor
    }
    if unexpected:
        fail(
            f"governors do not match required {required_governor!r}: {unexpected!r}"
        )

pre_throttled = throttled_value(pre)
post_throttled = throttled_value(post)
if strict:
    if pre_throttled is None or post_throttled is None:
        fail("Pi firmware throttling state is unavailable or malformed")
    if pre_throttled != 0 or post_throttled != 0:
        fail(
            "Pi firmware reported throttling/undervoltage bits "
            f"(pre=0x{pre_throttled:x}, post=0x{post_throttled:x})"
        )
elif (
    pre_throttled is not None
    and post_throttled is not None
    and pre_throttled != post_throttled
):
    fail(
        "Pi firmware throttling state changed "
        f"(0x{pre_throttled:x} -> 0x{post_throttled:x})"
    )
PY
}

assert_no_benchmark_processes() {
    python3 - "$benchmark" <<'PY'
from __future__ import annotations

import os
import sys
from pathlib import Path

target = Path(sys.argv[1]).resolve()
matches: list[int] = []
for entry in Path("/proc").iterdir():
    if not entry.name.isdigit():
        continue
    try:
        executable = Path(os.readlink(entry / "exe")).resolve()
    except (FileNotFoundError, OSError):
        continue
    if executable == target:
        matches.append(int(entry.name))
if matches:
    raise SystemExit(
        f"benchmark process still exists for {target}: PIDs "
        + ", ".join(str(pid) for pid in sorted(matches))
    )
PY
}

wait_for_no_benchmark_processes() {
    local attempt
    for ((attempt = 0; attempt < 11; ++attempt)); do
        if assert_no_benchmark_processes; then
            return 0
        fi
        if ((attempt < 10)); then
            sleep 0.2
        fi
    done
    return 1
}

validate_qualified_rust4_diagnostics() {
    local log_path="$1"
    python3 - "$log_path" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
expected = [
    "mosse_tracker_backend=FixedPaddedFourCore",
    "mosse_worker_activity_mode=ContinuousNormalSpin",
    "mosse_normal_spin_launch_hint=taskset-cpu-list-0",
]
diagnostics = [
    line.strip()
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines()
    if line.startswith("mosse_")
]
if diagnostics != expected:
    raise SystemExit(
        f"{path}: qualified Rust4 diagnostics differ; "
        f"expected {expected!r}, got {diagnostics!r}"
    )
PY
}

capture_config_identity() {
    local output_path="$1"
    [[ ! -e "$output_path" ]] ||
        die "refusing to overwrite config identity: $output_path"

    python3 - "$config" "$output_path" "$verify_video_hash" <<'PY'
from __future__ import annotations

import hashlib
import ast
import json
import re
import sys
from pathlib import Path

config = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2])
verify = sys.argv[3] == "1"


def scalar(text: str) -> str:
    text = text.strip()
    if not text:
        return ""
    if text[0] in {'"', "'"}:
        try:
            value = ast.literal_eval(text)
        except (SyntaxError, ValueError) as error:
            raise SystemExit(f"invalid quoted config value {text!r}: {error}")
        if not isinstance(value, str):
            raise SystemExit(f"expected a string config value, got {value!r}")
        return value
    return text.split(" #", 1)[0].strip()


path_text = ""
expected_sha256 = ""
in_video = False
video_indent = 0
for raw_line in config.read_text(encoding="utf-8").splitlines():
    if not raw_line.strip() or raw_line.lstrip().startswith(("#", "%", "---")):
        continue
    indent = len(raw_line) - len(raw_line.lstrip())
    stripped = raw_line.strip()
    if indent == 0:
        in_video = stripped == "video:"
        video_indent = indent
        continue
    if not in_video or indent <= video_indent:
        continue
    match = re.match(r"^(path|sha256)\s*:\s*(.*)$", stripped)
    if match is None:
        continue
    key, value_text = match.groups()
    value = scalar(value_text)
    if key == "path":
        path_text = value
    else:
        expected_sha256 = value.lower()

if not path_text:
    raise SystemExit("benchmark config is missing video.path")
video_path = Path(path_text)
if not video_path.is_absolute():
    video_path = (config.parent / video_path).resolve()
if not video_path.is_file():
    raise SystemExit(f"configured video is missing: {video_path}")

if expected_sha256 and (
    len(expected_sha256) != 64
    or any(character not in "0123456789abcdef" for character in expected_sha256)
):
    raise SystemExit("configured video.sha256 is not a 64-character hexadecimal digest")

actual_sha256 = None
verified = False
if verify:
    if not expected_sha256:
        raise SystemExit("video hash verification requested but video.sha256 is missing")
    digest = hashlib.sha256()
    with video_path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    actual_sha256 = digest.hexdigest()
    verified = actual_sha256 == expected_sha256

payload = {
    "config_path": str(config),
    "video_path": str(video_path),
    "video_size_bytes": video_path.stat().st_size,
    "expected_sha256": expected_sha256 or None,
    "actual_sha256": actual_sha256,
    "hash_verification_requested": verify,
    "hash_verified": verified,
}
with output.open("x", encoding="utf-8") as stream:
    json.dump(payload, stream, indent=2, sort_keys=True)
    stream.write("\n")

if verify and not verified:
    raise SystemExit(
        f"video SHA-256 mismatch: expected {expected_sha256}, got {actual_sha256}"
    )
PY
}

validate_summary() {
    local summary_path="$1"
    local tracker="$2"

    python3 - \
        "$summary_path" \
        "$tracker" \
        "$max_frames" \
        "$require_exact_parity" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
tracker = sys.argv[2]
max_frames = int(sys.argv[3])
require_exact = sys.argv[4] == "1"

with path.open(encoding="utf-8") as stream:
    summary = json.load(stream)

expected_name = {
    "opencv": "opencv_legacy_mosse",
    "rust": "rust_mosse_scalar",
}[tracker]
if summary.get("tracker") != expected_name:
    raise SystemExit(
        f"{path}: tracker is {summary.get('tracker')!r}, expected {expected_name!r}"
    )
if not isinstance(summary.get("decoded_frames"), int) or summary["decoded_frames"] < 1:
    raise SystemExit(f"{path}: invalid decoded_frames")
if not isinstance(summary.get("attempted_updates"), int):
    raise SystemExit(f"{path}: invalid attempted_updates")
if not summary.get("frame_sequence_checksum"):
    raise SystemExit(f"{path}: frame checksums were not recorded")
if max_frames == 0 and summary.get("full_video_processed") is not True:
    raise SystemExit(f"{path}: full-video processing was not completed")
if max_frames > 0 and summary["decoded_frames"] > max_frames:
    raise SystemExit(f"{path}: decoded more than the requested frame limit")
if require_exact:
    exact_values = {
        "decoded_frames": 4947,
        "attempted_updates": 4946,
        "successful_updates": 2219,
        "failed_updates": 2727,
        "expected_decoded_frames": 4947,
        "max_frames": 0,
        "frame_limit_reached": False,
        "end_of_stream_reached": True,
        "full_video_processed": True,
    }
    for field, expected in exact_values.items():
        actual = summary.get(field)
        if actual != expected:
            raise SystemExit(
                f"{path}: {field} is {actual!r}, expected exact {expected!r}"
            )
PY
}

write_manifest() {
    local requested_status="$1"
    local requested_exit_code="$2"

    MOSSE_SCORE_STATUS="$requested_status" \
        MOSSE_SCORE_EXIT_CODE="$requested_exit_code" \
        MOSSE_SCORE_FAILURE_CONTEXT="$failure_context" \
        MOSSE_SCORE_SUITE_DIR="$suite_dir" \
        MOSSE_SCORE_SUITE_ID="$run_id" \
        MOSSE_SCORE_SUITE_STARTED_AT="$suite_started_at" \
        MOSSE_SCORE_REPO_ROOT="$repo_root" \
        MOSSE_SCORE_BENCHMARK="$benchmark" \
        MOSSE_SCORE_CONFIG="$config" \
        MOSSE_SCORE_COMPARE_TOOL="$compare_tool" \
        MOSSE_SCORE_WARMUPS="$warmups" \
        MOSSE_SCORE_MEASURED_PAIRS="$measured_pairs" \
        MOSSE_SCORE_OPENCV_THREADS="$opencv_threads" \
        MOSSE_SCORE_RUST_THREADS="${thread_counts[*]}" \
        MOSSE_SCORE_MAX_FRAMES="$max_frames" \
        MOSSE_SCORE_PAUSE_SECONDS="$pause_seconds" \
        MOSSE_SCORE_REQUIRED_GOVERNOR="$required_governor" \
        MOSSE_SCORE_USE_TASKSET="$use_taskset" \
        MOSSE_SCORE_QUICK="$quick_mode" \
        MOSSE_SCORE_VERIFY_HASH="$verify_video_hash" \
        MOSSE_SCORE_RUST_CALLER_CPUS="$rust_caller_cpus" \
        MOSSE_SCORE_RUN_TIMEOUT_SECONDS="$run_timeout_seconds" \
        MOSSE_SCORE_REQUIRE_EXACT_PARITY="$require_exact_parity" \
        MOSSE_SCORE_EXPECTED_BENCHMARK_SHA256="$expected_benchmark_sha256" \
        MOSSE_SCORE_BENCHMARK_SHA256_INITIAL="$benchmark_sha256_initial" \
        MOSSE_SCORE_BENCHMARK_SHA256_LAST="$benchmark_sha256_last_verified" \
        MOSSE_SCORE_BENCHMARK_SHA256_FINAL="$benchmark_sha256_final" \
        MOSSE_SCORE_CONFIG_IDENTITY="$config_identity_path" \
        MOSSE_SCORE_ENVIRONMENT_PRE="$environment_pre_path" \
        MOSSE_SCORE_ENVIRONMENT_POST="$environment_post_path" \
        MOSSE_SCORE_STATE_PRE="$suite_state_pre_path" \
        MOSSE_SCORE_STATE_POST="$suite_state_post_path" \
        python3 - "$manifest_path" "$runs_tsv" "$parity_tsv" <<'PY'
from __future__ import annotations

import csv
import datetime as dt
import json
import os
import sys
from pathlib import Path
from typing import Any

manifest_path = Path(sys.argv[1])
runs_path = Path(sys.argv[2])
parity_path = Path(sys.argv[3])
suite_dir = Path(os.environ["MOSSE_SCORE_SUITE_DIR"])


def relative(path_text: str) -> str:
    path = Path(path_text)
    try:
        return str(path.relative_to(suite_dir))
    except ValueError:
        return str(path)


def load_json(path_text: str) -> Any:
    path = Path(path_text)
    if not path.is_file():
        return None
    try:
        with path.open(encoding="utf-8") as stream:
            return json.load(stream)
    except (OSError, ValueError) as error:
        return {"artifact_error": f"{type(error).__name__}: {error}"}


expected_benchmark_sha256 = os.environ[
    "MOSSE_SCORE_EXPECTED_BENCHMARK_SHA256"
]
initial_benchmark_sha256 = os.environ[
    "MOSSE_SCORE_BENCHMARK_SHA256_INITIAL"
]
last_benchmark_sha256 = os.environ["MOSSE_SCORE_BENCHMARK_SHA256_LAST"]
final_benchmark_sha256 = os.environ["MOSSE_SCORE_BENCHMARK_SHA256_FINAL"]


runs: list[dict[str, Any]] = []
with runs_path.open(newline="", encoding="utf-8") as stream:
    for row in csv.DictReader(stream, delimiter="\t"):
        runs.append(
            {
                "sequence": int(row["sequence"]),
                "phase": row["phase"],
                "opencv_thread_count": int(row["opencv_thread_count"]),
                "rust_thread_count": int(row["rust_thread_count"]),
                "tracker_thread_count": int(row["tracker_thread_count"]),
                "pair_index": int(row["pair_index"]),
                "global_pair_index": int(row["global_pair_index"]),
                "order_in_pair": int(row["order_in_pair"]),
                "tracker": row["tracker"],
                "started_at": row["started_at"],
                "ended_at": row["ended_at"],
                "exit_code": int(row["exit_code"]),
                "cpu_list": row["cpu_list"] or None,
                "benchmark_sha256_pre": row["benchmark_sha256_pre"],
                "benchmark_sha256_post": row["benchmark_sha256_post"],
                "artifacts": {
                    "frames_csv": relative(row["csv"]),
                    "summary_json": relative(row["summary"]),
                    "stdout_log": relative(row["log"]),
                    "runtime_state_pre": relative(row["pre_state"]),
                    "runtime_state_post": relative(row["post_state"]),
                },
                "runtime_state_pre": load_json(row["pre_state"]),
                "runtime_state_post": load_json(row["post_state"]),
                "benchmark_summary": load_json(row["summary"]),
            }
        )

parity: list[dict[str, Any]] = []
with parity_path.open(newline="", encoding="utf-8") as stream:
    for row in csv.DictReader(stream, delimiter="\t"):
        parity.append(
            {
                "opencv_thread_count": int(row["opencv_thread_count"]),
                "rust_thread_count": int(row["rust_thread_count"]),
                "pair_index": int(row["pair_index"]),
                "global_pair_index": int(row["global_pair_index"]),
                "exit_code": int(row["exit_code"]),
                "all_gates_pass": (
                    row["all_gates_pass"] == "1"
                    if row["all_gates_pass"] in {"0", "1"}
                    else None
                ),
                "opencv_csv": relative(row["opencv_csv"]),
                "rust_csv": relative(row["rust_csv"]),
                "comparison_json": relative(row["comparison"]),
                "stdout_log": relative(row["log"]),
                "comparison": load_json(row["comparison"]),
            }
        )

status = os.environ["MOSSE_SCORE_STATUS"]
now = dt.datetime.now(dt.timezone.utc).isoformat()
manifest = {
    "schema_version": 2,
    "suite_id": os.environ["MOSSE_SCORE_SUITE_ID"],
    "status": status,
    "exit_code": int(os.environ["MOSSE_SCORE_EXIT_CODE"]),
    "failure_context": (
        os.environ["MOSSE_SCORE_FAILURE_CONTEXT"]
        if status != "completed"
        else None
    ),
    "started_at": os.environ["MOSSE_SCORE_SUITE_STARTED_AT"],
    "updated_at": now,
    "completed_at": now if status != "running" else None,
    "repository_root": os.environ["MOSSE_SCORE_REPO_ROOT"],
    "benchmark_binary": os.environ["MOSSE_SCORE_BENCHMARK"],
    "benchmark_identity": {
        "expected_sha256": (
            expected_benchmark_sha256 or None
        ),
        "initial_sha256": initial_benchmark_sha256,
        "last_verified_sha256": last_benchmark_sha256 or None,
        "final_sha256": final_benchmark_sha256 or None,
        "verification_required": bool(expected_benchmark_sha256),
        "initial_matches_expected": (
            initial_benchmark_sha256 == expected_benchmark_sha256
            if expected_benchmark_sha256
            else None
        ),
        "last_matches_initial": (
            last_benchmark_sha256 == initial_benchmark_sha256
            if last_benchmark_sha256
            else False
        ),
        "final_matches_initial": (
            final_benchmark_sha256 == initial_benchmark_sha256
            if final_benchmark_sha256
            else None
        ),
    },
    "config_path": os.environ["MOSSE_SCORE_CONFIG"],
    "comparison_tool": os.environ["MOSSE_SCORE_COMPARE_TOOL"],
    "output_directory": str(suite_dir),
    "mode": "quick" if os.environ["MOSSE_SCORE_QUICK"] == "1" else "scoring",
    "parameters": {
        "warmups_per_tracker_and_configuration": int(
            os.environ["MOSSE_SCORE_WARMUPS"]
        ),
        "measured_pairs_per_configuration": int(
            os.environ["MOSSE_SCORE_MEASURED_PAIRS"]
        ),
        "opencv_thread_count": int(os.environ["MOSSE_SCORE_OPENCV_THREADS"]),
        "rust_core_counts": [
            int(value) for value in os.environ["MOSSE_SCORE_RUST_THREADS"].split()
        ],
        "core_pairings": [
            {
                "opencv_threads": int(os.environ["MOSSE_SCORE_OPENCV_THREADS"]),
                "rust_cores": int(value),
            }
            for value in os.environ["MOSSE_SCORE_RUST_THREADS"].split()
        ],
        "max_frames": int(os.environ["MOSSE_SCORE_MAX_FRAMES"]),
        "pause_seconds": float(os.environ["MOSSE_SCORE_PAUSE_SECONDS"]),
        "required_governor": os.environ["MOSSE_SCORE_REQUIRED_GOVERNOR"],
        "taskset_enabled": os.environ["MOSSE_SCORE_USE_TASKSET"] == "1",
        "rust_caller_cpu_list": (
            os.environ["MOSSE_SCORE_RUST_CALLER_CPUS"] or None
        ),
        "run_timeout_seconds": float(
            os.environ["MOSSE_SCORE_RUN_TIMEOUT_SECONDS"]
        ),
        "require_exact_parity": (
            os.environ["MOSSE_SCORE_REQUIRE_EXACT_PARITY"] == "1"
        ),
        "video_hash_verification_requested": (
            os.environ["MOSSE_SCORE_VERIFY_HASH"] == "1"
        ),
        "measured_order": "alternating globally across core configurations",
    },
    "config_identity": load_json(os.environ["MOSSE_SCORE_CONFIG_IDENTITY"]),
    "suite_artifacts": {
        "environment_pre": relative(os.environ["MOSSE_SCORE_ENVIRONMENT_PRE"]),
        "environment_post": relative(os.environ["MOSSE_SCORE_ENVIRONMENT_POST"]),
        "runtime_state_pre": relative(os.environ["MOSSE_SCORE_STATE_PRE"]),
        "runtime_state_post": relative(os.environ["MOSSE_SCORE_STATE_POST"]),
    },
    "suite_runtime_state_pre": load_json(os.environ["MOSSE_SCORE_STATE_PRE"]),
    "suite_runtime_state_post": load_json(os.environ["MOSSE_SCORE_STATE_POST"]),
    "runs": sorted(runs, key=lambda item: item["sequence"]),
    "parity_comparisons": parity,
}

temporary = manifest_path.with_name(f".{manifest_path.name}.{os.getpid()}.tmp")
with temporary.open("x", encoding="utf-8") as stream:
    json.dump(manifest, stream, indent=2, sort_keys=True)
    stream.write("\n")
os.replace(temporary, manifest_path)
PY
}

finalize_suite() {
    local original_exit_code=$?
    local final_exit_code="$original_exit_code"
    local cleanup_status=0
    local final_status
    local manifest_status
    local check_status

    trap - EXIT INT TERM
    set +e

    if ((suite_ready == 1)); then
        if [[ ! -e "$suite_state_post_path" ]]; then
            capture_runtime_state "$suite_state_post_path" "suite-post"
            cleanup_status=$?
        fi
        if [[ ! -e "$environment_post_path" ]]; then
            capture_full_environment "$environment_post_path"
            if (($? != 0 && cleanup_status == 0)); then
                cleanup_status=1
            fi
        fi
        if [[ -e "$suite_state_pre_path" && -e "$suite_state_post_path" ]]; then
            validate_runtime_state_transition \
                "$suite_state_pre_path" \
                "$suite_state_post_path" \
                "suite runtime invariant"
            check_status=$?
            if ((check_status != 0 && cleanup_status == 0)); then
                cleanup_status=72
                if ((final_exit_code == 0)); then
                    failure_context="validating final suite runtime invariants"
                fi
            fi
        fi
        wait_for_no_benchmark_processes
        check_status=$?
        if ((check_status != 0 && cleanup_status == 0)); then
            cleanup_status=73
            if ((final_exit_code == 0)); then
                failure_context="checking for lingering benchmark processes"
            fi
        fi
        verify_benchmark_identity "suite post"
        check_status=$?
        benchmark_sha256_final="$benchmark_sha256_last_verified"
        if ((check_status != 0 && cleanup_status == 0)); then
            cleanup_status=74
            if ((final_exit_code == 0)); then
                failure_context="verifying final benchmark identity"
            fi
        fi

        if ((final_exit_code == 0 && cleanup_status != 0)); then
            final_exit_code="$cleanup_status"
            failure_context="capturing final suite state"
        fi
        if ((final_exit_code == 0)) && [[ "$suite_status" == "completed" ]]; then
            final_status="completed"
        else
            final_status="failed"
        fi

        write_manifest "$final_status" "$final_exit_code"
        manifest_status=$?
        if ((final_exit_code == 0 && manifest_status != 0)); then
            final_exit_code="$manifest_status"
            echo "error: failed to finalize manifest: $manifest_path" >&2
        fi
    fi

    exit "$final_exit_code"
}

trap finalize_suite EXIT
trap 'failure_context="interrupted"; exit 130' INT
trap 'failure_context="terminated"; exit 143' TERM

run_one() {
    local phase="$1"
    local rust_thread_count="$2"
    local pair_index="$3"
    local global_pair_index="$4"
    local order_in_pair="$5"
    local tracker="$6"
    local stem="$7"
    local configuration_dir="${suite_dir}/opencv-${opencv_threads}-rust-${rust_thread_count}"
    local csv_path="${configuration_dir}/${stem}.csv"
    local summary_path="${configuration_dir}/${stem}.json"
    local log_path="${configuration_dir}/${stem}.log"
    local pre_state_path="${configuration_dir}/${stem}.pre-state.json"
    local post_state_path="${configuration_dir}/${stem}.post-state.json"
    local tracker_thread_count
    local rust_core_environment
    local cpu_list=""
    local started_at
    local ended_at
    local command_exit
    local post_state_exit
    local validation_exit=0
    local invariant_exit=0
    local no_linger_exit=0
    local hash_exit=0
    local diagnostics_exit=0
    local run_exit
    local benchmark_sha256_pre
    local benchmark_sha256_post
    local command=()

    if [[ "$tracker" == "opencv" ]]; then
        tracker_thread_count="$opencv_threads"
    else
        tracker_thread_count="$rust_thread_count"
    fi
    rust_core_environment="MOSSE_RUST_CORES=${rust_thread_count}"

    mkdir -p -- "$configuration_dir"
    for artifact in \
        "$csv_path" \
        "$summary_path" \
        "$log_path" \
        "$pre_state_path" \
        "$post_state_path"; do
        [[ ! -e "$artifact" ]] ||
            die "refusing to overwrite run artifact: $artifact"
    done

    if ((runs_started > 0)) && [[ "$pause_seconds" != "0" ]]; then
        echo "Pausing ${pause_seconds}s before ${stem}..."
        sleep "$pause_seconds"
    fi
    ((runs_started += 1))

    failure_context="validating governor before ${stem}"
    verify_governor_state
    failure_context="checking for pre-existing benchmark processes before ${stem}"
    assert_no_benchmark_processes
    failure_context="verifying benchmark identity before ${stem}"
    verify_benchmark_identity "${stem} pre"
    benchmark_sha256_pre="$benchmark_sha256_last_verified"
    capture_runtime_state "$pre_state_path" "${stem}-pre"

    if [[ "$run_timeout_seconds" != "0" ]]; then
        command+=(
            timeout
            --foreground
            --signal=TERM
            --kill-after=5s
            "${run_timeout_seconds}s"
        )
    fi
    if ((use_taskset == 1)); then
        if [[ "$tracker" == "rust" && -n "$rust_caller_cpus" ]]; then
            cpu_list="$rust_caller_cpus"
        elif ((tracker_thread_count == 1)); then
            cpu_list="0"
        else
            cpu_list="0-$((tracker_thread_count - 1))"
        fi
        command+=(taskset --cpu-list "$cpu_list")
    fi
    command+=(env "$rust_core_environment")
    if [[ "$tracker" == "rust" ]] && ((rust_thread_count == 4)); then
        command+=("MOSSE_REPORT_BACKEND=1")
    fi
    command+=(
        "$benchmark"
        --config "$config"
        --tracker "$tracker"
        --opencv-threads "$opencv_threads"
        --frames-csv "$csv_path"
        --summary-json "$summary_path"
    )
    if ((max_frames > 0)); then
        command+=(--max-frames "$max_frames")
    fi

    echo
    echo "[$phase opencv=$opencv_threads rust=$rust_thread_count active=$tracker_thread_count pair=$pair_index order=$order_in_pair] $tracker"
    printf 'Command:'
    printf ' %q' "${command[@]}"
    printf '\n'

    started_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    failure_context="running ${stem}"
    set +e
    "${command[@]}" 2>&1 | tee "$log_path"
    command_exit=${PIPESTATUS[0]}
    set -e
    ended_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

    set +e
    wait_for_no_benchmark_processes
    no_linger_exit=$?
    verify_benchmark_identity "${stem} post"
    hash_exit=$?
    benchmark_sha256_post="$benchmark_sha256_last_verified"
    capture_runtime_state "$post_state_path" "${stem}-post"
    post_state_exit=$?
    if ((post_state_exit == 0)); then
        validate_runtime_state_transition \
            "$pre_state_path" \
            "$post_state_path" \
            "${stem} runtime invariant"
        invariant_exit=$?
    fi
    if ((command_exit == 0)); then
        validate_summary "$summary_path" "$tracker"
        validation_exit=$?
        if [[ "$tracker" == "rust" ]] && ((rust_thread_count == 4)); then
            validate_qualified_rust4_diagnostics "$log_path"
            diagnostics_exit=$?
        fi
    fi
    set -e

    run_exit="$command_exit"
    if ((run_exit == 0 && post_state_exit != 0)); then
        run_exit=70
    fi
    if ((run_exit == 0 && validation_exit != 0)); then
        run_exit=71
    fi
    if ((run_exit == 0 && invariant_exit != 0)); then
        run_exit=72
    fi
    if ((run_exit == 0 && no_linger_exit != 0)); then
        run_exit=73
    fi
    if ((run_exit == 0 && hash_exit != 0)); then
        run_exit=74
    fi
    if ((run_exit == 0 && diagnostics_exit != 0)); then
        run_exit=75
    fi

    ((run_sequence += 1))
    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
        "$run_sequence" \
        "$phase" \
        "$opencv_threads" \
        "$rust_thread_count" \
        "$tracker_thread_count" \
        "$pair_index" \
        "$global_pair_index" \
        "$order_in_pair" \
        "$tracker" \
        "$started_at" \
        "$ended_at" \
        "$run_exit" \
        "$cpu_list" \
        "$benchmark_sha256_pre" \
        "$benchmark_sha256_post" \
        "$csv_path" \
        "$summary_path" \
        "$log_path" \
        "$pre_state_path" \
        "$post_state_path" \
        >>"$runs_tsv"

    write_manifest "running" 0
    if ((run_exit != 0)); then
        echo "error: run failed (${stem}, exit ${run_exit})" >&2
        return "$run_exit"
    fi

    LAST_CSV_PATH="$csv_path"
    LAST_SUMMARY_PATH="$summary_path"
}

compare_pair() {
    local rust_thread_count="$1"
    local pair_index="$2"
    local global_pair_index="$3"
    local opencv_csv="$4"
    local rust_csv="$5"
    local opencv_summary="$6"
    local rust_summary="$7"
    local configuration_dir="${suite_dir}/opencv-${opencv_threads}-rust-${rust_thread_count}"
    local stem="measured-pair-$(printf '%02d' "$pair_index")-parity"
    local comparison_path="${configuration_dir}/${stem}.json"
    local log_path="${configuration_dir}/${stem}.log"
    local comparison_exit
    local validation_exit=0
    local all_gates_pass=""

    [[ ! -e "$comparison_path" && ! -e "$log_path" ]] ||
        die "refusing to overwrite parity artifacts for OpenCV ${opencv_threads}/Rust ${rust_thread_count}, pair ${pair_index}"

    failure_context="comparing OpenCV ${opencv_threads}/Rust ${rust_thread_count}, pair ${pair_index}"
    set +e
    python3 "$compare_tool" \
        "$opencv_csv" \
        "$rust_csv" \
        --output "$comparison_path" \
        --format text \
        2>&1 | tee "$log_path"
    comparison_exit=${PIPESTATUS[0]}
    set -e

    if ((comparison_exit == 0)); then
        set +e
        python3 - \
            "$comparison_path" \
            "$opencv_csv" \
            "$rust_csv" \
            "$opencv_summary" \
            "$rust_summary" \
            "$require_exact_parity" 2>&1 <<'PY' | tee -a "$log_path"
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path
from typing import Any

comparison_path = Path(sys.argv[1])
opencv_csv = Path(sys.argv[2])
rust_csv = Path(sys.argv[3])
opencv_summary_path = Path(sys.argv[4])
rust_summary_path = Path(sys.argv[5])
require_exact = sys.argv[6] == "1"


def load_json(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as stream:
        result = json.load(stream)
    if not isinstance(result, dict):
        raise SystemExit(f"{path}: expected a JSON object")
    return result


comparison = load_json(comparison_path)
gates = comparison.get("gates")
if not isinstance(gates, dict) or not gates:
    raise SystemExit(f"{comparison_path}: comparison gates are missing")
failed_gates = sorted(name for name, passed in gates.items() if passed is not True)
if failed_gates:
    raise SystemExit(
        f"{comparison_path}: loose quality gates failed: {failed_gates}"
    )

if require_exact:
    exact_fields = [
        "frame_index",
        "is_initialization",
        "update_attempted",
        "success",
        "bbox_x",
        "bbox_y",
        "bbox_width",
        "bbox_height",
        "frame_checksum_fnv1a64",
    ]

    def read_exact_rows(path: Path) -> list[dict[str, str]]:
        with path.open(newline="", encoding="utf-8") as stream:
            reader = csv.DictReader(stream)
            missing = [name for name in exact_fields if name not in (reader.fieldnames or [])]
            if missing:
                raise SystemExit(f"{path}: missing exact CSV fields: {missing}")
            return [{name: row[name] for name in exact_fields} for row in reader]

    opencv_rows = read_exact_rows(opencv_csv)
    rust_rows = read_exact_rows(rust_csv)
    if len(opencv_rows) != 4947 or len(rust_rows) != 4947:
        raise SystemExit(
            "exact replay requires 4947 CSV rows; "
            f"got OpenCV={len(opencv_rows)}, Rust={len(rust_rows)}"
        )
    for index, (opencv_row, rust_row) in enumerate(zip(opencv_rows, rust_rows)):
        if opencv_row != rust_row:
            differing = [
                name
                for name in exact_fields
                if opencv_row[name] != rust_row[name]
            ]
            raise SystemExit(
                f"literal CSV mismatch at row/frame {index}: fields {differing}"
            )
        expected_index = str(index)
        if opencv_row["frame_index"] != expected_index:
            raise SystemExit(
                f"non-contiguous frame index at row {index}: "
                f"{opencv_row['frame_index']!r}"
            )
        expected_initialization = "1" if index == 0 else "0"
        expected_attempted = "0" if index == 0 else "1"
        if opencv_row["is_initialization"] != expected_initialization:
            raise SystemExit(
                f"invalid initialization marker at frame {index}: "
                f"{opencv_row['is_initialization']!r}"
            )
        if opencv_row["update_attempted"] != expected_attempted:
            raise SystemExit(
                f"invalid update marker at frame {index}: "
                f"{opencv_row['update_attempted']!r}"
            )

    opencv_summary = load_json(opencv_summary_path)
    rust_summary = load_json(rust_summary_path)
    exact_values = {
        "decoded_frames": 4947,
        "attempted_updates": 4946,
        "successful_updates": 2219,
        "failed_updates": 2727,
        "expected_decoded_frames": 4947,
        "max_frames": 0,
        "frame_limit_reached": False,
        "end_of_stream_reached": True,
        "full_video_processed": True,
    }
    for path, summary in (
        (opencv_summary_path, opencv_summary),
        (rust_summary_path, rust_summary),
    ):
        for field, expected in exact_values.items():
            if summary.get(field) != expected:
                raise SystemExit(
                    f"{path}: {field} is {summary.get(field)!r}, "
                    f"expected {expected!r}"
                )

    summary_identity_fields = [
        "schema_version",
        "config_path",
        "video_path",
        "expected_video_sha256",
        "frame_checksum_algorithm",
        "frame_sequence_checksum",
        "initial_roi",
        "max_frames",
        "expected_width",
        "expected_height",
        "expected_decoded_frames",
        "frame_width",
        "frame_height",
        "frame_type",
        "source_fps",
        "source_reported_frame_count",
        "decoded_frames",
        "attempted_updates",
        "successful_updates",
        "failed_updates",
        "frame_limit_reached",
        "end_of_stream_reached",
        "full_video_processed",
    ]
    for field in summary_identity_fields:
        if opencv_summary.get(field) != rust_summary.get(field):
            raise SystemExit(
                f"summary identity differs for {field}: "
                f"OpenCV={opencv_summary.get(field)!r}, "
                f"Rust={rust_summary.get(field)!r}"
            )

    frame_identity = comparison.get("frame_identity", {})
    success = comparison.get("success", {})
    center = comparison.get("center_distance_pixels", {})
    overlap = comparison.get("iou", {})
    size_delta = comparison.get("absolute_size_delta_pixels", {})
    exact_comparison_values = [
        ("frame_identity.row_count", frame_identity.get("row_count"), 4947),
        (
            "frame_identity.attempted_updates",
            frame_identity.get("attempted_updates"),
            4946,
        ),
        (
            "frame_identity.checksums_match",
            frame_identity.get("checksums_match"),
            True,
        ),
        ("success.reference_successes", success.get("reference_successes"), 2219),
        ("success.candidate_successes", success.get("candidate_successes"), 2219),
        ("success.agreement_count", success.get("agreement_count"), 4946),
        ("success.agreement_fraction", success.get("agreement_fraction"), 1.0),
        ("success.mismatch_count", success.get("mismatch_count"), 0),
        (
            "mutually_successful_frames",
            comparison.get("mutually_successful_frames"),
            2219,
        ),
        ("center.mean", center.get("mean"), 0.0),
        ("center.median", center.get("median"), 0.0),
        ("center.p95", center.get("p95"), 0.0),
        ("center.max", center.get("max"), 0.0),
        ("center.cumulative", center.get("cumulative"), 0.0),
        ("iou.mean", overlap.get("mean"), 1.0),
        ("iou.median", overlap.get("median"), 1.0),
        ("iou.p05", overlap.get("p05"), 1.0),
        ("iou.min", overlap.get("min"), 1.0),
        ("size.mean_width", size_delta.get("mean_width"), 0.0),
        ("size.max_width", size_delta.get("max_width"), 0.0),
        ("size.mean_height", size_delta.get("mean_height"), 0.0),
        ("size.max_height", size_delta.get("max_height"), 0.0),
    ]
    failures = [
        f"{name}={actual!r} (expected {expected!r})"
        for name, actual, expected in exact_comparison_values
        if actual != expected
    ]
    if failures:
        raise SystemExit(
            f"{comparison_path}: exact comparison metrics failed: "
            + "; ".join(failures)
        )

print(
    "Runner parity validation: PASS "
    + ("(literal nine-field exact replay)" if require_exact else "(quality gates)")
)
PY
        validation_exit=${PIPESTATUS[0]}
        set -e
        if ((validation_exit == 0)); then
            all_gates_pass="1"
        else
            all_gates_pass="0"
            comparison_exit=76
        fi
    fi

    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
        "$opencv_threads" \
        "$rust_thread_count" \
        "$pair_index" \
        "$global_pair_index" \
        "$comparison_exit" \
        "$all_gates_pass" \
        "$opencv_csv" \
        "$rust_csv" \
        "$comparison_path" \
        "$log_path" \
        >>"$parity_tsv"
    write_manifest "running" 0

    if ((comparison_exit != 0)); then
        echo \
            "error: parity comparison failed for OpenCV=${opencv_threads}, Rust=${rust_thread_count}, pair=${pair_index}" \
            >&2
        return "$comparison_exit"
    fi
}

write_manifest "running" 0

failure_context="verifying configured video identity"
capture_config_identity "$config_identity_path"

failure_context="capturing initial environment"
capture_full_environment "$environment_pre_path"
capture_runtime_state "$suite_state_pre_path" "suite-pre"

failure_context="validating initial CPU governor"
verify_governor_state
failure_context="validating initial runtime invariants"
validate_runtime_state_transition \
    "$suite_state_pre_path" \
    "$suite_state_pre_path" \
    "initial suite runtime invariant"
failure_context="checking for pre-existing benchmark processes"
assert_no_benchmark_processes
failure_context="verifying initial benchmark identity"
verify_benchmark_identity "suite pre"
write_manifest "running" 0

global_pair_index=0
for configuration_position in "${!thread_counts[@]}"; do
    rust_thread_count="${thread_counts[$configuration_position]}"
    mkdir -p -- "${suite_dir}/opencv-${opencv_threads}-rust-${rust_thread_count}"

    for ((warmup_index = 1; warmup_index <= warmups; ++warmup_index)); do
        if ((((warmup_index + configuration_position) % 2) == 1)); then
            tracker_order=(opencv rust)
        else
            tracker_order=(rust opencv)
        fi

        for order_position in "${!tracker_order[@]}"; do
            tracker="${tracker_order[$order_position]}"
            order_in_pair=$((order_position + 1))
            stem="warmup-$(printf '%02d' "$warmup_index")-order-${order_in_pair}-${tracker}"
            run_one \
                "warmup" \
                "$rust_thread_count" \
                "$warmup_index" \
                0 \
                "$order_in_pair" \
                "$tracker" \
                "$stem"
        done
    done

    for ((pair_index = 1; pair_index <= measured_pairs; ++pair_index)); do
        ((global_pair_index += 1))
        if (((global_pair_index % 2) == 1)); then
            tracker_order=(opencv rust)
        else
            tracker_order=(rust opencv)
        fi

        declare -A paired_csv=()
        declare -A paired_summary=()
        for order_position in "${!tracker_order[@]}"; do
            tracker="${tracker_order[$order_position]}"
            order_in_pair=$((order_position + 1))
            stem="measured-pair-$(printf '%02d' "$pair_index")-order-${order_in_pair}-${tracker}"
            run_one \
                "measured" \
                "$rust_thread_count" \
                "$pair_index" \
                "$global_pair_index" \
                "$order_in_pair" \
                "$tracker" \
                "$stem"
            paired_csv[$tracker]="$LAST_CSV_PATH"
            paired_summary[$tracker]="$LAST_SUMMARY_PATH"
        done

        compare_pair \
            "$rust_thread_count" \
            "$pair_index" \
            "$global_pair_index" \
            "${paired_csv[opencv]}" \
            "${paired_csv[rust]}" \
            "${paired_summary[opencv]}" \
            "${paired_summary[rust]}"
        unset paired_csv
        unset paired_summary
    done
done

suite_status="completed"
failure_context=""
echo
echo "Scoring suite complete: $suite_dir"
echo "Manifest: $manifest_path"
