# Pi 4 persistent Rust runtime

This runtime drives the feature-gated fixed 60x36 tracker FFT path. It does
not change tracker math or the C ABI.

## Activation and observable status

Build the Rust crate with the default-off feature:

```bash
cargo build --manifest-path rust/Cargo.toml \
  --release --locked --features pi4-four-core-runtime
```

That command selects the retained FIFO50/parked-worker policy. Experiment 063
adds a separate default-off build policy:

```bash
cargo build --manifest-path rust/Cargo.toml \
  --release --locked \
  --features pi4-four-core-runtime,normal-spin-four-core-runtime
```

The second build keeps workers at `SCHED_OTHER/0` and continuously polling on
CPUs 1-3. It needs no `CAP_SYS_NICE` or RT-runtime budget, but intentionally
consumes three CPUs for the complete tracker lifetime and is not qualified
until its exact Pi screen plus sustained thermal/live soak pass.

For this candidate, launch the complete video process with CPU0-only
affinity before OpenCV/FFmpeg creates decoder threads:

```bash
taskset --cpu-list 0 env MOSSE_RUST_CORES=4 MOSSE_REPORT_BACKEND=1 \
  ./your-video-process
```

Decoder threads inherit CPU0. The MOSSE caller remains on CPU0, while its
three newly created workers explicitly expand and pin themselves to CPUs 1-3.
`MOSSE_REPORT_BACKEND=1` reports
`mosse_normal_spin_launch_hint=taskset-cpu-list-0` when this policy is active.
That line is launch guidance, not proof of the effective affinity; deployment
and qualification must still inspect every thread's allowed mask.

`FourCoreRuntime::from_environment()` reads only `MOSSE_RUST_CORES`:

| Value | Behavior |
|---|---|
| `4` | On Linux/AArch64, attempt caller plus three persistent workers. |
| `1` | Explicit single-thread mode. |
| unset | Safe single-thread mode with `CoreRequest::Unset`. |
| anything else | Safe single-thread mode with an invalid/unsupported status. |

OpenCV's thread setting is separate and never changes the Rust worker count.
The official four-core request is `MOSSE_RUST_CORES=4`; it is not proof that
four-core startup succeeded. The compiled feature policy determines parked
FIFO versus continuous normal-spin behavior. Callers must record
`RuntimeStatus`, `worker_activity_mode()`, the effective core count, and any
`FallbackReason` in later scoring artifacts.

The staged Rust API is:

```rust
let mut runtime = FourCoreRuntime::from_environment();
let status = runtime.status();
{
    let _activity = runtime.begin_activity();
    runtime.dispatch(&mut tasks, |task_index, task| {
        // task_index % 4 is the fixed owner lane in four-core mode.
    });
} // parked policy waits for idle acknowledgement; normal-spin closes a gate
let shutdown = runtime.shutdown();
```

`from_requested_cores` provides the same policy without editing process
environment. The type is neither `Send` nor `Sync`, because lane zero and the
saved affinity state belong to the constructing caller thread. Activity
startup and dispatch also check that thread identity before publishing work. A
later C handle integration must strengthen its contract to keep
initialization, dispatch, explicit shutdown, and destruction on that same
caller thread; raw pointers must not be used to bypass this Rust ownership
rule.

## Four-core contract

Successful four-core startup establishes all of the following:

- lane zero is the caller on CPU 0;
- three threads are created once, with lanes 1-3 fixed to CPUs 1-3;
- the retained FIFO policy requires CPUs 0-3 in the caller's inherited
  affinity mask;
- normal-spin requires CPU 0 in the inherited caller mask and requires each
  worker's explicit CPU 1-3 pin to succeed before startup can complete;
- the caller must enter with and always retain `SCHED_OTHER`, real-time
  priority 0, and Linux nice value 0;
- under the retained policy only workers 1-3 use `SCHED_FIFO` priority 50;
- retained-policy workers block outside tracker initialization/update, wake
  once at the call boundary, spin across dispatches in that call, and
  acknowledge a parked state before the call returns or unwinds;
- under `normal-spin-four-core-runtime`, workers 1-3 are verified
  `SCHED_OTHER`, real-time priority 0, and nice value 0, then continuously
  poll across call boundaries;
- task `i` is always owned by lane `i % 4`;
- each dispatch publishes one stack-resident descriptor and completes caller
  work, all worker work, and all three completion epochs before returning;
- ordinary dispatch inside one active call has no allocation, queue, channel,
  mutex, park, thread creation, task stealing, or join.

The caller's timer must surround the entire tracker update. That interval
includes every dispatch publication/task/barrier, serial tail work, and the
selected policy's complete activity boundary: worker wake plus final parked
acknowledgement for the retained policy, or both normal-spin atomic gates.
Construction, thread creation, and teardown remain lifecycle costs outside an
individual tracker update.

If the platform, policy-specific inherited CPU mask, normal caller policy,
affinity calls, thread creation, worker-policy validation, or bounded
readiness handshake fails, startup stops any created workers, restores the
caller's captured affinity mask, and returns an explicit single-thread
runtime. For normal-spin, accepting a CPU0-only inherited mask does not assume
that CPUs 1-3 are available through the process's cpuset/cgroup. Each worker's
`pthread_setaffinity_np` call is part of readiness; an unavailable worker CPU
produces `SetupStage::PinThread` and the same safe serial fallback. An
already-FIFO/RR/deadline caller is rejected with
`SetupStage::ValidateCallerScheduler`; this also catches a wrapper that
accidentally lets an RT policy leak into the benchmark child. The retained
FIFO policy additionally requires worker real-time permission and a valid RT
budget. `kernel.sched_rt_runtime_us=-1` and a positive finite budget such as
the Pi default `950000` are accepted and disclosed; zero, another negative
value, unreadable input, or malformed text produces
`SetupStage::ValidateRtBandwidth`. Normal-spin skips that file entirely,
verifies nice value 0 on the caller and every worker in addition to
`SCHED_OTHER/0`, and reports RT runtime `0` as not applicable. Caller affinity
is restored after partial setup and normal shutdown.

A task panic is exceptional. The parallel runtime waits for the other live
lanes, marks itself poisoned, then propagates the caller panic or reports a
worker panic. A poisoned runtime cannot dispatch again, but its workers still
shut down safely.

Retained workers spin only inside a complete tracker call. Between calls they
block, leaving CPUs 1-3 available to PID 1, decode, IRQ/service work, and
ordinary cleanup. Normal-spin workers instead remain runnable at all times;
ordinary scheduling still permits competing work, but idle power, temperature,
frequency, IRQ latency, and decode starvation must be measured in the
sustained gate. The caller remains normally scheduled on CPU 0 in both modes.

Idle teardown publishes stop, wakes parked workers when applicable, waits at
most 100 ms for the fixed worker set, joins completed threads, and safely
detaches any worker the OS did not schedule before the deadline. Normal-spin
teardown needs no wake syscall because every worker polls stop continuously.
`ShutdownReport` makes a detach, worker panic, or caller-state restoration
error discoverable. A user operation that never returns can still hold a live
stack descriptor; a process watchdog remains mandatory for real deployment.

## Minimal capability and watchdog deployment (retained FIFO policy)

The tracker process does not need unrestricted root. Give it only enough
authority to set its own thread scheduling and a real-time priority ceiling
of 80. Because workers park between tracker calls, production uses the normal
positive kernel RT budget and does not mutate the global RT sysctl. A minimal
systemd shape is:

```ini
[Service]
User=mosse
RuntimeDirectory=mosse
Environment=MOSSE_RUST_CORES=4
CPUAffinity=0 1 2 3
AmbientCapabilities=CAP_SYS_NICE
CapabilityBoundingSet=CAP_SYS_NICE
NoNewPrivileges=true
LimitRTPRIO=80
Restart=on-failure
RestartSec=250ms
```

Do not set `CPUSchedulingPolicy=fifo` for the service or launch the benchmark
under `chrt`. The runtime requires its caller to enter and remain
`SCHED_OTHER`; an inherited RT caller returns the explicit single-thread
fallback. Do not grant the tracker `CAP_SYS_ADMIN`, run it as root, or let it
write global RT controls. Record the accepted finite or unlimited RT budget
from `RuntimeStatus` in every qualification artifact.

Before enabling tracker work, add one supervisor/watchdog thread with these
minimal rules:

1. Create it separately before the priority-50 workers and pin it to CPU 0.
2. Set only that thread to `SCHED_FIFO` priority 80.
3. Have it sleep on an absolute monotonic deadline, not spin, and inspect an
   atomic heartbeat advanced immediately before and after each dispatch.
4. If a priority-50 dispatch misses the bounded deadline, terminate the
   process so systemd can restart it; never return while workers may still
   hold the caller's stack descriptor.
5. Add `WatchdogSec=` plus `sd_notify` heartbeats as a slower PID 1 backstop
   when tracker wiring supplies notification support.

If a launcher uses a priority-80 `timeout` process, it must explicitly start
the benchmark child at `SCHED_OTHER`; scheduler policy is inherited across
fork/exec and the runtime rejects an inherited RT caller. Priority 80 can
preempt any awake priority-50 worker, while the normal caller and parked gaps
leave ordinary scheduler capacity for process-level recovery.

## Normal-spin candidate deployment

The Experiment 063 candidate does not use the capability/priority hierarchy
above. Run the tracker and its process watchdog at `SCHED_OTHER`, real-time
priority 0, and nice value 0; omit `CAP_SYS_NICE` and `LimitRTPRIO`; and retain
bounded heartbeats plus process restart. Startup rejects a caller or worker
with a different scheduler or nice value.

Launch the process through `taskset --cpu-list 0` before it creates
OpenCV/FFmpeg decoder threads. Those existing threads remain restricted to
CPU0 because the runtime never changes their affinity. The tracker captures
the constructing caller's CPU0-only mask, and its workers independently set
their masks to CPUs 1, 2, and 3. The caller's captured mask is restored
exactly at partial-startup cleanup and normal teardown. Do not use a cgroup or
cpuset that truly excludes CPUs 1-3: worker pinning will then fail safely and
the runtime will disclose a single-thread fallback. A CPU0-only `taskset`
mask is a per-thread launch mask, not authority to escape a restrictive
cpuset.

Normal scheduling makes the candidate recoverable without an RT preemption
hierarchy, but it does not make continuous polling free. Qualification must
show that PID 1, decode, IRQ/service work, and the watchdog remain responsive
while the three workers consume spare capacity on CPUs 1-3. Temperature,
frequency, firmware throttling, late/dropped frames, idle power, and teardown
must be captured before this policy can replace the parked default.

## First tracker wiring and sustained qualification

The indexed dispatch API is sufficient for task structures that borrow
disjoint crop rows or disjoint correlation-spectrum bins and carry
lane-owned scratch. The first tracker integration must keep inverse-response
peak/reduction work serial on the caller after the relevant dispatch barrier.
That preserves one deterministic reduction order and does not require a
parallel-reduction contract. All dispatches and the serial reduction still
belong inside the caller's tracker-update timer.

Before scoring or continuous deployment, run a preregistered sustained
live-style soak rather than only a compute-loop benchmark. Its producer must
decode or deliver frames against monotonic source deadlines through a bounded
queue; it must not predecode the complete input and thereby hide starvation.
Record at least:

- requested/effective Rust cores and every fallback or shutdown diagnostic;
- source frame cadence, decoded frames, queue depth, decode-starvation
  intervals, frames dropped, and frames completed after their deadline;
- update latency distribution and the longest uninterrupted stall;
- CPU frequency, temperature, and Pi firmware throttling state at a fixed
  sampling cadence;
- watchdog heartbeat deadlines, trips, signal/action, and systemd restart
  outcome;
- caller/worker affinity and scheduler policy/priority before startup, while
  active, and after shutdown.

The runtime only validates and reports `kernel.sched_rt_runtime_us`; it never
changes that or another global RT setting. Each worker's FIFO policy
disappears when that thread exits, and explicit shutdown restores the caller
affinity snapshot and reports restoration failure. The caller is
`SCHED_OTHER` throughout; every worker wake and park transition is included in
tracker latency. Process termination is the final kernel-enforced thread
cleanup if the priority-80 watchdog fires. Archive the scheduler state and
journal watchdog action with the soak results. Any governor change needs
snapshot/restore/verify discipline.

The authorized performance comparison may use four Rust cores against the
default one-core OpenCV reference; matched core counts are not required.
Every result must still disclose requested/effective Rust cores, CPU
ownership, scheduler policy/priority, watchdog policy, and the independent
OpenCV thread count.

Three FIFO50 workers can still delay normal tasks whose affinity is restricted
to CPUs 1-3 while a tracker call is active, and a high-duty-cycle caller can
still consume a finite RT budget. A FIFO80 watchdog is schedulable because it
can preempt awake workers, but that does not prove the rest of the system is
healthy. Qualification therefore must inspect IRQ/watchdog affinities and
complete the sustained decode/temperature/throttling/watchdog soak before any
full score is reported.
