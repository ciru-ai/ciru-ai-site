#!/usr/bin/env bash
#
# Build one architecture-native preview wheel and its reproducibility bundle.

set -euo pipefail

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
repo_root="$(cd -- "${script_dir}/.." && pwd -P)"
output_root="${MOSSE_PREVIEW_OUTPUT_DIR:-${repo_root}/artifacts/python-preview}"
cargo_target_dir="${MOSSE_PREVIEW_CARGO_TARGET_DIR:-${repo_root}/build/cargo-python-preview}"
source_commit="${MOSSE_PREVIEW_SOURCE_COMMIT:-}"
auditwheel_platform="${MOSSE_PREVIEW_AUDITWHEEL_PLAT:-}"
declared_wheel_platform="${MOSSE_PREVIEW_WHEEL_PLATFORM:-${auditwheel_platform}}"
native_library_override="${MOSSE_PREVIEW_NATIVE_LIBRARY:-}"
native_source_commit="${MOSSE_PREVIEW_NATIVE_SOURCE_COMMIT:-}"
native_rust_tree="${MOSSE_PREVIEW_NATIVE_RUST_TREE:-}"

for command_name in awk cargo cp find getconf install mktemp python3 readelf rustc sha256sum sort tail uname; do
    if ! command -v "$command_name" >/dev/null 2>&1; then
        echo "error: required command is unavailable: $command_name" >&2
        exit 1
    fi
done

case "$(uname -m)" in
    x86_64|amd64)
        architecture="x86_64"
        cargo_features=()
        feature_names=()
        release_codegen_units_json="null"
        release_lto_json="null"
        ;;
    aarch64|arm64)
        architecture="aarch64"
        feature_names=(
            shared-activity-futex-wake
            normal-spin-four-core-runtime
            fused-correlated-inverse-cfft36-60x36
            composite-preprocess-forward-60x36
            parallel-model-blend-filter-60x36
        )
        cargo_features=(--features "$(IFS=,; echo "${feature_names[*]}")")
        release_codegen_units_json="1"
        release_lto_json="false"
        ;;
    *)
        echo "error: unsupported preview architecture: $(uname -m)" >&2
        exit 1
        ;;
esac
if [[ -z "$declared_wheel_platform" ]]; then
    declared_wheel_platform="linux_${architecture}"
fi

if [[ -z "$source_commit" ]] && git -C "$repo_root" rev-parse HEAD >/dev/null 2>&1; then
    source_commit="$(git -C "$repo_root" rev-parse HEAD)"
fi
if [[ -z "$source_commit" ]]; then
    echo "error: set MOSSE_PREVIEW_SOURCE_COMMIT when building from a source archive" >&2
    exit 1
fi
if [[ ! "$source_commit" =~ ^[0-9a-fA-F]{40}$ ]]; then
    echo "error: source commit must be a full 40-character Git object ID" >&2
    exit 1
fi
if [[ -n "$native_library_override" ]]; then
    if [[ -z "$native_source_commit" || -z "$native_rust_tree" ]]; then
        echo "error: a supplied native library requires both " \
            "MOSSE_PREVIEW_NATIVE_SOURCE_COMMIT and MOSSE_PREVIEW_NATIVE_RUST_TREE" >&2
        exit 1
    fi
else
    if [[ -n "$native_source_commit" \
        && "$native_source_commit" != "$source_commit" ]]; then
        echo "error: a source-built native library must use the package source commit" >&2
        exit 1
    fi
    native_source_commit="$source_commit"
    detected_native_rust_tree="$(
        git -C "$repo_root" rev-parse HEAD:rust 2>/dev/null || true
    )"
    if [[ -n "$detected_native_rust_tree" ]]; then
        if [[ -n "$native_rust_tree" \
            && "$native_rust_tree" != "$detected_native_rust_tree" ]]; then
            echo "error: supplied native Rust tree disagrees with the checkout" >&2
            exit 1
        fi
        native_rust_tree="$detected_native_rust_tree"
    elif [[ -z "$native_rust_tree" ]]; then
        echo "error: set MOSSE_PREVIEW_NATIVE_RUST_TREE when building from " \
            "a source archive without Git metadata" >&2
        exit 1
    fi
fi
if [[ ! "$native_source_commit" =~ ^[0-9a-fA-F]{40}$ ]]; then
    echo "error: native source commit must be a full 40-character Git object ID" >&2
    exit 1
fi
if [[ ! "$native_rust_tree" =~ ^[0-9a-fA-F]{40}$ ]]; then
    echo "error: native Rust tree must be a full 40-character Git object ID" >&2
    exit 1
fi

short_commit="${source_commit:0:12}"
artifact_dir="${output_root}/${short_commit}/linux-${architecture}"
if [[ -e "$artifact_dir" ]]; then
    echo "error: refusing to overwrite existing artifact directory: $artifact_dir" >&2
    exit 1
fi
mkdir -p "$cargo_target_dir"

export CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR="$cargo_target_dir"
if [[ -z "${SOURCE_DATE_EPOCH:-}" ]]; then
    SOURCE_DATE_EPOCH="$(
        git -C "$repo_root" log -1 --format=%ct 2>/dev/null || printf '315532800'
    )"
fi
export SOURCE_DATE_EPOCH

cargo_environment=(
    -u RUSTFLAGS
    -u CARGO_ENCODED_RUSTFLAGS
    -u RUSTC
    -u RUSTC_WRAPPER
    -u RUSTC_WORKSPACE_WRAPPER
    -u CARGO_BUILD_TARGET
    -u CARGO_PROFILE_RELEASE_CODEGEN_UNITS
    -u CARGO_PROFILE_RELEASE_LTO
    -u CARGO_PROFILE_RELEASE_OPT_LEVEL
    -u CARGO_PROFILE_RELEASE_DEBUG
    -u CARGO_PROFILE_RELEASE_SPLIT_DEBUGINFO
    -u CARGO_PROFILE_RELEASE_STRIP
    -u CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS
    -u CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS
    -u CARGO_PROFILE_RELEASE_PANIC
    -u CARGO_PROFILE_RELEASE_INCREMENTAL
    -u CARGO_PROFILE_RELEASE_RPATH
    -u CFLAGS
    -u CXXFLAGS
)
if [[ "$architecture" == "aarch64" ]]; then
    cargo_environment+=(
        -u CARGO_TARGET_AARCH64_UNKNOWN_LINUX_GNU_RUSTFLAGS
        -u CARGO_TARGET_AARCH64_UNKNOWN_LINUX_GNU_LINKER
        CARGO_PROFILE_RELEASE_CODEGEN_UNITS=1
        CARGO_PROFILE_RELEASE_LTO=false
    )
else
    cargo_environment+=(
        -u CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_RUSTFLAGS
        -u CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER
    )
fi

native_library_supplied_json="false"
if [[ -n "$native_library_override" ]]; then
    if [[ ! -f "$native_library_override" ]]; then
        echo "error: supplied native library is missing: $native_library_override" >&2
        exit 1
    fi
    native_library="$(
        cd -- "$(dirname -- "$native_library_override")"
        printf '%s/%s\n' "$(pwd -P)" "$(basename -- "$native_library_override")"
    )"
    native_library_supplied_json="true"
    echo "Using qualified native library supplied for linux-${architecture}."
else
    echo "Building native library for linux-${architecture} at ${source_commit}..."
    env \
        "${cargo_environment[@]}" \
        cargo build \
            --manifest-path "${repo_root}/rust/Cargo.toml" \
            --release \
            --locked \
            --lib \
            --no-default-features \
            "${cargo_features[@]}"
    native_library="${cargo_target_dir}/release/libmosse_core.so"
fi
if [[ ! -f "$native_library" ]]; then
    echo "error: expected cdylib is missing: $native_library" >&2
    exit 1
fi
native_library_sha256="$(sha256sum "$native_library" | awk '{print $1}')"
minimum_glibc="$(
    readelf --version-info "$native_library" |
        awk '
            match($0, /GLIBC_[0-9]+(\.[0-9]+)*/) {
                print substr($0, RSTART + 6, RLENGTH - 6)
            }
        ' |
        sort -V |
        tail -n 1
)"
if [[ -z "$minimum_glibc" ]]; then
    echo "error: could not determine the native library GLIBC floor" >&2
    exit 1
fi

staging_root="$(mktemp -d)"
cleanup() {
    if [[ -n "$staging_root" && -d "$staging_root" && "$staging_root" != "/" \
        && "$staging_root" != "$repo_root" && ${#staging_root} -ge 8 ]]; then
        rm -rf -- "$staging_root"
    fi
}
trap cleanup EXIT

package_stage="${staging_root}/python"
artifact_stage="${staging_root}/artifact"
mkdir -p "$package_stage"
mkdir -p "$artifact_stage"
cp -a "${script_dir}/." "$package_stage/"
native_stage="${package_stage}/src/mosse_pi/native/linux-${architecture}"
mkdir -p "$native_stage"
install -m 755 "$native_library" "${native_stage}/libmosse_core.so"

rustc_version="$(rustc --version)"
glibc_version="$(getconf GNU_LIBC_VERSION)"
lock_sha256="$(sha256sum "${repo_root}/rust/Cargo.lock" | awk '{print $1}')"
features_csv="$(IFS=,; echo "${feature_names[*]}")"

python3 - \
    "${native_stage}/build_info.json" \
    "$source_commit" \
    "$features_csv" \
    "$rustc_version" \
    "$glibc_version" \
    "$lock_sha256" \
    "$release_codegen_units_json" \
    "$release_lto_json" \
    "$declared_wheel_platform" \
    "$minimum_glibc" \
    "$SOURCE_DATE_EPOCH" \
    "$native_library_sha256" \
    "$native_source_commit" \
    "$native_rust_tree" \
    "$native_library_supplied_json" <<'PY'
import json
import pathlib
import sys

(
    output,
    commit,
    features_csv,
    rustc,
    glibc,
    lock_sha256,
    release_codegen_units,
    release_lto,
    wheel_platform,
    minimum_glibc,
    source_date_epoch,
    native_library_sha256,
    native_source_commit,
    native_rust_tree,
    native_library_supplied,
) = sys.argv[1:]
payload = {
    "source_commit": commit,
    "features": [item for item in features_csv.split(",") if item],
    "rustc": rustc,
    "glibc": glibc,
    "cargo_lock_sha256": lock_sha256,
    "release_codegen_units": json.loads(release_codegen_units),
    "release_lto": json.loads(release_lto),
    "rustflags": None,
    "wheel_platform": wheel_platform or None,
    "minimum_glibc": minimum_glibc,
    "source_date_epoch": int(source_date_epoch),
    "native_library_sha256": native_library_sha256,
    "native_source_commit": native_source_commit,
    "native_rust_tree": native_rust_tree or None,
    "native_library_supplied": json.loads(native_library_supplied),
}
pathlib.Path(output).write_text(
    json.dumps(payload, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)
PY

echo "Building platform wheel..."
(
    cd "$package_stage"
    python3 -m build --wheel --outdir "$artifact_stage"
)

mapfile -t wheels < <(find "$artifact_stage" -maxdepth 1 -type f -name '*.whl' -print)
if ((${#wheels[@]} != 1)); then
    echo "error: expected exactly one wheel, found ${#wheels[@]}" >&2
    exit 1
fi

if [[ -n "$auditwheel_platform" ]]; then
    if ! command -v auditwheel >/dev/null 2>&1; then
        echo "error: MOSSE_PREVIEW_AUDITWHEEL_PLAT requires auditwheel" >&2
        exit 1
    fi
    repaired_dir="${staging_root}/repaired"
    mkdir -p "$repaired_dir"
    auditwheel repair \
        --plat "$auditwheel_platform" \
        --wheel-dir "$repaired_dir" \
        "${wheels[0]}"
    mapfile -t repaired_wheels < <(
        find "$repaired_dir" -maxdepth 1 -type f -name '*.whl' -print
    )
    if ((${#repaired_wheels[@]} != 1)); then
        echo "error: expected one repaired wheel, found ${#repaired_wheels[@]}" >&2
        exit 1
    fi
    rm -- "${wheels[0]}"
    install -m 644 "${repaired_wheels[0]}" \
        "${artifact_stage}/$(basename -- "${repaired_wheels[0]}")"
    wheels=("${artifact_stage}/$(basename -- "${repaired_wheels[0]}")")
fi

install -m 755 "$native_library" "${artifact_stage}/libmosse_core.so"
install -m 644 "${native_stage}/build_info.json" "${artifact_stage}/build_info.json"
install -m 644 "${repo_root}/rust/include/mosse.h" "${artifact_stage}/mosse.h"
install -m 644 "${script_dir}/README.md" "${artifact_stage}/README.md"
install -m 644 "${repo_root}/LICENSE" "${artifact_stage}/LICENSE"
install -m 644 "${script_dir}/REPRODUCE.md" "${artifact_stage}/REPRODUCE.md"
mkdir -p "${artifact_stage}/examples"
install -m 644 "${script_dir}/examples/numpy_api.py" \
    "${artifact_stage}/examples/numpy_api.py"
install -m 644 "${script_dir}/examples/video_capture.py" \
    "${artifact_stage}/examples/video_capture.py"
install -m 644 "${script_dir}/examples/measure_wrapper_latency.py" \
    "${artifact_stage}/examples/measure_wrapper_latency.py"

wheel_name="$(basename -- "${wheels[0]}")"
python3 - \
    "${artifact_stage}/manifest.json" \
    "$source_commit" \
    "$architecture" \
    "$wheel_name" \
    "$rustc_version" \
    "$glibc_version" \
    "$lock_sha256" \
    "$features_csv" \
    "$release_codegen_units_json" \
    "$release_lto_json" \
    "$declared_wheel_platform" \
    "$minimum_glibc" \
    "$SOURCE_DATE_EPOCH" \
    "$native_library_sha256" \
    "$native_source_commit" \
    "$native_rust_tree" \
    "$native_library_supplied_json" <<'PY'
import hashlib
import json
import pathlib
import sys

(
    output,
    commit,
    architecture,
    wheel_name,
    rustc,
    glibc,
    lock_sha256,
    features_csv,
    release_codegen_units,
    release_lto,
    wheel_platform,
    minimum_glibc,
    source_date_epoch,
    native_library_sha256,
    native_source_commit,
    native_rust_tree,
    native_library_supplied,
) = sys.argv[1:]
root = pathlib.Path(output).parent

def sha256(name: str) -> str:
    digest = hashlib.sha256()
    with (root / name).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

payload = {
    "artifact_status": "preview",
    "architecture": architecture,
    "source_commit": commit,
    "features": [item for item in features_csv.split(",") if item],
    "rustc": rustc,
    "glibc": glibc,
    "cargo_lock_sha256": lock_sha256,
    "release_codegen_units": json.loads(release_codegen_units),
    "release_lto": json.loads(release_lto),
    "rustflags": None,
    "wheel_platform": wheel_platform or None,
    "minimum_glibc": minimum_glibc,
    "native_library_sha256": native_library_sha256,
    "native_source_commit": native_source_commit,
    "native_rust_tree": native_rust_tree or None,
    "native_library_supplied": json.loads(native_library_supplied),
    "files": {
        wheel_name: sha256(wheel_name),
        "libmosse_core.so": sha256("libmosse_core.so"),
        "mosse.h": sha256("mosse.h"),
        "build_info.json": sha256("build_info.json"),
        "README.md": sha256("README.md"),
        "LICENSE": sha256("LICENSE"),
        "REPRODUCE.md": sha256("REPRODUCE.md"),
        "examples/numpy_api.py": sha256("examples/numpy_api.py"),
        "examples/video_capture.py": sha256("examples/video_capture.py"),
        "examples/measure_wrapper_latency.py": sha256(
            "examples/measure_wrapper_latency.py"
        ),
    },
    "source_date_epoch": int(source_date_epoch),
}
pathlib.Path(output).write_text(
    json.dumps(payload, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)
PY

(
    cd "$artifact_stage"
    sha256sum \
        "$wheel_name" \
        libmosse_core.so \
        mosse.h \
        build_info.json \
        README.md \
        LICENSE \
        REPRODUCE.md \
        examples/numpy_api.py \
        examples/video_capture.py \
        examples/measure_wrapper_latency.py \
        manifest.json > SHA256SUMS
)

mkdir -p "$(dirname -- "$artifact_dir")"
mv -- "$artifact_stage" "$artifact_dir"

echo "Preview artifact: $artifact_dir"
echo "Wheel:            $wheel_name"
cat "${artifact_dir}/SHA256SUMS"
echo
echo "Run smoke tests from the staged directory, record them as SMOKE_TEST.md,"
echo "then finalize the downloadable bundle with:"
echo "  ${script_dir}/finalize_preview.sh ${artifact_dir}"
