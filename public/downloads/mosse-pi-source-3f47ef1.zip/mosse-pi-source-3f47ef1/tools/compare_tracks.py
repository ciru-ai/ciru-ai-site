#!/usr/bin/env python3
"""Compare two MOSSE per-frame CSV files and enforce frame identity."""

from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class Frame:
    index: int
    update_attempted: bool
    success: bool
    x: float
    y: float
    width: float
    height: float
    checksum: str

    @property
    def center(self) -> tuple[float, float]:
        return (self.x + self.width * 0.5, self.y + self.height * 0.5)


def _parse_bool(value: str, field: str, path: Path, row: int) -> bool:
    if value == "0":
        return False
    if value == "1":
        return True
    raise ValueError(f"{path}:{row}: {field} must be 0 or 1, got {value!r}")


def read_frames(path: Path) -> list[Frame]:
    required = {
        "frame_index",
        "update_attempted",
        "success",
        "bbox_x",
        "bbox_y",
        "bbox_width",
        "bbox_height",
        "frame_checksum_fnv1a64",
    }
    frames: list[Frame] = []
    with path.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream)
        missing = required.difference(reader.fieldnames or ())
        if missing:
            raise ValueError(f"{path}: missing CSV columns: {sorted(missing)}")
        for row_number, row in enumerate(reader, start=2):
            try:
                frame = Frame(
                    index=int(row["frame_index"]),
                    update_attempted=_parse_bool(
                        row["update_attempted"],
                        "update_attempted",
                        path,
                        row_number,
                    ),
                    success=_parse_bool(
                        row["success"], "success", path, row_number
                    ),
                    x=float(row["bbox_x"]),
                    y=float(row["bbox_y"]),
                    width=float(row["bbox_width"]),
                    height=float(row["bbox_height"]),
                    checksum=row["frame_checksum_fnv1a64"].strip().lower(),
                )
            except (TypeError, ValueError) as error:
                if isinstance(error, ValueError) and str(error).startswith(
                    str(path)
                ):
                    raise
                raise ValueError(f"{path}:{row_number}: {error}") from error
            values = (frame.x, frame.y, frame.width, frame.height)
            if not all(math.isfinite(value) for value in values):
                raise ValueError(f"{path}:{row_number}: non-finite bounding box")
            if frame.width <= 0.0 or frame.height <= 0.0:
                raise ValueError(f"{path}:{row_number}: non-positive bounding box")
            if frames and frame.index <= frames[-1].index:
                raise ValueError(
                    f"{path}:{row_number}: frame indexes must increase strictly"
                )
            frames.append(frame)
    if not frames:
        raise ValueError(f"{path}: CSV contains no frame rows")
    return frames


def _nearest_rank(values: Iterable[float], percentile: float) -> float | None:
    ordered = sorted(values)
    if not ordered:
        return None
    rank = max(1, math.ceil(percentile * len(ordered)))
    return ordered[rank - 1]


def _mean(values: list[float]) -> float | None:
    return math.fsum(values) / len(values) if values else None


def _iou(left: Frame, right: Frame) -> float:
    intersection_width = max(
        0.0, min(left.x + left.width, right.x + right.width) - max(left.x, right.x)
    )
    intersection_height = max(
        0.0,
        min(left.y + left.height, right.y + right.height) - max(left.y, right.y),
    )
    intersection = intersection_width * intersection_height
    union = left.width * left.height + right.width * right.height - intersection
    return intersection / union if union > 0.0 else 0.0


def compare(reference: list[Frame], candidate: list[Frame], worst_count: int) -> dict:
    if len(reference) != len(candidate):
        raise ValueError(
            f"frame row count differs: reference={len(reference)}, "
            f"candidate={len(candidate)}"
        )

    for left, right in zip(reference, candidate):
        if left.index != right.index:
            raise ValueError(
                f"frame index differs: reference={left.index}, candidate={right.index}"
            )
        if left.update_attempted != right.update_attempted:
            raise ValueError(
                f"update_attempted differs at frame {left.index}"
            )
        if not left.checksum or not right.checksum:
            raise ValueError(
                f"missing frame checksum at frame {left.index}; "
                "identity checks must be enabled"
            )
        if left.checksum != right.checksum:
            raise ValueError(
                f"decoded frame checksum differs at frame {left.index}: "
                f"{left.checksum} != {right.checksum}"
            )

    paired_updates = [
        (left, right)
        for left, right in zip(reference, candidate)
        if left.update_attempted
    ]
    if not paired_updates:
        raise ValueError("CSV files contain no attempted tracker updates")

    agreement = [
        left.success == right.success for left, right in paired_updates
    ]
    mismatches = [
        {
            "frame_index": left.index,
            "reference_success": left.success,
            "candidate_success": right.success,
        }
        for left, right in paired_updates
        if left.success != right.success
    ]
    mutual = [
        (left, right)
        for left, right in paired_updates
        if left.success and right.success
    ]

    center_records: list[dict] = []
    ious: list[float] = []
    width_deltas: list[float] = []
    height_deltas: list[float] = []
    for left, right in mutual:
        left_center = left.center
        right_center = right.center
        distance = math.hypot(
            left_center[0] - right_center[0],
            left_center[1] - right_center[1],
        )
        overlap = _iou(left, right)
        width_delta = abs(left.width - right.width)
        height_delta = abs(left.height - right.height)
        center_records.append(
            {
                "frame_index": left.index,
                "center_distance_pixels": distance,
                "iou": overlap,
                "width_delta_pixels": width_delta,
                "height_delta_pixels": height_delta,
            }
        )
        ious.append(overlap)
        width_deltas.append(width_delta)
        height_deltas.append(height_delta)

    center_distances = [
        record["center_distance_pixels"] for record in center_records
    ]
    within_two = sum(distance <= 2.0 for distance in center_distances)
    worst = sorted(
        center_records,
        key=lambda record: (
            record["center_distance_pixels"],
            -record["iou"],
            record["frame_index"],
        ),
        reverse=True,
    )[:worst_count]

    attempted = len(paired_updates)
    mutually_successful = len(mutual)
    return {
        "schema_version": 1,
        "frame_identity": {
            "row_count": len(reference),
            "attempted_updates": attempted,
            "checksums_match": True,
        },
        "success": {
            "reference_successes": sum(left.success for left, _ in paired_updates),
            "candidate_successes": sum(right.success for _, right in paired_updates),
            "agreement_count": sum(agreement),
            "agreement_fraction": sum(agreement) / attempted,
            "mismatch_count": len(mismatches),
            "mismatches": mismatches,
        },
        "mutually_successful_frames": mutually_successful,
        "center_distance_pixels": {
            "mean": _mean(center_distances),
            "median": _nearest_rank(center_distances, 0.5),
            "p95": _nearest_rank(center_distances, 0.95),
            "max": max(center_distances) if center_distances else None,
            "cumulative": math.fsum(center_distances),
            "within_two_pixels_count": within_two,
            "within_two_pixels_fraction": (
                within_two / mutually_successful if mutually_successful else None
            ),
        },
        "iou": {
            "mean": _mean(ious),
            "median": _nearest_rank(ious, 0.5),
            "p05": _nearest_rank(ious, 0.05),
            "min": min(ious) if ious else None,
        },
        "absolute_size_delta_pixels": {
            "mean_width": _mean(width_deltas),
            "max_width": max(width_deltas) if width_deltas else None,
            "mean_height": _mean(height_deltas),
            "max_height": max(height_deltas) if height_deltas else None,
        },
        "worst_center_frames": worst,
        "gates": {
            "success_agreement_at_least_99_percent": sum(agreement) / attempted
            >= 0.99,
            "centers_within_two_pixels_at_least_99_percent": (
                mutually_successful > 0
                and within_two / mutually_successful >= 0.99
            ),
            "mean_iou_at_least_0_98": bool(ious and _mean(ious) >= 0.98),
        },
    }


def render_text(result: dict) -> str:
    success = result["success"]
    center = result["center_distance_pixels"]
    overlap = result["iou"]
    gates = result["gates"]
    return "\n".join(
        (
            f"Attempted updates: {result['frame_identity']['attempted_updates']}",
            f"Success agreement: {success['agreement_fraction']:.6%} "
            f"({success['mismatch_count']} mismatches)",
            "Mutually successful frames: "
            f"{result['mutually_successful_frames']}",
            "Centers within 2 px: "
            + (
                f"{center['within_two_pixels_fraction']:.6%}"
                if center["within_two_pixels_fraction"] is not None
                else "n/a"
            ),
            "Mean center distance: "
            + (
                f"{center['mean']:.6f} px"
                if center["mean"] is not None
                else "n/a"
            ),
            "Mean IoU: "
            + (
                f"{overlap['mean']:.6f}"
                if overlap["mean"] is not None
                else "n/a"
            ),
            "Gates: "
            + ", ".join(
                f"{name}={'PASS' if passed else 'FAIL'}"
                for name, passed in gates.items()
            ),
        )
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("reference_csv", type=Path)
    parser.add_argument("candidate_csv", type=Path)
    parser.add_argument("--output", type=Path, help="Write JSON to this path")
    parser.add_argument(
        "--format", choices=("json", "text"), default="text", dest="output_format"
    )
    parser.add_argument("--worst-count", type=int, default=20)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.worst_count < 0:
        raise SystemExit("--worst-count must be non-negative")
    result = compare(
        read_frames(args.reference_csv),
        read_frames(args.candidate_csv),
        args.worst_count,
    )
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(
            json.dumps(result, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
    if args.output_format == "json":
        print(json.dumps(result, indent=2, sort_keys=True))
    else:
        print(render_text(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
