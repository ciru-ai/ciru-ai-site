"""Single source of truth for Python package and native identity versions."""

__version__ = "0.1.0.dev5"
