#!/usr/bin/env bash
# Run one user-level command under the Pi's performance governor and restore
# every observed host setting on all exit paths. This wrapper must run as root.
set -Eeuo pipefail

usage() {
    echo "usage: $0 <new-evidence-directory> <run-as-user> <command> [args...]" >&2
    exit 64
}

[[ $# -ge 3 ]] || usage
evidence_dir=$1
run_as_user=$2
shift 2
command=("$@")

[[ $EUID -eq 0 ]] || {
    echo "this wrapper must run as root" >&2
    exit 77
}
id "$run_as_user" >/dev/null 2>&1 || {
    echo "run-as user does not exist: $run_as_user" >&2
    exit 67
}
[[ ! -e "$evidence_dir" ]] || {
    echo "evidence directory already exists: $evidence_dir" >&2
    exit 73
}
mkdir -p -- "$evidence_dir"
evidence_dir=$(readlink -f -- "$evidence_dir")

shopt -s nullglob
policy_paths=(/sys/devices/system/cpu/cpufreq/policy*/scaling_governor)
shopt -u nullglob
((${#policy_paths[@]} > 0)) || {
    echo "no cpufreq governor policies were found" >&2
    exit 69
}

original_governors=()
for path in "${policy_paths[@]}"; do
    [[ -r "$path" && -w "$path" ]] || {
        echo "governor path is not readable and writable: $path" >&2
        exit 77
    }
    original_governors+=("$(<"$path")")
done

pre_boot=$(< /proc/sys/kernel/random/boot_id)
pre_rt_period=$(< /proc/sys/kernel/sched_rt_period_us)
pre_rt_runtime=$(< /proc/sys/kernel/sched_rt_runtime_us)
pre_watchdog=$(systemctl show --property=RuntimeWatchdogUSec --value)
pre_throttle=$(vcgencmd get_throttled)
[[ "$pre_throttle" == "throttled=0x0" ]] || {
    echo "pre-run firmware throttle state is not clean: $pre_throttle" >&2
    exit 65
}

journal_cursor=$(
    journalctl --quiet --no-pager -n 0 --show-cursor _COMM=sshd |
        sed -n 's/^-- cursor: //p'
)

capture_state() {
    local label=$1
    {
        printf 'label=%s\n' "$label"
        printf 'utc=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
        printf 'boot_id=%s\n' "$(< /proc/sys/kernel/random/boot_id)"
        printf 'governors='
        local separator=""
        local path
        for path in "${policy_paths[@]}"; do
            printf '%s%s' "$separator" "$(<"$path")"
            separator=,
        done
        printf '\n'
        printf 'frequency_khz='
        separator=""
        for path in /sys/devices/system/cpu/cpufreq/policy*/scaling_cur_freq; do
            printf '%s%s' "$separator" "$(<"$path")"
            separator=,
        done
        printf '\n'
        printf 'temperature_millidegrees=%s\n' \
            "$(< /sys/class/thermal/thermal_zone0/temp)"
        printf 'throttle=%s\n' "$(vcgencmd get_throttled)"
        printf 'rt_period_us=%s\n' \
            "$(< /proc/sys/kernel/sched_rt_period_us)"
        printf 'rt_runtime_us=%s\n' \
            "$(< /proc/sys/kernel/sched_rt_runtime_us)"
        printf 'runtime_watchdog=%s\n' \
            "$(systemctl show --property=RuntimeWatchdogUSec --value)"
    } >"$evidence_dir/state-$label.txt"
}

status=ERROR
child_exit=125
restoration_result=NOT_RUN
observer_result=NOT_RUN

finalize() {
    local wrapper_exit=$?
    local restore_failed=0
    trap - EXIT INT TERM
    set +e

    for index in "${!policy_paths[@]}"; do
        printf '%s\n' "${original_governors[$index]}" \
            >"${policy_paths[$index]}" || restore_failed=1
    done

    capture_state post || restore_failed=1
    post_boot=$(< /proc/sys/kernel/random/boot_id)
    post_rt_period=$(< /proc/sys/kernel/sched_rt_period_us)
    post_rt_runtime=$(< /proc/sys/kernel/sched_rt_runtime_us)
    post_watchdog=$(systemctl show --property=RuntimeWatchdogUSec --value)
    post_throttle=$(vcgencmd get_throttled)

    for index in "${!policy_paths[@]}"; do
        [[ $(<"${policy_paths[$index]}") == "${original_governors[$index]}" ]] ||
            restore_failed=1
    done
    [[ "$post_boot" == "$pre_boot" ]] || restore_failed=1
    [[ "$post_rt_period" == "$pre_rt_period" ]] || restore_failed=1
    [[ "$post_rt_runtime" == "$pre_rt_runtime" ]] || restore_failed=1
    [[ "$post_watchdog" == "$pre_watchdog" ]] || restore_failed=1
    [[ "$post_throttle" == "throttled=0x0" ]] || restore_failed=1

    if ((restore_failed == 0)); then
        restoration_result=PASS
    else
        restoration_result=FAIL
    fi

    : >"$evidence_dir/sshd-events-after-launch.log"
    if [[ -n "$journal_cursor" ]]; then
        journalctl --quiet --no-pager --after-cursor "$journal_cursor" \
            _COMM=sshd >"$evidence_dir/sshd-events-after-launch.log" 2>&1 ||
            true
    fi
    if grep -Eq 'Accepted (publickey|password|keyboard-interactive)' \
        "$evidence_dir/sshd-events-after-launch.log"; then
        observer_result=FAIL
    else
        observer_result=PASS
    fi

    if ((wrapper_exit == 0 && child_exit == 0 && restore_failed == 0)) &&
        [[ "$observer_result" == PASS ]]; then
        status=PASS
    else
        status=FAIL
    fi

    {
        printf 'status=%s\n' "$status"
        printf 'wrapper_exit=%s\n' "$wrapper_exit"
        printf 'child_exit=%s\n' "$child_exit"
        printf 'restoration_result=%s\n' "$restoration_result"
        printf 'observer_result=%s\n' "$observer_result"
        printf 'original_governors=%s\n' \
            "$(IFS=,; printf '%s' "${original_governors[*]}")"
        printf 'required_governor=performance\n'
        printf 'run_as_user=%s\n' "$run_as_user"
    } >"$evidence_dir/RESULT_STATUS"
    (
        cd "$evidence_dir"
        find . -maxdepth 1 -type f ! -name SHA256SUMS -print0 |
            sort -z |
            xargs -0 sha256sum >SHA256SUMS
    ) || true
    chmod -R a+rX -- "$evidence_dir" || true

    if [[ "$status" == PASS ]]; then
        exit 0
    fi
    if ((wrapper_exit != 0)); then
        exit "$wrapper_exit"
    fi
    if ((child_exit != 0)); then
        exit "$child_exit"
    fi
    exit 65
}
trap finalize EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

capture_state pre
{
    printf 'wrapper=%s\n' "$(readlink -f -- "${BASH_SOURCE[0]}")"
    printf 'wrapper_sha256=%s\n' \
        "$(sha256sum "${BASH_SOURCE[0]}" | cut -d' ' -f1)"
    printf 'run_as_user=%s\n' "$run_as_user"
    printf 'command='
    printf '%q ' "${command[@]}"
    printf '\n'
} >"$evidence_dir/invocation.txt"

for path in "${policy_paths[@]}"; do
    printf 'performance\n' >"$path"
done
for path in "${policy_paths[@]}"; do
    [[ $(<"$path") == performance ]] || {
        echo "failed to activate performance governor: $path" >&2
        exit 65
    }
done
capture_state performance

set +e
runuser --user "$run_as_user" -- "${command[@]}"
child_exit=$?
set -e
((child_exit == 0)) || exit "$child_exit"

status=COMPLETING
