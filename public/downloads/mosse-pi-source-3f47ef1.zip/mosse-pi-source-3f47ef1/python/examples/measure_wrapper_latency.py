#!/usr/bin/env python3
"""Measure Python wrapper-call latency, never the native headline boundary."""

from __future__ import annotations

import argparse
import statistics
import time

import cv2

from mosse_pi import MosseTracker


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("video")
    parser.add_argument("--roi", type=float, nargs=4, required=True)
    parser.add_argument(
        "--mode", choices=("auto", "single", "multicore"), default="auto"
    )
    args = parser.parse_args()

    capture = cv2.VideoCapture(args.video)
    ok, frame = capture.read()
    if not ok:
        raise RuntimeError("could not read the initial frame")

    samples_ns: list[int] = []
    try:
        with MosseTracker(frame, args.roi, mode=args.mode) as tracker:
            while True:
                ok, frame = capture.read()
                if not ok:
                    break
                started = time.perf_counter_ns()
                tracker.update(frame)
                samples_ns.append(time.perf_counter_ns() - started)
            if not samples_ns:
                raise RuntimeError("video has no update frames")
            ordered = sorted(samples_ns)
            p95 = ordered[min(len(ordered) - 1, int(len(ordered) * 0.95))]
            print(
                "metric=python_wrapper_call "
                f"requested={tracker.requested_mode} selected={tracker.selected_mode} "
                f"backend={tracker.backend} calls={len(samples_ns)} "
                f"mean_ns={statistics.fmean(samples_ns):.3f} "
                f"median_ns={statistics.median(samples_ns):.3f} p95_ns={p95}"
            )
    finally:
        capture.release()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
