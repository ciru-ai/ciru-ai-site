#!/usr/bin/env bash
#
# Idempotent Debian 13 / Raspberry Pi prerequisite installation.
#
# This script intentionally does not change CPU governors, power settings,
# services, kernel parameters, or user credentials.

set -euo pipefail

dry_run=0
skip_update=0
allow_unsupported=0

usage() {
    cat <<'EOF'
Usage: bootstrap_pi.sh [--dry-run] [--skip-update] [--allow-unsupported]

Installs the Debian packages needed to build and profile the OpenCV and Rust
MOSSE implementations. It uses sudo explicitly and may prompt for the invoking
user's sudo credentials; no credentials are stored by this script.

Options:
  --dry-run            Print the apt commands without changing the host.
  --skip-update        Skip `sudo apt-get update`.
  --allow-unsupported  Continue when the host is not Debian 13.
EOF
}

while (($# > 0)); do
    case "$1" in
        --dry-run)
            dry_run=1
            shift
            ;;
        --skip-update)
            skip_update=1
            shift
            ;;
        --allow-unsupported)
            allow_unsupported=1
            shift
            ;;
        --help|-h)
            usage
            exit 0
            ;;
        *)
            echo "error: unknown argument: $1" >&2
            usage >&2
            exit 2
            ;;
    esac
done

if [[ ! -r /etc/os-release ]]; then
    echo "error: /etc/os-release is unavailable" >&2
    exit 1
fi

# shellcheck disable=SC1091
source /etc/os-release

if [[ "${ID:-}" != "debian" || "${VERSION_ID:-}" != "13" ]]; then
    if ((allow_unsupported == 0)); then
        echo \
            "error: expected Debian 13, found ${PRETTY_NAME:-unknown}; use --allow-unsupported to override" \
            >&2
        exit 1
    fi
    echo "warning: continuing on unsupported host ${PRETTY_NAME:-unknown}" >&2
fi

if ((EUID == 0)); then
    sudo_prefix=()
else
    if ! command -v sudo >/dev/null 2>&1; then
        echo "error: sudo is required when not running as root" >&2
        exit 1
    fi
    sudo_prefix=(sudo)
fi

required_packages=(
    build-essential
    ca-certificates
    cargo
    clang
    cmake
    curl
    ffmpeg
    gdb
    git
    jq
    libopencv-contrib-dev
    libopencv-dev
    ninja-build
    pkg-config
    python3
    python3-opencv
    python3-pip
    python3-venv
    rsync
    rustc
    time
    valgrind
)

# These are useful for authoritative profiling but can vary across Raspberry Pi
# OS and Debian repositories. Install each only when apt metadata exposes it.
optional_packages=(
    linux-cpupower
    linux-perf
    raspi-utils
)

print_command() {
    printf '  '
    printf '%q ' "$@"
    printf '\n'
}

run_privileged() {
    if ((dry_run == 1)); then
        print_command "${sudo_prefix[@]}" "$@"
    else
        "${sudo_prefix[@]}" "$@"
    fi
}

echo "Bootstrap target: ${PRETTY_NAME:-unknown} ($(uname -m))"

if ((skip_update == 0)); then
    echo "Refreshing apt package metadata:"
    run_privileged apt-get update
fi

echo "Installing required build and benchmark packages:"
run_privileged \
    env DEBIAN_FRONTEND=noninteractive \
    apt-get install --yes --no-install-recommends \
    "${required_packages[@]}"

for package in "${optional_packages[@]}"; do
    if apt-cache show "$package" >/dev/null 2>&1; then
        echo "Installing optional profiling package: $package"
        run_privileged \
            env DEBIAN_FRONTEND=noninteractive \
            apt-get install --yes --no-install-recommends \
            "$package"
    else
        echo "warning: optional package is unavailable: $package" >&2
    fi
done

if ((dry_run == 1)); then
    echo "Dry run complete; no packages were installed."
    exit 0
fi

echo "Verifying required tools:"
rustc --version
cargo --version
cmake --version | sed -n '1p'
ninja --version
c++ --version | sed -n '1p'
pkg-config --modversion opencv4

opencv_include_dir="$(pkg-config --variable=includedir opencv4)"
legacy_header="${opencv_include_dir}/opencv2/tracking/tracking_legacy.hpp"

if [[ ! -r "$legacy_header" ]]; then
    echo "error: OpenCV legacy tracking header is missing: $legacy_header" >&2
    exit 1
fi

if ! grep -q "TrackerMOSSE" "$legacy_header"; then
    echo "error: OpenCV was installed without legacy TrackerMOSSE support" >&2
    exit 1
fi

if ! pkg-config --libs opencv4 | grep -q -- "-lopencv_tracking"; then
    echo "error: OpenCV pkg-config metadata omits the contrib tracking library" >&2
    exit 1
fi

echo "OpenCV legacy TrackerMOSSE header: $legacy_header"
echo "Bootstrap complete. System performance settings were not changed."
