# MOSSE Rust optimization report

Status: **final production qualification passed. The exact four-core
Experiment 066 tracker measured 11,632.121609 FPS median, or 5.014304767×
the frozen 2,319.787518-FPS one-core OpenCV baseline. The contemporaneous
same-suite paired median was 4.938477642×. All five full-video traces were
literal-exact and every failed update remained timed.**

## Executive result

The production native identity is source
`60bdb90776ab5eb30a835a2ad35020b605f41c9e`, Rust tree
`b057110badaf5f94d63f557bfd869268f8f3fe4c`, benchmark SHA-256
`de88c190b751707521e2d991ed41a108e5ca81b0c3e8efb84df243f558e01288`,
and AArch64 shared-library SHA-256
`7aa6a3b8cae990503187d9f65b9dd47715f6209e51226d7ec61b988746eb9201`.

| Result | Median tracker FPS | Ratio | Qualification |
|---|---:|---:|---|
| Frozen official OpenCV 4.10 legacy MOSSE, one core | **2,319.787518** | 1.000000000× | Five-run reference |
| Final-suite OpenCV, one core | **2,358.526332** | 1.016699× frozen | Five measured alternating runs |
| Current Rust build, one-core companion | **7,071.160241** | **3.048193072× frozen** | Five exact measured pairs |
| Production Rust build, four cores | **11,632.121609** | **5.014304767× frozen** | Five exact measured pairs |
| Production Rust / same-suite OpenCV | — | **4.938477642× paired median** | Contemporaneous denominator |

The production mean was 11,626.625991 FPS. The median-FPS run's measured
mean update was 85.968840 µs, 21.799651 µs below the 107.768491-µs 4×
ceiling. The median is 25.357619% above the exact 4× target and only
0.286095% above the exact 5× frozen-baseline threshold. Four of five Rust
runs exceeded 5×; one did not. Accordingly, this report claims a **5.014305×
median versus the frozen baseline**, not a guaranteed 5× floor and not 5×
versus the faster contemporaneous OpenCV sample.

Each measured pair contained all 4,947 decoded frames, all 4,946 timed
updates, 2,219 successes, and 2,727 failures. Across 24,735 compared rows,
the nine non-timing fields were identical: checksum, decision, and box
mismatches were all zero. No lost-target clock exclusion or workload
shortening exists in this result.

The governed suite reached 67.679 °C without firmware throttling. It preserved
the boot ID, runtime watchdog, RT period/runtime, and scheduler state, found
no post-launch SSH observer, left no benchmark process behind, and restored
the original `ondemand` governor after scoring. The separately paced
OpenCV/Python production soak processed the complete source-rate video with
zero dropped/late frames, zero decode starvation, exact output, and
deterministic cleanup.

The detailed pre-composite experiment sections below are retained as
historical optimization evidence. Any statement in those sections that calls
Experiment 026, 029, or 032 “current,” “preferred,” or “next” describes the
state at that experiment and is superseded by this executive result and the
final Experiment 064/066 sections near the end of the report.

## Fixed benchmark identity

| Property | Recorded value |
|---|---|
| Object | Drone |
| Video | H.264, 848×480, 164.950244 seconds, 27,000,162 bytes |
| Video SHA-256 | `17293ee5158b5f41d2920bbb1ba835f96050ab2813942ff29008dffab10857b5` |
| Decoded work | 4,947 frames: frame 0 initialization plus 4,946 timed updates |
| Source frame rate | 29.9908619 FPS |
| Frame-0 ROI | `x=281, y=193, width=55, height=36` |
| Internal MOSSE/FFT window | 60×36 |
| Pi reference behavior | 2,219 successful updates followed by 2,727 failures |

The shared native harness supplies the same decoded BGR frames, ROI, tracker
window, and timing boundary to both implementations. Initialization is timed
separately. Tracker-only FPS is attempted updates divided by the sum of update
call durations. Decode, checksumming, CSV/JSON output, display, annotation,
and encoding are excluded. Failed updates remain in the numerator and the
full video is always processed.

## Authoritative environment

- Raspberry Pi 4 Model B Rev 1.4, 8 GB, four Cortex-A72 cores, AArch64/NEON.
- Debian GNU/Linux 13.5, kernel `6.18.34+rpt-rpi-v8`.
- CPU governor `performance`, observed at 1.8 GHz.
- OpenCV 4.10.0 with contrib legacy MOSSE and TBB.
- GCC/G++ 14.2.0, CMake 3.31.6, Ninja 1.12.1.
- The final AArch64 production library uses rustc/Cargo 1.97.1, RustFFT
  6.4.1, one release codegen unit, no LTO, and the exact feature composition
  recorded by Experiment 066. The earlier Rust 1.85 and Experiment 032 build
  notes below remain historical comparison points.
- Dunamis is also tested for transfer. Its results are labeled separately and
  never substituted for Pi scoring.

## Exact optimization progression

The scalar Rust reference began at 1,902.025274 FPS. Every retained step below
preserved the official Pi decisions and boxes.

| Experiment / commit | Retained exact change | Pi FPS | Increment |
|---|---|---:|---:|
| 001 / `97cfc71` | Exact 256-entry `f32` logarithm lookup | 2,087.448723 | +9.748737% |
| 002 / `d376f67` | Fused BGR subpixel sampling and grayscale | 2,221.347941 | +6.414491% |
| 003 / `97db126` | Exact half-pixel interior crop | 3,057.210353 | +37.628613% |
| 005 / `b0b6ff5` | Reuse zero-displacement localization spectrum | 3,151.892880 | +3.097024% |
| 006 / `82f7048` | Real row FFTs and unique half-spectrum | 4,461.459908 | +41.548589% |
| 009 / `d1de6cd` | Consuming real rows and column-major batched columns | 4,619.203005 | +3.535683% |
| 011 / `e193c19` | Batched fixed-size real row transforms | 4,766.745189 | +3.194105% |
| 013 / `c81cab6` | Fused crop, grayscale, log lookup, and ordered sum | 4,923.187147 | +3.281945% |
| 014 / `1a1ffc9` | Fused inverse scaling, maximum, sum, and sum-of-squares | 4,999.145860 | +1.542877% |
| 015 / `791cfde` | AArch64 NEON localization-spectrum multiply | 5,075.154485 | +1.520432% |
| 016 / `9883f8f` | AArch64 NEON fixed 60×36 crop and grayscale | 6,471.500559 | +27.513371% |
| 026 / `4f9dd19` | Context-specific AArch64 Good-Thomas localization/inverse columns | **6,541.536862** | **+1.082227%** |
| 029 / compiler-only build | Same production source, generic Rust 1.97.1 build | **6,620.575999** | **+1.208266%** vs Experiment 026 |
| 032 / Pi build setting | Same source/toolchain, release `codegen-units=1` | **6,747.282754** | **+1.913833%** vs Experiment 029 |
| 064 / retained composite | Whole-layout four-core runtime plus fused inverse, preprocessing/forward, and model/filter work | **11,421.388839** | **+69.280%** vs Experiment 032 |
| 066 / final median | Governed five-pair qualification of the retained composite | **11,632.121609** | **+1.845%** vs isolated Experiment 064 replay |

The main gains came from reducing FFT work, keeping only the unique
half-spectrum, eliminating intermediate image buffers, specializing the fixed
60×36 window, preserving allocation-free permanent workspaces, and applying
NEON only where bit-exact arithmetic could be maintained.

## Experiment 026 historical production source and retention gate

- Rust: **6,541.536862 FPS**.
- Ratio to the official OpenCV median: **2.819886223×**.
- Improvement over Experiment 016: **1.082227%**.
- Rust mean latency implied by tracker-only FPS: **152.869 microseconds**.
- Rust median / p95 / p99 latency:
  **123.831 / 200.830 / 242.107 microseconds**.
- Decisions: 2,219 success / 2,727 failure.
- Success agreement: 100%.
- Mean IoU: 1.0.
- Maximum center error: 0 px.
- Frame checksums: exact across all 4,947 decoded frames.
- Temperature: approximately 52.5 °C after the full run.
- Throttling: none.

The retained change is AArch64-only. It uses explicit RustFFT Good-Thomas 4×9
columns for localization forward and response inverse transforms, while
initialization and model-update forwards retain the architecture planner.
All 47 AArch64 Rust tests and all three native C++/FFI tests passed. Dunamis
keeps RustFFT's direct AVX planner rather than forcing the Pi factorization.

The production configuration at that milestone, commit `4f9dd19`, compiles the
AArch64-specific context dispatch completely out on x86: the extra plan
`Arc`, localization field, and runtime branch are absent rather than resolving
to duplicate planner paths. One lean exact Dunamis comparison was
directionally +0.92305% versus its baseline. It is classified as **neutral,
with no stable x86 speedup claim**, because it measured only one short,
fixed-order screen. A separate exact Pi Rust 1.97.1 screen measured the final
compile-out +0.86727% versus the pre-compile-out Rust 1.97.1 build. That is
also lean directional evidence, not a stable speedup.

The +0.86727% compile-out screen must not be stacked onto Experiment 029's
+1.208266% complete-video compiler result: the references overlap and the
measurements have different scopes. Commit `4f9dd19` is simply the production
source used for subsequent work.

## Experiment 029 preferred Rust 1.97.1 build

Experiment 029 rebuilt the unchanged production source with the generic Rust
1.97.1 release toolchain and no target-CPU, LTO, PGO, codegen-unit, or
opt-level override. The single complete Pi gate recorded:

- tracker-only FPS: **6,620.5759995355**;
- mean update latency: **151.044260 µs**;
- improvement over the Experiment 026 Rust 1.85.0 gate:
  **+1.2082655608%**;
- ratio to the official OpenCV median: **2.8539579375×**;
- 4,947 decoded frames and all 4,946 attempted updates;
- the unchanged 2,219-success/2,727-failure split;
- exact frame checksums, decisions, and reported boxes.

At that milestone, this made generic Rust 1.97.1 the preferred Pi toolchain.
Experiment 032 below supplied the then-preferred Pi-specific release setting.
Experiment 029 remains a single exact complete-video historical gate, not an
official repeated median.

## Experiment 032 historical Pi codegen setting

Experiment 032 kept the exact Experiment 026 source, Rust 1.97.1, generic CPU
selection, and ordinary release optimization while setting only:

```text
CARGO_PROFILE_RELEASE_CODEGEN_UNITS=1
```

Its single complete Pi candidate replay recorded:

- tracker-only FPS: **6,747.28275355185**;
- mean update latency: **148.207810 µs**;
- improvement over the retained Experiment 029 full replay:
  **+1.9138327847%**;
- ratio to the official one-thread OpenCV median: **2.9085779202×**;
- all 4,947 decoded frames and 4,946 attempted updates;
- the unchanged 2,219-success/2,727-failure split;
- exact checksums, all decisions, and every reported box.

The Pi stayed at 1.8 GHz under the `performance` governor with firmware
throttling `0x0`. Fat LTO plus one codegen unit also passed a short exact
screen, but was weaker and did not receive a full replay.

This setting does **not** transfer to Dunamis: a single exact x86_64 diagnostic
screen was **−1.555223%**. It is retained only for Pi/AArch64 builds; Dunamis
keeps its ordinary native release codegen-unit setting. This architecture
classification prevents an ARM-only gain from becoming a global x86
regression.

## Experiment 036 retained x86 preprocessing

Experiment 033 tested accumulating log sum and squared-log sum during the
existing crop/log pass, removing the later squared-deviation scan. Its
complete result was architecture-dependent: `+2.901012%` on a clean
native/native Dunamis pair, but only `+0.190649%` on Pi.

Experiment 036 integrates that finding with compile-time architecture
selection. On x86_64, the fused crop records both moments and computes
variance as `max(E[x²] - E[x]², 0)`. On AArch64, the squared-sum field,
accumulation, and one-pass finisher do not exist in the binary; the retained
two-pass Pi arithmetic is unchanged.

The final integrated Dunamis source completed all 4,947 frames and 4,946
timed updates at **64,014.111371 FPS**, versus the matched native reference's
**62,322.801821 FPS**: **+2.713789%**, or `423.936 ns` saved per update. All
4,946 decisions, all 2,043 successful boxes, and every decoded-frame checksum
were exact. This is a retained **x86-only production gain**, not a Pi score.

The final AArch64 compile-out screen was also exact and measured
`5,755.758747` versus `5,736.468773 FPS`, a small `+0.336269%` difference
treated as run noise rather than a Pi optimization claim. Local, Dunamis, and
Pi release tests passed. Full identities and artifacts are recorded in the
Experiment 036 protocol.

## Experiment 028 AoSoA CFFT36 ceiling

Experiment 028 measures a fixed four-lane AArch64 NEON length-36 complex FFT
codelet in the intended array-of-structures-of-arrays layout. The Pi medians
were **700.394 ns forward** and **703.752 ns inverse per batch of four
transforms**.

Charging eight calls for 32 columns, including the padded dummy column needed
to eliminate the 31-column tail, gives:

| Direction | AoSoA codelet, padded 32 columns | Retained GT4×9, 31 columns | Isolated ceiling ratio |
|---|---:|---:|---:|
| Forward | 5,603.152 ns | 12,099.105 ns | **2.159339×** |
| Inverse | 5,630.016 ns | 12,076.210 ns | **2.144969×** |

These are **kernel ceilings, not tracker FPS and not an end-to-end
projection**. The timing includes the codelet's CRT permutations, transpose,
radix stages, and scratch traffic, but excludes any tracker-side conversion
into or out of AoSoA. Wrapping the isolated kernel in layout conversions is
not a retained optimization. The margin instead passes the stop gate for the
next exact experiment: make the surrounding tracker produce, retain, and
consume the whole AoSoA layout so conversion cost is eliminated and fused
work can share the layout.

Experiment 030 confirmed that requirement with a real tracker screen. It
packed all 31 current `Complex32` columns into eight AoSoA batches, ran the
kernel, and unpacked them inside the update timer. Outputs stayed exact, but
throughput regressed from `5,562.626458` to `5,264.722298 FPS`
(`-5.355458643%`), adding `10.172 us/update`. It was stopped after the single
299-update gate. The wrapper is rejected; the row FFT and fused transpose must
produce the column layout directly.

## Experiment 031 AoSoA RFFT60 ceiling

Experiment 031 implements four complete fixed length-60 real FFTs in four
NEON lanes. Its forward call includes even/odd packing, Good-Thomas
permutation and stages, and real-FFT postprocessing. Its inverse includes
Hermitian preprocessing and output permutation/unpacking. No planning,
allocation, or external layout conversion is omitted from the timed kernel.

The Pi correctness gate made 9,728 comparisons against independent RealFFT
and full-Hermitian RustFFT oracles, including dirty scratch, DC/Nyquist,
round-trip, and non-finite checks. The Cortex-A72 timing was:

| Direction | Batch of four | Nine calls / all 36 rows | Experiment 024 context | Contextual ratio |
|---|---:|---:|---:|---:|
| Forward | **993.252 ns** | **8,939.268 ns** | 13,535.793 ns | **1.514195×** |
| Inverse | **996.933 ns** | **8,972.395 ns** | 13,529.328 ns | **1.507884×** |

The Pi stayed at 1.8 GHz, moved from 55.0 to 56.4 °C, and reported no
throttling. Unlike the retained context measurement, the new row values
include the complete RFFT60 around the inner CFFT30. The comparison therefore
clears the preregistered row-kernel stop gate, but remains a **kernel ceiling,
not tracker FPS**.

Dunamis transfer was mixed: the forward kernel was contextually 1.187123×
faster, while inverse latency regressed 9.135895%. Consequently the custom row
path is an AArch64 integration candidate and not a replacement for the native
x86 FFT path. The next experiment must fuse its four-row output through a 4×4
register transpose directly into Experiment 028's padded column layout.

## Experiment 034 whole-layout transform ceiling

Experiment 034 joined the passing row and column kernels without the rejected
Experiment 030 wrapper. It keeps a persistent padded
`[8 column groups][36 rows][4 lanes]` spectrum, fuses row output into 4×4
transposes, processes the padded 32 columns, reverses the layout during the
inverse, and includes gather, scatter, padding, and a production-style
response reduction in the timed work.

The production-relevant Pi build used Rust 1.97.1, one release codegen unit,
no LTO, and no `target-cpu`. Correctness, padding, dirty-scratch, round-trip,
maximum-index, and aggregate-reduction gates passed. Its matched single-core
Pi medians were:

| Complete transform chain | Experiment 034 | Current `Fft2` | Ratio |
|---|---:|---:|---:|
| Forward | `18,683.620 ns` | `28,612.666 ns` | **1.531431×** |
| Inverse plus response reduction | `26,363.651 ns` | `36,069.502 ns` | **1.368153×** |
| Workload-weighted proxy | `51,529.497 ns` | `74,609.247 ns` | **1.447894×** |

The weighted chain removes **30.934168%** of the matched transform latency.
This is the first complete structural layout result, but it remains a
**transform-chain ceiling, not tracker FPS**. Only Experiment 039's normal
tracker updates can establish how much survives pointwise model/filter work
and the surrounding control flow.

The portable implementation regressed against Dunamis's native AVX path
(`0.674270×` weighted throughput), so x86 retains RustFFT. This is an
intentional architecture-specific optimization rather than a global
replacement.

## Experiments 035 and 040 four-core executor

Experiment 035 implemented a caller plus three persistent workers with static
task ownership, affinity, epoch atomics, cache-line-separated completion
state, and no allocation, queue, mutex, parking, thread creation, or join in a
dispatch. Correctness and ownership gates were exact.

Ordinary `SCHED_OTHER` made the Pi result unusable: empty dispatch had a
`15,309.772 ns` median with roughly 19–22 ms outliers, and all real batch
groups regressed. The same executor had only a `219.986 ns` empty median on
Dunamis, identifying Pi scheduler latency rather than worker computation as
the failure.

Experiment 040 reran the exact Pi binary with caller/workers pinned to CPUs
0–3 under bounded `SCHED_FIFO` priority 50, protected by a higher-priority
timeout. The temporary RT bandwidth setting was restored after the run. Empty
dispatch fell to **`288.133 ns`**, and complete static batch groups measured:

| Batch group | Serial | Four-core | Ratio |
|---|---:|---:|---:|
| 8× CFFT36 forward | `6,338.302 ns` | `2,238.495 ns` | **2.831502×** |
| 8× CFFT36 inverse | `6,183.897 ns` | `2,188.565 ns` | **2.825549×** |
| 9× RFFT60 forward | `9,825.189 ns` | `3,272.697 ns` | **3.002169×** |
| 9× RFFT60 inverse | `9,521.441 ns` | `3,124.703 ns` | **3.047150×** |

All dispatch, worker computation, barriers, and waits were timed. These are
**executor/kernel ceilings, not tracker FPS**, and they cannot be multiplied
or added to Experiment 034's ratio. They authorized the later combined
whole-chain integration. The retained Experiment 064/066 runtime superseded
this FIFO design with continuously polling `SCHED_OTHER/0`, nice-0 workers,
so the final production path needs no root, `CAP_SYS_NICE`, FIFO policy, or
RT-runtime change. Its watchdog and safe single-thread fallback requirements
remain.

## Independent Qwen 3.8 Max review

The [`QWEN38_MAX_BL_4X_REVIEW.md`](QWEN38_MAX_BL_4X_REVIEW.md) audit through Bailian
was completed read-only; it ran no benchmark and produced no new profiler
evidence. Its actionable conclusion independently agrees with the measured
roadmap: the failed/localization path is binding, so a success-only shortcut
cannot close 4×, and the best exact path is whole-layout AoSoA integration
with surrounding fusion.

The review's statement that this report was stale described its earlier tree
snapshot. It is obsolete: this local report was updated after that snapshot.
The review remains advisory evidence; the Pi experiments above remain the
source of performance claims.

## Experiment 027 rejected challenge evidence

Experiment 027 reuses the displaced localization spectrum for successful
model training instead of performing the second recrop, preprocessing pass,
and forward FFT. It is deliberately non-exact, remains feature-gated off by
default, and is not part of the preferred exact build.

The 300-frame screen was +20.0447% with excellent early box quality, but the
complete trace showed accumulating drift. The full Pi challenge processed the
unchanged workload—4,947 decoded frames, 4,946 attempted updates, and the
same 2,219-success/2,727-failure split—and measured:

- **7,205.37386514342 FPS** at **138.785304 µs** mean update latency;
- **+8.8330360629%** versus the exact Rust 1.97.1 result;
- **3.1060490713×** the official OpenCV median;
- exact checksums and all 4,946 success/failure decisions.

The reported boxes failed the quality gate:

- center error mean / median / p95 / maximum:
  **2.050657 / 2.236068 / 3.605551 / 13.341664 px**;
- only **48.445246%** of centers were within two pixels;
- IoU mean / median / p05 / minimum:
  **0.893018 / 0.886463 / 0.795511 / 0.560130**.

This is rejected challenge evidence, not a retained result, exact score, or
quantity that may be stacked with Experiment 029. It provides a measured
ceiling for removing the second model-patch path, but its drift confirms that
the current shifted-goal formulation is unsuitable for the exact headline.
Whole-layout AoSoA integration was therefore the priority exact path and was
later completed by the Experiment 064/066 composite.

## Rejected or reverted directions

Negative results remain part of the record:

- Fused preprocessing staging gained 1.673643% but missed its retain gate.
- Cortex-A72/ThinLTO compiler tuning regressed 5.410101% in screening.
- Scalar real-B plus fused A/B/H work regressed 0.155902% full-video.
- Deferred filter/model update policies changed tracking behavior and were
  rejected before Pi scoring.
- Four independent `f64` crop sums gained only 0.138337% full-video and missed
  the retain threshold.
- A normalized-log lookup regressed 1.744877% in the screen.
- A persistent two-worker split of the small fixed FFT batches regressed
  54.213660%; scheduling overhead dominated useful work.
- Four-wide NEON forward-row twiddle arithmetic preserved exact parity but
  improved the 300-frame screen by only 0.130816%, missing its 0.5% gate; no
  full-video run was performed.
- Exact reuse of overlapping model-crop pixels passed exhaustive bit-for-bit
  and AArch64 gates but regressed the 300-frame Pi screen by 0.958959%; the
  required localization-cache stores outweighed the avoided resampling.
- Moving the spatial normalization scale into spectral arithmetic removed
  14,389,920 timed `f32` divisions and gained 4.493523% in the 300-frame
  screen, but only 0.717301% over the complete 4,946-update replay. It missed
  its locked 1.0% full-video retention gate and was reverted.
- FFTW 3.3.11 was slower than retained RustFFT in both complete transform
  layouts. CMSIS-DSP's correct pair-packed CFFT path improved the weighted
  FFT-only proxy by 1.307341× but missed its 1.75× integration gate.
- Applying the Pi's isolated Good-Thomas 4×9 column winner to every fixed
  forward/inverse transform gained 4.998808% in the short screen but regressed
  the complete tracker by 0.353350%. Experiment 025 remains rejected; only
  its context-specific Experiment 026 subset is retained.
- Experiment 027's shifted-goal challenge crossed 3× as a speed diagnostic,
  but failed the complete box-quality gate and remains feature-gated off.
- Experiment 030's exact AoS/AoSoA wrapper integration regressed the short Pi
  tracker screen by 5.355459%; conversion consumed the isolated column-kernel
  win, so no repeat or full replay was run.
- Experiment 033 accumulated log sum and sum-of-squares during crop and
  removed the separate squared-deviation pass. Its exact 300-frame Pi screen
  was +1.973467%, but the exact complete replay reached only
  **6,633.198083 FPS**, **+0.190649%** versus Experiment 029, so it is rejected
  on Pi. A corrected native/native Dunamis full pair was exact and improved
  from **62,322.801821** to **64,130.793833 FPS**, **+2.901012%**. The earlier
  generic-candidate/native-reference x86 screen is invalidated. Experiment
  036 performs the final x86-only production integration and AArch64
  compile-out gate.
- Experiment 032's one-codegen-unit setting regressed the exact Dunamis
  diagnostic by 1.555223%. Only its fully gated Pi/AArch64 result is retained;
  fat LTO was weaker and remains unselected.
- Experiment 038 isolated safely masked Cortex-A72 code generation under Rust
  1.97.1 plus one codegen unit, without LTO. Its one exact Pi screen regressed
  by **7.770725%**, adding `17.226 us` per update, so no complete replay or
  retry was run. Generic AArch64 CPU selection remains intentional.
- Experiment 037 trained architecture-specific LLVM PGO on one complete
  ordinary workload per host. Exact 300-frame screens regressed by
  **0.583267%** on Dunamis and **1.126254%** on Pi, so neither architecture
  received a full replay or retry.
- Experiment 035's ordinary-priority four-core Pi executor was rejected
  because scheduler latency dominated its small batches. Experiment 040's
  distinct bounded real-time runtime passed; that result supersedes the
  scheduling mode, not the missing end-to-end tracker gate.

These failures narrow the next search: global compiler flags,
behavior-changing update schedules, and high-overhead fine-grained FFT
threading are low-priority. Experiment 032 demonstrates that a narrowly
architecture-scoped build setting can still help; it does not reverse the
negative global or x86 flag evidence.

## Accuracy and visual limitation

The retained exact Rust trace matches OpenCV's reported decisions and boxes on
the Pi. This establishes implementation equivalence, not independent ground
truth accuracy. Both trackers enter failure at update frame 2,220 and do not
recover on the recorded Pi trace. Therefore no claim of continuous full-video
object lock is made.

Any future reacquisition work must be evaluated as a separate tracking-quality
change with ground truth, not folded into the OpenCV-equivalence speed score.

## Experiment 064 retained composite and Amdahl decision

Experiment 064 integrated the complete padded whole-layout tracker with:

- the watchdog-safe fixed four-core runtime;
- fused correlated inverse CFFT36 work for the 60×36 path;
- composite crop/preprocessing/forward work; and
- parallel model blend/filter work.

The isolated exact replay measured 11,421.388839 FPS at 87.555026 µs/update,
or 4.923463357× the frozen baseline. It processed all 4,947 frames and all
4,946 attempted updates, including all 2,727 failures, with exact checksums,
decisions, and boxes.

Measured caller-side inverse-response reduction was 8.044877 µs/update,
9.188% of the complete update. Amdahl's law put the idealized result of
parallelizing only that reduction at approximately 5.288×. That figure
remained a projection: floating-point addition is non-associative, so a fixed
cross-core combine would be repeatable without reproducing the original
serial row-major `f64` accumulation. Because the integrated candidate already
had useful margin above 4×, the final reduction stayed serial on the caller.
Parseval remained optional cache/buffer work, not a reduction-equivalence
shortcut.

The source-rate Python/OpenCV soak then processed all 4,947 decoded frames and
4,946 updates at 29.9953 effective FPS. It recorded exact decisions/boxes,
zero copies for the contiguous `VideoCapture` arrays, zero drops, zero
decode-starvation events, zero late deadlines, a live external process
watchdog, deterministic cleanup, unchanged boot/watchdog/RT settings, and
firmware throttle mask `0x0`. Its Python update-call mean/median/p95 was
252.899/227.913/265.441 µs and is intentionally separate from the native
tracker-only score.

## Experiment 066 final production qualification

The final root-governed matrix ran the retained binary without algorithm or
timer-boundary changes:

- one full-video warm-up for OpenCV1 and Rust4;
- five globally alternating measured full-video pairs;
- complete-process CPU0 affinity, with Rust workers self-pinned to CPUs 1–3;
- a 180-second boundary per replay;
- benchmark and video hashes before/throughout the suite;
- literal nine-field comparison for all 4,947 rows in every pair; and
- governor, boot, throttle, watchdog, RT-state, observer, and cleanup gates.

Rust4 measured 11,626.625991 FPS mean and 11,632.121609 FPS median. The
median-FPS run's mean was 85.968840 µs/update. Relative to the frozen baseline
this is 5.014304767×; relative to the faster same-suite OpenCV sample, the
median paired ratio is 4.938477642×. All five exactness comparisons passed.
The Pi reached 67.679 °C without throttling, and the wrapper restored the
original `ondemand` governor.

The current-build Rust1 companion was measured in its own governed
one-warm-up/five-pair suite: 7,073.822948 FPS mean, 7,071.160241 FPS median,
3.048193072× the frozen baseline, and exact in all five pairs. It is a
companion metric only; Rust4 is the production result.

The post-timing comparison video was rendered from measured pair 1 after all
scoring ended. The renderer required literal-exact traces before drawing,
never executed a tracker, and decoded all 4,947 output frames during
validation.

## Python-embeddable delivery

`mosse-pi 0.1.0.dev5` retains the stable C ABI and the exact Rust tracker
logic. Its NumPy API accepts `uint8` H×W×3 BGR arrays, keeps supported
contiguous/positive-row-stride layouts zero-copy, copies unsupported layouts
safely, releases the GIL during native calls, serializes handle mutation, and
provides deterministic close/context-manager behavior.

Both architecture downloads contain the wheel, raw library, C header,
install/reproduction/smoke documentation, `examples/numpy_api.py`,
`examples/video_capture.py`, and `examples/measure_wrapper_latency.py`.
`auto`, `single`, and `multicore` share one API. The AArch64 package embeds
the exact final-qualified library; multicore requires the internal 60×36
window and CPU0 launch topology. Unsupported size/topology makes `auto`
select single-thread and explicit multicore fail safely. The x86_64 package
deliberately provides the portable single-thread backend. Fresh extracted
archives were installed and runtime-smoked on both target architectures.

## Optional follow-on optimization work

The 4× objective is complete. Further work is optional and must preserve the
same exact workload and public API:

1. Measure row-partitioned crop/preprocessing and bin-partitioned correlation
   only if a production deployment needs more margin. Treat any gain as new
   measured evidence, not the earlier Amdahl projection.
2. Consider preprocessing→row-kernel and correlation→inverse-column fusion
   behind the stable native/Python ABI.
3. Keep the final row-major `f64` inverse-response reduction serial unless
   phase timings prove it necessary; any parallel reduction requires
   near-threshold PSR stress tests plus the full trace.
4. Keep Parseval as possible buffer/cache-traffic work, not as an exactness
   shortcut.
5. Preserve the architecture split: the final composite is AArch64-specific,
   while Dunamis retains its independently faster x86 paths.
6. Keep Experiment 027 rejected unless a new quality protocol with ground
   truth explicitly authorizes behavior change.

The derivation, evidence, classifications, experiment order, and stop rules
are recorded in
[`FOUR_X_RESEARCH_ROADMAP.md`](FOUR_X_RESEARCH_ROADMAP.md).

Every proposal must preserve the normal update workload. No score may omit
failed updates, model work, packing/layout costs, or any attempted frame.

## Artifacts

- [`FINAL_SUMMARY.md`](FINAL_SUMMARY.md)
- [`BASELINE_REPORT.md`](BASELINE_REPORT.md)
- [`PROFILE_REPORT.md`](PROFILE_REPORT.md)
- [`FOUR_X_RESEARCH_ROADMAP.md`](FOUR_X_RESEARCH_ROADMAP.md)
- [`OPTIMIZATION_LOG.md`](OPTIMIZATION_LOG.md)
- [`experiments/016-neon-fixed-crop-gray/protocol.md`](experiments/016-neon-fixed-crop-gray/protocol.md)
- [`experiments/026-context-specific-column-plans/protocol.md`](experiments/026-context-specific-column-plans/protocol.md)
- [`experiments/027-shifted-goal-model-update/protocol.md`](experiments/027-shifted-goal-model-update/protocol.md)
- [`experiments/028-aosoa-cfft36/protocol.md`](experiments/028-aosoa-cfft36/protocol.md)
- [`experiments/029-rust-1.97-compiler/protocol.md`](experiments/029-rust-1.97-compiler/protocol.md)
- [`experiments/030-aosoa-column-integration/protocol.md`](experiments/030-aosoa-column-integration/protocol.md)
- [`experiments/031-aosoa-rfft60/protocol.md`](experiments/031-aosoa-rfft60/protocol.md)
- [`experiments/032-codegen-lto/protocol.md`](experiments/032-codegen-lto/protocol.md)
- [`experiments/033-onepass-log-moments/protocol.md`](experiments/033-onepass-log-moments/protocol.md)
- [`experiments/034-whole-layout-fft2/protocol.md`](experiments/034-whole-layout-fft2/protocol.md)
- [`experiments/035-persistent-four-core-executor/protocol.md`](experiments/035-persistent-four-core-executor/protocol.md)
- [`experiments/036-x86-onepass-log-moments/protocol.md`](experiments/036-x86-onepass-log-moments/protocol.md)
- [`experiments/037-rust-pgo/protocol.md`](experiments/037-rust-pgo/protocol.md)
- [`experiments/038-cortex-a72-codegen/protocol.md`](experiments/038-cortex-a72-codegen/protocol.md)
- [`experiments/039-whole-layout-tracker-integration/protocol.md`](experiments/039-whole-layout-tracker-integration/protocol.md)
- [`experiments/040-realtime-four-core-executor/protocol.md`](experiments/040-realtime-four-core-executor/protocol.md)
- [`experiments/064-composite-preprocess-forward/protocol.md`](experiments/064-composite-preprocess-forward/protocol.md)
- [`experiments/064-composite-preprocess-forward/results/pi4/paced-live-python-cpu0-v2/summary.json`](experiments/064-composite-preprocess-forward/results/pi4/paced-live-python-cpu0-v2/summary.json)
- [`experiments/066-final-composite-qualification/protocol.md`](experiments/066-final-composite-qualification/protocol.md)
- [`experiments/066-final-composite-qualification/results/pi4/four-core-performance-v1/aggregate.md`](experiments/066-final-composite-qualification/results/pi4/four-core-performance-v1/aggregate.md)
- [`experiments/066-final-composite-qualification/results/pi4/single-thread-companion-v1/aggregate.md`](experiments/066-final-composite-qualification/results/pi4/single-thread-companion-v1/aggregate.md)
- [`experiments/066-final-composite-qualification/results/pi4/final-exact-annotated-video-v1/opencv-rust-exact-side-by-side-h264.mp4`](experiments/066-final-composite-qualification/results/pi4/final-exact-annotated-video-v1/opencv-rust-exact-side-by-side-h264.mp4)
- [`artifacts/python-preview/160c68016303`](artifacts/python-preview/160c68016303)
- [`QWEN38_MAX_BL_4X_REVIEW.md`](QWEN38_MAX_BL_4X_REVIEW.md)
- [`QWEN38_MAX_BL_REVIEW.md`](QWEN38_MAX_BL_REVIEW.md) (earlier audit)
- [`results/pi4-scoring/exp016-full-9883f8f/manifest.json`](results/pi4-scoring/exp016-full-9883f8f/manifest.json)
- [`README.md`](README.md)

The complete Experiment 066 four-core and single-thread suite evidence,
governor-wrapper captures, manifests, aggregate reports, checksums, package
bundles, and compact annotated-video delivery are now in the tracked evidence
set. The larger intermediate render remains local and is identified by hash
in the delivery manifest.

Final claim: **11,632.121609 FPS median tracker-only, 5.014304767× the frozen
one-thread OpenCV baseline, with exact full-workload parity.** The
same-suite paired median is **4.938477642×** and is reported alongside it.
