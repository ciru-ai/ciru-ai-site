#include "mosse/benchmark_config.hpp"
#include "mosse/frame_checksum.hpp"

#include <chrono>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>

#include <opencv2/core/mat.hpp>

namespace {

void require(const bool condition, const std::string &message) {
  if (!condition) {
    throw std::runtime_error(message);
  }
}

void test_checksums() {
  cv::Mat frame(2, 3, CV_8UC3);
  for (int row = 0; row < frame.rows; ++row) {
    for (int column = 0; column < frame.cols; ++column) {
      cv::Vec3b &pixel = frame.at<cv::Vec3b>(row, column);
      pixel[0] = static_cast<std::uint8_t>(row * 10 + column);
      pixel[1] = static_cast<std::uint8_t>(row * 10 + column + 1);
      pixel[2] = static_cast<std::uint8_t>(row * 10 + column + 2);
    }
  }

  const std::uint64_t original = mosse::frame_checksum_fnv1a64(frame);
  const std::uint64_t clone = mosse::frame_checksum_fnv1a64(frame.clone());
  require(original == clone, "Cloned frame checksum must match");
  require(mosse::checksum_hex(original).size() == 16U,
          "Checksum must render as sixteen hexadecimal digits");

  frame.at<cv::Vec3b>(1, 2)[0] ^= 0xffU;
  const std::uint64_t changed = mosse::frame_checksum_fnv1a64(frame);
  require(original != changed, "Pixel change must alter checksum");

  mosse::FrameSequenceChecksum first_order;
  first_order.add(0, original);
  first_order.add(1, changed);
  mosse::FrameSequenceChecksum second_order;
  second_order.add(0, changed);
  second_order.add(1, original);
  require(first_order.value() != second_order.value(),
          "Sequence checksum must preserve frame order");
}

void test_config() {
  const auto unique_suffix =
      std::chrono::steady_clock::now().time_since_epoch().count();
  const std::filesystem::path directory =
      std::filesystem::temp_directory_path() /
      ("mosse_core_test_" + std::to_string(unique_suffix));
  const std::filesystem::path video = directory / "fixture.mp4";
  const std::filesystem::path roi = directory / "roi.json";
  const std::filesystem::path config = directory / "benchmark.yml";

  std::filesystem::create_directory(directory);
  {
    std::ofstream video_file(video, std::ios::binary);
    video_file << "test fixture";
  }
  {
    std::ofstream roi_file(roi);
    roi_file << "{\n"
             << "  \"frame_index\": 0,\n"
             << "  \"x\": 2,\n"
             << "  \"y\": 3,\n"
             << "  \"width\": 20,\n"
             << "  \"height\": 10\n"
             << "}\n";
  }
  {
    std::ofstream config_file(config);
    config_file
        << "%YAML:1.0\n"
        << "video:\n"
        << "  path: fixture.mp4\n"
        << "  sha256: "
           "\"0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef\"\n"
        << "  expected_width: 100\n"
        << "  expected_height: 80\n"
        << "  expected_decoded_frames: 25\n"
        << "roi_file: roi.json\n"
        << "output:\n"
        << "  frames_csv: output/frames.csv\n"
        << "  summary_json: output/summary.json\n"
        << "benchmark:\n"
        << "  max_frames: 25\n"
        << "  opencv_threads: 4\n"
        << "  frame_checksums: 1\n";
  }

  try {
    const mosse::BenchmarkConfig loaded = mosse::load_benchmark_config(config);
    require(loaded.video_path == std::filesystem::absolute(video),
            "Relative video path must resolve from config directory");
    require(loaded.initial_roi.x == 2.0, "ROI x must load");
    require(loaded.initial_roi.y == 3.0, "ROI y must load");
    require(loaded.initial_roi.width == 20.0, "ROI width must load");
    require(loaded.initial_roi.height == 10.0, "ROI height must load");
    require(loaded.max_frames == 25U, "max_frames must load");
    require(loaded.opencv_threads == 4, "opencv_threads must load");
    require(loaded.expected_width == 100, "expected_width must load");
    require(loaded.expected_height == 80, "expected_height must load");
    require(loaded.expected_decoded_frames == 25U,
            "expected_decoded_frames must load");
    require(loaded.compute_frame_checksums, "frame_checksums must load");
    mosse::validate_roi_for_frame(loaded.initial_roi, cv::Size(100, 100));

    bool rejected = false;
    try {
      mosse::validate_roi_for_frame(loaded.initial_roi, cv::Size(10, 10));
    } catch (const std::runtime_error &) {
      rejected = true;
    }
    require(rejected, "Out-of-frame ROI must be rejected");
  } catch (...) {
    std::filesystem::remove(config);
    std::filesystem::remove(roi);
    std::filesystem::remove(video);
    std::filesystem::remove(directory);
    throw;
  }

  std::filesystem::remove(config);
  std::filesystem::remove(roi);
  std::filesystem::remove(video);
  std::filesystem::remove(directory);
}

} // namespace

int main() {
  try {
    test_checksums();
    test_config();
    std::cout << "mosse_core_tests passed\n";
    return 0;
  } catch (const std::exception &error) {
    std::cerr << "mosse_core_tests failed: " << error.what() << '\n';
    return 1;
  }
}
