#include "mosse/rust_ffi.h"
#include "mosse/tracker_backend.hpp"

#include <cmath>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>

#include <opencv2/core/mat.hpp>

namespace {

static_assert(sizeof(MosseMode) == sizeof(std::int32_t));
static_assert(sizeof(MosseBackendStatus) == sizeof(std::int32_t));
static_assert(MOSSE_ABI_VERSION == UINT32_C(1));

void require(const bool condition, const std::string &message) {
  if (!condition) {
    throw std::runtime_error(message);
  }
}

void test_rust_backend_lifecycle() {
  std::unique_ptr<mosse::TrackerBackend> backend =
      mosse::create_tracker_backend("rust");
  require(backend->name() == "rust_mosse_scalar",
          "Rust factory returned the wrong backend");

  const cv::Mat frame(32, 32, CV_8UC3, cv::Scalar(127, 127, 127));
  const cv::Rect2d initial_roi(8.0, 8.0, 16.0, 16.0);
  require(backend->initialize(frame, initial_roi),
          "Rust backend initialization failed");

  const mosse::TrackerUpdate update = backend->update(frame);
  require(!update.success,
          "A constant image should fail the default Rust PSR threshold");
  require(update.bbox == initial_roi,
          "A failed Rust update must preserve the caller-visible ROI");
  require(std::isfinite(update.bbox.x) && std::isfinite(update.bbox.y) &&
              update.bbox.width > 0.0 && update.bbox.height > 0.0,
          "Rust backend returned an invalid failure bounding box");

  backend.reset();
}

void test_rust_backend_rejects_non_bgr_frame() {
  std::unique_ptr<mosse::TrackerBackend> backend =
      mosse::create_tracker_backend("rust_mosse");
  const cv::Mat grayscale(32, 32, CV_8UC1, cv::Scalar(127));

  bool rejected = false;
  try {
    static_cast<void>(
        backend->initialize(grayscale, cv::Rect2d(8.0, 8.0, 16.0, 16.0)));
  } catch (const std::runtime_error &) {
    rejected = true;
  }
  require(rejected, "Rust backend must reject non-BGR frames");
}

void test_explicit_mode_c_abi() {
  MosseHandle *handle = nullptr;
  require(mosse_create_with_mode(nullptr, MOSSE_MODE_SINGLE, &handle) ==
              MOSSE_STATUS_OK,
          "Explicit single-mode creation failed");
  require(handle != nullptr, "Explicit mode creation returned a null handle");

  MosseBackendStatus backend_status = -1;
  require(mosse_get_backend_status(handle, &backend_status) == MOSSE_STATUS_OK,
          "Backend status query before initialization failed");
  require(backend_status == MOSSE_BACKEND_UNINITIALIZED,
          "New tracker did not report the uninitialized backend");

  const cv::Mat frame(32, 32, CV_8UC3, cv::Scalar(127, 127, 127));
  const MosseRect initial_roi{8.0, 8.0, 16.0, 16.0};
  require(mosse_init(handle, frame.data, static_cast<std::size_t>(frame.cols),
                     static_cast<std::size_t>(frame.rows), frame.step[0],
                     initial_roi) == MOSSE_STATUS_OK,
          "Explicit mode initialization failed");
  require(mosse_get_backend_status(handle, &backend_status) == MOSSE_STATUS_OK,
          "Backend status query after initialization failed");
  require(backend_status == MOSSE_BACKEND_GENERIC_SINGLE,
          "Portable test geometry did not report the generic single backend");
  require(mosse_destroy(handle) == MOSSE_STATUS_OK,
          "Explicit mode tracker destruction failed");

  require(mosse_create_with_mode(nullptr, 99, &handle) ==
              MOSSE_STATUS_INVALID_MODE,
          "Invalid execution mode was not rejected");
  require(handle == nullptr,
          "Invalid execution mode did not leave a null output handle");
}

void test_abi_version() {
  require(mosse_abi_version() == MOSSE_ABI_VERSION,
          "Rust library and C header ABI versions differ");
}

} // namespace

int main() {
  try {
    test_abi_version();
    test_rust_backend_lifecycle();
    test_rust_backend_rejects_non_bgr_frame();
    test_explicit_mode_c_abi();
    std::cout << "mosse_rust_backend_tests passed\n";
    return 0;
  } catch (const std::exception &error) {
    std::cerr << "mosse_rust_backend_tests failed: " << error.what() << '\n';
    return 1;
  }
}
