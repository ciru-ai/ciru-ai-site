//! Experiment 028: four independent length-36 complex FFTs in four SIMD lanes.
//!
//! This crate is deliberately isolated from the tracker. `Batch4` is a
//! split-complex AoSoA: at each logical FFT index, the four `f32` values are
//! four independent transforms. On AArch64 those four values are one NEON
//! register. Other targets use the same four-lane arithmetic through portable
//! scalar source, which is useful as a correctness oracle and transfer screen.

pub const FFT_LEN: usize = 36;
pub const LANES: usize = 4;

/// Four independent complex transforms in logical FFT order.
#[derive(Clone, Debug, PartialEq)]
#[repr(C)]
pub struct Batch4 {
    pub re: [[f32; LANES]; FFT_LEN],
    pub im: [[f32; LANES]; FFT_LEN],
}

impl Default for Batch4 {
    fn default() -> Self {
        Self {
            re: [[0.0; LANES]; FFT_LEN],
            im: [[0.0; LANES]; FFT_LEN],
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Direction {
    Forward,
    Inverse,
}

/// A fixed-size kernel with all work memory owned persistently.
#[derive(Clone, Debug, Default)]
#[repr(C)]
pub struct Kernel36x4 {
    scratch_a: Batch4,
    scratch_b: Batch4,
}

impl Kernel36x4 {
    pub fn new() -> Self {
        Self::default()
    }

    /// Process four forward length-36 FFTs. The transform is unnormalized.
    #[inline]
    pub fn process_forward(&mut self, buffer: &mut Batch4) {
        self.process_impl::<false>(buffer);
    }

    /// Process four inverse length-36 FFTs. The transform is unnormalized.
    #[inline]
    pub fn process_inverse(&mut self, buffer: &mut Batch4) {
        self.process_impl::<true>(buffer);
    }

    /// Correlate four sample/filter column pairs and immediately process their
    /// unnormalized inverse transforms.
    ///
    /// Correlation uses the established non-FMA operation order
    /// `sample * conj(filter)`. When `clear_padding_lane` is true, lane three
    /// is replaced with positive zero before any inverse arithmetic, matching
    /// the fixed 32-column layout's final three-valid-lane batch.
    ///
    /// Unlike a standalone correlation followed by [`Self::process_inverse`],
    /// this path never materializes the logical-order response and never
    /// writes or reads `scratch_a`. Radix-4 outputs are written directly in
    /// the transposed layout consumed by the existing radix-9 stage.
    #[inline]
    pub fn process_correlated_inverse(
        &mut self,
        sample: &Batch4,
        filter: &Batch4,
        output: &mut Batch4,
        clear_padding_lane: bool,
    ) {
        if clear_padding_lane {
            self.process_correlated_inverse_impl::<true>(sample, filter, output);
        } else {
            self.process_correlated_inverse_impl::<false>(sample, filter, output);
        }
    }

    #[inline]
    pub fn process(&mut self, buffer: &mut Batch4, direction: Direction) {
        match direction {
            Direction::Forward => self.process_forward(buffer),
            Direction::Inverse => self.process_inverse(buffer),
        }
    }

    /// Poison both persistent work areas. Validation uses this to prove that
    /// every value read by a transform was first overwritten by that call.
    pub fn poison_scratch(&mut self, salt: u32) {
        for i in 0..FFT_LEN {
            for lane in 0..LANES {
                let payload = ((i as u32 * 17 + lane as u32 * 29 + salt) & 0x003f_ffff) | 1;
                let nan = f32::from_bits(0x7fc0_0000 | payload);
                self.scratch_a.re[i][lane] = nan;
                self.scratch_a.im[i][lane] = nan;
                self.scratch_b.re[i][lane] = nan;
                self.scratch_b.im[i][lane] = nan;
            }
        }
    }

    pub const fn backend_name() -> &'static str {
        #[cfg(target_arch = "aarch64")]
        {
            "aarch64-neon"
        }
        #[cfg(not(target_arch = "aarch64"))]
        {
            "portable-scalar-source"
        }
    }

    #[inline(always)]
    fn process_impl<const INVERSE: bool>(&mut self, buffer: &mut Batch4) {
        // Good-Thomas 4x9 input CRT permutation. Every scratch_a element is
        // overwritten before any arithmetic can observe prior scratch state.
        for (dst, &src) in INPUT_MAP.iter().enumerate() {
            // SAFETY: both maps are const-checked permutations of 0..FFT_LEN,
            // and enumerate yields dst in that same range.
            unsafe {
                *self.scratch_a.re.get_unchecked_mut(dst) = *buffer.re.get_unchecked(src);
                *self.scratch_a.im.get_unchecked_mut(dst) = *buffer.im.get_unchecked(src);
            }
        }

        // Nine independent radix-4 transforms.
        for row in 0..9 {
            radix4_at::<INVERSE>(&mut self.scratch_a, row * 4);
        }

        // 9x4 -> 4x9 transpose. Every scratch_b element is overwritten.
        for y in 0..9 {
            for x in 0..4 {
                let src = y * 4 + x;
                let dst = x * 9 + y;
                self.scratch_b.re[dst] = self.scratch_a.re[src];
                self.scratch_b.im[dst] = self.scratch_a.im[src];
            }
        }

        // Four fixed radix-9 transforms, each expressed as 3x3.
        for column in 0..4 {
            radix9_at::<INVERSE>(&mut self.scratch_b, column * 9);
        }

        // Good-Thomas output CRT permutation back to logical frequency order.
        for (src, &dst) in OUTPUT_MAP.iter().enumerate() {
            // SAFETY: both maps are const-checked permutations of 0..FFT_LEN,
            // and enumerate yields src in that same range.
            unsafe {
                *buffer.re.get_unchecked_mut(dst) = *self.scratch_b.re.get_unchecked(src);
                *buffer.im.get_unchecked_mut(dst) = *self.scratch_b.im.get_unchecked(src);
            }
        }
    }

    #[inline(always)]
    fn process_correlated_inverse_impl<const CLEAR_PADDING_LANE: bool>(
        &mut self,
        sample: &Batch4,
        filter: &Batch4,
        output: &mut Batch4,
    ) {
        // Fuse the logical-order correlation, Good-Thomas input gather,
        // inverse radix-4 stage, and 9x4 -> 4x9 transpose. INPUT_MAP is a
        // compile-time-checked permutation, and every scratch_b element is
        // overwritten before the radix-9 stage observes it.
        for row in 0..9 {
            let base = row * 4;
            let mut inputs = [
                CReg::load_correlated(sample, filter, INPUT_MAP[base]),
                CReg::load_correlated(sample, filter, INPUT_MAP[base + 1]),
                CReg::load_correlated(sample, filter, INPUT_MAP[base + 2]),
                CReg::load_correlated(sample, filter, INPUT_MAP[base + 3]),
            ];

            if CLEAR_PADDING_LANE {
                for value in &mut inputs {
                    value.clear_padding_lane();
                }
            }

            let transformed = radix4::<true>(inputs[0], inputs[1], inputs[2], inputs[3]);
            for (column, value) in transformed.into_iter().enumerate() {
                value.store(&mut self.scratch_b, column * 9 + row);
            }
        }

        // Reuse the established radix-9 arithmetic and output permutation.
        for column in 0..4 {
            radix9_at::<true>(&mut self.scratch_b, column * 9);
        }
        for (src, &dst) in OUTPUT_MAP.iter().enumerate() {
            // SAFETY: OUTPUT_MAP is const-checked as a permutation of
            // 0..FFT_LEN and enumerate bounds `src` to the same range.
            unsafe {
                *output.re.get_unchecked_mut(dst) = *self.scratch_b.re.get_unchecked(src);
                *output.im.get_unchecked_mut(dst) = *self.scratch_b.im.get_unchecked(src);
            }
        }
    }
}

const fn make_input_map() -> [usize; FFT_LEN] {
    let mut map = [0; FFT_LEN];
    let mut i = 0;
    while i < FFT_LEN {
        let x = i % 4;
        let y = i / 4;
        map[i] = (x * 9 + y * 4) % FFT_LEN;
        i += 1;
    }
    map
}

const fn make_output_map() -> [usize; FFT_LEN] {
    let mut map = [0; FFT_LEN];
    let mut i = 0;
    while i < FFT_LEN {
        let y = i % 9;
        let x = i / 9;
        // inv(9 mod 4) = 1, inv(4 mod 9) = 7.
        map[i] = (x * 9 + y * 4 * 7) % FFT_LEN;
        i += 1;
    }
    map
}

pub const INPUT_MAP: [usize; FFT_LEN] = make_input_map();
pub const OUTPUT_MAP: [usize; FFT_LEN] = make_output_map();

const fn is_permutation(map: &[usize; FFT_LEN]) -> bool {
    let mut seen = [false; FFT_LEN];
    let mut i = 0;
    while i < FFT_LEN {
        let value = map[i];
        if value >= FFT_LEN || seen[value] {
            return false;
        }
        seen[value] = true;
        i += 1;
    }
    true
}

const _: () = {
    assert!(is_permutation(&INPUT_MAP));
    assert!(is_permutation(&OUTPUT_MAP));
};

#[derive(Clone, Copy)]
struct CReg {
    re: lane::Reg,
    im: lane::Reg,
}

impl CReg {
    #[inline(always)]
    fn load(batch: &Batch4, index: usize) -> Self {
        Self {
            re: lane::load(&batch.re[index]),
            im: lane::load(&batch.im[index]),
        }
    }

    #[inline(always)]
    fn store(self, batch: &mut Batch4, index: usize) {
        lane::store(self.re, &mut batch.re[index]);
        lane::store(self.im, &mut batch.im[index]);
    }

    #[inline(always)]
    fn load_correlated(sample: &Batch4, filter: &Batch4, index: usize) -> Self {
        let sample_re = lane::load(&sample.re[index]);
        let sample_im = lane::load(&sample.im[index]);
        let filter_re = lane::load(&filter.re[index]);
        let filter_im = lane::neg(lane::load(&filter.im[index]));
        Self {
            re: lane::sub(
                lane::mul(sample_re, filter_re),
                lane::mul(sample_im, filter_im),
            ),
            im: lane::add(
                lane::mul(sample_re, filter_im),
                lane::mul(sample_im, filter_re),
            ),
        }
    }

    #[inline(always)]
    fn clear_padding_lane(&mut self) {
        self.re = lane::clear_padding_lane(self.re);
        self.im = lane::clear_padding_lane(self.im);
    }

    #[inline(always)]
    fn add(self, rhs: Self) -> Self {
        Self {
            re: lane::add(self.re, rhs.re),
            im: lane::add(self.im, rhs.im),
        }
    }

    #[inline(always)]
    fn sub(self, rhs: Self) -> Self {
        Self {
            re: lane::sub(self.re, rhs.re),
            im: lane::sub(self.im, rhs.im),
        }
    }

    #[inline(always)]
    fn mul_twiddle<const INVERSE: bool>(self, cosine: f32, sine_magnitude: f32) -> Self {
        let sine = if INVERSE {
            sine_magnitude
        } else {
            -sine_magnitude
        };
        Self {
            re: lane::mul_add(lane::mul_scalar(self.re, cosine), self.im, -sine),
            im: lane::mul_add(lane::mul_scalar(self.im, cosine), self.re, sine),
        }
    }
}

#[inline(always)]
fn radix3<const INVERSE: bool>(x0: CReg, x1: CReg, x2: CReg) -> [CReg; 3] {
    const HALF: f32 = 0.5;
    const SQRT_3_OVER_2: f32 = 0.866_025_4;

    let sum12 = x1.add(x2);
    let diff12 = x1.sub(x2);
    let y0 = x0.add(sum12);
    let base = CReg {
        re: lane::mul_add(x0.re, sum12.re, -HALF),
        im: lane::mul_add(x0.im, sum12.im, -HALF),
    };
    let cross_re = lane::mul_scalar(diff12.im, SQRT_3_OVER_2);
    let cross_im = lane::mul_scalar(diff12.re, SQRT_3_OVER_2);

    let (y1, y2) = if INVERSE {
        (
            CReg {
                re: lane::sub(base.re, cross_re),
                im: lane::add(base.im, cross_im),
            },
            CReg {
                re: lane::add(base.re, cross_re),
                im: lane::sub(base.im, cross_im),
            },
        )
    } else {
        (
            CReg {
                re: lane::add(base.re, cross_re),
                im: lane::sub(base.im, cross_im),
            },
            CReg {
                re: lane::sub(base.re, cross_re),
                im: lane::add(base.im, cross_im),
            },
        )
    };

    [y0, y1, y2]
}

#[inline(always)]
fn radix4_at<const INVERSE: bool>(batch: &mut Batch4, base: usize) {
    let x0 = CReg::load(batch, base);
    let x1 = CReg::load(batch, base + 1);
    let x2 = CReg::load(batch, base + 2);
    let x3 = CReg::load(batch, base + 3);

    let [y0, y1, y2, y3] = radix4::<INVERSE>(x0, x1, x2, x3);

    y0.store(batch, base);
    y1.store(batch, base + 1);
    y2.store(batch, base + 2);
    y3.store(batch, base + 3);
}

#[inline(always)]
fn radix4<const INVERSE: bool>(x0: CReg, x1: CReg, x2: CReg, x3: CReg) -> [CReg; 4] {
    let sum02 = x0.add(x2);
    let diff02 = x0.sub(x2);
    let sum13 = x1.add(x3);
    let diff13 = x1.sub(x3);

    let y0 = sum02.add(sum13);
    let y2 = sum02.sub(sum13);
    let (y1, y3) = if INVERSE {
        (
            CReg {
                re: lane::sub(diff02.re, diff13.im),
                im: lane::add(diff02.im, diff13.re),
            },
            CReg {
                re: lane::add(diff02.re, diff13.im),
                im: lane::sub(diff02.im, diff13.re),
            },
        )
    } else {
        (
            CReg {
                re: lane::add(diff02.re, diff13.im),
                im: lane::sub(diff02.im, diff13.re),
            },
            CReg {
                re: lane::sub(diff02.re, diff13.im),
                im: lane::add(diff02.im, diff13.re),
            },
        )
    };

    [y0, y1, y2, y3]
}

#[inline(always)]
fn radix9_at<const INVERSE: bool>(batch: &mut Batch4, base: usize) {
    // DIT 3x3 factorization. With n = n1 + 3*n2 and k = k2 + 3*k1:
    // first transform n2, multiply W9^(n1*k2), then transform n1.
    let x0 = CReg::load(batch, base);
    let x1 = CReg::load(batch, base + 1);
    let x2 = CReg::load(batch, base + 2);
    let x3 = CReg::load(batch, base + 3);
    let x4 = CReg::load(batch, base + 4);
    let x5 = CReg::load(batch, base + 5);
    let x6 = CReg::load(batch, base + 6);
    let x7 = CReg::load(batch, base + 7);
    let x8 = CReg::load(batch, base + 8);

    let a0 = radix3::<INVERSE>(x0, x3, x6);
    let a1 = radix3::<INVERSE>(x1, x4, x7);
    let a2 = radix3::<INVERSE>(x2, x5, x8);

    const COS_2PI_9: f32 = 0.766_044_44;
    const SIN_2PI_9: f32 = 0.642_787_64;
    const COS_4PI_9: f32 = 0.173_648_18;
    const SIN_4PI_9: f32 = 0.984_807_7;
    const COS_8PI_9: f32 = -0.939_692_6;
    const SIN_8PI_9: f32 = 0.342_020_15;

    let b00 = a0[0];
    let b10 = a1[0];
    let b20 = a2[0];

    let b01 = a0[1];
    let b11 = a1[1].mul_twiddle::<INVERSE>(COS_2PI_9, SIN_2PI_9);
    let b21 = a2[1].mul_twiddle::<INVERSE>(COS_4PI_9, SIN_4PI_9);

    let b02 = a0[2];
    let b12 = a1[2].mul_twiddle::<INVERSE>(COS_4PI_9, SIN_4PI_9);
    let b22 = a2[2].mul_twiddle::<INVERSE>(COS_8PI_9, SIN_8PI_9);

    let c0 = radix3::<INVERSE>(b00, b10, b20);
    let c1 = radix3::<INVERSE>(b01, b11, b21);
    let c2 = radix3::<INVERSE>(b02, b12, b22);

    // c[k2][k1] belongs at k2 + 3*k1.
    c0[0].store(batch, base);
    c1[0].store(batch, base + 1);
    c2[0].store(batch, base + 2);
    c0[1].store(batch, base + 3);
    c1[1].store(batch, base + 4);
    c2[1].store(batch, base + 5);
    c0[2].store(batch, base + 6);
    c1[2].store(batch, base + 7);
    c2[2].store(batch, base + 8);
}

/// Stable symbols used only to make cross-target assembly inspection direct.
///
/// # Safety
///
/// Both pointers must be non-null, aligned, uniquely borrowed for the call,
/// and point to initialized values of the corresponding Rust types.
#[no_mangle]
pub unsafe extern "C" fn exp028_aosoa_cfft36_forward(kernel: *mut Kernel36x4, batch: *mut Batch4) {
    (*kernel).process_forward(&mut *batch);
}

/// Stable inverse symbol for cross-target assembly inspection.
///
/// # Safety
///
/// Both pointers must be non-null, aligned, uniquely borrowed for the call,
/// and point to initialized values of the corresponding Rust types.
#[no_mangle]
pub unsafe extern "C" fn exp028_aosoa_cfft36_inverse(kernel: *mut Kernel36x4, batch: *mut Batch4) {
    (*kernel).process_inverse(&mut *batch);
}

#[cfg(target_arch = "aarch64")]
mod lane {
    use core::arch::aarch64::{
        float32x4_t, vaddq_f32, vdupq_n_f32, vfmaq_n_f32, vld1q_f32, vmulq_f32, vnegq_f32,
        vsetq_lane_f32, vst1q_f32, vsubq_f32,
    };

    pub type Reg = float32x4_t;

    #[inline(always)]
    pub fn load(value: &[f32; 4]) -> Reg {
        unsafe { vld1q_f32(value.as_ptr()) }
    }

    #[inline(always)]
    pub fn store(value: Reg, target: &mut [f32; 4]) {
        unsafe { vst1q_f32(target.as_mut_ptr(), value) }
    }

    #[inline(always)]
    pub fn add(lhs: Reg, rhs: Reg) -> Reg {
        unsafe { vaddq_f32(lhs, rhs) }
    }

    #[inline(always)]
    pub fn sub(lhs: Reg, rhs: Reg) -> Reg {
        unsafe { vsubq_f32(lhs, rhs) }
    }

    #[inline(always)]
    pub fn mul(lhs: Reg, rhs: Reg) -> Reg {
        unsafe { vmulq_f32(lhs, rhs) }
    }

    #[inline(always)]
    pub fn neg(value: Reg) -> Reg {
        unsafe { vnegq_f32(value) }
    }

    #[inline(always)]
    pub fn clear_padding_lane(value: Reg) -> Reg {
        unsafe { vsetq_lane_f32(0.0, value, 3) }
    }

    #[inline(always)]
    pub fn mul_scalar(lhs: Reg, rhs: f32) -> Reg {
        unsafe { vmulq_f32(lhs, vdupq_n_f32(rhs)) }
    }

    #[inline(always)]
    pub fn mul_add(accumulator: Reg, multiplicand: Reg, scalar: f32) -> Reg {
        unsafe { vfmaq_n_f32(accumulator, multiplicand, scalar) }
    }
}

#[cfg(not(target_arch = "aarch64"))]
mod lane {
    pub type Reg = [f32; 4];

    #[inline(always)]
    pub fn load(value: &[f32; 4]) -> Reg {
        *value
    }

    #[inline(always)]
    pub fn store(value: Reg, target: &mut [f32; 4]) {
        *target = value;
    }

    #[inline(always)]
    pub fn add(lhs: Reg, rhs: Reg) -> Reg {
        [
            lhs[0] + rhs[0],
            lhs[1] + rhs[1],
            lhs[2] + rhs[2],
            lhs[3] + rhs[3],
        ]
    }

    #[inline(always)]
    pub fn sub(lhs: Reg, rhs: Reg) -> Reg {
        [
            lhs[0] - rhs[0],
            lhs[1] - rhs[1],
            lhs[2] - rhs[2],
            lhs[3] - rhs[3],
        ]
    }

    #[inline(always)]
    pub fn mul(lhs: Reg, rhs: Reg) -> Reg {
        [
            lhs[0] * rhs[0],
            lhs[1] * rhs[1],
            lhs[2] * rhs[2],
            lhs[3] * rhs[3],
        ]
    }

    #[inline(always)]
    pub fn neg(value: Reg) -> Reg {
        [-value[0], -value[1], -value[2], -value[3]]
    }

    #[inline(always)]
    pub fn clear_padding_lane(mut value: Reg) -> Reg {
        value[3] = 0.0;
        value
    }

    #[inline(always)]
    pub fn mul_scalar(lhs: Reg, rhs: f32) -> Reg {
        [lhs[0] * rhs, lhs[1] * rhs, lhs[2] * rhs, lhs[3] * rhs]
    }

    #[inline(always)]
    pub fn mul_add(accumulator: Reg, multiplicand: Reg, scalar: f32) -> Reg {
        [
            accumulator[0] + multiplicand[0] * scalar,
            accumulator[1] + multiplicand[1] * scalar,
            accumulator[2] + multiplicand[2] * scalar,
            accumulator[3] + multiplicand[3] * scalar,
        ]
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn reference_correlated_inverse(
        sample: &Batch4,
        filter: &Batch4,
        clear_padding_lane: bool,
    ) -> Batch4 {
        let mut response = Batch4::default();
        for index in 0..FFT_LEN {
            for lane in 0..LANES {
                // Keep this in the same explicit non-FMA order as Experiment
                // 044's retained scalar correlation.
                let filter_im = -filter.im[index][lane];
                let re_left = sample.re[index][lane] * filter.re[index][lane];
                let re_right = sample.im[index][lane] * filter_im;
                let im_left = sample.re[index][lane] * filter_im;
                let im_right = sample.im[index][lane] * filter.re[index][lane];
                response.re[index][lane] = re_left - re_right;
                response.im[index][lane] = im_left + im_right;
            }
        }
        if clear_padding_lane {
            for index in 0..FFT_LEN {
                response.re[index][LANES - 1] = 0.0;
                response.im[index][LANES - 1] = 0.0;
            }
        }

        let mut kernel = Kernel36x4::new();
        kernel.poison_scratch(0x51a7);
        kernel.process_inverse(&mut response);
        response
    }

    fn require_batch_bits(actual: &Batch4, expected: &Batch4, context: &str) {
        for index in 0..FFT_LEN {
            for lane in 0..LANES {
                for (component, left, right) in [
                    (
                        "re",
                        actual.re[index][lane].to_bits(),
                        expected.re[index][lane].to_bits(),
                    ),
                    (
                        "im",
                        actual.im[index][lane].to_bits(),
                        expected.im[index][lane].to_bits(),
                    ),
                ] {
                    assert_eq!(
                        left, right,
                        "{context} index={index} lane={lane} component={component}: \
                         actual=0x{left:08x} expected=0x{right:08x}"
                    );
                }
            }
        }
    }

    fn splitmix64(mut value: u64) -> u64 {
        value = value.wrapping_add(0x9e37_79b9_7f4a_7c15);
        value = (value ^ (value >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
        value = (value ^ (value >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
        value ^ (value >> 31)
    }

    fn random_batch(mut state: u64, scale: f32) -> Batch4 {
        let mut batch = Batch4::default();
        for index in 0..FFT_LEN {
            for lane in 0..LANES {
                state = splitmix64(state);
                let re = ((state >> 40) as u32) as f32 * (1.0 / 16_777_216.0);
                state = splitmix64(state);
                let im = ((state >> 40) as u32) as f32 * (1.0 / 16_777_216.0);
                batch.re[index][lane] = (re * 2.0 - 1.0) * scale;
                batch.im[index][lane] = (im * 2.0 - 1.0) * scale;
            }
        }
        batch
    }

    fn edge_batch(offset: usize) -> Batch4 {
        const VALUES: [f32; 16] = [
            0.0,
            -0.0,
            f32::from_bits(0x0000_0001),
            f32::from_bits(0x8000_0001),
            f32::MIN_POSITIVE,
            -f32::MIN_POSITIVE,
            1.0,
            -1.0,
            0.5,
            -0.5,
            1.0e-20,
            -1.0e-20,
            1.0e10,
            -1.0e10,
            3.141_592_7,
            -2.718_281_7,
        ];

        let mut batch = Batch4::default();
        for index in 0..FFT_LEN {
            for lane in 0..LANES {
                let linear = index * LANES + lane;
                batch.re[index][lane] = VALUES[(linear * 5 + offset) % VALUES.len()];
                batch.im[index][lane] = VALUES[(linear * 7 + offset + 3) % VALUES.len()];
            }
        }
        batch
    }

    fn poison_padding_inputs(sample: &mut Batch4, filter: &mut Batch4, salt: u32) {
        for index in 0..FFT_LEN {
            let payload = ((index as u32 * 37 + salt) & 0x003f_ffff) | 1;
            sample.re[index][LANES - 1] = if index & 1 == 0 {
                f32::from_bits(0x7fc0_0000 | payload)
            } else {
                -0.0
            };
            sample.im[index][LANES - 1] = f32::from_bits(0xffc0_0000 | payload);
            filter.re[index][LANES - 1] = if index % 3 == 0 {
                f32::INFINITY
            } else {
                f32::NEG_INFINITY
            };
            filter.im[index][LANES - 1] = -0.0;
        }
    }

    fn check_correlated_case(
        sample: &Batch4,
        filter: &Batch4,
        clear_padding_lane: bool,
        context: &str,
    ) {
        let expected = reference_correlated_inverse(sample, filter, clear_padding_lane);

        let mut clean_kernel = Kernel36x4::new();
        clean_kernel.poison_scratch(0x1111);
        let mut clean = Batch4::default();
        clean_kernel.process_correlated_inverse(sample, filter, &mut clean, clear_padding_lane);
        require_batch_bits(&clean, &expected, context);

        let mut dirty_kernel = Kernel36x4::new();
        dirty_kernel.poison_scratch(0xdead);
        let mut dirty = edge_batch(11);
        dirty_kernel.process_correlated_inverse(sample, filter, &mut dirty, clear_padding_lane);
        require_batch_bits(&dirty, &expected, &format!("{context} poisoned"));
    }

    #[test]
    fn crt_maps_are_permutations() {
        let mut input_seen = [false; FFT_LEN];
        let mut output_seen = [false; FFT_LEN];
        for &index in &INPUT_MAP {
            assert!(index < FFT_LEN);
            assert!(!input_seen[index]);
            input_seen[index] = true;
        }
        for &index in &OUTPUT_MAP {
            assert!(index < FFT_LEN);
            assert!(!output_seen[index]);
            output_seen[index] = true;
        }
        assert!(input_seen.into_iter().all(|seen| seen));
        assert!(output_seen.into_iter().all(|seen| seen));
    }

    #[test]
    fn zero_survives_poisoned_scratch() {
        let mut kernel = Kernel36x4::new();
        kernel.poison_scratch(0x1234);
        let mut batch = Batch4::default();
        kernel.process_forward(&mut batch);
        assert_eq!(batch, Batch4::default());
    }

    #[test]
    fn correlated_inverse_matches_standalone_bits_for_random_inputs() {
        for case in 0..24_u64 {
            let scale = [1.0e-10, 1.0e-3, 1.0, 1.0e3, 1.0e10][case as usize % 5];
            let sample = random_batch(0x0280_44c0_0000_0000 ^ case, scale);
            let filter = random_batch(0x0280_f117_0000_0000 ^ case.rotate_left(17), 1.0 / scale);
            check_correlated_case(&sample, &filter, false, &format!("random case={case}"));
        }
    }

    #[test]
    fn correlated_inverse_matches_standalone_bits_for_edges_and_padding() {
        let sample = edge_batch(0);
        let filter = edge_batch(9);
        check_correlated_case(&sample, &filter, false, "finite edge");

        let mut padded_sample = random_batch(0x0280_0000_fade_0001, 2.0);
        let mut padded_filter = random_batch(0x0280_0000_fade_0002, 0.5);
        poison_padding_inputs(&mut padded_sample, &mut padded_filter, 0x7788);
        check_correlated_case(&padded_sample, &padded_filter, true, "padded edge");
    }
}
