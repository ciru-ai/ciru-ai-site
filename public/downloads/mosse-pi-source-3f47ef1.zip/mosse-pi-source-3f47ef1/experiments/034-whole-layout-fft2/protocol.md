# Experiment 034: fixed whole-layout 60x36 FFT

## Status and non-claim

This is an isolated structural ceiling under
`experiments/034-whole-layout-fft2/`. It does not modify the tracker, its
reports, replay semantics, or timing boundary. A result from this crate is
not tracker FPS and cannot establish an end-to-end optimization.

The first implementation deliberately composes the locked Experiment 031
RFFT60 and Experiment 028 CFFT36 kernels. It answers whether their complete
row, transpose, padding, and column pipeline remains promising when the failed
Experiment 030 whole-spectrum wrapper is removed.

The locked implementation is **positive on the Pi Cortex-A72 and rejected as
an x86 replacement**. Against the current repository `Fft2` in one matched
process, the production-relevant generic Rust 1.97.1 build makes the complete
single-core Pi transform/reduction proxy `1.447893948x` faster. The
portable-source Dunamis build is only
`0.674270049x` as fast as native RustFFT. This architecture split is expected
and is retained explicitly; neither number is tracker FPS.

## Fixed transform and retained semantics

- spatial input/output: row-major real `36 x 60`, exactly 2,160 values;
- logical spectrum: the 31 unique real-frequency columns by 36 complex rows,
  exactly 1,116 complex values;
- persistent padded spectrum: eight batches of
  `[ky=36][kx_lane=4]`, exactly 1,152 complex values;
- dummy padding: `kx=31`, exactly 36 complex values, initialized to positive
  zero and transformed as an independent all-zero column;
- forward: unnormalized;
- inverse: unnormalized;
- round trip: `inverse(forward(x)) = 2160*x` within the locked mixed
  floating-point tolerance.

All eight column batches execute. The padded lane is not omitted from timing.
No frame, update, failure, FFT, model operation, layout operation, packing
operation, FFI work, or worker time may be moved outside the official tracker
timer in any successor integration.

## Whole-layout pipeline

Forward:

1. Gather four adjacent real rows into one `[x=60][row_lane=4]` input.
2. Execute one complete Experiment 031 RFFT60 batch.
3. Treat four adjacent `kx` vectors across those rows as one 4x4 complex tile.
4. Transpose its real and imaginary components directly into
   `[kx_batch][ky][kx_lane]` storage.
5. Use an exact zero vector as the fourth source for the final
   `(kx=28,29,30,pad)` tile.
6. Repeat for all nine row batches and eight `kx` batches.
7. Execute eight complete Experiment 028 CFFT36 batches in place.

Inverse performs the exact reverse: eight inverse CFFT36 batches, reverse
4x4 tiles into four-row half-spectra, nine inverse RFFT60 batches, and
row-major output scattering.

Each direction therefore includes:

- 9 complete four-lane RFFT60 calls;
- 8 complete four-lane CFFT36 calls;
- 72 complex 4x4 row/column tiles, implemented as 144 real 4x4 transposes;
- all 2,160 real input gathers or output scatters;
- all 36 padded complex values.

There is no separate 1,116-element AoS-to-AoSoA pack and no matching unpack.
Experiment 030 charged both around every column phase and regressed by
5.355%. Experiment 034 keeps the transformed spectrum in its native padded
layout between FFT phases and intended pointwise consumers.

## Production storage recommendation

The ceiling crate uses the already proved split-complex batches so it can
isolate the structural question without rewriting either codelet. The
preferred production representation is the equivalent padded interleaved
array:

```text
Complex32 data[8][36][4]
index(kx, ky) = ((kx / 4) * 36 + ky) * 4 + (kx % 4)
```

This order has three useful properties:

1. `data` remains a flat `Complex32` slice of length 1,152, so the current
   model blend, filter reconstruction, and scalar pointwise loops can keep
   their elementwise structure.
2. Four adjacent complex values are the four `kx` lanes at one `ky`; the
   current AArch64 localization multiply already uses `vld2q_f32` and
   `vst2q_f32` on exactly that interleaved shape.
3. An AoS CFFT36 fork can load/store one complex four-lane register with
   `vld2q_f32`/`vst2q_f32`; it does not need a memory conversion pass.

Every fixed-geometry spectral array must use this order together:
`goal_spectrum`, `spectrum`, `numerator`, `denominator`, `filter`, and
`response_spectrum`. Elementwise operations may include all 1,152 entries.
Because forward emits exact zero in the dummy lane, the model numerator and
denominator remain zero there, filter reconstruction returns zero for its
zero divisor, and localization response remains zero. This removes a hot tail
branch. Generic shapes and non-AArch64 production builds retain the current
31x36 column-major RustFFT path.

The next production-oriented codelet API should be:

```text
forward_four_rows_to_padded(input_rows, row_batch, padded_spectrum)
inverse_four_rows_from_padded(padded_spectrum, row_batch, output_rows)
cfft36_aos_forward(&mut data[kx_batch])
cfft36_aos_inverse(&mut data[kx_batch])
```

Forward postprocessing should compute four adjacent `kx` vectors, transpose
them in registers, and store them directly to the padded spectrum. This can
remove the ceiling crate's 124-complex row staging buffer. The reverse path
should load and transpose tiles while populating the RFFT inverse
Good-Thomas permutation, rather than materialize a whole row half-spectrum.

## Persistent four-core schedule compatibility

The layout deliberately exposes independent, statically indexed task groups
without any further packing:

- forward row phase, 9 tasks:
  core 0 gets row batches `0,4,8`; cores 1, 2, and 3 get `1,5`, `2,6`, and
  `3,7`;
- forward column phase, 8 tasks:
  each core gets column batches `core` and `core+4`;
- inverse column phase: the same 8-task assignment;
- inverse row phase: the same 9-task assignment as forward.

Row tasks write disjoint four-`ky` slabs within every column batch; column
tasks own disjoint complete batches. A phase barrier is required between rows
and columns, but no task needs a queue, work stealing, allocation, or a
layout conversion. Aligning each `[36][4]` column batch and each per-worker
row-kernel state to cache lines avoids false sharing of mutable kernel
scratch.

Experiment 034 remains a single-core correctness and layout ceiling.
A separate persistent-executor experiment must measure caller-plus-three
worker dispatch/barrier cost before integration. Worker creation and plan
construction may be persistent, but every dispatch, spin/barrier interval,
and all work performed by all four cores remains inside the tracker update
timer. The executor must process arbitrary video-derived values; static task
indices are geometry specialization, not trace-result hardcoding.

The user explicitly authorizes a four-core Rust candidate to be compared with
the default single-core OpenCV reference. Every result must disclose both
core counts clearly. A one-core Rust result should still be retained as an
architectural comparison, but a matched-four-core OpenCV gate is not imposed
on the authorized primary comparison.

## Correctness and dirty-state gates

Before timing:

- compare complete forward and inverse directions independently with
  persistent RealFFT/RustFFT 2-D oracles;
- compare a complete round trip against `2160*x`;
- include zero, impulses, structured nonperiodic data, and deterministic
  mixed-scale random data;
- require exact positive-zero forward padding;
- poison every row kernel, column kernel, staging buffer, output spectrum,
  and output image with distinct NaN payloads;
- require clean and poisoned results to be bit-identical;
- reject non-finite actual or oracle values;
- use `abs(error) <= 2e-2 + 2e-6*max_abs(reference_vector)` only for this
  compounded isolated ceiling. Scaling by the vector norm avoids making
  cancellation-near-zero bins define the tolerance for a large transform.

That numerical tolerance is not an acceptance substitute for the tracker.
An integrated candidate must retain every decoded-frame checksum, all 4,946
timed update attempts, all success/failure decisions, and every reported box
under the established exact replay comparator.

## Timing protocol

Time the complete forward and inverse calls separately. Forward includes row
gather, all RFFTs, tiled transposes, padding, and all CFFTs. Inverse includes
all CFFTs, tiled transposes, all RFFTs, and row scatter. Planning and
allocation are persistent. Deterministic fixture reset is outside the
isolated call, matching the fact that the tracker constructs a fresh response
spectrum before each consumed inverse.

Run 100 warmups and five 100 ms samples. Report median, range, checksum, host,
CPU, compiler, flags, affinity, governor/frequency, temperature, throttling,
and binary SHA-256.

## Architecture rule

The AArch64 candidate must compile the tile transpose to NEON and retain the
previously proved vector row/column kernels. A Dunamis run is required as a
transfer diagnostic, but its portable four-lane source must not replace
RustFFT's native AVX path unless a same-host full-pipeline comparison wins.
Mixed or negative x86 transfer and positive Pi transfer are legitimate when
clearly labeled.

The Pi ceiling advances to tracker integration only if both complete
directions:

1. pass every oracle, padding, round-trip, and dirty-state check;
2. beat the retained same-host complete fixed 2-D RustFFT/RealFFT path after
   an interleaved-AoS codelet implementation removes any split-layout
   ambiguity;
3. run under the shared benchmark lock on a fixed CPU with valid clock,
   thermal, and throttling telemetry.

## Locked source and validation

The source used by the final Dunamis and Pi matched probes has these SHA-256
identities:

| File | SHA-256 |
|---|---|
| `Cargo.toml` | `f9a30881b70eb30afbb3d7ce0264962dae510ef9397a8281f73f104a3aa73f22` |
| `Cargo.lock` | `d2d939f120bb8d2beff24ccef1e5c7672e6f1e1de0fe3a13493041435082c306` |
| `src/lib.rs` | `7610156d50a0fbf5501e9ed9adc5084b1f22c2d61c5339f2919ad10f8bff05be` |
| `src/main.rs` | `3d5674a88a10ff89997ef4f61bf18ca8fc8fb7a195427c1a0c18d7820cd33214` |
| `src/bin/matched_fft2_probe.rs` | `ee9b33f16bf502d1231c609dc63781751785ca35188b70640c1c1aba66fcc977` |

Local formatting, `clippy --all-targets -- -D warnings`, release tests, the
standalone executable gate, and the matched executable gate pass. The local
release run contains four Experiment 034 tests plus 13 applicable retained
`Fft2` tests. The Pi run contains the same four Experiment 034 tests plus all
14 AArch64-applicable retained `Fft2` tests.

The standalone Pi executable completed 6,552 comparisons across forward,
inverse, round-trip, and dirty-state checks:

- maximum absolute error: `6.103515625e-4`;
- RMS-relative error: `1.744415840e-7`;
- maximum tolerance fraction: `0.026263`;
- all padding remained exact positive zero;
- distinct poisoned persistent state did not change an output bit.

The matched gate independently compares three deterministic input scales,
both spectra, unnormalized inverse outputs, production-style scaled
reduction, the maximum index, sum, and sum of squares against the repository
`Fft2`. It passes on local x86, Dunamis, and Pi. This is numerical transform
equivalence; only a complete tracker replay can establish exact decisions and
boxes.

## Matched Dunamis transfer result

The final Dunamis probe used the Intel Core i9-14900KF, Rust/Cargo 1.97.0,
release mode, `RUSTFLAGS="-C target-cpu=native"`, CPU 0, and
`flock /tmp/mosse-dunamis-benchmark.lock`. Its SHA-256 was
`7b6eacd0809389ee572037194616611cabbb06bb305ee50b0065e6cf36518561`.
Intel P-state reported the `powersave` governor with
`energy_performance_preference=performance`; frequency was not fixed, so the
screen is a directional transfer result rather than a fixed-clock claim.

| Complete matched work | Portable candidate | Current/native `Fft2` | Candidate throughput |
|---|---:|---:|---:|
| Forward 2-D FFT | `2,834.129 ns` | `1,778.461 ns` | `0.627516042x` |
| Inverse 2-D FFT + reduction | `4,857.904 ns` | `3,454.019 ns` | `0.711010119x` |
| Weighted proxy | `8,675.325 ns` | `5,849.512 ns` | `0.674270049x` |

The weighted proxy is
`inverse_reduced + (1 + 1716/4946) * forward`. The portable candidate adds
`48.308530%` latency. It is rejected for x86 production; Dunamis stays on its
native RustFFT/AVX path.

## Matched Pi Cortex-A72 results

### Architecture-tuned diagnostic

The first Pi probe used Rust/Cargo 1.97.1,
`RUSTFLAGS="-C target-cpu=cortex-a72"`, release mode, CPU 0, and
`flock /tmp/mosse-pi4-benchmark.lock`. CPU 0 used the `performance` governor
and stayed at `1,800,000 kHz`. Temperature moved from `60.3 C` to `61.8 C`;
firmware throttling remained `0x0`. The matched binary SHA-256 was
`281bced21a2ae21a4f8562b3a51ffcce5676526fed02b9132c14c0a11603b3a8`.

| Complete matched work | Whole-layout candidate | Current `Fft2` | Candidate speedup |
|---|---:|---:|---:|
| Forward 2-D FFT | `20,349.311 ns` | `30,795.571 ns` | `1.513347118x` |
| Inverse 2-D FFT + reduction | `28,954.842 ns` | `38,465.471 ns` | `1.328464217x` |
| Weighted proxy | `56,364.285 ns` | `79,945.474 ns` | `1.418371105x` |

The candidate reduces this complete weighted transform/reduction proxy by
`29.496590%`. Every candidate number includes row gather/scatter, all nine
RFFT60 batches, all 72 complex tiles in each direction, all eight CFFT36
batches, 36 padded complex values, and inverse reduction. No wrapper cost was
subtracted.

This build is an architecture diagnostic, not the preferred production
compiler condition: a separate full-tracker experiment found that applying
`target-cpu=cortex-a72` globally is unfavorable. The candidate/reference ratio
remains useful because both sides shared the flag.

### Production-relevant generic + one codegen unit

The decision-grade matched probe used the same locked source with:

```text
rustc/cargo 1.97.1
release
codegen-units = 1
LTO = off
RUSTFLAGS unset
```

The profile overrides disabled this crate's diagnostic ThinLTO default.
Candidate and reference were built together with identical flags. The
AArch64 kernels still use explicit NEON intrinsics, which do not require a
global `target-cpu` flag.

The run was serialized by the shared Pi lock and pinned to CPU 0. The
`performance` governor held `1,800,000 kHz`, temperature moved from `55.5 C`
to `54.0 C`, and firmware throttling remained `0x0`. Correctness passed before
timing. The matched binary SHA-256 was
`a140fb50606e363bbd9e9d802816f42c816b00aa32a996b6bfecf9d9835f3849`.

| Complete matched work | Whole-layout candidate | Current `Fft2` | Candidate speedup |
|---|---:|---:|---:|
| Forward 2-D FFT | `18,683.620 ns` | `28,612.666 ns` | `1.531430539x` |
| Inverse 2-D FFT + reduction | `26,363.651 ns` | `36,069.502 ns` | `1.368152754x` |
| Weighted proxy | `51,529.497 ns` | `74,609.247 ns` | `1.447893948x` |

The production-relevant candidate reduces the complete weighted
transform/reduction proxy by `30.934168%`. This is the preferred Experiment
034 ceiling result.

Static inspection found 984 four-wide `trn1`/`trn2` instructions across the
fully linked architecture-tuned binary and 980 in the preferred generic
binary. The Experiment 034 tile transpose uses those AArch64 intrinsics
explicitly; the earlier component gates already established vector
arithmetic and no bounds-check calls in the stable RFFT60 and CFFT36 symbols.

For orientation only, combining the production-relevant `1.447893948x` phase
result
with the older sampled `45.26%` FFT share gives an Amdahl projection of about
`1.16280x` whole-tracker throughput. Applied to the preferred exact
`6,620.576 FPS`, that would be roughly `7,698.4 FPS` or `3.319x` the
one-thread OpenCV median. This is an inference across separate experiments,
not a replay result and not a score. It shows that the single-core layout win
is material but still needs the authorized persistent four-core schedule and
additional non-FFT savings to reach 4x.

## Integration decision

The Pi result passes the structural ceiling and justifies a feature-gated
tracker integration. It does not yet choose between:

1. retaining the measured split-complex padded representation and porting
   every fixed-geometry pointwise operation to four-lane arrays; or
2. implementing the preferred flat interleaved `Complex32[8][36][4]`
   representation plus direct `vld2q_f32`/`vst2q_f32` codelets.

The first preserves the measured kernels; the second minimizes tracker
surface changes. Either candidate must put all fixed spectra in one layout,
include every model update and response operation in timing, preserve the
generic/x86 fallback, and pass the short exact replay before a full 4,946
update run. The persistent four-core executor should be measured separately
and then attached to the same 9-row/8-column static task groups without any
new conversion.

## Commands

```sh
cargo fmt --manifest-path experiments/034-whole-layout-fft2/Cargo.toml -- --check
cargo clippy --manifest-path experiments/034-whole-layout-fft2/Cargo.toml \
  --all-targets -- -D warnings
cargo test --manifest-path experiments/034-whole-layout-fft2/Cargo.toml --release
cargo run --manifest-path experiments/034-whole-layout-fft2/Cargo.toml \
  --release -- --correctness-only
cargo run --manifest-path experiments/034-whole-layout-fft2/Cargo.toml \
  --release -- --warmup 100 --sample-ms 100 --samples 5
cargo run --manifest-path experiments/034-whole-layout-fft2/Cargo.toml \
  --release --bin matched_fft2_probe -- \
  --warmup 100 --sample-ms 100 --samples 5
```
