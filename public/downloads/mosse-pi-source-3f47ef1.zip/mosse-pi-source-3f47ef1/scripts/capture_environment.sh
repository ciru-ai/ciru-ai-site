#!/usr/bin/env bash
#
# Emit benchmark-host facts without changing system state.
#
# The default is pretty JSON so the same artifact is both machine-readable and
# reasonably easy to inspect. Use `--format text` for a compact terminal view.

set -euo pipefail

format="json"

usage() {
    cat <<'EOF'
Usage: capture_environment.sh [--format json|text]

Reads host, toolchain, OpenCV, CPU governor, thermal, and throttling state and
writes it to stdout. The script does not install packages, change governors,
start services, or write an output file.
EOF
}

while (($# > 0)); do
    case "$1" in
        --format)
            if (($# < 2)); then
                echo "error: --format requires json or text" >&2
                exit 2
            fi
            format="$2"
            shift 2
            ;;
        --help|-h)
            usage
            exit 0
            ;;
        *)
            echo "error: unknown argument: $1" >&2
            usage >&2
            exit 2
            ;;
    esac
done

case "$format" in
    json|text) ;;
    *)
        echo "error: unsupported format '$format' (expected json or text)" >&2
        exit 2
        ;;
esac

if ! command -v python3 >/dev/null 2>&1; then
    echo "error: python3 is required to serialize the environment capture" >&2
    exit 1
fi

export PYTHONDONTWRITEBYTECODE=1

python3 - "$format" <<'PY'
from __future__ import annotations

import datetime as dt
import getpass
import json
import os
import platform
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any


def read_text(path: Path) -> str | None:
    try:
        return path.read_text(encoding="utf-8", errors="replace").strip("\x00\n ")
    except (OSError, UnicodeError):
        return None


def read_int(path: Path) -> int | None:
    value = read_text(path)
    if value is None:
        return None
    try:
        return int(value)
    except ValueError:
        return None


def run(argv: list[str], timeout: float = 15.0) -> dict[str, Any]:
    executable = shutil.which(argv[0])
    if executable is None:
        return {
            "available": False,
            "path": None,
            "exit_code": None,
            "output": None,
        }

    try:
        completed = subprocess.run(
            [executable, *argv[1:]],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
            text=True,
            timeout=timeout,
            env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
        )
        output = completed.stdout.strip()
        return {
            "available": True,
            "path": executable,
            "exit_code": completed.returncode,
            "output": output or None,
        }
    except (OSError, subprocess.SubprocessError) as exc:
        return {
            "available": True,
            "path": executable,
            "exit_code": None,
            "output": f"{type(exc).__name__}: {exc}",
        }


def successful_output(record: dict[str, Any]) -> str | None:
    if record.get("exit_code") == 0:
        output = record.get("output")
        if isinstance(output, str):
            return output
    return None


def parse_os_release() -> dict[str, str]:
    result: dict[str, str] = {}
    content = read_text(Path("/etc/os-release"))
    if content is None:
        return result

    for line in content.splitlines():
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        result[key] = value
    return result


def cpu_model() -> str | None:
    device_model = read_text(Path("/proc/device-tree/model"))
    if device_model:
        return device_model

    content = read_text(Path("/proc/cpuinfo"))
    if content is None:
        return None
    for key in ("model name", "Model", "Hardware"):
        match = re.search(rf"^{re.escape(key)}\s*:\s*(.+)$", content, re.MULTILINE)
        if match:
            return match.group(1).strip()
    return None


def memory_total_bytes() -> int | None:
    content = read_text(Path("/proc/meminfo"))
    if content is None:
        return None
    match = re.search(r"^MemTotal:\s+(\d+)\s+kB$", content, re.MULTILINE)
    if match is None:
        return None
    return int(match.group(1)) * 1024


def cpufreq_state() -> list[dict[str, Any]]:
    policies: list[dict[str, Any]] = []
    for policy in sorted(Path("/sys/devices/system/cpu/cpufreq").glob("policy*")):
        policies.append(
            {
                "policy": policy.name,
                "affected_cpus": read_text(policy / "affected_cpus"),
                "governor": read_text(policy / "scaling_governor"),
                "driver": read_text(policy / "scaling_driver"),
                "min_khz": read_int(policy / "scaling_min_freq"),
                "max_khz": read_int(policy / "scaling_max_freq"),
                "current_khz": read_int(policy / "scaling_cur_freq"),
            }
        )
    return policies


def thermal_state() -> list[dict[str, Any]]:
    zones: list[dict[str, Any]] = []
    for zone in sorted(Path("/sys/class/thermal").glob("thermal_zone*")):
        millidegrees = read_int(zone / "temp")
        zones.append(
            {
                "zone": zone.name,
                "type": read_text(zone / "type"),
                "millidegrees_celsius": millidegrees,
                "celsius": (
                    round(millidegrees / 1000.0, 3)
                    if millidegrees is not None
                    else None
                ),
            }
        )
    return zones


def opencv_state() -> dict[str, Any]:
    exists_record = run(["pkg-config", "--exists", "opencv4"])
    pkg_config_available = exists_record.get("exit_code") == 0

    version_record = run(["pkg-config", "--modversion", "opencv4"])
    include_record = run(["pkg-config", "--variable=includedir", "opencv4"])
    cflags_record = run(["pkg-config", "--cflags", "opencv4"])
    libs_record = run(["pkg-config", "--libs", "opencv4"])
    verbose_record = run(["opencv_version", "--verbose"])

    include_dir = successful_output(include_record)
    header_candidates: list[Path] = []
    if include_dir:
        header_candidates.append(
            Path(include_dir) / "opencv2" / "tracking" / "tracking_legacy.hpp"
        )
    header_candidates.extend(
        [
            Path("/usr/include/opencv4/opencv2/tracking/tracking_legacy.hpp"),
            Path("/usr/local/include/opencv4/opencv2/tracking/tracking_legacy.hpp"),
        ]
    )

    legacy_header: Path | None = next(
        (candidate for candidate in header_candidates if candidate.is_file()),
        None,
    )
    legacy_header_text = read_text(legacy_header) if legacy_header else None

    python_binding: dict[str, Any]
    python_build_information: str | None = None
    try:
        import cv2  # type: ignore[import-not-found]

        legacy_namespace = getattr(cv2, "legacy", None)
        python_binding = {
            "available": True,
            "version": getattr(cv2, "__version__", None),
            "legacy_tracker_mosse_factory": bool(
                legacy_namespace is not None
                and hasattr(legacy_namespace, "TrackerMOSSE_create")
            ),
        }
        try:
            python_build_information = cv2.getBuildInformation()
        except Exception as exc:  # pragma: no cover - defensive for vendor builds
            python_build_information = f"{type(exc).__name__}: {exc}"
    except Exception as exc:
        python_binding = {
            "available": False,
            "version": None,
            "legacy_tracker_mosse_factory": False,
            "error": f"{type(exc).__name__}: {exc}",
        }

    return {
        "pkg_config_available": pkg_config_available,
        "version": successful_output(version_record),
        "include_dir": include_dir,
        "cflags": successful_output(cflags_record),
        "libs": successful_output(libs_record),
        "legacy_tracking_header": str(legacy_header) if legacy_header else None,
        "legacy_tracker_mosse_declared": (
            "TrackerMOSSE" in legacy_header_text
            if legacy_header_text is not None
            else False
        ),
        "opencv_version_verbose": successful_output(verbose_record),
        "python_binding": python_binding,
        "python_build_information": python_build_information,
    }


tool_commands = {
    "rustc": ["rustc", "-Vv"],
    "cargo": ["cargo", "-V"],
    "gcc": ["gcc", "--version"],
    "g++": ["g++", "--version"],
    "clang": ["clang", "--version"],
    "cmake": ["cmake", "--version"],
    "ninja": ["ninja", "--version"],
    "pkg_config": ["pkg-config", "--version"],
    "perf": ["perf", "--version"],
    "ffmpeg": ["ffmpeg", "-version"],
}

load_average: list[float] | None
try:
    load_average = [round(value, 4) for value in os.getloadavg()]
except (AttributeError, OSError):
    load_average = None

vcgencmd_temperature = run(["vcgencmd", "measure_temp"])
vcgencmd_throttled = run(["vcgencmd", "get_throttled"])

capture: dict[str, Any] = {
    "schema_version": 1,
    "captured_at_utc": dt.datetime.now(dt.timezone.utc)
    .replace(microsecond=0)
    .isoformat(),
    "host": {
        "hostname": platform.node(),
        "user": getpass.getuser(),
        "os_release": parse_os_release(),
        "kernel_release": platform.release(),
        "kernel_version": platform.version(),
        "architecture": platform.machine(),
        "uname": " ".join(platform.uname()),
    },
    "cpu": {
        "model": cpu_model(),
        "logical_cpus": os.cpu_count(),
        "lscpu": successful_output(run(["lscpu"])),
        "load_average_1m_5m_15m": load_average,
        "cpufreq_policies": cpufreq_state(),
        "intel_pstate_no_turbo": read_int(
            Path("/sys/devices/system/cpu/intel_pstate/no_turbo")
        ),
        "cpufreq_boost": read_int(Path("/sys/devices/system/cpu/cpufreq/boost")),
    },
    "memory": {
        "total_bytes": memory_total_bytes(),
    },
    "toolchain": {
        name: run(command) for name, command in tool_commands.items()
    }
    | {
        "python": {
            "available": True,
            "path": sys.executable,
            "exit_code": 0,
            "output": sys.version.replace("\n", " "),
        }
    },
    "opencv": opencv_state(),
    "thermal_and_throttling": {
        "thermal_zones": thermal_state(),
        "vcgencmd_measure_temp": vcgencmd_temperature,
        "vcgencmd_get_throttled": vcgencmd_throttled,
    },
}


def first_line(record: dict[str, Any]) -> str:
    if not record.get("available"):
        return "not found"
    output = record.get("output")
    if isinstance(output, str) and output:
        return output.splitlines()[0]
    code = record.get("exit_code")
    return f"available (exit {code})"


def render_text(data: dict[str, Any]) -> None:
    host = data["host"]
    os_release = host["os_release"]
    cpu = data["cpu"]
    opencv = data["opencv"]
    thermal = data["thermal_and_throttling"]

    print(f"Captured (UTC): {data['captured_at_utc']}")
    print(
        "Host: "
        f"{host['hostname']} | "
        f"{os_release.get('PRETTY_NAME', 'unknown OS')} | "
        f"{host['kernel_release']} | {host['architecture']}"
    )
    print(
        f"CPU: {cpu.get('model') or 'unknown'} | "
        f"logical CPUs={cpu.get('logical_cpus')} | "
        f"memory bytes={data['memory'].get('total_bytes')}"
    )

    policies = cpu.get("cpufreq_policies") or []
    if policies:
        policy_summary = ", ".join(
            f"{item['policy']}={item.get('governor') or 'unknown'}"
            for item in policies
        )
        print(f"CPU governors: {policy_summary}")
    else:
        print("CPU governors: unavailable")

    print("Toolchain:")
    for name, record in data["toolchain"].items():
        print(f"  {name}: {first_line(record)}")

    print("OpenCV:")
    print(f"  pkg-config available: {opencv['pkg_config_available']}")
    print(f"  version: {opencv.get('version') or 'not found'}")
    print(
        "  legacy TrackerMOSSE header declaration: "
        f"{opencv['legacy_tracker_mosse_declared']}"
    )
    print(
        "  Python legacy TrackerMOSSE factory: "
        f"{opencv['python_binding']['legacy_tracker_mosse_factory']}"
    )

    zones = thermal.get("thermal_zones") or []
    if zones:
        print("Temperatures:")
        for zone in zones:
            print(
                f"  {zone['zone']} ({zone.get('type') or 'unknown'}): "
                f"{zone.get('celsius')} C"
            )
    else:
        print("Temperatures: unavailable")

    print(
        "Raspberry Pi throttling: "
        f"{first_line(thermal['vcgencmd_get_throttled'])}"
    )

    build_info = (
        opencv.get("opencv_version_verbose")
        or opencv.get("python_build_information")
    )
    if build_info:
        print("\nOpenCV build information:")
        print(build_info)


if sys.argv[1] == "json":
    json.dump(capture, sys.stdout, indent=2, sort_keys=True)
    sys.stdout.write("\n")
else:
    render_text(capture)
PY
