#include "mosse/benchmark_config.hpp"
#include "mosse/frame_checksum.hpp"
#include "mosse/result_writer.hpp"
#include "mosse/tracker_backend.hpp"

#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <filesystem>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <optional>
#include <stdexcept>
#include <string>

#include <opencv2/core/ocl.hpp>
#include <opencv2/core/utility.hpp>
#include <opencv2/core/version.hpp>
#include <opencv2/videoio.hpp>

namespace {

using Clock = std::chrono::steady_clock;

struct CliOptions {
  std::filesystem::path config_path;
  std::string tracker{"opencv"};
  mosse::ConfigOverrides overrides;
  bool show_help{false};
};

std::string usage() {
  return "Usage: mosse_benchmark --config <config.yml> [options]\n"
         "\n"
         "Options:\n"
         "  --tracker <opencv|rust>  Tracker backend (Rust is build-time "
         "optional)\n"
         "  --frames-csv <path>      Override per-frame CSV output path\n"
         "  --summary-json <path>    Override JSON summary output path\n"
         "  --max-frames <count>     Process at most count decoded frames; "
         "0=all\n"
         "  --opencv-threads <count> OpenCV threads; -1 leaves library "
         "default\n"
         "  --frame-checksums        Enable per-frame and sequence checksums\n"
         "  --no-frame-checksums     Disable frame checksums\n"
         "  --help                   Show this help\n"
         "\n"
         "Config keys may be flat or grouped:\n"
         "  video_path: /path/video.mp4\n"
         "  roi: { x: 10, y: 20, width: 64, height: 48 }\n"
         "  # Or use: roi_file: roi_selection.json\n"
         "  output: { frames_csv: results/frames.csv,\n"
         "            summary_json: results/summary.json }\n"
         "  benchmark: { max_frames: 0, opencv_threads: -1,\n"
         "               frame_checksums: 1 }\n"
         "\n"
         "Relative config paths are resolved from the config file directory.\n"
         "CLI output overrides are resolved from the current working "
         "directory.\n";
}

std::string require_value(const int argc, char **argv, int &index,
                          const std::string &option) {
  if ((index + 1) >= argc) {
    throw std::runtime_error("Missing value after command-line option " +
                             option);
  }
  ++index;
  return argv[index];
}

std::uint64_t parse_u64(const std::string &value, const std::string &option) {
  std::size_t parsed = 0;
  unsigned long long converted = 0;
  try {
    converted = std::stoull(value, &parsed, 10);
  } catch (const std::exception &) {
    throw std::runtime_error("Invalid non-negative integer for " + option +
                             ": " + value);
  }
  if (parsed != value.size() || (!value.empty() && value.front() == '-')) {
    throw std::runtime_error("Invalid non-negative integer for " + option +
                             ": " + value);
  }
  return static_cast<std::uint64_t>(converted);
}

int parse_int(const std::string &value, const std::string &option) {
  std::size_t parsed = 0;
  long long converted = 0;
  try {
    converted = std::stoll(value, &parsed, 10);
  } catch (const std::exception &) {
    throw std::runtime_error("Invalid integer for " + option + ": " + value);
  }
  if (parsed != value.size() ||
      converted < static_cast<long long>(std::numeric_limits<int>::min()) ||
      converted > static_cast<long long>(std::numeric_limits<int>::max())) {
    throw std::runtime_error("Invalid integer for " + option + ": " + value);
  }
  return static_cast<int>(converted);
}

CliOptions parse_cli(const int argc, char **argv) {
  CliOptions options;

  for (int index = 1; index < argc; ++index) {
    const std::string argument = argv[index];
    if (argument == "--help" || argument == "-h") {
      options.show_help = true;
    } else if (argument == "--config") {
      options.config_path = require_value(argc, argv, index, argument);
    } else if (argument == "--tracker") {
      options.tracker = require_value(argc, argv, index, argument);
    } else if (argument == "--frames-csv") {
      options.overrides.frames_csv = require_value(argc, argv, index, argument);
    } else if (argument == "--summary-json") {
      options.overrides.summary_json =
          require_value(argc, argv, index, argument);
    } else if (argument == "--max-frames") {
      options.overrides.max_frames =
          parse_u64(require_value(argc, argv, index, argument), argument);
    } else if (argument == "--opencv-threads") {
      options.overrides.opencv_threads =
          parse_int(require_value(argc, argv, index, argument), argument);
    } else if (argument == "--frame-checksums") {
      options.overrides.compute_frame_checksums = true;
    } else if (argument == "--no-frame-checksums") {
      options.overrides.compute_frame_checksums = false;
    } else {
      throw std::runtime_error("Unknown command-line option: " + argument);
    }
  }

  if (!options.show_help && options.config_path.empty()) {
    throw std::runtime_error("--config is required\n\n" + usage());
  }
  return options;
}

std::uint64_t elapsed_ns(const Clock::time_point start,
                         const Clock::time_point end) {
  return static_cast<std::uint64_t>(
      std::chrono::duration_cast<std::chrono::nanoseconds>(end - start)
          .count());
}

std::int64_t reported_frame_count(const double value) {
  if (!std::isfinite(value) || value < 0.0 ||
      value > static_cast<double>(std::numeric_limits<std::int64_t>::max())) {
    return 0;
  }
  return static_cast<std::int64_t>(std::llround(value));
}

std::optional<std::uint64_t> checksum_frame(const cv::Mat &frame,
                                            const bool enabled) {
  if (!enabled) {
    return std::nullopt;
  }
  return mosse::frame_checksum_fnv1a64(frame);
}

void require_stable_frame_layout(const cv::Mat &frame,
                                 const cv::Size &expected_size,
                                 const int expected_type,
                                 const std::uint64_t frame_index) {
  if (frame.empty()) {
    throw std::runtime_error("Decoder returned an empty frame at index " +
                             std::to_string(frame_index));
  }
  if (frame.size() != expected_size || frame.type() != expected_type) {
    throw std::runtime_error(
        "Decoded frame layout changed at index " + std::to_string(frame_index) +
        "; a paired replay requires fixed dimensions and type");
  }
}

int run(const CliOptions &options) {
  mosse::BenchmarkConfig config =
      mosse::load_benchmark_config(options.config_path);
  mosse::apply_config_overrides(config, options.overrides);

  if (config.opencv_threads >= 0) {
    cv::setNumThreads(config.opencv_threads);
  }
  cv::ocl::setUseOpenCL(false);

  std::unique_ptr<mosse::TrackerBackend> tracker =
      mosse::create_tracker_backend(options.tracker);

  cv::VideoCapture capture(config.video_path.string(), cv::CAP_ANY);
  if (!capture.isOpened()) {
    throw std::runtime_error("Unable to open video: " +
                             config.video_path.string());
  }

  const double source_fps = capture.get(cv::CAP_PROP_FPS);
  const std::int64_t source_frame_count =
      reported_frame_count(capture.get(cv::CAP_PROP_FRAME_COUNT));

  mosse::CsvFrameWriter csv_writer(config.frames_csv);
  mosse::FrameSequenceChecksum sequence_checksum;
  mosse::BenchmarkSummary summary;
  summary.tracker_name = tracker->name();
  summary.opencv_version = CV_VERSION;
  summary.config_path = config.config_path;
  summary.video_path = config.video_path;
  summary.frames_csv = config.frames_csv;
  summary.initial_roi = config.initial_roi;
  summary.expected_video_sha256 = config.expected_video_sha256;
  summary.checksum_algorithm =
      config.compute_frame_checksums ? mosse::kFrameChecksumAlgorithm : "";
  summary.max_frames = config.max_frames;
  summary.expected_width = config.expected_width;
  summary.expected_height = config.expected_height;
  summary.expected_decoded_frames = config.expected_decoded_frames;
  summary.source_fps = source_fps;
  summary.source_reported_frame_count = source_frame_count;
  summary.opencv_threads_requested = config.opencv_threads;
  summary.opencv_threads_effective = cv::getNumThreads();
  summary.opencv_use_optimized = cv::useOptimized();

  const Clock::time_point end_to_end_start = Clock::now();

  cv::Mat frame;
  if (!capture.read(frame) || frame.empty()) {
    throw std::runtime_error("Video contains no decodable first frame: " +
                             config.video_path.string());
  }

  const cv::Size expected_size = frame.size();
  const int expected_type = frame.type();
  if (expected_type != CV_8UC3) {
    throw std::runtime_error(
        "Decoder did not produce the required 8-bit three-channel BGR "
        "frame representation");
  }
  if (config.expected_width > 0 &&
      (expected_size.width != config.expected_width ||
       expected_size.height != config.expected_height)) {
    throw std::runtime_error(
        "First decoded frame dimensions do not match configuration: got " +
        std::to_string(expected_size.width) + "x" +
        std::to_string(expected_size.height) + ", expected " +
        std::to_string(config.expected_width) + "x" +
        std::to_string(config.expected_height));
  }
  mosse::validate_roi_for_frame(config.initial_roi, expected_size);
  summary.frame_width = expected_size.width;
  summary.frame_height = expected_size.height;
  summary.frame_type = expected_type;

  const Clock::time_point initialization_start = Clock::now();
  const bool initialized = tracker->initialize(frame, config.initial_roi);
  const Clock::time_point initialization_end = Clock::now();
  summary.initialization_ns =
      elapsed_ns(initialization_start, initialization_end);
  if (!initialized) {
    throw std::runtime_error(
        "Tracker backend failed to initialize on the first frame");
  }

  const std::optional<std::uint64_t> first_checksum =
      checksum_frame(frame, config.compute_frame_checksums);
  if (first_checksum.has_value()) {
    sequence_checksum.add(0U, *first_checksum);
  }
  csv_writer.write(
      {0U, true, false, true, config.initial_roi, 0U, first_checksum});
  summary.decoded_frames = 1U;

  while (config.max_frames == 0U ||
         summary.decoded_frames < config.max_frames) {
    cv::Mat next_frame;
    if (!capture.read(next_frame)) {
      summary.end_of_stream_reached = true;
      break;
    }

    const std::uint64_t frame_index = summary.decoded_frames;
    require_stable_frame_layout(next_frame, expected_size, expected_type,
                                frame_index);

    const Clock::time_point update_start = Clock::now();
    const mosse::TrackerUpdate update = tracker->update(next_frame);
    const Clock::time_point update_end = Clock::now();
    const std::uint64_t update_ns = elapsed_ns(update_start, update_end);

    const std::optional<std::uint64_t> frame_checksum =
        checksum_frame(next_frame, config.compute_frame_checksums);
    if (frame_checksum.has_value()) {
      sequence_checksum.add(frame_index, *frame_checksum);
    }

    csv_writer.write({frame_index, false, true, update.success, update.bbox,
                      update_ns, frame_checksum});

    ++summary.decoded_frames;
    ++summary.attempted_updates;
    summary.total_update_ns += update_ns;
    summary.update_latencies_ns.push_back(update_ns);
    if (update.success) {
      ++summary.successful_updates;
    } else {
      ++summary.failed_updates;
    }
  }

  summary.frame_limit_reached =
      config.max_frames != 0U && summary.decoded_frames >= config.max_frames;
  const bool decoded_count_satisfied =
      config.expected_decoded_frames != 0U
          ? summary.decoded_frames == config.expected_decoded_frames
          : true;
  summary.full_video_processed = summary.end_of_stream_reached &&
                                 !summary.frame_limit_reached &&
                                 decoded_count_satisfied;
  if (config.compute_frame_checksums) {
    summary.frame_sequence_checksum = sequence_checksum.value();
  }

  csv_writer.flush();
  const Clock::time_point end_to_end_end = Clock::now();
  summary.end_to_end_ns = elapsed_ns(end_to_end_start, end_to_end_end);

  mosse::write_summary_json(config.summary_json, summary);

  if (config.max_frames == 0U && config.expected_decoded_frames != 0U &&
      summary.decoded_frames != config.expected_decoded_frames) {
    throw std::runtime_error(
        "Decoded frame count does not match configuration: got " +
        std::to_string(summary.decoded_frames) + ", expected " +
        std::to_string(config.expected_decoded_frames) +
        ". The JSON summary and partial CSV were retained for diagnosis.");
  }

  const double tracker_fps =
      summary.total_update_ns == 0U
          ? 0.0
          : static_cast<double>(summary.attempted_updates) * 1.0e9 /
                static_cast<double>(summary.total_update_ns);

  std::cout << "tracker=" << summary.tracker_name
            << " decoded_frames=" << summary.decoded_frames
            << " attempted_updates=" << summary.attempted_updates
            << " successful_updates=" << summary.successful_updates
            << " failed_updates=" << summary.failed_updates
            << " tracker_only_fps=" << std::fixed << std::setprecision(3)
            << tracker_fps << '\n'
            << "frames_csv=" << config.frames_csv.string() << '\n'
            << "summary_json=" << config.summary_json.string() << '\n';

  return EXIT_SUCCESS;
}

} // namespace

int main(const int argc, char **argv) {
  try {
    const CliOptions options = parse_cli(argc, argv);
    if (options.show_help) {
      std::cout << usage();
      return EXIT_SUCCESS;
    }
    return run(options);
  } catch (const cv::Exception &error) {
    std::cerr << "OpenCV error: " << error.what() << '\n';
  } catch (const std::exception &error) {
    std::cerr << "Error: " << error.what() << '\n';
  }
  return EXIT_FAILURE;
}
