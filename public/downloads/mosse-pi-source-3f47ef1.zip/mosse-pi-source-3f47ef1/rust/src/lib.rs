//! Portable scalar MOSSE object tracker.
//!
//! The implementation intentionally favors clarity and deterministic behavior.
//! It uses single-precision 2-D FFTs with portable fallbacks and bounded
//! architecture-specific hot paths. The public Rust API is safe; [`ffi`]
//! exposes the same tracker through an opaque C handle.

#![forbid(unsafe_op_in_unsafe_fn)]

pub mod ffi;
mod fft2;
#[cfg(any(test, feature = "pi4-four-core-runtime"))]
pub mod four_core_runtime;
#[cfg(any(
    test,
    all(
        feature = "parallel-whole-layout-60x36",
        target_os = "linux",
        target_arch = "aarch64"
    )
))]
pub mod parallel_whole_layout;
mod tracker;

pub use tracker::{
    BgrFrame, Diagnostics, MosseConfig, MosseTracker, Rect, TrackerBackendStatus, TrackerError,
    TrackerMode, UpdateResult,
};
