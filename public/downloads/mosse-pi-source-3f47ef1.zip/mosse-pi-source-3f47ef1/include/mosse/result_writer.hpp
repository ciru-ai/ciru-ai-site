#pragma once

#include <cstdint>
#include <filesystem>
#include <fstream>
#include <optional>
#include <string>
#include <vector>

#include <opencv2/core/types.hpp>

namespace mosse {

struct FrameRecord {
  std::uint64_t frame_index{0};
  bool is_initialization{false};
  bool update_attempted{false};
  bool success{false};
  cv::Rect2d bbox;
  std::uint64_t update_ns{0};
  std::optional<std::uint64_t> frame_checksum;
};

class CsvFrameWriter {
public:
  explicit CsvFrameWriter(const std::filesystem::path &path);

  void write(const FrameRecord &record);
  void flush();

private:
  std::ofstream output_;
};

struct BenchmarkSummary {
  std::string tracker_name;
  std::string opencv_version;
  std::filesystem::path config_path;
  std::filesystem::path video_path;
  std::filesystem::path frames_csv;
  cv::Rect2d initial_roi;
  std::string expected_video_sha256;
  std::string checksum_algorithm;
  std::optional<std::uint64_t> frame_sequence_checksum;

  std::uint64_t max_frames{0};
  int expected_width{0};
  int expected_height{0};
  std::uint64_t expected_decoded_frames{0};
  int frame_width{0};
  int frame_height{0};
  int frame_type{0};
  double source_fps{0.0};
  std::int64_t source_reported_frame_count{0};
  int opencv_threads_requested{-1};
  int opencv_threads_effective{0};
  bool opencv_use_optimized{false};

  std::uint64_t decoded_frames{0};
  std::uint64_t attempted_updates{0};
  std::uint64_t successful_updates{0};
  std::uint64_t failed_updates{0};
  bool frame_limit_reached{false};
  bool end_of_stream_reached{false};
  bool full_video_processed{false};

  std::uint64_t initialization_ns{0};
  std::uint64_t total_update_ns{0};
  std::uint64_t end_to_end_ns{0};
  std::vector<std::uint64_t> update_latencies_ns;
};

void write_summary_json(const std::filesystem::path &path,
                        const BenchmarkSummary &summary);

} // namespace mosse
