# Experiment 056: parallel fixed-padded model blend/filter

## Status

Isolated and correctness-gated only. This experiment is not integrated into
the tracker and has no Pi runtime or tracker-speed result.

## Question

Can the retained fixed 60x36 MOSSE model blend and filter reconstruction be
partitioned into eight disjoint padded-spectrum batches for the existing
caller-plus-three-worker executor without changing any `f32` result bit?

Experiment 050 measured the combined `Model blend/filter` phase at
`10.167 us/update` averaged across its exact instrumented full replay. That is
the entire measured phase ceiling, not an expected saving. Even ideal
four-way work would leave computation and all dispatch/barrier cost; every
speed figure remains a projection until an integrated tracker is measured.

## Exact retained arithmetic

For each spectral bin, the task preserves the current tracker expression and
operation order:

```rust
let keep = 1.0 - rate;
let numerator_new = goal * sample.conj();
let denominator_new = sample * sample.conj();
numerator = numerator * keep + numerator_new * rate;
denominator = denominator * keep + denominator_new * rate;

let divisor = denominator.re * denominator.re
    + denominator.im * denominator.im;
filter = if divisor > 0.0 && divisor.is_finite() {
    Complex32::new(
        (numerator.re * denominator.re
            + numerator.im * denominator.im) / divisor,
        -(numerator.im * denominator.re
            + numerator.re * denominator.im) / divisor,
    )
} else {
    Complex32::new(0.0, 0.0)
};
```

The experiment intentionally uses scalar `Complex32` operations per lane.
No NEON reassociation, reciprocal approximation, fused reduction, or changed
fallback is introduced. A task stores and reloads its updated numerator and
denominator before reconstructing the filter, matching the retained
two-traversal composition while fusing the traversals only across independent
bins.

## Work partition and runtime shape

There are eight tasks, one for each
`[kx_batch][36 ky][4 kx lanes]` batch. Each task owns mutable references to its
matching numerator, denominator, and filter batch and immutable references to
its matching goal and sample batch. The safe binding API cannot construct
overlapping tasks.

The retained runtime's static modulo-four ownership maps batches as:

| Runtime lane | Batches |
| --- | --- |
| caller / lane 0 | 0, 4 |
| worker lane 1 | 1, 5 |
| worker lane 2 | 2, 6 |
| worker lane 3 | 3, 7 |

Intended integration shape, if later selected:

```rust
let mut tasks = bind_blend_filter_batches(
    &goal,
    &sample,
    &mut numerator,
    &mut denominator,
    &mut filter,
    rate,
);
runtime.dispatch(&mut tasks, |_, task| task.run());
```

There are no reductions and no cross-task combination order. Valid fixed
spectra enter with batch 7 lane 3 set to positive zero. Tests require
numerator, denominator, and filter padding to remain positive zero across the
tracker-valid edge-rate range, including signed zero.

## Correctness gates

The release suite compares all real and imaginary output bits in numerator,
denominator, and filter against an independent production-equivalent serial
composition. It covers:

- 32 randomized complete padded-spectrum fixtures at the default `0.2` rate;
- concurrent four-lane execution in the exact modulo-four task order;
- tracker-valid rates `-0.0`, `0.0`, `f32::MIN_POSITIVE`, `0.2`, the largest
  `f32` below one, and `1.0`;
- signed-zero inputs, distinct quiet-NaN payloads, and positive/negative
  infinity in valid bins;
- differently poisoned initial filter storage to prove every filter field is
  overwritten;
- positive-zero dummy-lane preservation for all edge rates; and
- a compile-time `Send` gate for runtime publication.

Commands:

```text
cargo test --release \
  --manifest-path experiments/056-parallel-model-blend-filter/Cargo.toml

cargo clippy --release --all-targets \
  --manifest-path experiments/056-parallel-model-blend-filter/Cargo.toml \
  -- -D warnings
```

Recorded local gates:

```text
release tests: 6 passed; 0 failed
release all-target Clippy with -D warnings: passed
AArch64 release library Clippy with -D warnings: passed
```

The AArch64 command was:

```text
cargo clippy --release --target aarch64-unknown-linux-gnu --lib \
  --manifest-path experiments/056-parallel-model-blend-filter/Cargo.toml \
  -- -D warnings
```

It is a cross-compile/lint result only; it did not execute code on a Pi.

## Future compact Pi screen gate

There is no Pi claim from this experiment. If a default-off tracker
integration is later attempted, first run its Pi-native release oracle tests.
Then run exactly one bounded 300-frame canonical screen with the retained
four-core RT/watchdog/governor/thermal protocol. Require:

- the fixed four-core backend actually selected;
- all 299 timed update attempts present;
- exact retained frame checksums, success/failure decisions, and boxes;
- watchdog survival, clean worker parking/teardown, no throttling, and
  restored RT settings; and
- a material whole-update improvement including dispatch and barrier time.

Do not repeat the compact screen to select a favorable timing. A passing
screen authorizes one exact full replay; it does not establish a headline
tracker score. The final five-pair matrix and sustained live-style soak remain
later qualification gates.

## Non-goals

- No production or Cargo feature integration.
- No default-on behavior change.
- No SIMD claim.
- No isolated-kernel timing claim.
- No Pi, full-replay, OpenCV-multiple, or tracker-throughput claim.
