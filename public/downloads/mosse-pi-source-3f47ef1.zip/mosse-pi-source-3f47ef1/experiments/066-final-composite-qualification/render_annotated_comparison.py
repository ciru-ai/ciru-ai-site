#!/usr/bin/env python3
"""Render an exact saved-trace comparison without running either tracker."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
import uuid
from pathlib import Path
from typing import Any

try:
    import cv2
except ImportError as exc:  # pragma: no cover - depends on the render host
    raise SystemExit(
        "OpenCV Python bindings are required: install python3-opencv or opencv-python"
    ) from exc


EXPECTED_FRAMES = 4_947
EXPECTED_SOURCE_SHA256 = (
    "17293ee5158b5f41d2920bbb1ba835f96050ab2813942ff29008dffab10857b5"
)
EXACT_FIELDS = (
    "frame_index",
    "is_initialization",
    "update_attempted",
    "success",
    "bbox_x",
    "bbox_y",
    "bbox_width",
    "bbox_height",
    "frame_checksum_fnv1a64",
)
CODECS = ("mp4v", "avc1")


class CodecError(RuntimeError):
    """An output-codec failure for which the next codec may be tried."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_trace(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream)
        fieldnames = reader.fieldnames or []
        missing = [field for field in EXACT_FIELDS if field not in fieldnames]
        duplicated = sorted(
            {field for field in EXACT_FIELDS if fieldnames.count(field) > 1}
        )
        if missing or duplicated:
            raise ValueError(
                f"{path}: invalid header; missing={missing}, duplicated={duplicated}"
            )
        rows = list(reader)

    if len(rows) != EXPECTED_FRAMES:
        raise ValueError(
            f"{path}: expected {EXPECTED_FRAMES} data rows, found {len(rows)}"
        )

    for index, row in enumerate(rows):
        if None in row or any(row.get(field) is None for field in EXACT_FIELDS):
            raise ValueError(f"{path}: malformed CSV row {index + 2}")
        if row["frame_index"] != str(index):
            raise ValueError(
                f"{path}: row {index + 2} has frame_index="
                f"{row['frame_index']!r}, expected {index!r}"
            )
    return rows


def require_exact_traces(
    opencv_rows: list[dict[str, str]], rust_rows: list[dict[str, str]]
) -> None:
    for index, (opencv_row, rust_row) in enumerate(zip(opencv_rows, rust_rows)):
        for field in EXACT_FIELDS:
            if opencv_row[field] != rust_row[field]:
                raise ValueError(
                    f"trace mismatch at frame {index}, field {field}: "
                    f"OpenCV={opencv_row[field]!r}, Rust={rust_row[field]!r}"
                )


def fourcc_text(value: float) -> str | None:
    integer = int(value)
    if integer == 0:
        return None
    text = "".join(chr((integer >> (8 * offset)) & 0xFF) for offset in range(4))
    return text if all(32 <= ord(character) <= 126 for character in text) else None


def probe_source(path: Path) -> dict[str, Any]:
    capture = cv2.VideoCapture(os.fspath(path))
    try:
        if not capture.isOpened():
            raise ValueError(f"could not open source video: {path}")
        width = int(round(capture.get(cv2.CAP_PROP_FRAME_WIDTH)))
        height = int(round(capture.get(cv2.CAP_PROP_FRAME_HEIGHT)))
        fps = float(capture.get(cv2.CAP_PROP_FPS))
        if width <= 0 or height <= 0 or not math.isfinite(fps) or fps <= 0.0:
            raise ValueError(
                f"invalid source metadata: width={width}, height={height}, fps={fps}"
            )
        return {
            "width": width,
            "height": height,
            "fps": fps,
            "reported_frame_count": int(
                round(capture.get(cv2.CAP_PROP_FRAME_COUNT))
            ),
            "reported_codec": fourcc_text(capture.get(cv2.CAP_PROP_FOURCC)),
        }
    finally:
        capture.release()


def parse_box(row: dict[str, str], frame_index: int) -> tuple[int, int, int, int]:
    values = [
        float(row[field])
        for field in ("bbox_x", "bbox_y", "bbox_width", "bbox_height")
    ]
    if not all(math.isfinite(value) for value in values):
        raise ValueError(f"frame {frame_index}: non-finite bounding box {values}")
    x, y, width, height = (int(round(value)) for value in values)
    if width <= 0 or height <= 0:
        raise ValueError(
            f"frame {frame_index}: invalid bounding-box size {width}x{height}"
        )
    return x, y, width, height


def annotate(
    frame: Any, row: dict[str, str], implementation: str, frame_index: int
) -> Any:
    panel = frame.copy()
    is_initialization = row["is_initialization"] == "1"
    success = row["success"] == "1"
    if is_initialization:
        status, color = "INITIALIZED", (0, 215, 255)
    elif success:
        status, color = "SUCCESS", (0, 220, 0)
    else:
        status, color = "FAILED", (0, 0, 255)

    x, y, width, height = parse_box(row, frame_index)
    cv2.rectangle(
        panel,
        (x, y),
        (x + width - 1, y + height - 1),
        color,
        2,
        lineType=cv2.LINE_AA,
    )

    text = f"{implementation} | frame {frame_index}/{EXPECTED_FRAMES - 1} | {status}"
    font = cv2.FONT_HERSHEY_SIMPLEX
    scale = max(0.45, min(0.75, panel.shape[1] / 960.0))
    thickness = 2
    (text_width, text_height), baseline = cv2.getTextSize(
        text, font, scale, thickness
    )
    cv2.rectangle(
        panel,
        (0, 0),
        (min(panel.shape[1] - 1, text_width + 16), text_height + baseline + 14),
        (0, 0, 0),
        cv2.FILLED,
    )
    cv2.putText(
        panel,
        text,
        (8, text_height + 7),
        font,
        scale,
        color,
        thickness,
        lineType=cv2.LINE_AA,
    )
    return panel


def validate_encoded_video(
    path: Path, expected_width: int, expected_height: int, expected_fps: float
) -> dict[str, Any]:
    capture = cv2.VideoCapture(os.fspath(path))
    try:
        if not capture.isOpened():
            raise CodecError(f"encoded file is not readable: {path}")
        width = int(round(capture.get(cv2.CAP_PROP_FRAME_WIDTH)))
        height = int(round(capture.get(cv2.CAP_PROP_FRAME_HEIGHT)))
        fps = float(capture.get(cv2.CAP_PROP_FPS))
        codec = fourcc_text(capture.get(cv2.CAP_PROP_FOURCC))
        frames = 0
        while True:
            ok, frame = capture.read()
            if not ok:
                break
            if frame.shape[1] != expected_width or frame.shape[0] != expected_height:
                raise CodecError(
                    f"encoded frame {frames} has dimensions "
                    f"{frame.shape[1]}x{frame.shape[0]}"
                )
            frames += 1
    finally:
        capture.release()

    if width != expected_width or height != expected_height:
        raise CodecError(
            f"encoded dimensions are {width}x{height}, expected "
            f"{expected_width}x{expected_height}"
        )
    if frames != EXPECTED_FRAMES:
        raise CodecError(
            f"encoded file has {frames} frames, expected {EXPECTED_FRAMES}"
        )
    if not math.isclose(fps, expected_fps, rel_tol=1e-6, abs_tol=1e-3):
        raise CodecError(f"encoded fps is {fps}, expected {expected_fps}")
    return {
        "reported_codec": codec,
        "reported_fps": fps,
        "frames": frames,
        "width": width,
        "height": height,
    }


def render_with_codec(
    source: Path,
    opencv_rows: list[dict[str, str]],
    rust_rows: list[dict[str, str]],
    source_metadata: dict[str, Any],
    codec: str,
    temporary_output: Path,
) -> dict[str, Any]:
    width = int(source_metadata["width"])
    height = int(source_metadata["height"])
    fps = float(source_metadata["fps"])
    capture = cv2.VideoCapture(os.fspath(source))
    writer = cv2.VideoWriter(
        os.fspath(temporary_output),
        cv2.VideoWriter_fourcc(*codec),
        fps,
        (width * 2, height),
    )
    try:
        if not capture.isOpened():
            raise ValueError(f"could not reopen source video: {source}")
        if not writer.isOpened():
            raise CodecError(f"VideoWriter could not open codec {codec}")

        for frame_index, (opencv_row, rust_row) in enumerate(
            zip(opencv_rows, rust_rows)
        ):
            ok, frame = capture.read()
            if not ok:
                raise ValueError(
                    f"source video ended before frame {frame_index}; "
                    f"expected {EXPECTED_FRAMES} frames"
                )
            if frame.shape[1] != width or frame.shape[0] != height:
                raise ValueError(
                    f"source frame {frame_index} has dimensions "
                    f"{frame.shape[1]}x{frame.shape[0]}, expected {width}x{height}"
                )
            left = annotate(frame, opencv_row, "OpenCV", frame_index)
            right = annotate(frame, rust_row, "Rust", frame_index)
            writer.write(cv2.hconcat((left, right)))

        extra, _ = capture.read()
        if extra:
            raise ValueError(
                f"source video contains more than {EXPECTED_FRAMES} decoded frames"
            )
    finally:
        writer.release()
        capture.release()

    if not temporary_output.is_file() or temporary_output.stat().st_size == 0:
        raise CodecError(f"codec {codec} produced no output")
    result = validate_encoded_video(temporary_output, width * 2, height, fps)
    result["requested_codec"] = codec
    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Render side-by-side OpenCV/Rust annotations from exact saved CSV "
            "traces; neither tracker is executed."
        )
    )
    parser.add_argument("--source-video", required=True, type=Path)
    parser.add_argument("--opencv-csv", required=True, type=Path)
    parser.add_argument("--rust-csv", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--manifest", required=True, type=Path)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    for path in (args.source_video, args.opencv_csv, args.rust_csv):
        if not path.is_file():
            raise SystemExit(f"input does not exist: {path}")
    if args.output.suffix.lower() != ".mp4":
        raise SystemExit("--output must name an .mp4 file")

    input_paths = {
        args.source_video.resolve(),
        args.opencv_csv.resolve(),
        args.rust_csv.resolve(),
    }
    if args.output.resolve() in input_paths or args.manifest.resolve() in input_paths:
        raise SystemExit("output and manifest paths must not overwrite an input")
    if args.output.resolve() == args.manifest.resolve():
        raise SystemExit("output and manifest must be different paths")

    source_sha256 = sha256_file(args.source_video)
    if source_sha256 != EXPECTED_SOURCE_SHA256:
        raise SystemExit(
            f"source SHA-256 mismatch: {source_sha256}; "
            f"expected {EXPECTED_SOURCE_SHA256}"
        )

    try:
        opencv_rows = read_trace(args.opencv_csv)
        rust_rows = read_trace(args.rust_csv)
        require_exact_traces(opencv_rows, rust_rows)
        source_metadata = probe_source(args.source_video)
    except (OSError, csv.Error, ValueError) as exc:
        raise SystemExit(str(exc)) from exc

    args.output.parent.mkdir(parents=True, exist_ok=True)
    render_metadata: dict[str, Any] | None = None
    codec_errors: list[str] = []
    temporary_output: Path | None = None
    for codec in CODECS:
        temporary_output = args.output.parent / (
            f".{args.output.stem}.{uuid.uuid4().hex}.{codec}.mp4"
        )
        try:
            render_metadata = render_with_codec(
                args.source_video,
                opencv_rows,
                rust_rows,
                source_metadata,
                codec,
                temporary_output,
            )
            temporary_output.replace(args.output)
            temporary_output = None
            break
        except CodecError as exc:
            codec_errors.append(str(exc))
            temporary_output.unlink(missing_ok=True)
            temporary_output = None
        except (OSError, ValueError) as exc:
            temporary_output.unlink(missing_ok=True)
            raise SystemExit(str(exc)) from exc
    if render_metadata is None:
        raise SystemExit("all output codecs failed: " + "; ".join(codec_errors))

    manifest = {
        "schema_version": 1,
        "post_timing_render": True,
        "tracker_executed": False,
        "renderer": {
            "path": str(Path(__file__).resolve()),
            "sha256": sha256_file(Path(__file__).resolve()),
            "bytes": Path(__file__).resolve().stat().st_size,
        },
        "expected_source_sha256": EXPECTED_SOURCE_SHA256,
        "expected_frames": EXPECTED_FRAMES,
        "exact_fields": list(EXACT_FIELDS),
        "literal_trace_exact": True,
        "inputs": {
            "source_video": {
                "path": str(args.source_video.resolve()),
                "sha256": source_sha256,
                "bytes": args.source_video.stat().st_size,
                **source_metadata,
            },
            "opencv_csv": {
                "path": str(args.opencv_csv.resolve()),
                "sha256": sha256_file(args.opencv_csv),
                "bytes": args.opencv_csv.stat().st_size,
                "rows": len(opencv_rows),
            },
            "rust_csv": {
                "path": str(args.rust_csv.resolve()),
                "sha256": sha256_file(args.rust_csv),
                "bytes": args.rust_csv.stat().st_size,
                "rows": len(rust_rows),
            },
        },
        "output": {
            "path": str(args.output.resolve()),
            "sha256": sha256_file(args.output),
            "bytes": args.output.stat().st_size,
            "panel_width": source_metadata["width"],
            "panel_height": source_metadata["height"],
            "requested_fps": source_metadata["fps"],
            **render_metadata,
        },
    }

    args.manifest.parent.mkdir(parents=True, exist_ok=True)
    temporary_manifest = args.manifest.parent / (
        f".{args.manifest.name}.{uuid.uuid4().hex}.tmp"
    )
    try:
        temporary_manifest.write_text(
            json.dumps(manifest, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        temporary_manifest.replace(args.manifest)
    finally:
        temporary_manifest.unlink(missing_ok=True)

    print(json.dumps(manifest, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
