#!/usr/bin/env python3
"""Select and persist the benchmark ROI from the first decoded video frame."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2


WINDOW_TITLE = "MOSSE ROI - drag around the drone, then press Enter"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("video", type=Path, help="Source video")
    parser.add_argument("--output", type=Path, required=True, help="ROI JSON path")
    parser.add_argument(
        "--preview", type=Path, required=True, help="Annotated first-frame image"
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    capture = cv2.VideoCapture(str(args.video))
    ok, frame = capture.read()
    capture.release()
    if not ok or frame is None:
        raise SystemExit(f"Could not decode frame 0 from {args.video}")

    cv2.namedWindow(WINDOW_TITLE, cv2.WINDOW_AUTOSIZE)
    x, y, width, height = (
        int(value)
        for value in cv2.selectROI(
            WINDOW_TITLE, frame, showCrosshair=True, fromCenter=False
        )
    )
    cv2.destroyAllWindows()
    if width <= 0 or height <= 0:
        raise SystemExit("ROI selection was cancelled")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.preview.parent.mkdir(parents=True, exist_ok=True)
    selection = {
        "frame_index": 0,
        "x": x,
        "y": y,
        "width": width,
        "height": height,
    }
    args.output.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")

    annotated = frame.copy()
    cv2.rectangle(
        annotated,
        (x, y),
        (x + width, y + height),
        color=(0, 255, 0),
        thickness=2,
    )
    cv2.putText(
        annotated,
        f"ROI: x={x} y={y} w={width} h={height}",
        (16, 32),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.75,
        (0, 255, 0),
        2,
        cv2.LINE_AA,
    )
    if not cv2.imwrite(str(args.preview), annotated):
        raise SystemExit(f"Could not write preview to {args.preview}")

    print(json.dumps(selection))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
