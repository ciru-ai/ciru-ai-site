#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct MosseHandle MosseHandle;

typedef int32_t MosseStatus;

#define MOSSE_ABI_VERSION UINT32_C(1)

/*
 * Threading and lifetime contract:
 * - Calls using the same handle must not overlap, including diagnostics and destroy.
 * - If initialization selects MOSSE_BACKEND_FIXED_MULTICORE, every subsequent
 *   update, query, and destroy call must run on the same OS thread that initialized
 *   the handle.
 * - Other backends have no thread-affinity requirement beyond non-overlap.
 * - A frame allocation must remain live and immutable for the full duration of a call.
 * - Frame storage must be one contiguous allocation. Every byte through
 *   stride * (height - 1) + width * 3 must be initialized, including row padding.
 */

enum {
  MOSSE_STATUS_OK = 0,
  MOSSE_STATUS_NULL_POINTER = -1,
  MOSSE_STATUS_INVALID_CONFIG = -2,
  MOSSE_STATUS_INVALID_FRAME = -3,
  MOSSE_STATUS_INVALID_BOUNDING_BOX = -4,
  MOSSE_STATUS_WINDOW_TOO_LARGE = -5,
  MOSSE_STATUS_NOT_INITIALIZED = -6,
  MOSSE_STATUS_INVALID_MODE = -7,
  MOSSE_STATUS_PANIC = -127
};

typedef int32_t MosseMode;

enum {
  MOSSE_MODE_AUTO = 0,
  MOSSE_MODE_SINGLE = 1,
  MOSSE_MODE_MULTICORE = 2
};

typedef int32_t MosseBackendStatus;

enum {
  MOSSE_BACKEND_UNINITIALIZED = 0,
  MOSSE_BACKEND_GENERIC_SINGLE = 1,
  MOSSE_BACKEND_FIXED_SINGLE = 2,
  MOSSE_BACKEND_FIXED_MULTICORE = 3
};

typedef struct MosseRect {
  double x;
  double y;
  double width;
  double height;
} MosseRect;

typedef struct MosseConfig {
  double learning_rate;
  double epsilon;
  double psr_threshold;
  uint64_t random_seed;
  uint32_t training_warps;
  uint32_t reserved;
} MosseConfig;

typedef struct MosseDiagnostics {
  uint8_t initialized;
  uint8_t last_success;
  uint8_t reserved[6];
  uint64_t updates;
  uint32_t window_width;
  uint32_t window_height;
  int32_t delta_x;
  int32_t delta_y;
  double center_x;
  double center_y;
  double psr;
  double peak;
  double response_mean;
  double response_stddev;
} MosseDiagnostics;

/* Infallibly returns MOSSE_ABI_VERSION for loader compatibility checks. */
uint32_t mosse_abi_version(void);

MosseStatus mosse_default_config(MosseConfig *output);

/* Legacy entry point retaining MOSSE_RUST_CORES environment selection. */
MosseStatus mosse_create(const MosseConfig *config,
                         MosseHandle **output_handle);

/*
 * Creates a tracker with an explicit per-handle mode. This call never reads
 * or modifies MOSSE_RUST_CORES. AUTO and MULTICORE safely fall back when the
 * validated fixed-layout Linux/AArch64 four-core runtime is unavailable.
 */
MosseStatus mosse_create_with_mode(const MosseConfig *config, MosseMode mode,
                                   MosseHandle **output_handle);

MosseStatus mosse_init(MosseHandle *handle, const uint8_t *bgr_data,
                       size_t width, size_t height, size_t stride,
                       MosseRect bounding_box);

MosseStatus mosse_update(MosseHandle *handle, const uint8_t *bgr_data,
                         size_t width, size_t height, size_t stride,
                         MosseRect *output_bounding_box,
                         uint8_t *output_success);

MosseStatus mosse_get_diagnostics(const MosseHandle *handle,
                                  MosseDiagnostics *output);

/* Reports one MOSSE_BACKEND_* value; uninitialized trackers report zero. */
MosseStatus mosse_get_backend_status(const MosseHandle *handle,
                                     MosseBackendStatus *output);

MosseStatus mosse_destroy(MosseHandle *handle);

#ifdef __cplusplus
} // extern "C"
#endif
