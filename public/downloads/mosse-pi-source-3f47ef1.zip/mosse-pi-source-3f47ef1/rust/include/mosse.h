#ifndef MOSSE_CORE_H
#define MOSSE_CORE_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct mosse_handle mosse_handle;
typedef int32_t mosse_status;

#define MOSSE_ABI_VERSION UINT32_C(1)

/*
 * Threading and lifetime contract:
 * - Calls using the same handle must not overlap, including diagnostics and destroy.
 * - If initialization selects MOSSE_BACKEND_FIXED_MULTICORE, every subsequent
 *   update, query, and destroy call must run on the same OS thread that initialized
 *   the handle.
 * - Other backends have no thread-affinity requirement beyond non-overlap.
 * - A frame allocation must remain live and immutable for the full duration of a call.
 * - Frame storage must be one contiguous allocation. Every byte through
 *   stride * (height - 1) + width * 3 must be initialized, including row padding.
 */

enum {
    MOSSE_STATUS_OK = 0,
    MOSSE_STATUS_NULL_POINTER = -1,
    MOSSE_STATUS_INVALID_CONFIG = -2,
    MOSSE_STATUS_INVALID_FRAME = -3,
    MOSSE_STATUS_INVALID_BOUNDING_BOX = -4,
    MOSSE_STATUS_WINDOW_TOO_LARGE = -5,
    MOSSE_STATUS_NOT_INITIALIZED = -6,
    MOSSE_STATUS_INVALID_MODE = -7,
    MOSSE_STATUS_PANIC = -127
};

typedef int32_t mosse_mode;

enum {
    MOSSE_MODE_AUTO = 0,
    MOSSE_MODE_SINGLE = 1,
    MOSSE_MODE_MULTICORE = 2
};

typedef int32_t mosse_backend_status;

enum {
    MOSSE_BACKEND_UNINITIALIZED = 0,
    MOSSE_BACKEND_GENERIC_SINGLE = 1,
    MOSSE_BACKEND_FIXED_SINGLE = 2,
    MOSSE_BACKEND_FIXED_MULTICORE = 3
};

typedef struct mosse_rect {
    double x;
    double y;
    double width;
    double height;
} mosse_rect;

typedef struct mosse_config {
    double learning_rate;
    double epsilon;
    double psr_threshold;
    uint64_t random_seed;
    uint32_t training_warps;
    uint32_t reserved;
} mosse_config;

typedef struct mosse_diagnostics {
    uint8_t initialized;
    uint8_t last_success;
    uint8_t reserved[6];
    uint64_t updates;
    uint32_t window_width;
    uint32_t window_height;
    int32_t delta_x;
    int32_t delta_y;
    double center_x;
    double center_y;
    double psr;
    double peak;
    double response_mean;
    double response_stddev;
} mosse_diagnostics;

/* Infallibly returns MOSSE_ABI_VERSION for loader compatibility checks. */
uint32_t mosse_abi_version(void);

mosse_status mosse_default_config(mosse_config* output);

/*
 * A null config selects OpenCV-compatible defaults. The returned handle is
 * exclusively mutable and must be released exactly once with mosse_destroy.
 * This legacy entry point retains MOSSE_RUST_CORES environment selection.
 */
mosse_status mosse_create(const mosse_config* config, mosse_handle** output_handle);

/*
 * Creates a tracker with an explicit per-handle mode. This call never reads
 * or modifies MOSSE_RUST_CORES. AUTO and MULTICORE safely fall back when the
 * validated fixed-layout Linux/AArch64 four-core runtime is unavailable.
 */
mosse_status mosse_create_with_mode(
    const mosse_config* config,
    mosse_mode mode,
    mosse_handle** output_handle);

/*
 * Frames are interleaved BGR8. stride is the distance in bytes between rows
 * and must be at least width * 3. See the lifetime contract above.
 */
mosse_status mosse_init(
    mosse_handle* handle,
    const uint8_t* bgr_data,
    size_t width,
    size_t height,
    size_t stride,
    mosse_rect bounding_box);

/*
 * A low-confidence tracking result is not an API error: this returns
 * MOSSE_STATUS_OK and writes 0 to output_success.
 */
mosse_status mosse_update(
    mosse_handle* handle,
    const uint8_t* bgr_data,
    size_t width,
    size_t height,
    size_t stride,
    mosse_rect* output_bounding_box,
    uint8_t* output_success);

mosse_status mosse_get_diagnostics(
    const mosse_handle* handle,
    mosse_diagnostics* output);

/* Reports one MOSSE_BACKEND_* value; uninitialized trackers report zero. */
mosse_status mosse_get_backend_status(
    const mosse_handle* handle,
    mosse_backend_status* output);

/* A null handle is accepted as a no-op. */
mosse_status mosse_destroy(mosse_handle* handle);

#ifdef __cplusplus
}
#endif

#endif
