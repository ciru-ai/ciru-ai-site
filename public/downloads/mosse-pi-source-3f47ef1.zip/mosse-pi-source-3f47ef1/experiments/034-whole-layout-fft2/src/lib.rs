//! Experiment 034: fixed 60x36 whole-layout FFT ceiling.
//!
//! This crate deliberately stays outside the tracker. It composes the proven
//! Experiment 031 four-row RFFT60 and Experiment 028 four-column CFFT36
//! kernels around a persistent padded spectrum. The row-to-column transition
//! is a tiled 4x4 transpose, not a whole-spectrum AoS pack/unpack wrapper.
//!
//! The retained half-spectrum contains 31 real-frequency columns. Storage has
//! eight four-lane column batches, so lane three of the final batch is a
//! permanently padded 32nd column. Forward and inverse transforms are both
//! unnormalized; a round trip therefore has scale 60 * 36 = 2160.

use mosse_exp028_aosoa_cfft36::{Batch4 as ColumnBatch4, Kernel36x4, FFT_LEN as COLUMN_LEN};
use mosse_exp031_aosoa_rfft60::{
    ComplexBatch4 as RowSpectrum4, Kernel60x4, RealBatch4 as RealRows4, REAL_LEN as ROW_LEN,
    UNIQUE_LEN,
};
use rustfft::num_complex::Complex32;

pub const WIDTH: usize = ROW_LEN;
pub const HEIGHT: usize = COLUMN_LEN;
pub const LANES: usize = 4;
pub const ROW_BATCHES: usize = HEIGHT / LANES;
pub const COLUMN_BATCHES: usize = UNIQUE_LEN.div_ceil(LANES);
pub const PADDED_SPECTRUM_WIDTH: usize = COLUMN_BATCHES * LANES;
pub const VALID_SPECTRUM_LEN: usize = UNIQUE_LEN * HEIGHT;
pub const PADDED_SPECTRUM_LEN: usize = PADDED_SPECTRUM_WIDTH * HEIGHT;
pub const SPATIAL_LEN: usize = WIDTH * HEIGHT;
pub const ROUND_TRIP_SCALE: f32 = SPATIAL_LEN as f32;

const _: () = {
    assert!((HEIGHT & (LANES - 1)) == 0);
    assert!(UNIQUE_LEN == 31);
    assert!(COLUMN_BATCHES == 8);
    assert!(PADDED_SPECTRUM_WIDTH == 32);
};

/// Persistent split-complex spectrum in `[kx_batch][ky][kx_lane]` order.
///
/// This ceiling reuses the already validated split-complex CFFT36 codelet.
/// The production layout recommendation in `protocol.md` is the equivalent
/// interleaved `Complex32` order, which keeps tracker pointwise loops flat.
#[derive(Clone, Debug, PartialEq)]
pub struct PaddedSpectrum {
    pub batches: [ColumnBatch4; COLUMN_BATCHES],
}

impl Default for PaddedSpectrum {
    fn default() -> Self {
        Self {
            batches: std::array::from_fn(|_| ColumnBatch4::default()),
        }
    }
}

impl PaddedSpectrum {
    #[inline]
    pub fn get(&self, kx: usize, ky: usize) -> Complex32 {
        assert!(kx < PADDED_SPECTRUM_WIDTH);
        assert!(ky < HEIGHT);
        let batch = kx / LANES;
        let lane = kx % LANES;
        Complex32::new(
            self.batches[batch].re[ky][lane],
            self.batches[batch].im[ky][lane],
        )
    }

    #[inline]
    pub fn set(&mut self, kx: usize, ky: usize, value: Complex32) {
        assert!(kx < PADDED_SPECTRUM_WIDTH);
        assert!(ky < HEIGHT);
        let batch = kx / LANES;
        let lane = kx % LANES;
        self.batches[batch].re[ky][lane] = value.re;
        self.batches[batch].im[ky][lane] = value.im;
    }

    /// Extract the 31x36 logical half-spectrum in the production tracker's
    /// current column-major order, solely for oracle validation.
    pub fn to_column_major_valid(&self) -> Vec<Complex32> {
        let mut output = vec![Complex32::new(0.0, 0.0); VALID_SPECTRUM_LEN];
        for kx in 0..UNIQUE_LEN {
            for ky in 0..HEIGHT {
                output[kx * HEIGHT + ky] = self.get(kx, ky);
            }
        }
        output
    }

    /// Construct from the current tracker's 31x36 column-major half-spectrum.
    /// This is an oracle/test helper, not part of the proposed hot path.
    pub fn from_column_major_valid(values: &[Complex32]) -> Self {
        assert_eq!(values.len(), VALID_SPECTRUM_LEN);
        let mut output = Self::default();
        for kx in 0..UNIQUE_LEN {
            for ky in 0..HEIGHT {
                output.set(kx, ky, values[kx * HEIGHT + ky]);
            }
        }
        output
    }

    pub fn padding_is_positive_zero(&self) -> bool {
        let padding_lane = LANES - 1;
        self.batches[COLUMN_BATCHES - 1]
            .re
            .iter()
            .zip(&self.batches[COLUMN_BATCHES - 1].im)
            .all(|(re, im)| re[padding_lane].to_bits() == 0 && im[padding_lane].to_bits() == 0)
    }

    pub fn poison_all(&mut self, salt: u32) {
        for batch in 0..COLUMN_BATCHES {
            for ky in 0..HEIGHT {
                for lane in 0..LANES {
                    let index = ((batch * HEIGHT + ky) * LANES + lane) as u32;
                    let re_payload = (index.wrapping_mul(17).wrapping_add(salt) & 0x003f_ffff) | 1;
                    let im_payload =
                        (index.wrapping_mul(29).wrapping_add(salt ^ 0x1357) & 0x003f_ffff) | 1;
                    self.batches[batch].re[ky][lane] = f32::from_bits(0x7fc0_0000 | re_payload);
                    self.batches[batch].im[ky][lane] = f32::from_bits(0x7fc0_0000 | im_payload);
                }
            }
        }
    }
}

/// Persistent whole-layout fixed FFT state.
pub struct WholeLayoutFft2 {
    row_kernel: Kernel60x4,
    column_kernels: [Kernel36x4; COLUMN_BATCHES],
    row_input: RealRows4,
    row_spectrum: RowSpectrum4,
    row_output: RealRows4,
}

impl Default for WholeLayoutFft2 {
    fn default() -> Self {
        Self::new()
    }
}

impl WholeLayoutFft2 {
    pub fn new() -> Self {
        Self {
            row_kernel: Kernel60x4::new(),
            column_kernels: std::array::from_fn(|_| Kernel36x4::new()),
            row_input: RealRows4::default(),
            row_spectrum: RowSpectrum4::default(),
            row_output: RealRows4::default(),
        }
    }

    pub const fn backend_name() -> &'static str {
        #[cfg(target_arch = "aarch64")]
        {
            "aarch64-neon"
        }
        #[cfg(not(target_arch = "aarch64"))]
        {
            "portable-scalar-source"
        }
    }

    /// Poison every persistent scratch and staging area. A subsequent result
    /// must be bit-identical to a clean call.
    pub fn poison_scratch(&mut self, salt: u32) {
        self.row_kernel.poison_scratch(salt ^ 0x0310);
        for (index, kernel) in self.column_kernels.iter_mut().enumerate() {
            kernel.poison_scratch(salt ^ 0x2800 ^ (index as u32 * 0x101));
        }
        poison_real_rows(&mut self.row_input, salt ^ 0xa100);
        poison_real_rows(&mut self.row_output, salt ^ 0xb200);
        poison_row_spectrum(&mut self.row_spectrum, salt ^ 0xc300);
    }

    /// Complete unnormalized real-to-complex 60x36 transform.
    ///
    /// The call includes row-major gathering, all nine RFFT60 batches, every
    /// tiled row-to-column transpose, explicit padded-lane zeroing, and all
    /// eight CFFT36 batches.
    pub fn forward(&mut self, input: &[f32], output: &mut PaddedSpectrum) {
        assert_eq!(input.len(), SPATIAL_LEN);

        for row_batch in 0..ROW_BATCHES {
            let row_base = row_batch * LANES;
            for x in 0..WIDTH {
                self.row_input.values[x] = [
                    input[row_base * WIDTH + x],
                    input[(row_base + 1) * WIDTH + x],
                    input[(row_base + 2) * WIDTH + x],
                    input[(row_base + 3) * WIDTH + x],
                ];
            }

            self.row_kernel
                .process_forward(&self.row_input, &mut self.row_spectrum);
            transpose_rows_to_columns(&self.row_spectrum, row_batch, &mut output.batches);
        }

        for (kernel, batch) in self
            .column_kernels
            .iter_mut()
            .zip(output.batches.iter_mut())
        {
            kernel.process_forward(batch);
        }
    }

    /// Complete unnormalized complex-to-real 60x36 transform.
    ///
    /// The spectrum is consumed in place, matching the production `Fft2`
    /// contract. The call includes all eight inverse CFFT36 batches, every
    /// reverse 4x4 transpose, all nine inverse RFFT60 batches, and row-major
    /// output scattering.
    pub fn inverse(&mut self, spectrum: &mut PaddedSpectrum, output: &mut [f32]) {
        assert_eq!(output.len(), SPATIAL_LEN);

        for (kernel, batch) in self
            .column_kernels
            .iter_mut()
            .zip(spectrum.batches.iter_mut())
        {
            kernel.process_inverse(batch);
        }

        for row_batch in 0..ROW_BATCHES {
            transpose_columns_to_rows(&spectrum.batches, row_batch, &mut self.row_spectrum);
            self.row_kernel
                .process_inverse(&self.row_spectrum, &mut self.row_output);

            let row_base = row_batch * LANES;
            for x in 0..WIDTH {
                let values = self.row_output.values[x];
                output[row_base * WIDTH + x] = values[0];
                output[(row_base + 1) * WIDTH + x] = values[1];
                output[(row_base + 2) * WIDTH + x] = values[2];
                output[(row_base + 3) * WIDTH + x] = values[3];
            }
        }
    }
}

#[inline(always)]
fn transpose_rows_to_columns(
    rows: &RowSpectrum4,
    row_batch: usize,
    columns: &mut [ColumnBatch4; COLUMN_BATCHES],
) {
    let ky_base = row_batch * LANES;
    for (column_batch, column) in columns.iter_mut().enumerate() {
        let kx_base = column_batch * LANES;
        let mut re = [[0.0; LANES]; LANES];
        let mut im = [[0.0; LANES]; LANES];
        for kx_lane in 0..LANES {
            let kx = kx_base + kx_lane;
            if kx < UNIQUE_LEN {
                re[kx_lane] = rows.re[kx];
                im[kx_lane] = rows.im[kx];
            }
        }
        let re = transpose4x4(re);
        let im = transpose4x4(im);
        column.re[ky_base..ky_base + LANES].copy_from_slice(&re);
        column.im[ky_base..ky_base + LANES].copy_from_slice(&im);
    }
}

#[inline(always)]
fn transpose_columns_to_rows(
    columns: &[ColumnBatch4; COLUMN_BATCHES],
    row_batch: usize,
    rows: &mut RowSpectrum4,
) {
    let ky_base = row_batch * LANES;
    for (column_batch, column) in columns.iter().enumerate() {
        let kx_base = column_batch * LANES;
        let re = transpose4x4([
            column.re[ky_base],
            column.re[ky_base + 1],
            column.re[ky_base + 2],
            column.re[ky_base + 3],
        ]);
        let im = transpose4x4([
            column.im[ky_base],
            column.im[ky_base + 1],
            column.im[ky_base + 2],
            column.im[ky_base + 3],
        ]);
        for kx_lane in 0..LANES {
            let kx = kx_base + kx_lane;
            if kx < UNIQUE_LEN {
                rows.re[kx] = re[kx_lane];
                rows.im[kx] = im[kx_lane];
            }
        }
    }
}

#[cfg(target_arch = "aarch64")]
#[inline(always)]
fn transpose4x4(input: [[f32; LANES]; LANES]) -> [[f32; LANES]; LANES] {
    use core::arch::aarch64::{
        float32x4_t, vcombine_f32, vget_high_f32, vget_low_f32, vld1q_f32, vst1q_f32, vtrn1q_f32,
        vtrn2q_f32,
    };

    // SAFETY: every load and store spans exactly one `[f32; 4]`. NEON is a
    // mandatory part of AArch64, and the intrinsics accept unaligned pointers.
    unsafe {
        let a = vld1q_f32(input[0].as_ptr());
        let b = vld1q_f32(input[1].as_ptr());
        let c = vld1q_f32(input[2].as_ptr());
        let d = vld1q_f32(input[3].as_ptr());
        let ab_low = vtrn1q_f32(a, b);
        let ab_high = vtrn2q_f32(a, b);
        let cd_low = vtrn1q_f32(c, d);
        let cd_high = vtrn2q_f32(c, d);
        let outputs: [float32x4_t; LANES] = [
            vcombine_f32(vget_low_f32(ab_low), vget_low_f32(cd_low)),
            vcombine_f32(vget_low_f32(ab_high), vget_low_f32(cd_high)),
            vcombine_f32(vget_high_f32(ab_low), vget_high_f32(cd_low)),
            vcombine_f32(vget_high_f32(ab_high), vget_high_f32(cd_high)),
        ];
        let mut result = [[0.0; LANES]; LANES];
        for index in 0..LANES {
            vst1q_f32(result[index].as_mut_ptr(), outputs[index]);
        }
        result
    }
}

#[cfg(not(target_arch = "aarch64"))]
#[inline(always)]
fn transpose4x4(input: [[f32; LANES]; LANES]) -> [[f32; LANES]; LANES] {
    let mut output = [[0.0; LANES]; LANES];
    for y in 0..LANES {
        for x in 0..LANES {
            output[y][x] = input[x][y];
        }
    }
    output
}

fn poison_real_rows(rows: &mut RealRows4, salt: u32) {
    for index in 0..WIDTH {
        for lane in 0..LANES {
            let payload = ((index as u32 * 17 + lane as u32 * 29 + salt) & 0x003f_ffff) | 1;
            rows.values[index][lane] = f32::from_bits(0x7fc0_0000 | payload);
        }
    }
}

fn poison_row_spectrum(spectrum: &mut RowSpectrum4, salt: u32) {
    for index in 0..UNIQUE_LEN {
        for lane in 0..LANES {
            let re_payload = ((index as u32 * 31 + lane as u32 * 43 + salt) & 0x003f_ffff) | 1;
            let im_payload = ((index as u32 * 47 + lane as u32 * 59 + salt) & 0x003f_ffff) | 1;
            spectrum.re[index][lane] = f32::from_bits(0x7fc0_0000 | re_payload);
            spectrum.im[index][lane] = f32::from_bits(0x7fc0_0000 | im_payload);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use realfft::RealFftPlanner;
    use rustfft::FftPlanner;

    const ABS_TOLERANCE: f32 = 2.0e-2;
    const REL_TOLERANCE: f32 = 2.0e-6;

    fn assert_close(actual: f32, expected: f32, reference_scale: f32, context: &str) {
        assert!(
            actual.is_finite(),
            "{context}: non-finite actual {actual:?}"
        );
        assert!(
            expected.is_finite(),
            "{context}: non-finite expected {expected:?}"
        );
        let error = (actual - expected).abs();
        let allowed = ABS_TOLERANCE + REL_TOLERANCE * reference_scale;
        assert!(
            error <= allowed,
            "{context}: actual={actual:.9e} expected={expected:.9e} \
             error={error:.9e} allowed={allowed:.9e}"
        );
    }

    fn complex_reference_scale(values: &[Complex32]) -> f32 {
        values.iter().fold(0.0f32, |scale, value| {
            scale.max(value.re.abs()).max(value.im.abs())
        })
    }

    fn real_reference_scale(values: &[f32]) -> f32 {
        values
            .iter()
            .fold(0.0f32, |scale, value| scale.max(value.abs()))
    }

    fn oracle_forward(input: &[f32]) -> Vec<Complex32> {
        let mut real_planner = RealFftPlanner::<f32>::new();
        let row_plan = real_planner.plan_fft_forward(WIDTH);
        let mut row_input = vec![0.0; WIDTH];
        let mut row_output = row_plan.make_output_vec();
        let mut output = vec![Complex32::new(0.0, 0.0); VALID_SPECTRUM_LEN];

        for y in 0..HEIGHT {
            row_input.copy_from_slice(&input[y * WIDTH..(y + 1) * WIDTH]);
            row_plan
                .process(&mut row_input, &mut row_output)
                .expect("oracle row forward buffers");
            for kx in 0..UNIQUE_LEN {
                output[kx * HEIGHT + y] = row_output[kx];
            }
        }

        let mut planner = FftPlanner::<f32>::new();
        let column_plan = planner.plan_fft_forward(HEIGHT);
        column_plan.process(&mut output);
        output
    }

    fn oracle_inverse(input: &[Complex32]) -> Vec<f32> {
        let mut columns = input.to_vec();
        let mut planner = FftPlanner::<f32>::new();
        let column_plan = planner.plan_fft_inverse(HEIGHT);
        column_plan.process(&mut columns);

        let mut real_planner = RealFftPlanner::<f32>::new();
        let row_plan = real_planner.plan_fft_inverse(WIDTH);
        let mut row_input = row_plan.make_input_vec();
        let mut row_output = row_plan.make_output_vec();
        let mut output = vec![0.0; SPATIAL_LEN];
        for y in 0..HEIGHT {
            for kx in 0..UNIQUE_LEN {
                row_input[kx] = columns[kx * HEIGHT + y];
            }
            row_input[0].im = 0.0;
            row_input[UNIQUE_LEN - 1].im = 0.0;
            row_plan
                .process(&mut row_input, &mut row_output)
                .expect("oracle row inverse buffers");
            output[y * WIDTH..(y + 1) * WIDTH].copy_from_slice(&row_output);
        }
        output
    }

    fn fixtures() -> Vec<Vec<f32>> {
        let zero = vec![0.0; SPATIAL_LEN];

        let mut impulse = vec![0.0; SPATIAL_LEN];
        impulse[17 * WIDTH + 23] = -0.75;
        impulse[35 * WIDTH + 59] = 0.5;

        let structured = (0..SPATIAL_LEN)
            .map(|index| {
                let x = (index % WIDTH) as f32;
                let y = (index / WIDTH) as f32;
                (x * 0.173).sin() * 0.4 + (y * 0.291).cos() * 0.6 + (x - y) * 0.001
            })
            .collect();

        let random = (0..SPATIAL_LEN)
            .map(|index| {
                let bits = splitmix64(0x0340_f00d_cafe_beef ^ index as u64);
                let fraction = ((bits >> 40) as u32) as f32 * (1.0 / 16_777_216.0);
                (fraction * 2.0 - 1.0) * if index % 7 == 0 { 1_000.0 } else { 0.25 }
            })
            .collect();

        vec![zero, impulse, structured, random]
    }

    fn splitmix64(mut value: u64) -> u64 {
        value = value.wrapping_add(0x9e37_79b9_7f4a_7c15);
        value = (value ^ (value >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
        value = (value ^ (value >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
        value ^ (value >> 31)
    }

    #[test]
    fn transpose_is_an_involution() {
        let input = [
            [0.0, 1.0, 2.0, 3.0],
            [4.0, 5.0, 6.0, 7.0],
            [8.0, 9.0, 10.0, 11.0],
            [12.0, 13.0, 14.0, 15.0],
        ];
        assert_eq!(transpose4x4(transpose4x4(input)), input);
    }

    #[test]
    fn complete_forward_and_inverse_match_oracles() {
        for (fixture_index, input) in fixtures().into_iter().enumerate() {
            let expected_spectrum = oracle_forward(&input);
            let forward_scale = complex_reference_scale(&expected_spectrum);
            let mut fft = WholeLayoutFft2::new();
            let mut actual_spectrum = PaddedSpectrum::default();
            fft.forward(&input, &mut actual_spectrum);
            assert!(
                actual_spectrum.padding_is_positive_zero(),
                "fixture {fixture_index}: padded column must remain +0"
            );

            for (index, (&actual, &expected)) in actual_spectrum
                .to_column_major_valid()
                .iter()
                .zip(&expected_spectrum)
                .enumerate()
            {
                assert_close(
                    actual.re,
                    expected.re,
                    forward_scale,
                    &format!("fixture={fixture_index} forward={index} re"),
                );
                assert_close(
                    actual.im,
                    expected.im,
                    forward_scale,
                    &format!("fixture={fixture_index} forward={index} im"),
                );
            }

            let expected_spatial = oracle_inverse(&expected_spectrum);
            let inverse_scale = real_reference_scale(&expected_spatial);
            let mut inverse_input = PaddedSpectrum::from_column_major_valid(&expected_spectrum);
            let mut actual_spatial = vec![f32::NAN; SPATIAL_LEN];
            fft.inverse(&mut inverse_input, &mut actual_spatial);
            for (index, (&actual, &expected)) in
                actual_spatial.iter().zip(&expected_spatial).enumerate()
            {
                assert_close(
                    actual,
                    expected,
                    inverse_scale,
                    &format!("fixture={fixture_index} inverse={index}"),
                );
            }

            let mut round_trip_spectrum = PaddedSpectrum::default();
            fft.forward(&input, &mut round_trip_spectrum);
            let mut round_trip = vec![f32::NAN; SPATIAL_LEN];
            fft.inverse(&mut round_trip_spectrum, &mut round_trip);
            let round_trip_scale = real_reference_scale(&input) * ROUND_TRIP_SCALE;
            for (index, (&actual, &value)) in round_trip.iter().zip(&input).enumerate() {
                assert_close(
                    actual,
                    value * ROUND_TRIP_SCALE,
                    round_trip_scale,
                    &format!("fixture={fixture_index} roundtrip={index}"),
                );
            }
        }
    }

    #[test]
    fn dirty_persistent_state_cannot_change_output_bits() {
        let input = fixtures().pop().expect("fixture");
        let mut clean = WholeLayoutFft2::new();
        let mut dirty = WholeLayoutFft2::new();
        dirty.poison_scratch(0x1234_5678);

        let mut expected_spectrum = PaddedSpectrum::default();
        let mut actual_spectrum = PaddedSpectrum::default();
        actual_spectrum.poison_all(0x55aa_9911);
        clean.forward(&input, &mut expected_spectrum);
        dirty.forward(&input, &mut actual_spectrum);
        assert_eq!(actual_spectrum, expected_spectrum);

        let mut expected_inverse_spectrum = expected_spectrum.clone();
        let mut actual_inverse_spectrum = actual_spectrum;
        let mut expected_output = vec![f32::NAN; SPATIAL_LEN];
        let mut actual_output = vec![f32::from_bits(0x7fc0_1234); SPATIAL_LEN];
        dirty.poison_scratch(0xa5a5_3c3c);
        clean.inverse(&mut expected_inverse_spectrum, &mut expected_output);
        dirty.inverse(&mut actual_inverse_spectrum, &mut actual_output);
        assert_eq!(
            actual_inverse_spectrum, expected_inverse_spectrum,
            "consumed spectrum must be scratch-independent"
        );
        for (index, (&actual, &expected)) in actual_output.iter().zip(&expected_output).enumerate()
        {
            assert_eq!(
                actual.to_bits(),
                expected.to_bits(),
                "dirty inverse output {index}"
            );
        }
    }

    #[test]
    fn logical_layout_round_trip_preserves_values_and_zeroes_padding() {
        let values: Vec<_> = (0..VALID_SPECTRUM_LEN)
            .map(|index| Complex32::new(index as f32 + 0.25, -(index as f32) - 0.75))
            .collect();
        let padded = PaddedSpectrum::from_column_major_valid(&values);
        assert_eq!(padded.to_column_major_valid(), values);
        assert!(padded.padding_is_positive_zero());
    }
}
