from __future__ import annotations

import csv
import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "render_comparison_video", ROOT / "tools" / "render_comparison_video.py"
)
assert SPEC is not None and SPEC.loader is not None
RENDER = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = RENDER
SPEC.loader.exec_module(RENDER)


HEADER = (
    "frame_index",
    "is_initialization",
    "update_attempted",
    "success",
    "bbox_x",
    "bbox_y",
    "bbox_width",
    "bbox_height",
    "update_ns",
    "update_us",
    "frame_checksum_fnv1a64",
)


def write_csv(path: Path, rows: list[tuple]) -> None:
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(HEADER)
        writer.writerows(rows)


class RenderComparisonVideoTests(unittest.TestCase):
    def test_csv_metrics_and_running_fps(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            left_path = root / "left.csv"
            right_path = root / "right.csv"
            write_csv(
                left_path,
                [
                    (0, 1, 0, 1, 0, 0, 10, 10, 0, 0, "0000000000000001"),
                    (
                        1,
                        0,
                        1,
                        1,
                        0,
                        0,
                        10,
                        10,
                        1_000_000,
                        1000,
                        "0000000000000002",
                    ),
                    (
                        2,
                        0,
                        1,
                        0,
                        0,
                        0,
                        10,
                        10,
                        3_000_000,
                        3000,
                        "0000000000000003",
                    ),
                ],
            )
            write_csv(
                right_path,
                [
                    (0, 1, 0, 1, 1, 0, 10, 10, 0, 0, "0000000000000001"),
                    (
                        1,
                        0,
                        1,
                        1,
                        1,
                        0,
                        10,
                        10,
                        2_000_000,
                        2000,
                        "0000000000000002",
                    ),
                    (
                        2,
                        0,
                        1,
                        0,
                        1,
                        0,
                        10,
                        10,
                        2_000_000,
                        2000,
                        "0000000000000003",
                    ),
                ],
            )

            left = RENDER.read_records(left_path)
            right = RENDER.read_records(right_path)
            RENDER.validate_matching_records(left, right)

            metrics = RENDER.frame_metrics(left[1], right[1])
            self.assertEqual(metrics.center_distance, 1.0)
            self.assertAlmostEqual(metrics.iou, 9.0 / 11.0)

            left_timing = RENDER.RunningTrackerTiming()
            self.assertIsNone(left_timing.add(left[0]))
            self.assertEqual(left_timing.add(left[1]), 1000.0)
            self.assertEqual(left_timing.add(left[2]), 500.0)

    def test_failure_row_preserves_its_box_and_latency(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "failed.csv"
            write_csv(
                path,
                [
                    (0, 1, 0, 1, 4, 5, 8, 9, 0, 0, "0000000000000001"),
                    (
                        1,
                        0,
                        1,
                        0,
                        7.25,
                        8.5,
                        8,
                        9,
                        123_456,
                        123.456,
                        "0000000000000002",
                    ),
                ],
            )

            failed = RENDER.read_records(path)[1]
            self.assertFalse(failed.success)
            self.assertEqual(failed.box, RENDER.Box(7.25, 8.5, 8.0, 9.0))
            self.assertEqual(failed.update_us, 123.456)

    def test_checksum_mismatch_is_rejected(self) -> None:
        left = [
            RENDER.FrameRecord(
                0,
                True,
                False,
                True,
                RENDER.Box(0.0, 0.0, 10.0, 10.0),
                0,
                "0000000000000001",
            )
        ]
        right = [
            RENDER.FrameRecord(
                0,
                True,
                False,
                True,
                RENDER.Box(0.0, 0.0, 10.0, 10.0),
                0,
                "0000000000000002",
            )
        ]
        with self.assertRaisesRegex(ValueError, "checksum differs"):
            RENDER.validate_matching_records(left, right)

    def test_noncontiguous_frame_index_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad.csv"
            write_csv(
                path,
                [
                    (0, 1, 0, 1, 0, 0, 10, 10, 0, 0, "0000000000000001"),
                    (
                        2,
                        0,
                        1,
                        1,
                        0,
                        0,
                        10,
                        10,
                        1000,
                        1,
                        "0000000000000002",
                    ),
                ],
            )
            with self.assertRaisesRegex(ValueError, "contiguous frame index 1"):
                RENDER.read_records(path)

    def test_labels_are_trimmed_and_reject_multiline_text(self) -> None:
        self.assertEqual(RENDER._validate_label(" Challenge ", "--label"), "Challenge")
        with self.assertRaisesRegex(ValueError, "single line"):
            RENDER._validate_label("Exact\nChallenge", "--label")


if __name__ == "__main__":
    unittest.main()
