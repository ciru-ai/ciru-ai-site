from __future__ import annotations

import ctypes
import threading
from dataclasses import dataclass

import numpy as np
import pytest

from mosse_pi import (
    InvalidBoundingBoxError,
    InvalidFrameError,
    MosseTracker,
    MulticoreUnavailableError,
    TrackerClosedError,
    TrackerThreadError,
    __version__,
)
from mosse_pi._native import (
    BACKEND_FIXED_MULTICORE,
    BACKEND_FIXED_SINGLE,
    BACKEND_GENERIC_SINGLE,
    MODE_AUTO,
    MODE_MULTICORE,
    MODE_SINGLE,
    NativeLibraryInfo,
    Rect,
)
from mosse_pi.tracker import _allocation_bounds


@dataclass
class FakeBindings:
    backend_code: int = BACKEND_FIXED_MULTICORE

    def __post_init__(self) -> None:
        self.info = NativeLibraryInfo(
            path="/fake/libmosse_core.so",
            architecture="aarch64",
            sha256="ab" * 32,
        )
        self.create_modes: list[int] = []
        self.init_frames: list[object] = []
        self.update_frames: list[object] = []
        self.destroyed: list[int] = []
        self._next_handle = 100

    def create(self, mode: int) -> ctypes.c_void_p:
        self.create_modes.append(mode)
        self._next_handle += 1
        return ctypes.c_void_p(self._next_handle)

    def init(self, handle: ctypes.c_void_p, frame: object, rect: Rect) -> None:
        self.init_frames.append(frame)

    def backend_status(self, handle: ctypes.c_void_p) -> int:
        return self.backend_code

    def update(self, handle: ctypes.c_void_p, frame: object) -> tuple[bool, Rect]:
        self.update_frames.append(frame)
        return True, Rect(4.0, 5.0, 20.0, 12.0)

    def destroy(self, handle: ctypes.c_void_p) -> None:
        self.destroyed.append(int(handle.value))


def frame() -> np.ndarray:
    return np.zeros((24, 32, 3), dtype=np.uint8)


def test_allocation_bounds_support_current_numpy_api() -> None:
    image = frame()
    low, high = _allocation_bounds(image)
    assert low == image.ctypes.data
    assert high - low == image.nbytes


def test_native_identity_uses_public_package_version() -> None:
    assert FakeBindings().info.package_version == __version__ == "0.1.0.dev5"


def test_auto_multicore_lifecycle_and_context_manager() -> None:
    bindings = FakeBindings()
    image = frame()
    with MosseTracker(image, (2, 3, 20, 12), _bindings=bindings) as tracker:
        assert bindings.create_modes == [MODE_AUTO]
        assert tracker.requested_mode == "auto"
        assert tracker.selected_mode == "multicore"
        assert tracker.backend == "fixed-multicore"
        assert tracker.native_library_info == bindings.info
        assert tracker.last_frame_was_zero_copy
        assert bindings.init_frames[0].pointer.value == image.ctypes.data

        success, box = tracker.update(image)
        assert success is True
        assert box == (4.0, 5.0, 20.0, 12.0)
        assert tracker.last_frame_was_zero_copy

    assert tracker.closed
    assert len(bindings.destroyed) == 1
    tracker.close()
    assert len(bindings.destroyed) == 1


def test_positive_padded_row_stride_is_zero_copy_when_span_is_owned() -> None:
    bindings = FakeBindings()
    storage = np.zeros((10, 40, 3), dtype=np.uint8)
    padded = storage[:, 4:28, :]
    assert padded.strides[0] > padded.shape[1] * 3

    tracker = MosseTracker(padded, (1, 1, 12, 8), _bindings=bindings)
    try:
        native_frame = bindings.init_frames[0]
        assert native_frame.zero_copy
        assert native_frame.row_stride == storage.strides[0]
        assert native_frame.pointer.value == padded.ctypes.data
    finally:
        tracker.close()


def test_read_only_contiguous_frame_remains_zero_copy() -> None:
    bindings = FakeBindings()
    image = frame()
    image.flags.writeable = False
    tracker = MosseTracker(image, (1, 1, 8, 8), _bindings=bindings)
    try:
        native_frame = bindings.init_frames[0]
        assert native_frame.zero_copy
        assert native_frame.pointer.value == image.ctypes.data
    finally:
        tracker.close()


def test_structurally_valid_stride_is_rejected_if_span_exceeds_owner() -> None:
    bindings = FakeBindings()
    storage = np.zeros((2, 8, 3), dtype=np.uint8)
    unsafe_shape = np.lib.stride_tricks.as_strided(
        storage,
        shape=(20, 8, 3),
        strides=storage.strides,
        writeable=False,
    )
    with pytest.raises(InvalidFrameError, match="backing allocation"):
        MosseTracker(unsafe_shape, (1, 1, 4, 4), _bindings=bindings)
    assert bindings.create_modes == []


@pytest.mark.parametrize(
    "view",
    [
        lambda value: value[:, ::-1, :],
        lambda value: value[::2, :, ::-1],
        lambda value: np.transpose(value, (1, 0, 2)),
    ],
)
def test_unsupported_strides_are_copied_safely(view) -> None:
    bindings = FakeBindings()
    noncontiguous = view(frame())
    tracker = MosseTracker(noncontiguous, (1, 1, 8, 8), _bindings=bindings)
    try:
        native_frame = bindings.init_frames[0]
        assert not native_frame.zero_copy
        assert native_frame.array.flags.c_contiguous
        assert native_frame.row_stride == native_frame.width * 3
        assert tracker.last_frame_was_zero_copy is False
    finally:
        tracker.close()


@pytest.mark.parametrize(
    "bad",
    [
        np.zeros((8, 8, 3), dtype=np.float32),
        np.zeros((8, 8), dtype=np.uint8),
        np.zeros((8, 8, 4), dtype=np.uint8),
        np.zeros((0, 8, 3), dtype=np.uint8),
    ],
)
def test_invalid_frames_are_rejected_before_native_create(bad: np.ndarray) -> None:
    bindings = FakeBindings()
    with pytest.raises(InvalidFrameError):
        MosseTracker(bad, (1, 1, 4, 4), _bindings=bindings)
    assert bindings.create_modes == []


@pytest.mark.parametrize(
    "bad_rect",
    [
        (1, 2, 0, 4),
        (1, 2, -1, 4),
        (1, 2, float("nan"), 4),
        (1, 2, 3),
        3,
    ],
)
def test_invalid_rectangles_are_rejected_before_native_create(bad_rect) -> None:
    bindings = FakeBindings()
    with pytest.raises(InvalidBoundingBoxError):
        MosseTracker(frame(), bad_rect, _bindings=bindings)
    assert bindings.create_modes == []


def test_explicit_multicore_raises_and_cleans_up_on_fallback() -> None:
    bindings = FakeBindings(backend_code=BACKEND_FIXED_SINGLE)
    with pytest.raises(
        MulticoreUnavailableError,
        match="60x36",
    ):
        MosseTracker(frame(), (1, 1, 8, 8), mode="multicore", _bindings=bindings)
    assert bindings.create_modes == [MODE_MULTICORE]
    assert len(bindings.destroyed) == 1


@pytest.mark.parametrize(
    ("backend", "name"),
    [
        (BACKEND_FIXED_SINGLE, "fixed-single"),
        (BACKEND_GENERIC_SINGLE, "generic-single"),
    ],
)
def test_auto_reports_single_thread_fallback(backend: int, name: str) -> None:
    bindings = FakeBindings(backend_code=backend)
    tracker = MosseTracker(frame(), (1, 1, 8, 8), _bindings=bindings)
    try:
        assert tracker.selected_mode == "single"
        assert tracker.backend == name
    finally:
        tracker.close()


def test_single_mode_is_forwarded_and_enforced() -> None:
    bindings = FakeBindings(backend_code=BACKEND_FIXED_SINGLE)
    tracker = MosseTracker(frame(), (1, 1, 8, 8), mode="single", _bindings=bindings)
    try:
        assert bindings.create_modes == [MODE_SINGLE]
        assert tracker.selected_mode == "single"
    finally:
        tracker.close()


def test_live_handle_rejects_update_and_close_from_another_thread() -> None:
    bindings = FakeBindings()
    tracker = MosseTracker(frame(), (1, 1, 8, 8), _bindings=bindings)
    errors: list[BaseException] = []

    def wrong_thread() -> None:
        for operation in (lambda: tracker.update(frame()), tracker.close):
            try:
                operation()
            except BaseException as error:
                errors.append(error)

    thread = threading.Thread(target=wrong_thread)
    thread.start()
    thread.join()
    try:
        assert len(errors) == 2
        assert all(isinstance(error, TrackerThreadError) for error in errors)
        assert not tracker.closed
    finally:
        tracker.close()


def test_update_after_close_is_clear_error() -> None:
    tracker = MosseTracker(frame(), (1, 1, 8, 8), _bindings=FakeBindings())
    tracker.close()
    with pytest.raises(TrackerClosedError):
        tracker.update(frame())
