"""Ergonomic NumPy-facing MOSSE tracker."""

from __future__ import annotations

import ctypes
import math
import threading
import warnings
from dataclasses import dataclass
from typing import Any, Optional, Sequence

import numpy as np

try:
    from numpy.lib.array_utils import byte_bounds as _byte_bounds
except ImportError:  # NumPy 1.x
    _byte_bounds = np.byte_bounds

from ._errors import (
    InvalidBoundingBoxError,
    InvalidFrameError,
    MulticoreUnavailableError,
    NativeLibraryError,
    TrackerClosedError,
    TrackerThreadError,
)
from ._native import (
    BACKEND_FIXED_MULTICORE,
    BACKEND_FIXED_SINGLE,
    BACKEND_GENERIC_SINGLE,
    BACKEND_UNINITIALIZED,
    MODE_AUTO,
    MODE_MULTICORE,
    MODE_SINGLE,
    NativeBindings,
    NativeLibraryInfo,
    Rect,
    load_bindings,
)

_MODE_VALUES = {"auto": MODE_AUTO, "single": MODE_SINGLE, "multicore": MODE_MULTICORE}
_BACKEND_NAMES = {
    BACKEND_UNINITIALIZED: "uninitialized",
    BACKEND_GENERIC_SINGLE: "generic-single",
    BACKEND_FIXED_SINGLE: "fixed-single",
    BACKEND_FIXED_MULTICORE: "fixed-multicore",
}


@dataclass(frozen=True)
class _FrameView:
    array: np.ndarray
    pointer: ctypes.c_void_p
    width: int
    height: int
    row_stride: int
    zero_copy: bool


def _allocation_bounds(array: np.ndarray) -> tuple[int, int]:
    owner = array
    current: Any = array
    seen: set[int] = set()
    while True:
        base = getattr(current, "base", None)
        if base is None or id(base) in seen:
            break
        seen.add(id(base))
        current = base
        if isinstance(current, np.ndarray):
            owner = current
    low, high = _byte_bounds(owner)
    return int(low), int(high)


def _array_address(array: np.ndarray) -> int:
    if array.flags.c_contiguous and array.flags.writeable:
        return ctypes.addressof(ctypes.c_uint8.from_buffer(array))
    return int(array.ctypes.data)


def _prepare_frame(frame: np.ndarray) -> _FrameView:
    if not isinstance(frame, np.ndarray):
        raise InvalidFrameError("frame must be a numpy.ndarray")
    if frame.dtype != np.uint8:
        raise InvalidFrameError(f"frame dtype must be uint8, got {frame.dtype}")
    if frame.ndim != 3 or frame.shape[2] != 3:
        raise InvalidFrameError(f"frame shape must be HxWx3 BGR, got {frame.shape}")
    height, width, _ = (int(value) for value in frame.shape)
    if height <= 0 or width <= 0:
        raise InvalidFrameError("frame width and height must be positive")

    row_stride, column_stride, channel_stride = (int(value) for value in frame.strides)
    row_bytes = width * 3
    supported_layout = (
        row_stride > 0
        and row_stride >= row_bytes
        and column_stride == 3
        and channel_stride == 1
    )
    zero_copy = supported_layout
    if supported_layout:
        data = _array_address(frame)
        span = row_stride * (height - 1) + row_bytes
        if not (frame.flags.c_contiguous and frame.base is None):
            low, high = _allocation_bounds(frame)
            if not (low <= data and data + span <= high):
                raise InvalidFrameError(
                    "frame byte span exceeds its discoverable backing allocation"
                )

    prepared = frame if zero_copy else np.ascontiguousarray(frame)
    if not zero_copy:
        row_stride = int(prepared.strides[0])
        data = _array_address(prepared)
    pointer = ctypes.c_void_p(data)
    return _FrameView(
        array=prepared,
        pointer=pointer,
        width=width,
        height=height,
        row_stride=row_stride,
        zero_copy=zero_copy,
    )


def _prepare_rect(value: Sequence[float]) -> Rect:
    try:
        component_count = len(value)
    except TypeError as error:
        raise InvalidBoundingBoxError(
            "initial rectangle must contain (x, y, width, height)"
        ) from error
    if isinstance(value, (str, bytes)) or component_count != 4:
        raise InvalidBoundingBoxError(
            "initial rectangle must contain (x, y, width, height)"
        )
    try:
        x, y, width, height = (float(component) for component in value)
    except (TypeError, ValueError) as error:
        raise InvalidBoundingBoxError(
            "rectangle components must be real numbers"
        ) from error
    if not all(math.isfinite(component) for component in (x, y, width, height)):
        raise InvalidBoundingBoxError("rectangle components must be finite")
    if width <= 0.0 or height <= 0.0:
        raise InvalidBoundingBoxError("rectangle width and height must be positive")
    return Rect(x=x, y=y, width=width, height=height)


class MosseTracker:
    """Native MOSSE tracker over OpenCV/NumPy BGR frames.

    A live handle is bound to the native thread that constructed it. Use and
    close it from that same thread; the per-handle lock additionally prevents
    overlapping mutation.
    """

    def __init__(
        self,
        initial_frame: np.ndarray,
        initial_rect: Sequence[float],
        *,
        mode: str = "auto",
        _bindings: Optional[NativeBindings] = None,
    ) -> None:
        if mode not in _MODE_VALUES:
            raise ValueError("mode must be 'auto', 'single', or 'multicore'")
        self._requested_mode = mode
        self._creator_thread = threading.current_thread()
        self._creator_native_id = threading.get_native_id()
        self._lock = threading.Lock()
        self._bindings = _bindings if _bindings is not None else load_bindings()
        self._handle: Optional[ctypes.c_void_p] = None
        self._backend_code = BACKEND_UNINITIALIZED
        self._last_frame_zero_copy = False

        frame = _prepare_frame(initial_frame)
        rect = _prepare_rect(initial_rect)
        try:
            with self._lock:
                self._handle = self._bindings.create(_MODE_VALUES[mode])
                self._bindings.init(self._handle, frame, rect)
                self._backend_code = self._bindings.backend_status(self._handle)
            self._last_frame_zero_copy = frame.zero_copy
            self._validate_selected_backend()
        except BaseException:
            self._close_after_constructor_failure()
            raise

    @property
    def requested_mode(self) -> str:
        return self._requested_mode

    @property
    def backend(self) -> str:
        return _BACKEND_NAMES.get(self._backend_code, f"unknown-{self._backend_code}")

    @property
    def selected_mode(self) -> str:
        if self._backend_code == BACKEND_FIXED_MULTICORE:
            return "multicore"
        if self._backend_code in {BACKEND_GENERIC_SINGLE, BACKEND_FIXED_SINGLE}:
            return "single"
        return "uninitialized"

    @property
    def native_library_info(self) -> Optional[NativeLibraryInfo]:
        return getattr(self._bindings, "info", None)

    @property
    def last_frame_was_zero_copy(self) -> bool:
        return self._last_frame_zero_copy

    @property
    def closed(self) -> bool:
        return self._handle is None

    def update(
        self, frame: np.ndarray
    ) -> tuple[bool, tuple[float, float, float, float]]:
        self._require_creator_thread()
        prepared = _prepare_frame(frame)
        with self._lock:
            handle = self._require_open()
            success, rect = self._bindings.update(handle, prepared)
        self._last_frame_zero_copy = prepared.zero_copy
        return bool(success), rect.as_tuple()

    def close(self) -> None:
        if self._handle is None:
            return
        self._require_creator_thread()
        with self._lock:
            handle = self._handle
            if handle is None:
                return
            self._bindings.destroy(handle)
            self._handle = None
            self._backend_code = BACKEND_UNINITIALIZED

    def __enter__(self) -> "MosseTracker":
        self._require_creator_thread()
        self._require_open()
        return self

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        self.close()

    def __del__(self) -> None:
        handle = getattr(self, "_handle", None)
        if handle is None:
            return
        if threading.current_thread() is not getattr(
            self, "_creator_thread", None
        ) or threading.get_native_id() != getattr(self, "_creator_native_id", None):
            warnings.warn(
                "live MosseTracker finalized on a different thread; native handle "
                "was not destroyed because multicore cleanup is caller-thread-bound",
                ResourceWarning,
                stacklevel=2,
            )
            return
        try:
            self.close()
        except BaseException as error:
            warnings.warn(
                f"failed to close native MosseTracker during finalization: {error}",
                ResourceWarning,
                stacklevel=2,
            )

    def _validate_selected_backend(self) -> None:
        if self._backend_code not in _BACKEND_NAMES:
            raise NativeLibraryError(
                f"native library returned unknown backend status {self._backend_code}"
            )
        if self._backend_code == BACKEND_UNINITIALIZED:
            raise NativeLibraryError(
                "native tracker remained uninitialized after mosse_init"
            )
        if (
            self._requested_mode == "multicore"
            and self._backend_code != BACKEND_FIXED_MULTICORE
        ):
            raise MulticoreUnavailableError(
                f"explicit multicore mode fell back to {self.backend}; verify Linux "
                "AArch64 support, ensure the internally rounded FFT window is "
                "exactly 60x36, launch the complete process with "
                "'taskset --cpu-list 0' before decoder threads start, keep the "
                "caller at SCHED_OTHER/0 and nice 0, and ensure CPUs 1-3 are "
                "available to the watchdog-safe runtime"
            )
        if (
            self._requested_mode == "single"
            and self._backend_code == BACKEND_FIXED_MULTICORE
        ):
            raise NativeLibraryError(
                "native library violated explicit single-thread mode"
            )

    def _require_creator_thread(self) -> None:
        current = threading.current_thread()
        current_native_id = threading.get_native_id()
        if (
            current is not self._creator_thread
            or current_native_id != self._creator_native_id
        ):
            raise TrackerThreadError(
                "live tracker belongs to native thread "
                f"{self._creator_native_id}, called from {current_native_id}"
            )

    def _require_open(self) -> ctypes.c_void_p:
        if self._handle is None:
            raise TrackerClosedError("tracker is closed")
        return self._handle

    def _close_after_constructor_failure(self) -> None:
        handle = self._handle
        if handle is None:
            return
        try:
            with self._lock:
                self._bindings.destroy(handle)
        finally:
            self._handle = None
            self._backend_code = BACKEND_UNINITIALIZED
