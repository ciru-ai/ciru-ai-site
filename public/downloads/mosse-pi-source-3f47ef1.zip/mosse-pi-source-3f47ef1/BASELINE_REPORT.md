# OpenCV MOSSE baseline report

Status: **a complete paired one-thread/four-thread Raspberry Pi suite has been
recorded.** The suite is authoritative for those two measured configurations.
The OpenCV default-thread test and hardware performance-counter profile remain
pending, so the wider baseline protocol is not yet closed.

The source is suite
[`baseline-reference-90677e3`](results/pi4-scoring/baseline-reference-90677e3/manifest.json),
which completed with status `completed` and exit code `0`. It ran from
2026-07-25 20:22:17 UTC to 20:42:42 UTC. Commit
`90677e3ea011cd2822efa24383dd10bb1673bd80` (`90677e3`,
“Establish MOSSE benchmark and Rust reference”) is the **pre-optimization
reference**, not an accepted optimization result. The suite name maps to that
commit in this repository, but the manifest itself does not contain a commit
ID or benchmark-binary hash.

## Headline baseline and targets

The selected stock OpenCV reference actually measured in this suite is
the explicit one-thread configuration. Its five-run median tracker-only rate
is **2319.78751774436 FPS**. This is the current headline baseline; it is a
median, not the best individual run.

- Exact 3× target: **6959.36255323308 FPS**.
- Exact 4× target: **9279.15007097744 FPS**.

The explicit four-thread stock median is 2198.10826154364 FPS. Its
configuration-specific 3× and 4× targets are 6594.32478463092 FPS and
8792.43304617456 FPS, respectively. The unmeasured OpenCV default-thread mode
must not be inferred from either explicit setting.

| Stock OpenCV configuration | Measured runs | Median tracker FPS | Exact 3× target | Exact 4× target |
|---|---:|---:|---:|---:|
| Default threads | pending | pending | pending | pending |
| Explicit one thread; selected production baseline | 5 | 2319.78751774436 | 6959.36255323308 | 9279.15007097744 |
| Explicit four threads / four-core allowance | 5 | 2198.10826154364 | 6594.32478463092 | 8792.43304617456 |

## Benchmark identity

- Video SHA-256:
  `17293ee5158b5f41d2920bbb1ba835f96050ab2813942ff29008dffab10857b5`
  (expected and actual values matched).
- Video: H.264, 848×480, 164.950244 seconds, 27,000,162 bytes.
- Per full run: 4,947 decoded frames and 4,946 tracker updates.
- Initial drone ROI: `x=281, y=193, width=55, height=36`.
- Decoded-frame sequence checksum:
  `457b6137d381261e` for every OpenCV and Rust run.
- Execution: headless, full video (`max_frames=0`), shared benchmark harness.

## Raspberry Pi environment

- Host: `raspi-node`, Raspberry Pi 4 Model B Rev 1.4, 8 GB
  (8,187,076,608 bytes observed).
- OS: Debian GNU/Linux 13 (trixie), Debian 13.5, AArch64.
- Kernel: `6.18.34+rpt-rpi-v8`.
- CPU: four Cortex-A72 cores, ASIMD/NEON, one thread per core, shared 1 MiB
  L2 cache.
- Frequency policy: `performance`, boost disabled, 600–1800 MHz policy range,
  observed at 1800 MHz in the suite boundary captures.
- Affinity: the runner recorded child-process `taskset` CPU lists of CPU 0 for
  one-thread runs and CPUs 0–3 for four-thread runs. The runtime-state probes
  ran outside the benchmark child and therefore do not independently prove
  its affinity. OpenCV reported effective thread counts of 1 and 4.
- Earlier setup idle temperature was approximately 44–45 °C. That observation
  is not a scoring sample. The suite boundary CPU thermal-zone readings were
  51.121 °C before and 59.400 °C after.
- Suite boundary throttling was `0x0` before and after. All 40 measured-run
  pre/post throttling samples were also `0x0`.
- The physical cooling arrangement, power supply, and storage device were not
  encoded in the suite artifacts and remain pending documentation.

## Build and tool versions

The benchmark executable was
`/home/crown/mosse-bench/build/release/mosse_benchmark`. At commit `90677e3`,
the repository build recipe configured CMake `Release` with C++17 and built
the Rust static library with Cargo `--release --locked`. The suite did not
snapshot the build command, `compile_commands.json`, or ambient `CFLAGS`,
`CXXFLAGS`, and `RUSTFLAGS`; no unrecorded flags are assumed here.

| Component | Recorded version/configuration |
|---|---|
| OpenCV | 4.10.0 with contrib legacy MOSSE available; dynamic Release package, `-O2`, NEON FP16 baseline, NEON_DOTPROD/NEON_FP16/NEON_BF16 dispatch compiled, TBB 2022.0 |
| C/C++ | GCC and G++ 14.2.0 |
| CMake / Ninja | CMake 3.31.6; Ninja 1.12.1 |
| Rust | rustc 1.85.0, Cargo 1.85.0, AArch64 host, LLVM 19.1.7 |
| Rust FFT dependency | rustfft 6.4.1 from the locked dependency graph |
| FFmpeg | 7.1.5-0+deb13u1+rpt1 |
| Python / pkg-config | Python 3.13.5; pkg-config 1.8.1 |
| perf | 6.18.34 installed; no counter measurements recorded |

OpenCV reported `opencv_use_optimized=true` in every summary. The OpenCV and
Rust backends in this reference suite identify themselves as
`opencv_legacy_mosse` and `rust_mosse_scalar`.

## Run protocol

- One full-video warm-up for each tracker at each thread count.
- Five measured OpenCV/Rust pairs at one thread, then five at four threads.
- OpenCV/Rust order alternated globally; neither tracker was always first.
- Two seconds of runner pause before each run after the first.
- Required `performance` governor and child-process `taskset` affinity.
- The versioned video hash was verified before the suite.
- Tracker initialization and updates used the same decoded BGR frames; decode,
  checksum, output, and reporting work remained outside tracker-update timing.

## Aggregate results

“Median latency” below is the median of the five per-run
`latency_ns.median` values. “p95 latency” is the median of the five per-run
nearest-rank `latency_ns.p95` values. Temperatures are the exact CPU
thermal-zone extrema across each configuration's measured pre/post captures.
The four-thread section ran after the one-thread section and consequently
started hotter; the table does not imply a common starting temperature across
thread modes.

| Threads | Tracker | Runs | Mean tracker FPS | Median tracker FPS | Median latency (µs) | p95 latency (µs) | Temperature (°C) | Throttling | Stable updates (success/failure) |
|---:|---|---:|---:|---:|---:|---:|---:|---|---|
| 1 | OpenCV | 5 | 2309.41710587784 | 2319.78751774436 | 305.2265 | 626.768 | 53.556–57.452 | none (`0x0`) | 2219 / 2727 |
| 1 | Rust scalar reference | 5 | 1901.08110626905 | 1902.02527374266 | 421.4850 | 728.545 | 53.069–55.991 | none (`0x0`) | 2219 / 2727 |
| 4 | OpenCV | 5 | 2192.78393338210 | 2198.10826154364 | 322.5705 | 658.512 | 56.478–59.887 | none (`0x0`) | 2219 / 2727 |
| 4 | Rust scalar reference | 5 | 1898.86062149231 | 1900.63436357981 | 416.9115 | 725.492 | 55.991–59.887 | none (`0x0`) | 2219 / 2727 |

The pre-optimization Rust reference reached 0.8199135736328514× the matched
one-thread OpenCV median and 0.8646682225947659× the matched four-thread
OpenCV median. It is deliberately a correctness reference and is slower than
stock OpenCV; it does not claim an optimization win.

## Every measured run

FPS is tracker-only. Latencies are taken directly from each summary. The
temperature and throttling columns show the corresponding pre → post runtime
captures. Pair order is the actual alternating order.

| Threads | Pair | Order | Tracker | Tracker FPS | Median latency (µs) | p95 latency (µs) | Temperature (°C) | Throttling |
|---:|---:|---:|---|---:|---:|---:|---|---|
| 1 | 1 | 1 | OpenCV | 2278.834426 | 307.6160 | 638.509 | 55.017 → 55.504 | `0x0` → `0x0` |
| 1 | 1 | 2 | Rust reference | 1895.181579 | 390.4945 | 731.193 | 54.043 → 55.504 | `0x0` → `0x0` |
| 1 | 2 | 1 | Rust reference | 1897.922397 | 421.8920 | 729.804 | 53.069 → 55.991 | `0x0` → `0x0` |
| 1 | 2 | 2 | OpenCV | 2305.309447 | 306.2820 | 630.176 | 54.530 → 55.991 | `0x0` → `0x0` |
| 1 | 3 | 1 | OpenCV | 2321.976287 | 305.0050 | 625.046 | 55.017 → 55.017 | `0x0` → `0x0` |
| 1 | 3 | 2 | Rust reference | 1907.388360 | 421.4850 | 726.396 | 54.530 → 55.991 | `0x0` → `0x0` |
| 1 | 4 | 1 | Rust reference | 1902.887921 | 422.1690 | 728.453 | 55.017 → 55.991 | `0x0` → `0x0` |
| 1 | 4 | 2 | OpenCV | 2319.787518 | 305.1530 | 626.768 | 55.504 → 55.017 | `0x0` → `0x0` |
| 1 | 5 | 1 | OpenCV | 2321.177851 | 305.2265 | 624.250 | 53.556 → 57.452 | `0x0` → `0x0` |
| 1 | 5 | 2 | Rust reference | 1902.025274 | 388.2255 | 728.545 | 54.530 → 55.991 | `0x0` → `0x0` |
| 4 | 1 | 1 | Rust reference | 1900.634364 | 416.5050 | 725.771 | 55.991 → 59.400 | `0x0` → `0x0` |
| 4 | 1 | 2 | OpenCV | 2176.391102 | 330.3390 | 661.771 | 56.965 → 58.426 | `0x0` → `0x0` |
| 4 | 2 | 1 | OpenCV | 2190.540770 | 324.0800 | 658.512 | 56.478 → 57.939 | `0x0` → `0x0` |
| 4 | 2 | 2 | Rust reference | 1898.181196 | 418.4125 | 725.492 | 57.452 → 59.887 | `0x0` → `0x0` |
| 4 | 3 | 1 | Rust reference | 1900.897088 | 416.4215 | 725.400 | 57.939 → 58.913 | `0x0` → `0x0` |
| 4 | 3 | 2 | OpenCV | 2199.325382 | 322.0795 | 658.048 | 57.939 → 58.913 | `0x0` → `0x0` |
| 4 | 4 | 1 | OpenCV | 2198.108262 | 321.6440 | 659.529 | 56.965 → 59.887 | `0x0` → `0x0` |
| 4 | 4 | 2 | Rust reference | 1889.840963 | 418.3285 | 729.417 | 57.939 → 59.400 | `0x0` → `0x0` |
| 4 | 5 | 1 | Rust reference | 1904.749496 | 416.9115 | 723.899 | 56.478 → 58.913 | `0x0` → `0x0` |
| 4 | 5 | 2 | OpenCV | 2199.554151 | 322.5705 | 655.584 | 56.965 → 59.887 | `0x0` → `0x0` |

## Tracking behavior and parity

Every one of the 20 measured summaries reported exactly 4,946 attempted
updates, **2,219 successful updates**, and **2,727 failed updates**. This
2219/2727 behavior was stable across both trackers, both thread counts, and all
five measured pairs. Frame 0 initialization succeeded; update frames 1–2,219
were successful, and frame 2,220 onward failed continuously while the harness
continued processing to the end of the video.

All ten paired parity reports passed every gate:

- Success/failure agreement: 4,946/4,946, or 100%.
- Mutually successful frames: 2,219.
- Mean, median, and minimum IoU: 1.0.
- Mean, median, p95, and maximum center error: 0 pixels.
- Width and height deltas: 0 pixels.
- Decoded-frame checksums: exact matches.

The large failure count is therefore part of the reference tracker's matched
behavior on this fixed video, not run-to-run instability or Rust/OpenCV drift.

## Pending measurements

- OpenCV's default thread configuration and its five-run median.
- A representative `perf stat`/profile run: cycles, instructions, cache
  references and misses, branches and branch misses, and any derived
  cycles/frame or cache-misses/frame values.
- Profile-backed bottleneck ranking. No bottleneck claim is made without the
  pending counter/profile evidence.
- Physical cooling, power-supply, and storage details.
- A captured build invocation and ambient compiler/Rust flags for the exact
  binary, plus a benchmark-binary hash and captured repository dirty state.

These fields are intentionally marked pending rather than reconstructed or
invented from tool availability.
