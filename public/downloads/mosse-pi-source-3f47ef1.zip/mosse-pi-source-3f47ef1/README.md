# MOSSE Pi 4 Rust optimization

This repository is the reproducible benchmark and implementation workspace for
a CPU-only Rust MOSSE tracker that exceeded the 4× tracker-only target over
OpenCV's native legacy MOSSE tracker on a Raspberry Pi 4.

The final exact five-pair production matrix measured **11,632.121609 FPS
median** for the four-core Rust tracker: **5.014305×** the frozen
2,319.787518-FPS one-core OpenCV baseline and 25.3576% above the 4× target.
The contemporaneous same-suite paired median was 4.938478× because that
OpenCV sample ran 1.67% faster than the frozen baseline. Every one of the
4,946 updates—including 2,727 failures—remained timed, and all five
4,947-row traces matched exactly. The 5× frozen-baseline margin is only
0.2861%, so this is reported as a median result, not a guaranteed 5× floor.

## Fixed benchmark identity

| Property | Value |
|---|---|
| Object | Drone |
| Video SHA-256 | `17293ee5158b5f41d2920bbb1ba835f96050ab2813942ff29008dffab10857b5` |
| Encoded video | H.264, 848×480, 164.950244 s |
| Decoded frames | 4,947 (4,946 tracker updates) |
| Average frame rate | 29.9908619 fps |
| Frame-0 ROI | `x=281, y=193, width=55, height=36` |

The ROI was selected once from decoded frame 0 with
[`tools/select_roi.py`](tools/select_roi.py) and is versioned in
[`config/benchmark.yml`](config/benchmark.yml).

## Assigned paths

| Purpose | Path |
|---|---|
| Dunamis development checkout | `/srv/ssd/intel/research/mosse-pi4-rust-optimization` |
| Pi 4 deployment checkout | `/home/crown/mosse-bench` |
| Video within either checkout | `assets/test-video.mp4` |

The video itself is not committed. Verify it before every official suite:

```bash
sha256sum -c <(printf '%s  %s\n' \
  17293ee5158b5f41d2920bbb1ba835f96050ab2813942ff29008dffab10857b5 \
  assets/test-video.mp4)
```

## Build on Dunamis

Enter the pinned Nix development environment and build Release artifacts:

```bash
nix develop
./scripts/build_release.sh
```

Run the C++ tests and a short harness smoke test:

```bash
ctest --test-dir build/release --output-on-failure
./build/release/mosse_benchmark \
  --config config/benchmark.yml \
  --tracker opencv \
  --max-frames 120
```

Run the same decoded frames through the scalar Rust reference:

```bash
./build/release/mosse_benchmark \
  --config config/benchmark.yml \
  --tracker rust \
  --max-frames 120 \
  --frames-csv results/rust-smoke.csv \
  --summary-json results/rust-smoke.json
```

The production run omits `--max-frames`. Per-frame results are written to CSV;
the summary JSON contains tracker-only FPS, initialization time, median/p95/p99
latency, success/failure counts, end-to-end FPS, and a decoded-frame sequence
checksum.

After full OpenCV and Rust runs, validate both decoded-frame identity and
tracking equivalence:

```bash
python3 tools/compare_tracks.py \
  results/opencv-frames.csv \
  results/rust-frames.csv \
  --output results/tracking-comparison.json
```

## Score on the Raspberry Pi 4

Build the release binary on the Pi, configure the performance governor and
cooling beforehand, then run the paired scoring matrix as an ordinary user:

```bash
rustup toolchain install 1.97.1 --profile minimal
./scripts/build_release.sh --pi4-production
bash scripts/run_pi4_scoring.sh
```

`--pi4-production` selects the exact Experiment 066 Cargo feature set with
default features disabled, one release codegen unit, and LTO disabled. It
selects and verifies Rust/Cargo 1.97.1, and rejects conflicting
feature/profile/toolchain overrides instead of silently building a different
core. The one-codegen-unit setting is retained only for Pi/AArch64 after the
exact Experiment 032 full replay. It regressed on Dunamis x86_64; native x86
builds should keep the ordinary release setting and pass an explicit feature
set with `--cargo-features` only when needed.

The runner never invokes `sudo` or changes host configuration. Official
defaults are one full-video warm-up per tracker, five measured OpenCV/Rust
pairs, default one-thread OpenCV versus four-core Rust, `taskset` affinity,
and a required `performance` governor. Measured execution order alternates
globally so neither implementation is consistently first. Matched
configurations remain available as diagnostics with `--threads 1,4` and an
explicit `--opencv-threads` value. Every worker's computation, dispatch,
barrier, and completion wait must remain inside the timed update.
The runner exports `MOSSE_RUST_CORES` for the Rust runtime and always passes
the separately recorded OpenCV thread count to the native harness.

The official
[`Experiment 066`](experiments/066-final-composite-qualification/protocol.md)
matrix used one warm-up per implementation and five globally alternating
full-video pairs under the performance governor. Rust measured
11,626.625991 FPS mean and 11,632.121609 FPS median, with the median-FPS run
at 85.968840 µs/update. The five Rust runs ranged from 11,585.054510 to
11,659.514987 FPS. All pairs had exact checksums, decisions, and boxes; the
Pi reached 67.679 °C without throttling, and the wrapper restored `ondemand`
with boot, watchdog, and RT settings unchanged. The separate current-build
single-thread companion measured 7,071.160241 FPS median (3.048193× the
frozen baseline).

The preceding isolated
[`Experiment 064`](experiments/064-composite-preprocess-forward/protocol.md)
replay remains the prerequisite implementation/phase-timing record, not the
final score.

Every invocation creates a unique directory below `results/pi4-scoring/`.
Nothing from an earlier suite is overwritten. Each directory contains
per-run CSV/JSON/log files, pre/post temperature/governor/throttling captures,
real-time scheduler bandwidth captures, paired parity reports from
`tools/compare_tracks.py`, full host captures, and an incrementally updated
machine-readable `manifest.json`.

Use smoke mode to validate deployment and plumbing without claiming a score:

```bash
bash scripts/run_pi4_scoring.sh --quick
```

Smoke mode defaults to one warm-up and one measured pair on CPU 0, limited to
120 frames, with no governor requirement. Explicit options override smoke
defaults, for example:

```bash
bash scripts/run_pi4_scoring.sh \
  --quick \
  --opencv-threads 1 \
  --threads 4 \
  --runs 2 \
  --max-frames 300 \
  --required-governor performance
```

Use `--pause-seconds` when a fixed settling interval is part of the recorded
protocol. The official run should retain video hash verification; only
non-scoring diagnostics should use `--skip-video-hash`.

## Diagnostic tracker replay profiling

`mosse_tracker_replay` is a separate, non-scoring executable for optimization
work. It decodes a bounded frame cache once, creates a fresh tracker for each
pass, and repeatedly replays the same cached frames. Every measured pass must
produce bit-identical success decisions and bounding boxes.

Run it directly:

```bash
./build/release/mosse_tracker_replay \
  --config config/benchmark.yml \
  --tracker rust \
  --cached-frames 300 \
  --repetitions 20
```

On the Pi, collect a sampled phase profile with:

```bash
./scripts/run_tracker_profile.sh \
  --run-id replay-$(git rev-parse --short HEAD)-300x50 \
  --cached-frames 300 \
  --repetitions 50
```

The script writes `perf.data`, the raw report, tracker-symbol rows, a normalized
phase summary, replay metadata, and the stable-trace result below
`results/pi4-profiling/<run-id>/`. Replay FPS is diagnostic: predecoded frames,
cache state, aggregate loop timing, and profiler overhead differ from official
scoring. Do not publish it as a benchmark score.

## Python preview package

The early `mosse-pi` preview embeds the existing Rust cdylib/C ABI without
duplicating tracker logic:

```python
from mosse_pi import MosseTracker

with MosseTracker(initial_frame, (x, y, width, height), mode="auto") as tracker:
    success, (x, y, width, height) = tracker.update(frame)
    print(tracker.selected_mode, tracker.backend)
```

It accepts OpenCV/NumPy `uint8` `HxWx3` BGR frames, passes supported layouts
zero-copy, releases the GIL during native work, and exposes
`mode="auto"|"single"|"multicore"`. `auto` attempts the qualified
continuous-normal-spin backend on capable Pi/AArch64 hosts and otherwise
reports a safe single-thread fallback. Explicit multicore fails clearly if
activation is unavailable. The fixed multicore kernels require an internally
rounded FFT window of exactly 60×36; other sizes use the exact single-thread
fallback. The AArch64 bundle requires glibc 2.34 or newer, while x86_64
requires glibc 2.28 or newer.

For production video on Pi, launch the complete process on CPU 0 before
OpenCV/FFmpeg creates decoder threads:

```bash
taskset --cpu-list 0 python3 python/examples/video_capture.py input.mp4 \
  --roi 100 80 60 36 --mode auto
```

The normally scheduled, nice-0 caller remains on CPU 0 while the three
normally scheduled Rust workers pin to CPUs 1–3 and continuously poll for the
tracker-handle lifetime. This topology needs no RT privilege. Keep an external
normal-priority process watchdog, close the handle deterministically, and use
the safe single-thread fallback when the isolated topology is unavailable.

Self-contained AArch64 and x86_64 archives, platform wheels, raw shared
libraries, the ABI header, all three staged examples, build identity, smoke
records, and recursive SHA-256 manifests are under
[`artifacts/python-preview/160c68016303`](artifacts/python-preview/160c68016303).
These `0.1.0.dev5` wrapper-only bundles retain the stable C ABI. The AArch64
wheel embeds the exact final-qualified `7aa6a3b8...` native library; the
x86_64 bundle deliberately exposes the portable single-thread backend.
Both downloadable archives were hash-checked and runtime-smoked after fresh
extraction on their target architectures. Earlier preview artifacts remain
archived under their original source identities. Source copies of the API
examples are
[`numpy_api.py`](python/examples/numpy_api.py) and
[`video_capture.py`](python/examples/video_capture.py).
Qualification and separately labeled Python-call timing are recorded in
[`experiments/051-python-preview-package/protocol.md`](experiments/051-python-preview-package/protocol.md).
This preview does not change the native headline benchmark boundary.

## Benchmark contract

- The shared C++ harness decodes every frame once and feeds the selected
  backend the same BGR `cv::Mat` representation.
- Initialization and every update are timed separately.
- Decode, checksumming, CSV/JSON output, display, annotation, and video writing
  are outside the tracker-update timer.
- Failed updates still count in attempted updates and tracker-only FPS.
- Processing continues to end-of-video after tracker failures.
- The official baseline is the median of at least five measured Pi runs after
  one warm-up.
- The production headline compares the authorized four-core Rust tracker with
  the default one-core OpenCV baseline. Core counts and scheduling policy are
  recorded explicitly; matched-core runs remain optional diagnostics.
- Measured implementation order alternates in the final suite.

Machine provisioning, environment capture, thermal controls, and the exact run
matrix are documented by the scripts in `scripts/`. Do not treat Dunamis
numbers as challenge results; the Raspberry Pi is authoritative.

The retained Rust implementation has complete Pi parity: all 4,947 decoded
frame checksums, 4,946 success/failure decisions, and 2,219 successful boxes
match the reference trace. Dunamis was also screened for transferable gains,
but its timings are labeled by architecture and never substituted for Pi
scoring. See [`FINAL_SUMMARY.md`](FINAL_SUMMARY.md), `FINAL_REPORT.md`, and
`FOUR_X_RESEARCH_ROADMAP.md` for the qualified result, evidence identities,
and optional follow-on work.
