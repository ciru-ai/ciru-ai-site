#include "mosse/frame_checksum.hpp"

#include <cstddef>
#include <iomanip>
#include <sstream>
#include <stdexcept>

namespace mosse {
namespace {

constexpr std::uint64_t kFnvOffsetBasis = 14695981039346656037ULL;
constexpr std::uint64_t kFnvPrime = 1099511628211ULL;

void add_byte(std::uint64_t &hash, const std::uint8_t byte) {
  hash ^= byte;
  hash *= kFnvPrime;
}

void add_u64_little_endian(std::uint64_t &hash, const std::uint64_t value) {
  for (unsigned int shift = 0; shift < 64U; shift += 8U) {
    add_byte(hash, static_cast<std::uint8_t>((value >> shift) & 0xffU));
  }
}

void add_bytes(std::uint64_t &hash, const std::uint8_t *data,
               const std::size_t byte_count) {
  for (std::size_t index = 0; index < byte_count; ++index) {
    add_byte(hash, data[index]);
  }
}

} // namespace

std::uint64_t frame_checksum_fnv1a64(const cv::Mat &frame) {
  if (frame.empty() || frame.dims != 2) {
    throw std::runtime_error(
        "Frame checksum requires a non-empty two-dimensional matrix");
  }

  const std::size_t row_bytes =
      static_cast<std::size_t>(frame.cols) * frame.elemSize();
  std::uint64_t hash = kFnvOffsetBasis;
  add_u64_little_endian(hash, static_cast<std::uint64_t>(frame.rows));
  add_u64_little_endian(hash, static_cast<std::uint64_t>(frame.cols));
  add_u64_little_endian(hash, static_cast<std::uint64_t>(frame.type()));
  add_u64_little_endian(hash, static_cast<std::uint64_t>(row_bytes));

  for (int row = 0; row < frame.rows; ++row) {
    add_bytes(hash, frame.ptr<std::uint8_t>(row), row_bytes);
  }
  return hash;
}

std::string checksum_hex(const std::uint64_t checksum) {
  std::ostringstream stream;
  stream << std::hex << std::nouppercase << std::setfill('0') << std::setw(16)
         << checksum;
  return stream.str();
}

void FrameSequenceChecksum::add(const std::uint64_t frame_index,
                                const std::uint64_t frame_checksum) {
  add_u64_little_endian(hash_, frame_index);
  add_u64_little_endian(hash_, frame_checksum);
}

std::uint64_t FrameSequenceChecksum::value() const noexcept { return hash_; }

} // namespace mosse
