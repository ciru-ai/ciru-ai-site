//! Feature-gated caller-plus-three-worker runtime for the Pi 4.
//!
//! This module drives the tracker's feature-gated fixed-layout parallel FFT.
//! [`FourCoreRuntime::from_environment`] honors `MOSSE_RUST_CORES`: `4`
//! requests the fixed four-lane runtime, while `1`, an unset value, or an
//! invalid value selects an explicit single-thread mode. Four-lane activation
//! is limited to Linux/AArch64 and succeeds only when all four lanes can be
//! pinned to CPUs 0-3. The retained production policy requires all four CPUs
//! in the caller's inherited affinity mask, places workers 1-3 in `SCHED_FIFO`
//! priority 50, and requires a positive finite or unlimited RT runtime budget.
//! The default-off `normal-spin-four-core-runtime` candidate accepts an
//! inherited mask containing CPU 0, then requires each worker to expand and
//! pin itself successfully to its dedicated CPU 1-3 before reporting ready.
//! It verifies nice value zero on the caller and every worker, verifies that
//! all workers remain `SCHED_OTHER` priority 0, and keeps them continuously
//! polling between tracker calls. That candidate needs no real-time scheduling
//! capability, but intentionally dedicates and consumes CPUs 1-3 whenever the
//! tracker exists.
//! Lane zero retains its captured normal scheduler policy for the complete
//! runtime lifetime. Retained-policy workers block while the tracker is
//! outside an initialization/update scope, then remain awake across every
//! dispatch in that scope; normal-spin workers poll across the same boundary.
//! The retained caller waits for parked acknowledgements before returning,
//! while the candidate only closes the atomic activity gate.
//!
//! Dispatch uses a static `task_index % 4` partition. Lane zero always runs on
//! the constructing caller, and three persistent workers own lanes one
//! through three. Job publication, caller work, worker work, and all three
//! completion barriers occur before [`FourCoreRuntime::dispatch`] returns.
//! Normal dispatch inside an active scope performs no allocation,
//! queue/channel operation, mutex operation, parking, thread creation, or
//! join. Parking and wakeup happen only at the enclosing tracker-call boundary
//! in the retained FIFO policy. The normal-spin candidate makes scope
//! open/close allocation- and syscall-free atomic gates and never parks a live
//! worker.
//! The default-off crop pipeline may publish one three-task worker-only epoch
//! before that boundary opens: task `i` belongs to worker lane `i + 1`. Under
//! the parked policy all three workers wake directly into useful work; under
//! normal-spin they observe the publication without a wake. Lane zero remains
//! on the normal-scheduler caller.
//!
//! The runtime is deliberately neither `Send` nor `Sync`: the caller's saved
//! affinity belongs to the thread that constructed it.

use std::{
    ffi::OsStr,
    marker::PhantomData,
    panic::{catch_unwind, resume_unwind, AssertUnwindSafe},
    ptr,
    rc::Rc,
    sync::{
        atomic::{AtomicBool, AtomicI32, AtomicPtr, AtomicU32, AtomicU64, AtomicU8, Ordering},
        Arc,
    },
    thread::{self, JoinHandle},
    time::{Duration, Instant},
};

/// Caller plus three persistent workers.
pub const LANE_COUNT: usize = 4;
/// The number of persistent worker threads.
pub const WORKER_COUNT: usize = LANE_COUNT - 1;
/// Static lane-to-CPU ownership used by the Pi 4 runtime.
pub const FIXED_CPUS: [usize; LANE_COUNT] = [0, 1, 2, 3];
/// Real-time priority used only by persistent worker lanes 1-3.
pub const EXECUTOR_FIFO_PRIORITY: i32 = 50;

const STARTUP_TIMEOUT: Duration = Duration::from_millis(250);
const SHUTDOWN_TIMEOUT: Duration = Duration::from_millis(100);
const SCOPE_PARK_TIMEOUT: Duration = Duration::from_millis(100);
const READY_WAITING: u8 = 0;
const READY_OK: u8 = 1;
const READY_FAILED: u8 = 2;

/// Effective execution mode, independent of the requested core count.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ExecutionMode {
    SingleThread,
    PersistentFourCore,
}

/// How persistent worker lanes behave outside tracker-call scopes.
///
/// This is additive runtime metadata; tracker, C ABI, and Python backend
/// selection retain the existing single-versus-multicore contract.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum WorkerActivityMode {
    /// Retained watchdog-safe policy: FIFO50 workers block between calls.
    ParkedFifo,
    /// Experimental policy: SCHED_OTHER workers continuously poll.
    ContinuousNormalSpin,
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
enum WorkerPolicy {
    #[default]
    ParkedFifo,
    ContinuousNormalSpin,
}

impl WorkerPolicy {
    const fn parks_between_scopes(self) -> bool {
        matches!(self, Self::ParkedFifo)
    }

    const fn scheduler_priority(self) -> i32 {
        match self {
            Self::ParkedFifo => EXECUTOR_FIFO_PRIORITY,
            Self::ContinuousNormalSpin => 0,
        }
    }

    #[cfg(any(
        test,
        all(
            feature = "pi4-four-core-runtime",
            target_os = "linux",
            target_arch = "aarch64"
        )
    ))]
    const fn requires_rt_bandwidth(self) -> bool {
        matches!(self, Self::ParkedFifo)
    }
}

const fn production_worker_policy() -> WorkerPolicy {
    if cfg!(feature = "normal-spin-four-core-runtime") {
        WorkerPolicy::ContinuousNormalSpin
    } else {
        WorkerPolicy::ParkedFifo
    }
}

#[cfg(any(
    test,
    all(
        feature = "pi4-four-core-runtime",
        target_os = "linux",
        target_arch = "aarch64"
    )
))]
fn validate_inherited_affinity(
    worker_policy: WorkerPolicy,
    mut cpu_is_allowed: impl FnMut(usize) -> bool,
) -> Result<(), SetupFailure> {
    let required_cpus: &[usize] = match worker_policy {
        // Retain the qualified FIFO policy's strict inherited-mask gate.
        WorkerPolicy::ParkedFifo => &FIXED_CPUS,
        // A CPU0-only launch intentionally isolates decoder threads. Workers
        // prove CPUs 1-3 are actually usable through their readiness-time
        // pthread_setaffinity_np calls instead of assuming that a caller's
        // current per-thread mask describes its cpuset/cgroup allowance.
        WorkerPolicy::ContinuousNormalSpin => &FIXED_CPUS[..1],
    };
    if required_cpus.iter().copied().all(&mut cpu_is_allowed) {
        Ok(())
    } else {
        Err(SetupFailure {
            lane: 0,
            stage: SetupStage::ValidateAllowedCpus,
            os_error: None,
        })
    }
}

/// Parsed `MOSSE_RUST_CORES` request.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CoreRequest {
    Unset,
    One,
    Four,
    Unsupported(usize),
    Invalid,
}

/// Startup operation associated with a failure.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[repr(u8)]
pub enum SetupStage {
    UnsupportedPlatform = 1,
    CaptureAffinity = 2,
    CaptureScheduler = 3,
    ValidateAllowedCpus = 4,
    SpawnWorker = 5,
    PinThread = 6,
    SetFifoPriority = 7,
    WorkerReadiness = 8,
    WorkerStartupPanic = 9,
    RestoreAffinity = 10,
    RestoreScheduler = 11,
    WrongCallerThread = 12,
    ValidateRtBandwidth = 13,
    ValidateCallerScheduler = 14,
    ValidateWorkerScheduler = 15,
    ValidateCallerNice = 16,
    ValidateWorkerNice = 17,
}

/// Allocation-free diagnostic for one setup or restoration failure.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct SetupFailure {
    /// Lane zero is the caller; lanes one through three are workers.
    pub lane: u8,
    pub stage: SetupStage,
    /// Positive platform error number when the failing API supplied one.
    pub os_error: Option<i32>,
}

/// Why a requested four-lane runtime is not active.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FallbackReason {
    CoreRequest(CoreRequest),
    UnsupportedPlatform,
    StartupFailed {
        cause: SetupFailure,
        caller_restore_failure: Option<SetupFailure>,
        detached_workers: u8,
    },
}

/// Discoverable requested/effective runtime state.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RuntimeStatus {
    SingleThread {
        request: CoreRequest,
        reason: FallbackReason,
    },
    PersistentFourCore {
        request: CoreRequest,
        cpus: [usize; LANE_COUNT],
        caller_normal_scheduler: bool,
        workers_park_between_scopes: bool,
        worker_scheduler_priority: i32,
        rt_runtime_us: i64,
    },
}

/// Result of explicit or automatic teardown.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct ShutdownReport {
    pub joined_workers: u8,
    pub detached_workers: u8,
    pub worker_panics: u8,
    pub caller_restore_failure: Option<SetupFailure>,
}

impl ShutdownReport {
    pub const fn clean(self) -> bool {
        self.detached_workers == 0
            && self.worker_panics == 0
            && self.caller_restore_failure.is_none()
    }
}

enum Backend {
    SingleThread,
    Parallel(ParallelBackend),
}

/// Owned RAII boundary that enables persistent workers across a group of
/// dispatches and completes the selected policy's close gate before return.
///
/// The guard deliberately does not borrow the runtime: tracker code must keep
/// mutably borrowing its workspace while the boundary is active. It is still
/// `!Send` so safe Rust cannot move the boundary away from the owning caller.
pub struct ActiveFourCoreScope {
    shared: Option<Arc<Shared>>,
    _caller_thread_bound: PhantomData<Rc<()>>,
}

impl Drop for ActiveFourCoreScope {
    fn drop(&mut self) {
        let Some(shared) = self.shared.take() else {
            return;
        };
        shared.scope_active.0.close();
        if !shared.worker_policy.parks_between_scopes() {
            // Every dispatch barrier has already cleared its caller-owned job.
            // Normal-priority workers deliberately continue polling, so the
            // close boundary is only this gate plus the owned Arc decrement.
            return;
        }
        if shared.stop.load(Ordering::Acquire) {
            return;
        }
        let deadline = Instant::now() + SCOPE_PARK_TIMEOUT;
        while shared
            .parked
            .iter()
            .any(|parked| !parked.0.load(Ordering::Acquire))
        {
            if shared.stop.load(Ordering::Acquire) {
                return;
            }
            if Instant::now() >= deadline {
                eprintln!(
                    "fatal: persistent MOSSE worker failed to acknowledge the parked boundary"
                );
                // Returning would leave an unexpected FIFO worker runnable
                // outside the watchdog-safe tracker-call boundary.
                std::process::abort();
            }
            std::hint::spin_loop();
        }
    }
}

/// Environment-selected single-thread or persistent four-core runtime.
///
/// Construction and teardown may allocate or enter the scheduler. Dispatch
/// does neither. A parallel runtime is bound to its constructing thread so
/// lane zero cannot silently migrate to another caller.
pub struct FourCoreRuntime {
    backend: Option<Backend>,
    status: RuntimeStatus,
    _caller_thread_bound: PhantomData<Rc<()>>,
}

impl FourCoreRuntime {
    /// Read `MOSSE_RUST_CORES` and construct the requested safe runtime.
    pub fn from_environment() -> Self {
        let request = parse_core_request(std::env::var_os("MOSSE_RUST_CORES").as_deref());
        Self::from_core_request(request)
    }

    /// Construct from an explicit core count using the same production policy.
    ///
    /// This is useful for diagnostics that should not mutate process
    /// environment. Only `1` and `4` are accepted.
    pub fn from_requested_cores(requested: usize) -> Self {
        let request = match requested {
            1 => CoreRequest::One,
            4 => CoreRequest::Four,
            other => CoreRequest::Unsupported(other),
        };
        Self::from_core_request(request)
    }

    fn from_core_request(request: CoreRequest) -> Self {
        if request != CoreRequest::Four {
            return Self::single_thread(request, FallbackReason::CoreRequest(request));
        }
        if !production_target_supported() {
            return Self::single_thread(request, FallbackReason::UnsupportedPlatform);
        }

        Self::from_four_core_plan(request, SetupPlan::Production)
    }

    fn from_four_core_plan(request: CoreRequest, plan: SetupPlan) -> Self {
        match ParallelBackend::start(plan) {
            Ok(parallel) => {
                let rt_runtime_us = parallel.rt_runtime_us;
                let worker_policy = parallel.worker_policy;
                Self {
                    backend: Some(Backend::Parallel(parallel)),
                    status: RuntimeStatus::PersistentFourCore {
                        request,
                        cpus: FIXED_CPUS,
                        caller_normal_scheduler: true,
                        workers_park_between_scopes: worker_policy.parks_between_scopes(),
                        worker_scheduler_priority: worker_policy.scheduler_priority(),
                        rt_runtime_us,
                    },
                    _caller_thread_bound: PhantomData,
                }
            }
            Err(error) => Self::single_thread(
                request,
                FallbackReason::StartupFailed {
                    cause: error.cause,
                    caller_restore_failure: error.caller_restore_failure,
                    detached_workers: error.cleanup.detached_workers,
                },
            ),
        }
    }

    fn single_thread(request: CoreRequest, reason: FallbackReason) -> Self {
        Self {
            backend: Some(Backend::SingleThread),
            status: RuntimeStatus::SingleThread { request, reason },
            _caller_thread_bound: PhantomData,
        }
    }

    /// Requested and effective mode, including any fallback reason.
    pub const fn status(&self) -> RuntimeStatus {
        self.status
    }

    pub const fn mode(&self) -> ExecutionMode {
        match self.status {
            RuntimeStatus::SingleThread { .. } => ExecutionMode::SingleThread,
            RuntimeStatus::PersistentFourCore { .. } => ExecutionMode::PersistentFourCore,
        }
    }

    #[cfg(all(test, feature = "composite-preprocess-forward-60x36"))]
    pub(crate) fn test_dispatch_epoch(&self) -> u64 {
        match self
            .backend
            .as_ref()
            .expect("four-core runtime backend missing before drop")
        {
            Backend::SingleThread => 0,
            Backend::Parallel(parallel) => parallel.next_epoch,
        }
    }

    pub const fn effective_core_count(&self) -> usize {
        match self.mode() {
            ExecutionMode::SingleThread => 1,
            ExecutionMode::PersistentFourCore => LANE_COUNT,
        }
    }

    pub const fn fallback_reason(&self) -> Option<FallbackReason> {
        match self.status {
            RuntimeStatus::SingleThread { reason, .. } => Some(reason),
            RuntimeStatus::PersistentFourCore { .. } => None,
        }
    }

    /// Disclose the selected persistent-worker lifecycle policy.
    ///
    /// `None` means startup selected the single-thread fallback.
    pub const fn worker_activity_mode(&self) -> Option<WorkerActivityMode> {
        match self.status {
            RuntimeStatus::SingleThread { .. } => None,
            RuntimeStatus::PersistentFourCore {
                workers_park_between_scopes: true,
                ..
            } => Some(WorkerActivityMode::ParkedFifo),
            RuntimeStatus::PersistentFourCore {
                workers_park_between_scopes: false,
                ..
            } => Some(WorkerActivityMode::ContinuousNormalSpin),
        }
    }

    /// Open persistent worker activity for one tracker initialization/update.
    ///
    /// The returned owned guard does not borrow this runtime, so dispatches may
    /// continue through the workspace that owns it. Dropping the guard clears
    /// the active flag. The retained policy then waits for parked
    /// acknowledgements; normal-spin closes immediately because workers remain
    /// runnable by design. A single-thread runtime returns a no-op guard.
    pub fn begin_activity(&mut self) -> ActiveFourCoreScope {
        let shared = match self
            .backend
            .as_mut()
            .expect("four-core runtime backend missing before drop")
        {
            Backend::SingleThread => None,
            Backend::Parallel(parallel) => Some(parallel.begin_activity()),
        };
        ActiveFourCoreScope {
            shared,
            _caller_thread_bound: PhantomData,
        }
    }

    /// Publish one three-task worker-only epoch before opening and waking an
    /// activity, then return the still-active scope after all tasks complete.
    ///
    /// In four-core mode task indices zero through two belong exclusively to
    /// worker lanes one through three. The caller executes no task. The stack
    /// job descriptor is cleared before this method returns, while dropping
    /// the returned guard still performs the normal final park barrier after
    /// later dispatches. A single-thread backend executes all three tasks on
    /// the caller before returning a no-op guard.
    #[cfg(all(
        feature = "wake-crop-pipeline-60x36",
        any(test, all(target_os = "linux", target_arch = "aarch64"))
    ))]
    pub(crate) fn begin_activity_with_worker_job<T, F>(
        &mut self,
        tasks: &mut [T; WORKER_COUNT],
        operation: F,
    ) -> ActiveFourCoreScope
    where
        T: Send,
        F: Fn(usize, &mut T) + Sync,
    {
        let (shared, worker_panicked) = match self
            .backend
            .as_mut()
            .expect("four-core runtime backend missing before drop")
        {
            Backend::SingleThread => {
                for (index, task) in tasks.iter_mut().enumerate() {
                    operation(index, task);
                }
                (None, false)
            }
            Backend::Parallel(parallel) => {
                let (shared, worker_panicked) =
                    parallel.begin_activity_with_worker_job(tasks, operation);
                (Some(shared), worker_panicked)
            }
        };
        // Construct the guard before propagating a worker panic. Its unwind
        // drop closes the active word and waits for the final park barrier.
        let activity = ActiveFourCoreScope {
            shared,
            _caller_thread_bound: PhantomData,
        };
        assert!(
            !worker_panicked,
            "persistent four-core worker operation panicked"
        );
        activity
    }

    /// Execute every task exactly once.
    ///
    /// Parallel ownership is static: task `i` always belongs to lane `i % 4`.
    /// The operation may borrow caller-owned state but must not block
    /// indefinitely. A panic poisons a parallel backend after all live lanes
    /// reach the completion barrier; teardown remains safe, but another
    /// dispatch is rejected.
    pub fn dispatch<T, F>(&mut self, tasks: &mut [T], operation: F)
    where
        T: Send,
        F: Fn(usize, &mut T) + Sync,
    {
        match self
            .backend
            .as_mut()
            .expect("four-core runtime backend missing before drop")
        {
            Backend::SingleThread => {
                for (index, task) in tasks.iter_mut().enumerate() {
                    operation(index, task);
                }
            }
            Backend::Parallel(parallel) => parallel.dispatch(tasks, operation),
        }
    }

    /// Run worker-only tasks while the caller consumes independently
    /// published results.
    ///
    /// Parallel task ownership is static: worker lane one owns indices
    /// `0, 3, 6, ...`, lane two owns `1, 4, 7, ...`, and lane three owns
    /// `2, 5, 8, ...`. The caller closure runs immediately after publication
    /// and may wait for per-task release stores through [`WorkerJobProgress`].
    /// Both caller and worker panics still cross the complete worker barrier,
    /// clear the stack descriptor, and poison the runtime before propagation.
    /// A single-thread backend runs all tasks first and then the caller.
    #[cfg(all(
        feature = "pipelined-inverse-reduction-60x36",
        any(test, all(target_os = "linux", target_arch = "aarch64"))
    ))]
    pub(crate) fn dispatch_workers_with_caller<T, F, C, R>(
        &mut self,
        tasks: &mut [T],
        operation: F,
        caller: C,
    ) -> R
    where
        T: Send,
        F: Fn(usize, &mut T) + Sync,
        C: FnOnce(&WorkerJobProgress<'_>) -> R,
    {
        match self
            .backend
            .as_mut()
            .expect("four-core runtime backend missing before drop")
        {
            Backend::SingleThread => {
                for (index, task) in tasks.iter_mut().enumerate() {
                    operation(index, task);
                }
                caller(&WorkerJobProgress {
                    shared: None,
                    dispatch_epoch: 0,
                })
            }
            Backend::Parallel(parallel) => {
                parallel.dispatch_workers_with_caller(tasks, operation, caller)
            }
        }
    }

    /// Publish and complete one epoch containing no tasks.
    pub fn dispatch_empty(&mut self) {
        let mut no_tasks: [u8; 0] = [];
        self.dispatch(&mut no_tasks, |_, _| {});
    }

    /// Stop workers within the bounded teardown window and restore caller
    /// affinity. The caller scheduler is never changed. `Drop` performs the
    /// same operation and discards the report.
    pub fn shutdown(mut self) -> ShutdownReport {
        self.shutdown_inner()
    }

    fn shutdown_inner(&mut self) -> ShutdownReport {
        match self.backend.take() {
            Some(Backend::Parallel(mut parallel)) => parallel.shutdown(),
            Some(Backend::SingleThread) | None => ShutdownReport::default(),
        }
    }

    #[cfg(test)]
    fn test_parallel(setup: TestSetup) -> Result<Self, StartError> {
        let parallel = ParallelBackend::start(SetupPlan::Test(setup))?;
        let rt_runtime_us = parallel.rt_runtime_us;
        let worker_policy = parallel.worker_policy;
        Ok(Self {
            backend: Some(Backend::Parallel(parallel)),
            status: RuntimeStatus::PersistentFourCore {
                request: CoreRequest::Four,
                cpus: FIXED_CPUS,
                caller_normal_scheduler: true,
                workers_park_between_scopes: worker_policy.parks_between_scopes(),
                worker_scheduler_priority: worker_policy.scheduler_priority(),
                rt_runtime_us,
            },
            _caller_thread_bound: PhantomData,
        })
    }

    /// Construct an unpinned deterministic four-lane runtime for crate tests.
    ///
    /// This bypasses production affinity/scheduler setup while retaining the
    /// real publication, static ownership, and completion barriers.
    #[cfg(all(
        test,
        any(
            feature = "parallel-tail-preprocess-60x36",
            feature = "parallel-correlated-inverse-60x36",
            feature = "fused-correlated-inverse-cfft36-60x36",
            feature = "fused-normalize-forward-60x36",
            feature = "composite-preprocess-forward-60x36",
            feature = "parallel-model-blend-filter-60x36",
            feature = "wake-crop-pipeline-60x36",
            feature = "pipelined-inverse-reduction-60x36"
        )
    ))]
    pub(crate) fn test_parallel_unconfigured() -> Self {
        Self::test_parallel(TestSetup {
            worker_policy: production_worker_policy(),
            ..TestSetup::default()
        })
        .expect("unconfigured deterministic test workers must start")
    }

    #[cfg(test)]
    fn test_with_setup(setup: TestSetup) -> Self {
        Self::from_four_core_plan(CoreRequest::Four, SetupPlan::Test(setup))
    }
}

impl Default for FourCoreRuntime {
    fn default() -> Self {
        Self::from_environment()
    }
}

impl Drop for FourCoreRuntime {
    fn drop(&mut self) {
        let _ = self.shutdown_inner();
    }
}

fn parse_core_request(value: Option<&OsStr>) -> CoreRequest {
    let Some(value) = value else {
        return CoreRequest::Unset;
    };
    let Some(value) = value.to_str() else {
        return CoreRequest::Invalid;
    };
    match value.trim().parse::<usize>() {
        Ok(1) => CoreRequest::One,
        Ok(4) => CoreRequest::Four,
        Ok(other) => CoreRequest::Unsupported(other),
        Err(_) => CoreRequest::Invalid,
    }
}

#[cfg(any(
    test,
    all(
        feature = "pi4-four-core-runtime",
        target_os = "linux",
        target_arch = "aarch64"
    )
))]
fn parse_rt_runtime_us(value: &str) -> Option<i64> {
    match value.trim().parse::<i64>() {
        Ok(runtime_us) if runtime_us == -1 || runtime_us > 0 => Some(runtime_us),
        _ => None,
    }
}

const fn production_target_supported() -> bool {
    cfg!(all(
        feature = "pi4-four-core-runtime",
        target_os = "linux",
        target_arch = "aarch64"
    ))
}

#[repr(align(128))]
struct CacheLine<T>(T);

struct ErasedJob {
    context: *mut u8,
    task_count: usize,
    invoke: unsafe fn(*mut u8, usize),
    partition: TaskPartition,
}

#[derive(Clone, Copy)]
enum TaskPartition {
    CallerAndWorkers,
    #[cfg(all(
        any(
            feature = "wake-crop-pipeline-60x36",
            feature = "pipelined-inverse-reduction-60x36"
        ),
        any(test, all(target_os = "linux", target_arch = "aarch64"))
    ))]
    WorkersOnly,
}

/// Read-only progress handle supplied to a caller that overlaps worker work.
///
/// A published result uses an algorithm-owned epoch, while `dispatch_epoch`
/// identifies the runtime job whose worker panic state must also be observed.
#[cfg(all(
    feature = "pipelined-inverse-reduction-60x36",
    any(test, all(target_os = "linux", target_arch = "aarch64"))
))]
pub(crate) struct WorkerJobProgress<'a> {
    shared: Option<&'a Shared>,
    dispatch_epoch: u64,
}

#[cfg(all(
    feature = "pipelined-inverse-reduction-60x36",
    any(test, all(target_os = "linux", target_arch = "aarch64"))
))]
impl WorkerJobProgress<'_> {
    /// Wait for one algorithm-owned release publication without deadlocking
    /// if the responsible worker panics before publishing it.
    pub(crate) fn wait_until(&self, ready_epoch: &AtomicU64, expected_epoch: u64) {
        loop {
            let observed = ready_epoch.load(Ordering::Acquire);
            if observed == expected_epoch {
                return;
            }
            assert!(
                observed < expected_epoch,
                "worker result epoch advanced past the caller's expected epoch"
            );
            if let Some(shared) = self.shared {
                let mut all_workers_completed = true;
                let mut worker_panicked = false;
                for completion in &shared.completion {
                    let completed =
                        completion.0.epoch.load(Ordering::Acquire) == self.dispatch_epoch;
                    all_workers_completed &= completed;
                    worker_panicked |= completed && completion.0.panicked.load(Ordering::Relaxed);
                }
                assert!(
                    !worker_panicked,
                    "persistent four-core worker panicked before publishing caller-consumed data"
                );
                if all_workers_completed {
                    // The first ready load may have preceded the completion
                    // acquire. Reload after acquiring all completions so the
                    // worker's preceding publication is visible before
                    // declaring it missing.
                    let observed_after_completion = ready_epoch.load(Ordering::Acquire);
                    if observed_after_completion == expected_epoch {
                        return;
                    }
                    assert!(
                        observed_after_completion < expected_epoch,
                        "worker result epoch advanced past the caller's expected epoch"
                    );
                    panic!(
                        "persistent four-core workers completed without publishing \
                         caller-consumed data"
                    );
                }
            }
            std::hint::spin_loop();
        }
    }
}

struct TypedJob<'a, T, F> {
    tasks: *mut T,
    operation: &'a F,
    _borrow: PhantomData<&'a mut [T]>,
}

unsafe fn invoke_typed<T, F>(context: *mut u8, index: usize)
where
    T: Send,
    F: Fn(usize, &mut T) + Sync,
{
    // SAFETY: dispatch keeps the descriptor, operation, and task slice alive
    // through all completion epochs. Modulo-four ownership makes this task's
    // mutable reference unique.
    let typed = unsafe { &*(context.cast::<TypedJob<'_, T, F>>()) };
    // SAFETY: execute_partition emits only in-bounds indices and each selected
    // partition assigns every index to exactly one lane.
    let task = unsafe { &mut *typed.tasks.add(index) };
    (typed.operation)(index, task);
}

struct Completion {
    epoch: AtomicU64,
    panicked: AtomicBool,
}

struct ActivityState {
    value: AtomicU32,
}

impl ActivityState {
    const fn new() -> Self {
        Self {
            value: AtomicU32::new(0),
        }
    }

    fn open(&self) -> Result<(), u32> {
        self.value
            .compare_exchange(0, 1, Ordering::AcqRel, Ordering::Acquire)
            .map(|_| ())
    }

    fn close(&self) {
        // Shutdown may publish STOPPED while an owned activity guard still
        // exists. Never overwrite that retained wake state with INACTIVE.
        let _ = self
            .value
            .compare_exchange(1, 0, Ordering::Release, Ordering::Acquire);
    }

    fn is_active(&self) -> bool {
        self.value.load(Ordering::Acquire) == 1
    }

    fn mark_stopped(&self) {
        // A nonzero stopped state is a retained futex token: a worker that
        // reaches FUTEX_WAIT after the shutdown wake receives EAGAIN rather
        // than sleeping forever on the inactive value.
        self.value.store(2, Ordering::Release);
    }
}

struct Readiness {
    state: AtomicU8,
    stage: AtomicU8,
    os_error: AtomicI32,
}

impl Readiness {
    const fn new() -> Self {
        Self {
            state: AtomicU8::new(READY_WAITING),
            stage: AtomicU8::new(0),
            os_error: AtomicI32::new(0),
        }
    }

    fn publish_failure(&self, failure: SetupFailure) {
        self.stage.store(failure.stage as u8, Ordering::Relaxed);
        self.os_error
            .store(failure.os_error.unwrap_or(0), Ordering::Relaxed);
        self.state.store(READY_FAILED, Ordering::Release);
    }

    fn failure(&self, lane: u8) -> SetupFailure {
        SetupFailure {
            lane,
            stage: decode_setup_stage(self.stage.load(Ordering::Relaxed)),
            os_error: match self.os_error.load(Ordering::Relaxed) {
                0 => None,
                error => Some(error),
            },
        }
    }
}

struct Shared {
    worker_policy: WorkerPolicy,
    epoch: CacheLine<AtomicU64>,
    current_job: AtomicPtr<ErasedJob>,
    scope_active: CacheLine<ActivityState>,
    stop: AtomicBool,
    completion: [CacheLine<Completion>; WORKER_COUNT],
    parked: [CacheLine<AtomicBool>; WORKER_COUNT],
    readiness: [CacheLine<Readiness>; WORKER_COUNT],
}

impl Shared {
    fn new(worker_policy: WorkerPolicy) -> Self {
        Self {
            worker_policy,
            epoch: CacheLine(AtomicU64::new(0)),
            current_job: AtomicPtr::new(ptr::null_mut()),
            scope_active: CacheLine(ActivityState::new()),
            stop: AtomicBool::new(false),
            completion: std::array::from_fn(|_| {
                CacheLine(Completion {
                    epoch: AtomicU64::new(0),
                    panicked: AtomicBool::new(false),
                })
            }),
            parked: std::array::from_fn(|_| CacheLine(AtomicBool::new(false))),
            readiness: std::array::from_fn(|_| CacheLine(Readiness::new())),
        }
    }
}

struct ParallelBackend {
    shared: Arc<Shared>,
    workers: [Option<JoinHandle<()>>; WORKER_COUNT],
    caller_state: Option<CallerState>,
    caller_thread: thread::ThreadId,
    next_epoch: u64,
    poisoned: bool,
    rt_runtime_us: i64,
    worker_policy: WorkerPolicy,
}

impl ParallelBackend {
    fn start(plan: SetupPlan) -> Result<Self, StartError> {
        let worker_policy = plan.worker_policy();
        let caller_state = prepare_caller(plan).map_err(StartError::without_cleanup)?;
        let rt_runtime_us = caller_state.rt_runtime_us;
        pin_caller(plan).map_err(StartError::without_cleanup)?;
        let shared = Arc::new(Shared::new(worker_policy));
        let mut workers: [Option<JoinHandle<()>>; WORKER_COUNT] = std::array::from_fn(|_| None);

        for worker_index in 0..WORKER_COUNT {
            let worker_shared = Arc::clone(&shared);
            let lane = (worker_index + 1) as u8;
            let handle = thread::Builder::new()
                .name(format!("mosse-four-core-{lane}"))
                .spawn(move || worker_entry(worker_shared, worker_index, lane, plan));
            match handle {
                Ok(handle) => workers[worker_index] = Some(handle),
                Err(error) => {
                    let cleanup = stop_workers(&shared, &mut workers);
                    return Err(StartError::after_caller_pin(
                        SetupFailure {
                            lane,
                            stage: SetupStage::SpawnWorker,
                            os_error: error.raw_os_error(),
                        },
                        cleanup,
                        &caller_state,
                    ));
                }
            }
        }

        let deadline = Instant::now() + STARTUP_TIMEOUT;
        loop {
            let mut all_ready = true;
            for (worker_index, readiness) in shared.readiness.iter().enumerate() {
                match readiness.0.state.load(Ordering::Acquire) {
                    READY_OK if shared.parked[worker_index].0.load(Ordering::Acquire) => {}
                    READY_OK => all_ready = false,
                    READY_FAILED => {
                        let cleanup = stop_workers(&shared, &mut workers);
                        return Err(StartError::after_caller_pin(
                            readiness.0.failure((worker_index + 1) as u8),
                            cleanup,
                            &caller_state,
                        ));
                    }
                    _ => all_ready = false,
                }
            }
            if all_ready {
                break;
            }
            if Instant::now() >= deadline {
                let lane = shared
                    .readiness
                    .iter()
                    .position(|ready| ready.0.state.load(Ordering::Acquire) == READY_WAITING)
                    .map_or(1, |index| (index + 1) as u8);
                let cleanup = stop_workers(&shared, &mut workers);
                return Err(StartError::after_caller_pin(
                    SetupFailure {
                        lane,
                        stage: SetupStage::WorkerReadiness,
                        os_error: None,
                    },
                    cleanup,
                    &caller_state,
                ));
            }
            std::hint::spin_loop();
            thread::yield_now();
        }

        Ok(Self {
            shared,
            workers,
            caller_state: Some(caller_state),
            caller_thread: thread::current().id(),
            next_epoch: 0,
            poisoned: false,
            rt_runtime_us,
            worker_policy,
        })
    }

    fn begin_activity(&mut self) -> Arc<Shared> {
        assert_eq!(
            thread::current().id(),
            self.caller_thread,
            "persistent four-core activity started from a different caller thread"
        );
        assert!(
            !self.poisoned,
            "persistent four-core runtime is poisoned by an earlier panic"
        );
        self.shared
            .scope_active
            .0
            .open()
            .expect("persistent four-core activity scopes must not overlap");
        if self.worker_policy.parks_between_scopes() {
            wake_parked_workers(&self.shared, &self.workers);
        }
        Arc::clone(&self.shared)
    }

    #[cfg(all(
        feature = "wake-crop-pipeline-60x36",
        any(test, all(target_os = "linux", target_arch = "aarch64"))
    ))]
    fn begin_activity_with_worker_job<T, F>(
        &mut self,
        tasks: &mut [T; WORKER_COUNT],
        operation: F,
    ) -> (Arc<Shared>, bool)
    where
        T: Send,
        F: Fn(usize, &mut T) + Sync,
    {
        assert_eq!(
            thread::current().id(),
            self.caller_thread,
            "persistent four-core activity started from a different caller thread"
        );
        assert!(
            !self.poisoned,
            "persistent four-core runtime is poisoned by an earlier panic"
        );
        assert_eq!(
            self.shared.scope_active.0.value.load(Ordering::Acquire),
            0,
            "persistent four-core activity scopes must not overlap"
        );
        let epoch = self
            .next_epoch
            .checked_add(1)
            .expect("persistent four-core runtime exhausted its dispatch epoch");

        let typed = TypedJob {
            tasks: tasks.as_mut_ptr(),
            operation: &operation,
            _borrow: PhantomData,
        };
        let erased = ErasedJob {
            context: ptr::from_ref(&typed).cast_mut().cast(),
            task_count: tasks.len(),
            invoke: invoke_typed::<T, F>,
            partition: TaskPartition::WorkersOnly,
        };

        // Publication deliberately precedes opening the activity word. Parked
        // workers therefore wake directly into a valid useful epoch.
        self.shared
            .current_job
            .store(ptr::from_ref(&erased).cast_mut(), Ordering::Relaxed);
        self.shared.epoch.0.store(epoch, Ordering::Release);
        self.next_epoch = epoch;
        self.shared
            .scope_active
            .0
            .open()
            .expect("prevalidated four-core activity scope must open");
        if self.worker_policy.parks_between_scopes() {
            wake_parked_workers(&self.shared, &self.workers);
        }

        for completion in &self.shared.completion {
            while completion.0.epoch.load(Ordering::Acquire) != epoch {
                std::hint::spin_loop();
            }
        }
        self.shared
            .current_job
            .store(ptr::null_mut(), Ordering::Relaxed);

        let worker_panicked = self
            .shared
            .completion
            .iter()
            .any(|completion| completion.0.panicked.load(Ordering::Relaxed));
        if worker_panicked {
            self.poisoned = true;
        }
        (Arc::clone(&self.shared), worker_panicked)
    }

    fn dispatch<T, F>(&mut self, tasks: &mut [T], operation: F)
    where
        T: Send,
        F: Fn(usize, &mut T) + Sync,
    {
        assert_eq!(
            thread::current().id(),
            self.caller_thread,
            "persistent four-core runtime used from a different caller thread"
        );
        assert!(
            !self.poisoned,
            "persistent four-core runtime is poisoned by an earlier panic"
        );
        assert!(
            self.shared.scope_active.0.is_active(),
            "persistent four-core dispatch requires an active tracker-call scope"
        );
        let epoch = self
            .next_epoch
            .checked_add(1)
            .expect("persistent four-core runtime exhausted its dispatch epoch");

        let typed = TypedJob {
            tasks: tasks.as_mut_ptr(),
            operation: &operation,
            _borrow: PhantomData,
        };
        let erased = ErasedJob {
            context: ptr::from_ref(&typed).cast_mut().cast(),
            task_count: tasks.len(),
            invoke: invoke_typed::<T, F>,
            partition: TaskPartition::CallerAndWorkers,
        };

        self.shared
            .current_job
            .store(ptr::from_ref(&erased).cast_mut(), Ordering::Relaxed);
        self.shared.epoch.0.store(epoch, Ordering::Release);
        self.next_epoch = epoch;

        let caller_panic = catch_unwind(AssertUnwindSafe(|| {
            // SAFETY: lane zero owns exactly indices 0, 4, 8, ...
            unsafe { execute_partition(&erased, 0) };
        }))
        .err();

        for completion in &self.shared.completion {
            while completion.0.epoch.load(Ordering::Acquire) != epoch {
                std::hint::spin_loop();
            }
        }
        self.shared
            .current_job
            .store(ptr::null_mut(), Ordering::Relaxed);

        let worker_panicked = self
            .shared
            .completion
            .iter()
            .any(|completion| completion.0.panicked.load(Ordering::Relaxed));
        if caller_panic.is_some() || worker_panicked {
            self.poisoned = true;
        }
        if let Some(payload) = caller_panic {
            resume_unwind(payload);
        }
        assert!(
            !worker_panicked,
            "persistent four-core worker operation panicked"
        );
    }

    #[cfg(all(
        feature = "pipelined-inverse-reduction-60x36",
        any(test, all(target_os = "linux", target_arch = "aarch64"))
    ))]
    fn dispatch_workers_with_caller<T, F, C, R>(
        &mut self,
        tasks: &mut [T],
        operation: F,
        caller: C,
    ) -> R
    where
        T: Send,
        F: Fn(usize, &mut T) + Sync,
        C: FnOnce(&WorkerJobProgress<'_>) -> R,
    {
        assert_eq!(
            thread::current().id(),
            self.caller_thread,
            "persistent four-core runtime used from a different caller thread"
        );
        assert!(
            !self.poisoned,
            "persistent four-core runtime is poisoned by an earlier panic"
        );
        assert!(
            self.shared.scope_active.0.is_active(),
            "persistent four-core dispatch requires an active tracker-call scope"
        );
        let epoch = self
            .next_epoch
            .checked_add(1)
            .expect("persistent four-core runtime exhausted its dispatch epoch");

        let typed = TypedJob {
            tasks: tasks.as_mut_ptr(),
            operation: &operation,
            _borrow: PhantomData,
        };
        let erased = ErasedJob {
            context: ptr::from_ref(&typed).cast_mut().cast(),
            task_count: tasks.len(),
            invoke: invoke_typed::<T, F>,
            partition: TaskPartition::WorkersOnly,
        };

        self.shared
            .current_job
            .store(ptr::from_ref(&erased).cast_mut(), Ordering::Relaxed);
        self.shared.epoch.0.store(epoch, Ordering::Release);
        self.next_epoch = epoch;

        let progress = WorkerJobProgress {
            shared: Some(&self.shared),
            dispatch_epoch: epoch,
        };
        let caller_result = catch_unwind(AssertUnwindSafe(|| caller(&progress)));

        for completion in &self.shared.completion {
            while completion.0.epoch.load(Ordering::Acquire) != epoch {
                std::hint::spin_loop();
            }
        }
        self.shared
            .current_job
            .store(ptr::null_mut(), Ordering::Relaxed);

        let worker_panicked = self
            .shared
            .completion
            .iter()
            .any(|completion| completion.0.panicked.load(Ordering::Relaxed));
        if caller_result.is_err() || worker_panicked {
            self.poisoned = true;
        }
        let value = match caller_result {
            Ok(value) => value,
            Err(payload) => resume_unwind(payload),
        };
        assert!(
            !worker_panicked,
            "persistent four-core worker operation panicked"
        );
        value
    }

    fn shutdown(&mut self) -> ShutdownReport {
        let mut report = stop_workers(&self.shared, &mut self.workers);
        if thread::current().id() != self.caller_thread {
            self.caller_state.take();
            report.caller_restore_failure = Some(SetupFailure {
                lane: 0,
                stage: SetupStage::WrongCallerThread,
                os_error: None,
            });
            return report;
        }
        if let Some(caller_state) = self.caller_state.take() {
            report.caller_restore_failure = restore_caller(&caller_state);
        }
        report
    }
}

#[derive(Debug)]
struct StartError {
    cause: SetupFailure,
    caller_restore_failure: Option<SetupFailure>,
    cleanup: ShutdownReport,
}

impl StartError {
    fn without_cleanup(cause: SetupFailure) -> Self {
        Self {
            cause,
            caller_restore_failure: None,
            cleanup: ShutdownReport::default(),
        }
    }

    fn after_caller_pin(
        cause: SetupFailure,
        cleanup: ShutdownReport,
        caller_state: &CallerState,
    ) -> Self {
        Self {
            cause,
            caller_restore_failure: restore_caller(caller_state),
            cleanup,
        }
    }
}

#[derive(Clone, Copy)]
enum SetupPlan {
    Production,
    #[cfg(test)]
    Test(TestSetup),
}

impl SetupPlan {
    const fn worker_policy(self) -> WorkerPolicy {
        match self {
            Self::Production => production_worker_policy(),
            #[cfg(test)]
            Self::Test(setup) => setup.worker_policy,
        }
    }
}

#[cfg(test)]
#[derive(Clone, Copy)]
struct TestSetup {
    failure: Option<TestFailure>,
    worker_policy: WorkerPolicy,
    inherited_allowed_cpus: [bool; LANE_COUNT],
}

#[cfg(test)]
impl Default for TestSetup {
    fn default() -> Self {
        Self {
            failure: None,
            worker_policy: WorkerPolicy::default(),
            inherited_allowed_cpus: [true; LANE_COUNT],
        }
    }
}

#[cfg(test)]
#[derive(Clone, Copy)]
struct TestFailure {
    lane: u8,
    stage: SetupStage,
}

struct CallerState {
    rt_runtime_us: i64,
    #[cfg(all(
        feature = "pi4-four-core-runtime",
        target_os = "linux",
        target_arch = "aarch64"
    ))]
    platform: Option<platform::ThreadState>,
}

impl CallerState {
    #[cfg(test)]
    const fn unchanged(worker_policy: WorkerPolicy) -> Self {
        Self {
            rt_runtime_us: if worker_policy.requires_rt_bandwidth() {
                -1
            } else {
                0
            },
            #[cfg(all(
                feature = "pi4-four-core-runtime",
                target_os = "linux",
                target_arch = "aarch64"
            ))]
            platform: None,
        }
    }
}

fn prepare_caller(plan: SetupPlan) -> Result<CallerState, SetupFailure> {
    match plan {
        SetupPlan::Production => prepare_production_caller(plan.worker_policy()),
        #[cfg(test)]
        SetupPlan::Test(setup) => {
            test_failure(setup, 0, SetupStage::CaptureAffinity)?;
            test_failure(setup, 0, SetupStage::CaptureScheduler)?;
            test_failure(setup, 0, SetupStage::ValidateCallerScheduler)?;
            if setup.worker_policy == WorkerPolicy::ContinuousNormalSpin {
                test_failure(setup, 0, SetupStage::ValidateCallerNice)?;
            }
            test_failure(setup, 0, SetupStage::ValidateAllowedCpus)?;
            validate_inherited_affinity(setup.worker_policy, |cpu| {
                setup.inherited_allowed_cpus[cpu]
            })?;
            if setup.worker_policy.requires_rt_bandwidth() {
                test_failure(setup, 0, SetupStage::ValidateRtBandwidth)?;
            }
            Ok(CallerState::unchanged(setup.worker_policy))
        }
    }
}

fn pin_caller(plan: SetupPlan) -> Result<(), SetupFailure> {
    match plan {
        SetupPlan::Production => pin_production_caller(),
        #[cfg(test)]
        SetupPlan::Test(setup) => test_failure(setup, 0, SetupStage::PinThread),
    }
}

fn configure_worker(plan: SetupPlan, lane: u8) -> Result<(), SetupFailure> {
    match plan {
        SetupPlan::Production => configure_production_worker(lane, plan.worker_policy()),
        #[cfg(test)]
        SetupPlan::Test(setup) => {
            test_failure(setup, lane, SetupStage::PinThread)?;
            match setup.worker_policy {
                WorkerPolicy::ParkedFifo => test_failure(setup, lane, SetupStage::SetFifoPriority),
                WorkerPolicy::ContinuousNormalSpin => {
                    test_failure(setup, lane, SetupStage::ValidateWorkerScheduler)?;
                    test_failure(setup, lane, SetupStage::ValidateWorkerNice)
                }
            }
        }
    }
}

#[cfg(test)]
fn test_failure(setup: TestSetup, lane: u8, stage: SetupStage) -> Result<(), SetupFailure> {
    match setup.failure {
        Some(failure) if failure.lane == lane && failure.stage == stage => Err(SetupFailure {
            lane,
            stage,
            os_error: Some(1),
        }),
        _ => Ok(()),
    }
}

fn worker_entry(shared: Arc<Shared>, worker_index: usize, lane: u8, plan: SetupPlan) {
    let setup = catch_unwind(AssertUnwindSafe(|| configure_worker(plan, lane)));
    match setup {
        Ok(Ok(())) => {
            // Publish the initial parked intent before readiness. The caller's
            // acquire load of READY_OK can therefore rely on this worker being
            // outside the active dispatch loop.
            shared.parked[worker_index].0.store(true, Ordering::Release);
            shared.readiness[worker_index]
                .0
                .state
                .store(READY_OK, Ordering::Release);
        }
        Ok(Err(error)) => {
            shared.readiness[worker_index].0.publish_failure(error);
            return;
        }
        Err(_) => {
            shared.readiness[worker_index]
                .0
                .publish_failure(SetupFailure {
                    lane,
                    stage: SetupStage::WorkerStartupPanic,
                    os_error: None,
                });
            return;
        }
    }

    let mut observed_epoch = 0_u64;
    let mut parked = true;
    loop {
        if shared.stop.load(Ordering::Acquire) {
            break;
        }
        if !shared.scope_active.0.is_active() {
            if !parked {
                shared.parked[worker_index].0.store(true, Ordering::Release);
                parked = true;
            }
            // Close the wake-before-wait race. The retained notification
            // mechanism (Thread::unpark or a nonzero futex predicate) plus
            // this second active/stop observation prevents sleeping after the
            // caller opens a scope or publishes shutdown.
            if shared.stop.load(Ordering::Acquire) || shared.scope_active.0.is_active() {
                continue;
            }
            if shared.worker_policy.parks_between_scopes() {
                wait_for_activity(&shared.scope_active.0);
            } else {
                // This intentionally keeps the normal-priority worker
                // runnable and resident on its dedicated CPU between calls.
                std::hint::spin_loop();
            }
            continue;
        }
        if parked {
            shared.parked[worker_index]
                .0
                .store(false, Ordering::Release);
            parked = false;
        }

        let epoch = shared.epoch.0.load(Ordering::Acquire);
        if epoch == observed_epoch {
            std::hint::spin_loop();
            continue;
        }
        // Shutdown is not a dispatch. In particular, a retained parked-policy
        // wake epoch has no caller-owned descriptor. Recheck stop after the
        // epoch acquire so a worker that crossed the loop-top stop check
        // cannot interpret shutdown publication as work.
        if shared.stop.load(Ordering::Acquire) {
            break;
        }

        let panic_payload = catch_unwind(AssertUnwindSafe(|| {
            let pointer = shared.current_job.load(Ordering::Relaxed);
            assert!(
                !pointer.is_null(),
                "four-core worker observed a dispatch without a job"
            );
            // SAFETY: the release/acquire epoch keeps the caller-owned
            // descriptor alive, and this worker publishes completion before
            // the caller returns.
            unsafe { execute_partition(&*pointer, lane as usize) };
        }))
        .err();
        let panicked = panic_payload.is_some();
        shared.completion[worker_index]
            .0
            .panicked
            .store(panicked, Ordering::Relaxed);
        shared.completion[worker_index]
            .0
            .epoch
            .store(epoch, Ordering::Release);
        observed_epoch = epoch;

        if let Some(payload) = panic_payload {
            // Completion is already visible, so a hostile payload destructor
            // can no longer hold the caller's stack job live. Contain a
            // secondary destructor panic; shutdown can detach a destructor
            // that blocks beyond its bounded window.
            if let Err(secondary_payload) = catch_unwind(AssertUnwindSafe(|| drop(payload))) {
                std::mem::forget(secondary_payload);
            }
        }
    }
}

unsafe fn execute_partition(job: &ErasedJob, lane: usize) {
    let (mut index, stride) = match job.partition {
        TaskPartition::CallerAndWorkers => (lane, LANE_COUNT),
        #[cfg(all(
            any(
                feature = "wake-crop-pipeline-60x36",
                feature = "pipelined-inverse-reduction-60x36"
            ),
            any(test, all(target_os = "linux", target_arch = "aarch64"))
        ))]
        TaskPartition::WorkersOnly => {
            assert!(
                (1..LANE_COUNT).contains(&lane),
                "worker-only job reached caller lane"
            );
            (lane - 1, WORKER_COUNT)
        }
    };
    while index < job.task_count {
        // SAFETY: the descriptor's invoke contract is upheld by dispatch, and
        // the selected static lane partition never repeats an index.
        unsafe { (job.invoke)(job.context, index) };
        index += stride;
    }
}

#[cfg(all(feature = "shared-activity-futex-wake", target_os = "linux"))]
fn wait_for_activity(activity: &ActivityState) {
    const FUTEX_WAIT_PRIVATE: libc::c_int = 128;

    // SAFETY: ActivityState owns a naturally aligned 32-bit atomic that
    // remains live while every worker holds Shared. The kernel reads one futex
    // word, and the predicate loop handles EAGAIN, EINTR, and spurious wakes.
    let result = unsafe {
        libc::syscall(
            libc::SYS_futex,
            activity.value.as_ptr(),
            FUTEX_WAIT_PRIVATE,
            0_u32,
            std::ptr::null::<libc::timespec>(),
        )
    };
    if result < 0 {
        let error = std::io::Error::last_os_error().raw_os_error();
        if !matches!(error, Some(libc::EAGAIN) | Some(libc::EINTR)) {
            eprintln!("fatal: MOSSE activity futex wait failed: {error:?}");
            std::process::abort();
        }
    }
}

#[cfg(not(all(feature = "shared-activity-futex-wake", target_os = "linux")))]
fn wait_for_activity(_activity: &ActivityState) {
    thread::park();
}

#[cfg(all(feature = "shared-activity-futex-wake", target_os = "linux"))]
fn wake_parked_workers(shared: &Shared, _workers: &[Option<JoinHandle<()>>; WORKER_COUNT]) {
    const FUTEX_WAKE_PRIVATE: libc::c_int = 129;

    // One shared wake replaces three sequential Thread::unpark calls. A
    // worker that has published parked intent but not entered the kernel sees
    // the nonzero activity word and receives EAGAIN instead of losing a wake.
    // SAFETY: the aligned activity word remains live for this syscall.
    let result = unsafe {
        libc::syscall(
            libc::SYS_futex,
            shared.scope_active.0.value.as_ptr(),
            FUTEX_WAKE_PRIVATE,
            WORKER_COUNT as libc::c_int,
        )
    };
    if result < 0 {
        let error = std::io::Error::last_os_error().raw_os_error();
        eprintln!("fatal: MOSSE activity futex wake failed: {error:?}");
        // Continuing could strand FIFO workers outside a bounded shutdown.
        std::process::abort();
    }
}

#[cfg(not(all(feature = "shared-activity-futex-wake", target_os = "linux")))]
fn wake_parked_workers(_shared: &Shared, workers: &[Option<JoinHandle<()>>; WORKER_COUNT]) {
    for worker in workers.iter().flatten() {
        // Thread::unpark retains a token, so this also covers a worker that has
        // published its parked intent but has not entered the kernel yet.
        worker.thread().unpark();
    }
}

fn stop_workers(
    shared: &Arc<Shared>,
    workers: &mut [Option<JoinHandle<()>>; WORKER_COUNT],
) -> ShutdownReport {
    shared.stop.store(true, Ordering::Release);
    shared.scope_active.0.mark_stopped();
    if shared.worker_policy.parks_between_scopes() {
        // Preserve the retained FIFO shutdown protocol exactly: publish its
        // historical wake epoch before waking workers blocked outside a scope.
        // Continuous normal-spin workers poll stop/STOPPED directly, so
        // publishing a descriptor-less epoch would be both unnecessary and
        // unsafe.
        let wake_epoch = shared.epoch.0.load(Ordering::Relaxed).wrapping_add(1);
        shared.epoch.0.store(wake_epoch, Ordering::Release);
        wake_parked_workers(shared, workers);
    }

    let deadline = Instant::now() + SHUTDOWN_TIMEOUT;
    while workers.iter().flatten().any(|worker| !worker.is_finished()) && Instant::now() < deadline
    {
        std::hint::spin_loop();
        thread::yield_now();
    }

    let mut report = ShutdownReport::default();
    for worker in workers {
        let Some(handle) = worker.take() else {
            continue;
        };
        if handle.is_finished() {
            report.joined_workers += 1;
            if handle.join().is_err() {
                report.worker_panics += 1;
            }
        } else {
            // Detaching after the bounded wait is memory-safe: stop is
            // published, no dispatch descriptor is live, and the worker owns
            // its Arc until it observes stop and exits.
            report.detached_workers += 1;
            drop(handle);
        }
    }
    report
}

fn decode_setup_stage(value: u8) -> SetupStage {
    match value {
        1 => SetupStage::UnsupportedPlatform,
        2 => SetupStage::CaptureAffinity,
        3 => SetupStage::CaptureScheduler,
        4 => SetupStage::ValidateAllowedCpus,
        5 => SetupStage::SpawnWorker,
        6 => SetupStage::PinThread,
        7 => SetupStage::SetFifoPriority,
        8 => SetupStage::WorkerReadiness,
        9 => SetupStage::WorkerStartupPanic,
        10 => SetupStage::RestoreAffinity,
        11 => SetupStage::RestoreScheduler,
        12 => SetupStage::WrongCallerThread,
        13 => SetupStage::ValidateRtBandwidth,
        14 => SetupStage::ValidateCallerScheduler,
        15 => SetupStage::ValidateWorkerScheduler,
        16 => SetupStage::ValidateCallerNice,
        17 => SetupStage::ValidateWorkerNice,
        _ => SetupStage::WorkerStartupPanic,
    }
}

#[cfg(any(
    test,
    all(
        feature = "pi4-four-core-runtime",
        target_os = "linux",
        target_arch = "aarch64"
    )
))]
const fn decode_getpriority_result(priority: i32, errno: i32) -> Result<i32, i32> {
    if priority == -1 && errno != 0 {
        Err(errno)
    } else {
        Ok(priority)
    }
}

#[cfg(all(
    feature = "pi4-four-core-runtime",
    target_os = "linux",
    target_arch = "aarch64"
))]
fn prepare_production_caller(worker_policy: WorkerPolicy) -> Result<CallerState, SetupFailure> {
    platform::ThreadState::capture(worker_policy).map(|platform| CallerState {
        rt_runtime_us: platform.rt_runtime_us(),
        platform: Some(platform),
    })
}

#[cfg(not(all(
    feature = "pi4-four-core-runtime",
    target_os = "linux",
    target_arch = "aarch64"
)))]
fn prepare_production_caller(_worker_policy: WorkerPolicy) -> Result<CallerState, SetupFailure> {
    Err(SetupFailure {
        lane: 0,
        stage: SetupStage::UnsupportedPlatform,
        os_error: None,
    })
}

#[cfg(all(
    feature = "pi4-four-core-runtime",
    target_os = "linux",
    target_arch = "aarch64"
))]
fn pin_production_caller() -> Result<(), SetupFailure> {
    platform::pin_current_thread(FIXED_CPUS[0], 0)
}

#[cfg(not(all(
    feature = "pi4-four-core-runtime",
    target_os = "linux",
    target_arch = "aarch64"
)))]
fn pin_production_caller() -> Result<(), SetupFailure> {
    Err(SetupFailure {
        lane: 0,
        stage: SetupStage::UnsupportedPlatform,
        os_error: None,
    })
}

#[cfg(all(
    feature = "pi4-four-core-runtime",
    target_os = "linux",
    target_arch = "aarch64"
))]
fn configure_production_worker(lane: u8, worker_policy: WorkerPolicy) -> Result<(), SetupFailure> {
    platform::pin_current_thread(FIXED_CPUS[lane as usize], lane)?;
    match worker_policy {
        WorkerPolicy::ParkedFifo => platform::set_current_thread_fifo(lane),
        WorkerPolicy::ContinuousNormalSpin => {
            platform::validate_current_thread_normal(lane)?;
            platform::validate_current_thread_nice(lane, SetupStage::ValidateWorkerNice)
        }
    }
}

#[cfg(not(all(
    feature = "pi4-four-core-runtime",
    target_os = "linux",
    target_arch = "aarch64"
)))]
fn configure_production_worker(lane: u8, _worker_policy: WorkerPolicy) -> Result<(), SetupFailure> {
    Err(SetupFailure {
        lane,
        stage: SetupStage::UnsupportedPlatform,
        os_error: None,
    })
}

#[cfg(all(
    feature = "pi4-four-core-runtime",
    target_os = "linux",
    target_arch = "aarch64"
))]
fn restore_caller(state: &CallerState) -> Option<SetupFailure> {
    state
        .platform
        .as_ref()
        .and_then(platform::ThreadState::restore)
}

#[cfg(not(all(
    feature = "pi4-four-core-runtime",
    target_os = "linux",
    target_arch = "aarch64"
)))]
fn restore_caller(_state: &CallerState) -> Option<SetupFailure> {
    None
}

#[cfg(all(
    feature = "pi4-four-core-runtime",
    target_os = "linux",
    target_arch = "aarch64"
))]
mod platform {
    use super::{
        decode_getpriority_result, parse_rt_runtime_us, validate_inherited_affinity, SetupFailure,
        SetupStage, WorkerPolicy, EXECUTOR_FIFO_PRIORITY,
    };

    pub(super) struct ThreadState {
        affinity: libc::cpu_set_t,
        rt_runtime_us: i64,
    }

    impl ThreadState {
        pub(super) fn capture(worker_policy: WorkerPolicy) -> Result<Self, SetupFailure> {
            // SAFETY: pthread_getaffinity_np initializes the provided
            // cpu_set_t for the current live thread.
            let affinity = unsafe {
                let mut affinity: libc::cpu_set_t = std::mem::zeroed();
                let result = libc::pthread_getaffinity_np(
                    libc::pthread_self(),
                    std::mem::size_of::<libc::cpu_set_t>(),
                    &mut affinity,
                );
                if result != 0 {
                    return Err(failure(0, SetupStage::CaptureAffinity, result));
                }
                affinity
            };

            validate_inherited_affinity(worker_policy, |cpu| {
                // SAFETY: fixed CPU IDs 0-3 are within CPU_SETSIZE, and
                // affinity was initialized by pthread_getaffinity_np.
                unsafe { libc::CPU_ISSET(cpu, &affinity) }
            })?;

            // SAFETY: pthread_getschedparam initializes policy and parameter
            // for the current live thread.
            let (scheduler_policy, scheduler_parameter) = unsafe {
                let mut policy = 0;
                let mut parameter: libc::sched_param = std::mem::zeroed();
                let result =
                    libc::pthread_getschedparam(libc::pthread_self(), &mut policy, &mut parameter);
                if result != 0 {
                    return Err(failure(0, SetupStage::CaptureScheduler, result));
                }
                (policy, parameter)
            };
            if scheduler_policy != libc::SCHED_OTHER || scheduler_parameter.sched_priority != 0 {
                return Err(SetupFailure {
                    lane: 0,
                    stage: SetupStage::ValidateCallerScheduler,
                    os_error: None,
                });
            }
            if worker_policy == WorkerPolicy::ContinuousNormalSpin {
                validate_current_thread_nice(0, SetupStage::ValidateCallerNice)?;
            }

            let rt_runtime_us = if worker_policy.requires_rt_bandwidth() {
                validate_rt_bandwidth()?
            } else {
                // Zero means "not applicable": normal-spin workers remain
                // SCHED_OTHER and do not consume the kernel RT budget.
                0
            };

            Ok(Self {
                affinity,
                rt_runtime_us,
            })
        }

        pub(super) const fn rt_runtime_us(&self) -> i64 {
            self.rt_runtime_us
        }

        pub(super) fn restore(&self) -> Option<SetupFailure> {
            // The caller's scheduler policy was never changed. Restore only
            // the affinity captured before lane zero was pinned to CPU 0.
            // SAFETY: saved affinity came from pthread_getaffinity_np on this
            // same live caller thread.
            let affinity_result = unsafe {
                libc::pthread_setaffinity_np(
                    libc::pthread_self(),
                    std::mem::size_of::<libc::cpu_set_t>(),
                    &self.affinity,
                )
            };
            if affinity_result == 0 {
                None
            } else {
                Some(failure(0, SetupStage::RestoreAffinity, affinity_result))
            }
        }
    }

    pub(super) fn pin_current_thread(cpu: usize, lane: u8) -> Result<(), SetupFailure> {
        // SAFETY: CPU_ZERO/CPU_SET initialize a local cpu_set_t, and fixed
        // CPU IDs 0-3 are within CPU_SETSIZE.
        unsafe {
            let mut set: libc::cpu_set_t = std::mem::zeroed();
            libc::CPU_ZERO(&mut set);
            libc::CPU_SET(cpu, &mut set);
            let result = libc::pthread_setaffinity_np(
                libc::pthread_self(),
                std::mem::size_of::<libc::cpu_set_t>(),
                &set,
            );
            if result == 0 {
                Ok(())
            } else {
                Err(failure(lane, SetupStage::PinThread, result))
            }
        }
    }

    pub(super) fn set_current_thread_fifo(lane: u8) -> Result<(), SetupFailure> {
        let parameter = libc::sched_param {
            sched_priority: EXECUTOR_FIFO_PRIORITY,
        };
        // SAFETY: pthread_setschedparam applies a valid FIFO parameter to the
        // current live thread and returns an error number on permission/setup
        // failure.
        let result = unsafe {
            libc::pthread_setschedparam(libc::pthread_self(), libc::SCHED_FIFO, &parameter)
        };
        if result == 0 {
            Ok(())
        } else {
            Err(failure(lane, SetupStage::SetFifoPriority, result))
        }
    }

    pub(super) fn validate_current_thread_normal(lane: u8) -> Result<(), SetupFailure> {
        // New pthreads inherit the caller's scheduler. Verify that invariant
        // instead of trying to change policy, so this mode needs no
        // CAP_SYS_NICE and cannot accidentally preserve an RT wrapper policy.
        let (policy, parameter) = unsafe {
            let mut policy = 0;
            let mut parameter: libc::sched_param = std::mem::zeroed();
            let result =
                libc::pthread_getschedparam(libc::pthread_self(), &mut policy, &mut parameter);
            if result != 0 {
                return Err(failure(lane, SetupStage::ValidateWorkerScheduler, result));
            }
            (policy, parameter)
        };
        if policy == libc::SCHED_OTHER && parameter.sched_priority == 0 {
            Ok(())
        } else {
            Err(SetupFailure {
                lane,
                stage: SetupStage::ValidateWorkerScheduler,
                os_error: None,
            })
        }
    }

    pub(super) fn validate_current_thread_nice(
        lane: u8,
        stage: SetupStage,
    ) -> Result<(), SetupFailure> {
        // getpriority can legitimately return -1, so errno must be cleared
        // before the call and inspected afterward to distinguish that value
        // from an error. PRIO_PROCESS with who=0 addresses the calling thread
        // on Linux.
        let (priority, errno) = unsafe {
            let errno_location = libc::__errno_location();
            *errno_location = 0;
            let priority = libc::getpriority(libc::PRIO_PROCESS, 0);
            let errno = *errno_location;
            (priority, errno)
        };
        match decode_getpriority_result(priority, errno) {
            Err(error) => Err(failure(lane, stage, error)),
            Ok(0) => Ok(()),
            Ok(_) => Err(SetupFailure {
                lane,
                stage,
                os_error: None,
            }),
        }
    }

    fn validate_rt_bandwidth() -> Result<i64, SetupFailure> {
        let value =
            std::fs::read_to_string("/proc/sys/kernel/sched_rt_runtime_us").map_err(|error| {
                SetupFailure {
                    lane: 0,
                    stage: SetupStage::ValidateRtBandwidth,
                    os_error: error.raw_os_error(),
                }
            })?;
        parse_rt_runtime_us(&value).ok_or(SetupFailure {
            lane: 0,
            stage: SetupStage::ValidateRtBandwidth,
            os_error: None,
        })
    }

    fn failure(lane: u8, stage: SetupStage, error: libc::c_int) -> SetupFailure {
        SetupFailure {
            lane,
            stage,
            os_error: Some(error.abs().max(1)),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::{
        collections::HashSet,
        panic::catch_unwind,
        sync::atomic::{AtomicUsize, Ordering},
        thread::ThreadId,
    };

    #[derive(Clone, Copy, Debug, Default)]
    struct OwnedTask {
        calls: u64,
        owner: Option<ThreadId>,
    }

    fn parallel_runtime() -> FourCoreRuntime {
        let runtime = FourCoreRuntime::test_parallel(TestSetup::default())
            .expect("unconfigured deterministic test workers must start");
        assert_eq!(
            runtime.status(),
            RuntimeStatus::PersistentFourCore {
                request: CoreRequest::Four,
                cpus: FIXED_CPUS,
                caller_normal_scheduler: true,
                workers_park_between_scopes: true,
                worker_scheduler_priority: EXECUTOR_FIFO_PRIORITY,
                rt_runtime_us: -1,
            }
        );
        runtime
    }

    fn normal_spin_runtime() -> FourCoreRuntime {
        let runtime = FourCoreRuntime::test_parallel(TestSetup {
            worker_policy: WorkerPolicy::ContinuousNormalSpin,
            ..TestSetup::default()
        })
        .expect("normal-spin deterministic test workers must start");
        assert_eq!(
            runtime.status(),
            RuntimeStatus::PersistentFourCore {
                request: CoreRequest::Four,
                cpus: FIXED_CPUS,
                caller_normal_scheduler: true,
                workers_park_between_scopes: false,
                worker_scheduler_priority: 0,
                rt_runtime_us: 0,
            }
        );
        assert_eq!(
            runtime.worker_activity_mode(),
            Some(WorkerActivityMode::ContinuousNormalSpin)
        );
        runtime
    }

    fn shared_weak(runtime: &FourCoreRuntime) -> std::sync::Weak<Shared> {
        match runtime.backend.as_ref() {
            Some(Backend::Parallel(parallel)) => Arc::downgrade(&parallel.shared),
            _ => panic!("test runtime is not parallel"),
        }
    }

    #[test]
    fn parses_core_requests_without_guessing() {
        assert_eq!(parse_core_request(None), CoreRequest::Unset);
        assert_eq!(parse_core_request(Some(OsStr::new("1"))), CoreRequest::One);
        assert_eq!(
            parse_core_request(Some(OsStr::new(" 4 "))),
            CoreRequest::Four
        );
        assert_eq!(
            parse_core_request(Some(OsStr::new("2"))),
            CoreRequest::Unsupported(2)
        );
        assert_eq!(
            parse_core_request(Some(OsStr::new("many"))),
            CoreRequest::Invalid
        );
    }

    #[test]
    fn accepts_finite_or_unlimited_rt_runtime_but_rejects_disabled_values() {
        assert_eq!(parse_rt_runtime_us("-1\n"), Some(-1));
        assert_eq!(parse_rt_runtime_us("950000"), Some(950_000));
        assert_eq!(parse_rt_runtime_us("1"), Some(1));
        assert_eq!(parse_rt_runtime_us("0"), None);
        assert_eq!(parse_rt_runtime_us("-2"), None);
        assert_eq!(parse_rt_runtime_us("not-a-budget"), None);
    }

    #[test]
    fn getpriority_decoding_distinguishes_valid_minus_one_from_error() {
        assert_eq!(decode_getpriority_result(0, 0), Ok(0));
        assert_eq!(decode_getpriority_result(7, 0), Ok(7));
        assert_eq!(decode_getpriority_result(-1, 0), Ok(-1));
        assert_eq!(decode_getpriority_result(-1, 13), Err(13));
    }

    #[test]
    fn inherited_affinity_validation_is_policy_specific() {
        for mask in 0_u8..(1 << LANE_COUNT) {
            let allowed = |cpu: usize| mask & (1 << cpu) != 0;
            assert_eq!(
                validate_inherited_affinity(WorkerPolicy::ParkedFifo, allowed).is_ok(),
                mask == 0b1111,
                "FIFO inherited-mask decision for {mask:04b}"
            );
            assert_eq!(
                validate_inherited_affinity(WorkerPolicy::ContinuousNormalSpin, allowed).is_ok(),
                mask & 0b0001 != 0,
                "normal-spin inherited-mask decision for {mask:04b}"
            );
        }

        let cpu_zero_only = [true, false, false, false];
        let normal_spin = FourCoreRuntime::test_parallel(TestSetup {
            worker_policy: WorkerPolicy::ContinuousNormalSpin,
            inherited_allowed_cpus: cpu_zero_only,
            ..TestSetup::default()
        })
        .expect("normal-spin must accept an inherited CPU0-only mask");
        assert!(normal_spin.shutdown().clean());

        for worker_policy in [WorkerPolicy::ParkedFifo, WorkerPolicy::ContinuousNormalSpin] {
            let missing_cpu_zero = FourCoreRuntime::test_parallel(TestSetup {
                worker_policy,
                inherited_allowed_cpus: [false, true, true, true],
                ..TestSetup::default()
            })
            .err()
            .expect("every policy must reject an inherited mask without CPU0");
            assert_eq!(
                missing_cpu_zero.cause,
                SetupFailure {
                    lane: 0,
                    stage: SetupStage::ValidateAllowedCpus,
                    os_error: None,
                }
            );
            assert_eq!(missing_cpu_zero.cleanup, ShutdownReport::default());
        }

        let fifo_cpu_zero_only = FourCoreRuntime::test_parallel(TestSetup {
            inherited_allowed_cpus: cpu_zero_only,
            ..TestSetup::default()
        })
        .err()
        .expect("retained FIFO startup must still require CPUs 0-3");
        assert_eq!(
            fifo_cpu_zero_only.cause,
            SetupFailure {
                lane: 0,
                stage: SetupStage::ValidateAllowedCpus,
                os_error: None,
            }
        );
        assert_eq!(fifo_cpu_zero_only.cleanup, ShutdownReport::default());
    }

    #[test]
    fn explicit_one_and_unsupported_counts_are_discoverable_serial_modes() {
        for (requested, expected) in [
            (1, CoreRequest::One),
            (0, CoreRequest::Unsupported(0)),
            (3, CoreRequest::Unsupported(3)),
            (8, CoreRequest::Unsupported(8)),
        ] {
            let mut runtime = FourCoreRuntime::from_requested_cores(requested);
            assert_eq!(runtime.mode(), ExecutionMode::SingleThread);
            assert_eq!(runtime.effective_core_count(), 1);
            assert_eq!(
                runtime.fallback_reason(),
                Some(FallbackReason::CoreRequest(expected))
            );

            let caller = thread::current().id();
            let mut tasks = [OwnedTask::default(); 9];
            runtime.dispatch(&mut tasks, |_, task| {
                task.calls += 1;
                task.owner = Some(thread::current().id());
            });
            assert!(tasks
                .iter()
                .all(|task| task.calls == 1 && task.owner == Some(caller)));
        }
    }

    #[cfg(not(all(
        feature = "pi4-four-core-runtime",
        target_os = "linux",
        target_arch = "aarch64"
    )))]
    #[test]
    fn four_core_request_is_safe_and_discoverable_off_target() {
        let mut runtime = FourCoreRuntime::from_requested_cores(4);
        assert_eq!(runtime.mode(), ExecutionMode::SingleThread);
        assert_eq!(
            runtime.status(),
            RuntimeStatus::SingleThread {
                request: CoreRequest::Four,
                reason: FallbackReason::UnsupportedPlatform,
            }
        );
        let mut tasks = [0_u8; 5];
        runtime.dispatch(&mut tasks, |index, task| *task = index as u8 + 1);
        assert_eq!(tasks, [1, 2, 3, 4, 5]);
    }

    #[test]
    fn caller_must_be_normal_and_never_enters_fifo() {
        let rejected_setup = TestSetup {
            failure: Some(TestFailure {
                lane: 0,
                stage: SetupStage::ValidateCallerScheduler,
            }),
            ..TestSetup::default()
        };
        let error = FourCoreRuntime::test_parallel(rejected_setup)
            .err()
            .expect("an already-RT caller must reject parallel startup");
        assert_eq!(
            error.cause,
            SetupFailure {
                lane: 0,
                stage: SetupStage::ValidateCallerScheduler,
                os_error: Some(1),
            }
        );
        assert_eq!(error.cleanup, ShutdownReport::default());

        // A synthetic failure at the old caller-FIFO stage is never observed:
        // lane zero stays at its captured normal policy for the full lifetime.
        let no_caller_fifo = TestSetup {
            failure: Some(TestFailure {
                lane: 0,
                stage: SetupStage::SetFifoPriority,
            }),
            ..TestSetup::default()
        };
        let mut runtime = FourCoreRuntime::test_parallel(no_caller_fifo)
            .expect("parallel startup must not change the caller scheduler");
        let activity = runtime.begin_activity();
        let mut tasks = [0_u8; LANE_COUNT];
        runtime.dispatch(&mut tasks, |index, task| *task = (index + 1) as u8);
        assert_eq!(tasks, [1, 2, 3, 4]);
        drop(activity);
        assert!(runtime.shutdown().clean());
    }

    #[test]
    fn workers_park_between_activity_scopes_without_lost_wakeups() {
        let mut runtime = parallel_runtime();
        let shared = match runtime.backend.as_ref() {
            Some(Backend::Parallel(parallel)) => Arc::clone(&parallel.shared),
            _ => panic!("test runtime is not parallel"),
        };
        assert!(shared
            .parked
            .iter()
            .all(|parked| parked.0.load(Ordering::Acquire)));

        let mut tasks = [0_u16; 9];
        for epoch in 1..=128 {
            let activity = runtime.begin_activity();
            runtime.dispatch(&mut tasks, |_, task| *task += 1);
            assert!(shared
                .parked
                .iter()
                .all(|parked| !parked.0.load(Ordering::Acquire)));
            drop(activity);
            assert!(shared
                .parked
                .iter()
                .all(|parked| parked.0.load(Ordering::Acquire)));
            assert!(tasks.iter().all(|task| *task == epoch));
        }
        assert!(runtime.shutdown().clean());
    }

    #[test]
    fn normal_spin_scope_close_is_a_nonblocking_atomic_gate() {
        let shared = Arc::new(Shared::new(WorkerPolicy::ContinuousNormalSpin));
        shared
            .scope_active
            .0
            .open()
            .expect("synthetic normal-spin scope must open");
        for parked in &shared.parked {
            parked.0.store(false, Ordering::Release);
        }
        let activity = ActiveFourCoreScope {
            shared: Some(Arc::clone(&shared)),
            _caller_thread_bound: PhantomData,
        };

        // There are deliberately no worker threads that could publish a
        // parked acknowledgement. Returning proves this policy does not wait
        // on one or enter a wake/park syscall at scope close.
        drop(activity);
        assert!(!shared.scope_active.0.is_active());
        assert!(shared
            .parked
            .iter()
            .all(|parked| !parked.0.load(Ordering::Acquire)));
    }

    #[test]
    fn normal_spin_dispatch_is_exact_and_shutdown_joins_every_worker() {
        let mut runtime = normal_spin_runtime();
        let weak = shared_weak(&runtime);
        let mut tasks = [0_u16; 17];

        for epoch in 1..=256_u16 {
            let activity = runtime.begin_activity();
            runtime.dispatch(&mut tasks, |index, task| {
                assert_eq!(*task, epoch - 1, "task {index} skipped or repeated");
                *task += 1;
            });
            drop(activity);
        }
        assert_eq!(tasks, [256; 17]);

        let report = runtime.shutdown();
        assert_eq!(report.joined_workers, WORKER_COUNT as u8);
        assert_eq!(report.detached_workers, 0);
        assert!(report.clean());
        assert!(
            weak.upgrade().is_none(),
            "normal-spin worker outlived clean runtime teardown"
        );
    }

    #[test]
    fn repeated_normal_spin_close_then_shutdown_never_publishes_a_fake_job() {
        for iteration in 0..256 {
            let mut runtime = normal_spin_runtime();
            let shared = match runtime.backend.as_ref() {
                Some(Backend::Parallel(parallel)) => Arc::clone(&parallel.shared),
                _ => panic!("test runtime is not parallel"),
            };
            let weak = Arc::downgrade(&shared);

            let activity = runtime.begin_activity();
            runtime.dispatch_empty();
            assert!(shared.current_job.load(Ordering::Acquire).is_null());
            let last_real_epoch = shared.epoch.0.load(Ordering::Acquire);
            drop(activity);

            // This immediate transition used to publish one descriptor-less
            // wake epoch. A worker that had crossed its loop-top stop check
            // could catch an internal null-job panic before observing stop.
            let report = runtime.shutdown();
            assert_eq!(
                report.joined_workers, WORKER_COUNT as u8,
                "iteration {iteration} did not join every worker"
            );
            assert_eq!(report.detached_workers, 0, "iteration {iteration}");
            assert_eq!(report.worker_panics, 0, "iteration {iteration}");
            assert!(
                report.caller_restore_failure.is_none(),
                "iteration {iteration}"
            );
            assert_eq!(
                shared.epoch.0.load(Ordering::Acquire),
                last_real_epoch,
                "normal-spin shutdown published a fake epoch at iteration {iteration}"
            );
            assert!(
                shared
                    .completion
                    .iter()
                    .all(|completion| !completion.0.panicked.load(Ordering::Acquire)),
                "worker caught an internal/null-descriptor panic at iteration {iteration}"
            );
            assert!(
                shared.current_job.load(Ordering::Acquire).is_null(),
                "shutdown left a live descriptor at iteration {iteration}"
            );
            assert_eq!(
                Arc::strong_count(&shared),
                1,
                "worker retained shared state after join at iteration {iteration}"
            );
            drop(shared);
            assert!(
                weak.upgrade().is_none(),
                "shared runtime state survived iteration {iteration}"
            );
        }
    }

    #[test]
    fn normal_spin_needs_neither_fifo_setup_nor_rt_bandwidth() {
        for ignored_stage in [SetupStage::SetFifoPriority, SetupStage::ValidateRtBandwidth] {
            let setup = TestSetup {
                failure: Some(TestFailure {
                    lane: if ignored_stage == SetupStage::SetFifoPriority {
                        2
                    } else {
                        0
                    },
                    stage: ignored_stage,
                }),
                worker_policy: WorkerPolicy::ContinuousNormalSpin,
                ..TestSetup::default()
            };
            let runtime = FourCoreRuntime::test_parallel(setup)
                .expect("normal-spin setup must not enter FIFO or RT-budget stages");
            assert!(runtime.shutdown().clean());
        }

        let rejected = TestSetup {
            failure: Some(TestFailure {
                lane: 2,
                stage: SetupStage::ValidateWorkerScheduler,
            }),
            worker_policy: WorkerPolicy::ContinuousNormalSpin,
            ..TestSetup::default()
        };
        let error = FourCoreRuntime::test_parallel(rejected)
            .err()
            .expect("non-normal worker policy must reject normal-spin startup");
        assert_eq!(
            error.cause,
            SetupFailure {
                lane: 2,
                stage: SetupStage::ValidateWorkerScheduler,
                os_error: Some(1),
            }
        );
        assert_eq!(error.cleanup.detached_workers, 0);
        assert_eq!(error.cleanup.joined_workers, WORKER_COUNT as u8);
    }

    #[test]
    fn normal_spin_requires_zero_nice_for_caller_and_workers() {
        let caller_error = FourCoreRuntime::test_parallel(TestSetup {
            failure: Some(TestFailure {
                lane: 0,
                stage: SetupStage::ValidateCallerNice,
            }),
            worker_policy: WorkerPolicy::ContinuousNormalSpin,
            ..TestSetup::default()
        })
        .err()
        .expect("nonzero caller nice must reject normal-spin startup");
        assert_eq!(
            caller_error.cause,
            SetupFailure {
                lane: 0,
                stage: SetupStage::ValidateCallerNice,
                os_error: Some(1),
            }
        );
        assert_eq!(caller_error.cleanup, ShutdownReport::default());

        let worker_error = FourCoreRuntime::test_parallel(TestSetup {
            failure: Some(TestFailure {
                lane: 2,
                stage: SetupStage::ValidateWorkerNice,
            }),
            worker_policy: WorkerPolicy::ContinuousNormalSpin,
            ..TestSetup::default()
        })
        .err()
        .expect("nonzero worker nice must reject normal-spin startup");
        assert_eq!(
            worker_error.cause,
            SetupFailure {
                lane: 2,
                stage: SetupStage::ValidateWorkerNice,
                os_error: Some(1),
            }
        );
        assert_eq!(worker_error.cleanup.detached_workers, 0);
        assert_eq!(worker_error.cleanup.joined_workers, WORKER_COUNT as u8);

        for ignored in [
            TestFailure {
                lane: 0,
                stage: SetupStage::ValidateCallerNice,
            },
            TestFailure {
                lane: 2,
                stage: SetupStage::ValidateWorkerNice,
            },
        ] {
            let runtime = FourCoreRuntime::test_parallel(TestSetup {
                failure: Some(ignored),
                worker_policy: WorkerPolicy::ParkedFifo,
                ..TestSetup::default()
            })
            .expect("retained FIFO startup must not enter normal-spin nice gates");
            assert!(runtime.shutdown().clean());
        }
    }

    #[test]
    fn normal_spin_worker_pin_failure_falls_back_and_cleans_up() {
        let setup = TestSetup {
            failure: Some(TestFailure {
                lane: 2,
                stage: SetupStage::PinThread,
            }),
            worker_policy: WorkerPolicy::ContinuousNormalSpin,
            inherited_allowed_cpus: [true, false, false, false],
        };
        let error = FourCoreRuntime::test_parallel(setup)
            .err()
            .expect("an unavailable worker CPU must reject normal-spin startup");
        assert_eq!(
            error.cause,
            SetupFailure {
                lane: 2,
                stage: SetupStage::PinThread,
                os_error: Some(1),
            }
        );
        assert_eq!(error.cleanup.detached_workers, 0);
        assert_eq!(error.cleanup.joined_workers, WORKER_COUNT as u8);
        assert_eq!(error.cleanup.worker_panics, 0);
        assert_eq!(error.caller_restore_failure, None);

        let mut runtime = FourCoreRuntime::test_with_setup(setup);
        assert_eq!(runtime.mode(), ExecutionMode::SingleThread);
        assert_eq!(
            runtime.fallback_reason(),
            Some(FallbackReason::StartupFailed {
                cause: error.cause,
                caller_restore_failure: None,
                detached_workers: 0,
            })
        );
        let mut tasks = [0_u8; LANE_COUNT];
        runtime.dispatch(&mut tasks, |index, task| *task = index as u8 + 1);
        assert_eq!(tasks, [1, 2, 3, 4]);
    }

    #[test]
    fn normal_spin_worker_panic_is_contained_before_teardown() {
        let mut runtime = normal_spin_runtime();
        let weak = shared_weak(&runtime);
        let activity = runtime.begin_activity();
        let mut tasks = [false; 8];
        let panic = catch_unwind(AssertUnwindSafe(|| {
            runtime.dispatch(&mut tasks, |index, task| {
                if index == 2 {
                    panic!("normal-spin worker panic");
                }
                *task = true;
            });
        }));
        assert!(panic.is_err());
        for index in [0, 1, 3, 4, 5, 7] {
            assert!(tasks[index], "non-panicking task {index} missed barrier");
        }
        drop(activity);
        let report = runtime.shutdown();
        assert!(report.clean());
        assert!(
            weak.upgrade().is_none(),
            "panicked normal-spin worker outlived teardown"
        );
    }

    #[cfg(feature = "wake-crop-pipeline-60x36")]
    #[test]
    fn worker_job_is_published_before_wake_and_runs_once_on_lanes_one_to_three() {
        let caller = thread::current().id();
        let mut runtime = parallel_runtime();
        let shared = match runtime.backend.as_ref() {
            Some(Backend::Parallel(parallel)) => Arc::clone(&parallel.shared),
            _ => panic!("test runtime is not parallel"),
        };
        assert!(shared
            .parked
            .iter()
            .all(|parked| parked.0.load(Ordering::Acquire)));
        let expected_epoch = shared.epoch.0.load(Ordering::Acquire) + 1;
        let mut tasks = [OwnedTask::default(); WORKER_COUNT];

        let activity = runtime.begin_activity_with_worker_job(&mut tasks, |index, task| {
            assert!(shared.scope_active.0.is_active());
            assert_eq!(shared.epoch.0.load(Ordering::Acquire), expected_epoch);
            assert!(!shared.current_job.load(Ordering::Relaxed).is_null());
            assert_ne!(
                thread::current().id(),
                caller,
                "caller ran worker-only task"
            );
            assert_eq!(
                thread::current().name(),
                Some(match index {
                    0 => "mosse-four-core-1",
                    1 => "mosse-four-core-2",
                    2 => "mosse-four-core-3",
                    _ => unreachable!(),
                })
            );
            task.calls += 1;
            task.owner = Some(thread::current().id());
        });

        assert!(shared.scope_active.0.is_active());
        assert!(shared.current_job.load(Ordering::Relaxed).is_null());
        assert!(tasks.iter().all(|task| task.calls == 1));
        assert!(tasks.iter().all(|task| task.owner != Some(caller)));
        assert_eq!(
            tasks
                .iter()
                .filter_map(|task| task.owner)
                .collect::<HashSet<_>>()
                .len(),
            WORKER_COUNT
        );

        let mut later_tasks = [0_u8; LANE_COUNT];
        runtime.dispatch(&mut later_tasks, |index, task| *task = index as u8 + 1);
        assert_eq!(later_tasks, [1, 2, 3, 4]);
        drop(activity);
        assert!(shared
            .parked
            .iter()
            .all(|parked| parked.0.load(Ordering::Acquire)));
        assert!(runtime.shutdown().clean());
    }

    #[cfg(feature = "wake-crop-pipeline-60x36")]
    #[test]
    fn repeated_worker_job_activity_scopes_do_not_lose_wakes() {
        let mut runtime = parallel_runtime();
        let shared = match runtime.backend.as_ref() {
            Some(Backend::Parallel(parallel)) => Arc::clone(&parallel.shared),
            _ => panic!("test runtime is not parallel"),
        };
        let mut totals = [0_u16; WORKER_COUNT];

        for epoch in 1..=256_u16 {
            let activity =
                runtime.begin_activity_with_worker_job(&mut totals, |_, task| *task += 1);
            assert_eq!(totals, [epoch; WORKER_COUNT]);

            let mut later_tasks = [0_u16; 9];
            runtime.dispatch(&mut later_tasks, |_, task| *task = epoch);
            assert_eq!(later_tasks, [epoch; 9]);
            drop(activity);
            assert!(shared
                .parked
                .iter()
                .all(|parked| parked.0.load(Ordering::Acquire)));
        }

        assert!(runtime.shutdown().clean());
    }

    #[cfg(feature = "wake-crop-pipeline-60x36")]
    #[test]
    fn worker_job_panic_clears_descriptor_parks_and_poisons_runtime() {
        let mut runtime = parallel_runtime();
        let shared = match runtime.backend.as_ref() {
            Some(Backend::Parallel(parallel)) => Arc::clone(&parallel.shared),
            _ => panic!("test runtime is not parallel"),
        };
        let mut tasks = [false; WORKER_COUNT];
        let panic = catch_unwind(AssertUnwindSafe(|| {
            let _activity = runtime.begin_activity_with_worker_job(&mut tasks, |index, task| {
                if index == 1 {
                    panic!("worker-only lane panic");
                }
                *task = true;
            });
        }));

        assert!(panic.is_err());
        assert_eq!(tasks, [true, false, true]);
        assert!(shared.current_job.load(Ordering::Relaxed).is_null());
        assert!(!shared.scope_active.0.is_active());
        assert!(shared
            .parked
            .iter()
            .all(|parked| parked.0.load(Ordering::Acquire)));
        let poisoned = catch_unwind(AssertUnwindSafe(|| runtime.begin_activity()));
        assert!(poisoned.is_err());
        assert!(runtime.shutdown().clean());
    }

    #[cfg(feature = "wake-crop-pipeline-60x36")]
    #[test]
    fn worker_job_preserves_single_thread_fallback_semantics() {
        let caller = thread::current().id();
        let mut runtime = FourCoreRuntime::from_requested_cores(1);
        let mut tasks = [OwnedTask::default(); WORKER_COUNT];
        let activity = runtime.begin_activity_with_worker_job(&mut tasks, |_, task| {
            task.calls += 1;
            task.owner = Some(thread::current().id());
        });
        assert!(tasks
            .iter()
            .all(|task| task.calls == 1 && task.owner == Some(caller)));
        drop(activity);
        assert!(runtime.shutdown().clean());
    }

    #[test]
    fn parallel_dispatch_rejects_a_missing_activity_scope() {
        let mut runtime = parallel_runtime();
        let panic = catch_unwind(AssertUnwindSafe(|| runtime.dispatch_empty()));
        assert!(panic.is_err());
        assert!(runtime.shutdown().clean());
    }

    #[test]
    fn ownership_is_static_and_exact_across_epochs() {
        let caller = thread::current().id();
        let mut runtime = parallel_runtime();
        let activity = runtime.begin_activity();
        let mut tasks = [OwnedTask::default(); 9];
        for _ in 0..64 {
            runtime.dispatch(&mut tasks, |_, task| {
                let owner = thread::current().id();
                match task.owner {
                    Some(previous) => assert_eq!(previous, owner),
                    None => task.owner = Some(owner),
                }
                task.calls += 1;
            });
        }

        assert!(tasks.iter().all(|task| task.calls == 64));
        assert_eq!(tasks[0].owner, Some(caller));
        let owners: HashSet<ThreadId> = tasks.iter().filter_map(|task| task.owner).collect();
        assert_eq!(owners.len(), LANE_COUNT);
        for (index, task) in tasks.iter().enumerate() {
            assert_eq!(task.owner, tasks[index % LANE_COUNT].owner);
        }
        drop(activity);
    }

    #[cfg(feature = "pipelined-inverse-reduction-60x36")]
    #[test]
    fn worker_only_dispatch_overlaps_caller_and_uses_modulo_three_ownership() {
        let caller = thread::current().id();
        let mut runtime = parallel_runtime();
        let activity = runtime.begin_activity();
        let ready: [AtomicU64; 9] = std::array::from_fn(|_| AtomicU64::new(0));
        let owners: [AtomicUsize; 9] = std::array::from_fn(|_| AtomicUsize::new(0));
        let release_first = AtomicBool::new(false);
        let mut tasks = [0_u8; 9];

        let returned = runtime.dispatch_workers_with_caller(
            &mut tasks,
            |index, task| {
                assert_ne!(
                    thread::current().id(),
                    caller,
                    "caller executed a worker-only task"
                );
                if index == 0 {
                    while !release_first.load(Ordering::Acquire) {
                        std::hint::spin_loop();
                    }
                }
                let lane = match thread::current().name() {
                    Some("mosse-four-core-1") => 1,
                    Some("mosse-four-core-2") => 2,
                    Some("mosse-four-core-3") => 3,
                    other => panic!("unexpected worker name {other:?}"),
                };
                *task = (index + 1) as u8;
                owners[index].store(lane, Ordering::Relaxed);
                ready[index].store(17, Ordering::Release);
            },
            |progress| {
                // Worker one is deliberately blocked on task zero. Observing
                // worker three's task proves the caller overlaps live worker
                // execution instead of running after a hidden barrier.
                progress.wait_until(&ready[2], 17);
                release_first.store(true, Ordering::Release);
                for slot in &ready {
                    progress.wait_until(slot, 17);
                }
                0x61_u8
            },
        );

        assert_eq!(returned, 0x61);
        assert_eq!(tasks, [1, 2, 3, 4, 5, 6, 7, 8, 9]);
        assert_eq!(
            owners.map(|owner| owner.load(Ordering::Relaxed)),
            [1, 2, 3, 1, 2, 3, 1, 2, 3]
        );
        drop(activity);
        assert!(runtime.shutdown().clean());
    }

    #[cfg(feature = "pipelined-inverse-reduction-60x36")]
    #[test]
    fn worker_only_dispatch_detects_prepublication_panic_and_clears_descriptor() {
        let mut runtime = parallel_runtime();
        let shared = match runtime.backend.as_ref() {
            Some(Backend::Parallel(parallel)) => Arc::clone(&parallel.shared),
            _ => panic!("test runtime is not parallel"),
        };
        let activity = runtime.begin_activity();
        let ready = AtomicU64::new(0);
        let mut tasks = [false; 6];
        let panic = catch_unwind(AssertUnwindSafe(|| {
            runtime.dispatch_workers_with_caller(
                &mut tasks,
                |index, task| {
                    if index == 0 {
                        panic!("worker failed before publication");
                    }
                    *task = true;
                },
                |progress| progress.wait_until(&ready, 1),
            );
        }));

        assert!(panic.is_err());
        assert!(shared.current_job.load(Ordering::Relaxed).is_null());
        for index in [1, 2, 4, 5] {
            assert!(tasks[index], "non-panicking worker missed task {index}");
        }
        let poisoned = catch_unwind(AssertUnwindSafe(|| runtime.dispatch_empty()));
        assert!(poisoned.is_err());
        drop(activity);
        assert!(runtime.shutdown().clean());
    }

    #[cfg(feature = "pipelined-inverse-reduction-60x36")]
    #[test]
    fn worker_only_dispatch_caller_panic_still_waits_and_clears_descriptor() {
        let mut runtime = parallel_runtime();
        let shared = match runtime.backend.as_ref() {
            Some(Backend::Parallel(parallel)) => Arc::clone(&parallel.shared),
            _ => panic!("test runtime is not parallel"),
        };
        let activity = runtime.begin_activity();
        let mut tasks = [false; 9];
        let panic = catch_unwind(AssertUnwindSafe(|| {
            runtime.dispatch_workers_with_caller(
                &mut tasks,
                |_, task| *task = true,
                |_| -> () { panic!("overlapped caller panic") },
            );
        }));

        assert!(panic.is_err());
        assert!(
            tasks.iter().all(|task| *task),
            "caller panic returned before all worker-only tasks completed"
        );
        assert!(shared.current_job.load(Ordering::Relaxed).is_null());
        let poisoned = catch_unwind(AssertUnwindSafe(|| runtime.dispatch_empty()));
        assert!(poisoned.is_err());
        drop(activity);
        assert!(runtime.shutdown().clean());
    }

    #[cfg(feature = "pipelined-inverse-reduction-60x36")]
    #[test]
    fn worker_only_dispatch_rejects_missing_successful_publication() {
        let mut runtime = parallel_runtime();
        let shared = match runtime.backend.as_ref() {
            Some(Backend::Parallel(parallel)) => Arc::clone(&parallel.shared),
            _ => panic!("test runtime is not parallel"),
        };
        let activity = runtime.begin_activity();
        let ready = AtomicU64::new(0);
        let mut tasks = [false; 9];
        let panic = catch_unwind(AssertUnwindSafe(|| {
            runtime.dispatch_workers_with_caller(
                &mut tasks,
                |_, task| *task = true,
                |progress| progress.wait_until(&ready, 1),
            );
        }));

        assert!(panic.is_err());
        assert!(tasks.iter().all(|task| *task));
        assert!(shared.current_job.load(Ordering::Relaxed).is_null());
        let poisoned = catch_unwind(AssertUnwindSafe(|| runtime.dispatch_empty()));
        assert!(poisoned.is_err());
        drop(activity);
        assert!(runtime.shutdown().clean());
    }

    #[cfg(feature = "pipelined-inverse-reduction-60x36")]
    #[test]
    fn worker_only_dispatch_preserves_single_thread_fallback_order() {
        let caller = thread::current().id();
        let ready: [AtomicU64; 5] = std::array::from_fn(|_| AtomicU64::new(0));
        let mut runtime = FourCoreRuntime::from_requested_cores(1);
        let mut tasks = [OwnedTask::default(); 5];
        let result = runtime.dispatch_workers_with_caller(
            &mut tasks,
            |index, task| {
                task.calls = index as u64 + 1;
                task.owner = Some(thread::current().id());
                ready[index].store(9, Ordering::Release);
            },
            |progress| {
                for slot in &ready {
                    progress.wait_until(slot, 9);
                }
                23
            },
        );

        assert_eq!(result, 23);
        assert!(tasks
            .iter()
            .enumerate()
            .all(|(index, task)| task.calls == index as u64 + 1 && task.owner == Some(caller)));
        assert!(runtime.shutdown().clean());
    }

    #[test]
    fn empty_dispatch_has_a_full_worker_barrier() {
        let mut runtime = parallel_runtime();
        let activity = runtime.begin_activity();
        for _ in 0..1_024 {
            runtime.dispatch_empty();
        }
        drop(activity);
        let report = runtime.shutdown();
        assert_eq!(report.joined_workers, WORKER_COUNT as u8);
        assert!(report.clean());
    }

    #[test]
    fn caller_panic_waits_for_workers_and_poisoning_is_explicit() {
        let mut runtime = parallel_runtime();
        let activity = runtime.begin_activity();
        let mut tasks = [false; 8];
        let panic = catch_unwind(AssertUnwindSafe(|| {
            runtime.dispatch(&mut tasks, |index, task| {
                if index == 0 {
                    panic!("caller lane panic");
                }
                *task = true;
            });
        }));
        assert!(panic.is_err());
        for index in [1, 2, 3, 5, 6, 7] {
            assert!(tasks[index], "worker task {index} missed the barrier");
        }

        let poisoned = catch_unwind(AssertUnwindSafe(|| {
            runtime.dispatch_empty();
        }));
        assert!(poisoned.is_err());
        drop(activity);
        assert!(runtime.shutdown().clean());
    }

    #[test]
    fn worker_panic_waits_for_other_lanes_and_drop_joins() {
        let mut runtime = parallel_runtime();
        let activity = runtime.begin_activity();
        let weak = shared_weak(&runtime);
        let mut tasks = [false; 8];
        let panic = catch_unwind(AssertUnwindSafe(|| {
            runtime.dispatch(&mut tasks, |index, task| {
                if index == 1 {
                    panic!("worker lane panic");
                }
                *task = true;
            });
        }));
        assert!(panic.is_err());
        for index in [0, 2, 3, 4, 6, 7] {
            assert!(tasks[index], "non-panicking lane task {index} was skipped");
        }
        assert!(!tasks[1]);
        assert!(!tasks[5]);

        drop(activity);
        drop(runtime);
        assert!(
            weak.upgrade().is_none(),
            "drop left a persistent worker alive"
        );
    }

    #[test]
    fn worker_panic_payload_drops_only_after_completion() {
        static PAYLOAD_DROPS: AtomicUsize = AtomicUsize::new(0);
        struct DropCounter;

        impl Drop for DropCounter {
            fn drop(&mut self) {
                PAYLOAD_DROPS.fetch_add(1, Ordering::Relaxed);
            }
        }

        PAYLOAD_DROPS.store(0, Ordering::Relaxed);
        let mut runtime = parallel_runtime();
        let activity = runtime.begin_activity();
        let mut tasks = [0_u8; 4];
        let panic = catch_unwind(AssertUnwindSafe(|| {
            runtime.dispatch(&mut tasks, |index, _| {
                if index == 1 {
                    std::panic::panic_any(DropCounter);
                }
            });
        }));
        assert!(panic.is_err());
        drop(activity);
        assert!(runtime.shutdown().clean());
        assert_eq!(
            PAYLOAD_DROPS.load(Ordering::Relaxed),
            1,
            "worker panic payload was leaked or dropped outside guarded teardown"
        );
    }

    #[test]
    fn drop_joins_all_idle_workers() {
        let runtime = parallel_runtime();
        let weak = shared_weak(&runtime);
        drop(runtime);
        assert!(weak.upgrade().is_none());
    }

    #[cfg(all(feature = "shared-activity-futex-wake", target_os = "linux"))]
    #[test]
    fn futex_shutdown_wake_is_retained_before_worker_wait() {
        // Immediate teardown repeatedly races worker startup's parked intent
        // against entry into FUTEX_WAIT. STOPPED must remain nonzero so a wake
        // that wins that race cannot strand a worker in the kernel.
        for _ in 0..256 {
            let runtime = parallel_runtime();
            assert!(runtime.shutdown().clean());
        }
    }

    #[test]
    fn injected_worker_setup_failure_falls_back_and_cleans_up() {
        let setup = TestSetup {
            failure: Some(TestFailure {
                lane: 2,
                stage: SetupStage::SetFifoPriority,
            }),
            ..TestSetup::default()
        };
        let error = match FourCoreRuntime::test_parallel(setup) {
            Ok(_) => panic!("injected worker setup failure unexpectedly succeeded"),
            Err(error) => error,
        };
        assert_eq!(
            error.cause,
            SetupFailure {
                lane: 2,
                stage: SetupStage::SetFifoPriority,
                os_error: Some(1),
            }
        );
        assert_eq!(error.cleanup.detached_workers, 0);
        assert_eq!(error.cleanup.joined_workers, WORKER_COUNT as u8);

        let mut runtime = FourCoreRuntime::test_with_setup(setup);
        assert_eq!(runtime.mode(), ExecutionMode::SingleThread);
        assert_eq!(
            runtime.fallback_reason(),
            Some(FallbackReason::StartupFailed {
                cause: error.cause,
                caller_restore_failure: None,
                detached_workers: 0,
            })
        );
        let mut tasks = [0_u8; 4];
        runtime.dispatch(&mut tasks, |index, task| *task = index as u8 + 1);
        assert_eq!(tasks, [1, 2, 3, 4]);
    }

    #[test]
    fn environment_selected_runtime_always_dispatches_safely() {
        let mut runtime = FourCoreRuntime::from_environment();
        println!("runtime_status={:?}", runtime.status());
        let calls = AtomicUsize::new(0);
        let mut tasks = [0_u8; 9];
        let activity = runtime.begin_activity();
        runtime.dispatch(&mut tasks, |index, task| {
            assert_eq!(*task, 0);
            *task = (index + 1) as u8;
            calls.fetch_add(1, Ordering::Relaxed);
        });
        drop(activity);
        assert_eq!(calls.load(Ordering::Relaxed), tasks.len());
        assert_eq!(tasks, [1, 2, 3, 4, 5, 6, 7, 8, 9]);
        let report = runtime.shutdown();
        assert_eq!(report.detached_workers, 0);
    }
}
