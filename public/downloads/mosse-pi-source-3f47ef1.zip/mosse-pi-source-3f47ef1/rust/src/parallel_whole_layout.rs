//! Runtime-integrated parallel 60x36 whole-layout transform.
//!
//! This module adapts Experiment 041's exact row/column task chain to the
//! production [`FourCoreRuntime`]. The transform owns persistent kernel and
//! staging state, while its caller supplies the runtime so one executor can
//! later service FFT and disjoint tracker-tail work.
//!
//! Forward performs one nine-task row dispatch and one eight-task column
//! dispatch. Inverse performs the two FFT dispatches in reverse order, then
//! scatters on the caller and performs the complete scaled response reduction
//! in the original serial row-major order. The optional inverse pipeline lets
//! worker-only row tasks publish complete four-row batches while the caller
//! consumes them in that same serial order, avoiding both a spatial scatter
//! and a second buffer read. Floating-point partial reductions are deliberately
//! not combined across cores.

#[cfg(all(
    feature = "composite-preprocess-forward-60x36",
    any(test, not(feature = "wake-crop-pipeline-60x36"))
))]
use crate::four_core_runtime::ExecutionMode;
use crate::four_core_runtime::FourCoreRuntime;
#[cfg(feature = "pipelined-inverse-reduction-60x36")]
use crate::four_core_runtime::WorkerJobProgress;
use mosse_exp028_aosoa_cfft36::{Batch4 as ColumnBatch4, Kernel36x4};
use mosse_exp031_aosoa_rfft60::{
    ComplexBatch4 as RowSpectrum4, Kernel60x4, RealBatch4 as RealRows4, UNIQUE_LEN,
};
use mosse_exp034_whole_layout_fft2::{
    PaddedSpectrum, COLUMN_BATCHES, LANES, ROUND_TRIP_SCALE, ROW_BATCHES, SPATIAL_LEN, WIDTH,
};
#[cfg(all(
    feature = "parallel-correlated-inverse-60x36",
    not(feature = "fused-correlated-inverse-cfft36-60x36")
))]
use mosse_exp044_parallel_tail_kernels::correlate_padded_batch;
#[cfg(all(
    feature = "composite-preprocess-forward-60x36",
    any(test, not(feature = "wake-crop-pipeline-60x36"))
))]
use mosse_exp044_parallel_tail_kernels::{reduce_log_values_row_major, RawCropLogRowsTask};
use std::ptr;
#[cfg(any(
    feature = "pipelined-inverse-reduction-60x36",
    all(
        feature = "composite-preprocess-forward-60x36",
        any(test, not(feature = "wake-crop-pipeline-60x36"))
    )
))]
use std::sync::atomic::Ordering;
#[cfg(feature = "pipelined-inverse-reduction-60x36")]
use std::{cell::UnsafeCell, sync::atomic::AtomicU64};
#[cfg(all(
    feature = "composite-preprocess-forward-60x36",
    any(test, not(feature = "wake-crop-pipeline-60x36"))
))]
use std::{
    panic::{catch_unwind, resume_unwind, AssertUnwindSafe},
    sync::atomic::{AtomicU32, AtomicU8},
};

/// Production-style statistics returned with an inverse response.
#[derive(Clone, Copy, Debug)]
pub struct InverseReduction {
    pub maximum: f32,
    pub maximum_index: usize,
    pub sum: f64,
    pub sum_of_squares: f64,
}

impl InverseReduction {
    /// Compare every floating-point field by representation.
    pub fn bit_identical(self, other: Self) -> bool {
        self.maximum.to_bits() == other.maximum.to_bits()
            && self.maximum_index == other.maximum_index
            && self.sum.to_bits() == other.sum.to_bits()
            && self.sum_of_squares.to_bits() == other.sum_of_squares.to_bits()
    }
}

struct RowTask {
    index: usize,
    kernel: Kernel60x4,
    input: RealRows4,
    spectrum: RowSpectrum4,
    output: RealRows4,
}

impl RowTask {
    fn new(index: usize) -> Self {
        Self {
            index,
            kernel: Kernel60x4::new(),
            input: RealRows4::default(),
            spectrum: RowSpectrum4::default(),
            output: RealRows4::default(),
        }
    }

    #[inline]
    fn forward(&mut self, spatial: &[f32]) {
        let row_base = self.index * LANES;
        for x in 0..WIDTH {
            self.input.values[x] = [
                spatial[row_base * WIDTH + x],
                spatial[(row_base + 1) * WIDTH + x],
                spatial[(row_base + 2) * WIDTH + x],
                spatial[(row_base + 3) * WIDTH + x],
            ];
        }
        self.kernel.process_forward(&self.input, &mut self.spectrum);
    }

    #[cfg(feature = "fused-normalize-forward-60x36")]
    #[inline]
    fn forward_normalized(
        &mut self,
        log_values: &[f32],
        hann: &[f32],
        mean: f32,
        denominator: f32,
    ) {
        let row_base = self.index * LANES;
        for x in 0..WIDTH {
            let indices = [
                row_base * WIDTH + x,
                (row_base + 1) * WIDTH + x,
                (row_base + 2) * WIDTH + x,
                (row_base + 3) * WIDTH + x,
            ];
            self.input.values[x] = [
                ((log_values[indices[0]] - mean) / denominator) * hann[indices[0]],
                ((log_values[indices[1]] - mean) / denominator) * hann[indices[1]],
                ((log_values[indices[2]] - mean) / denominator) * hann[indices[2]],
                ((log_values[indices[3]] - mean) / denominator) * hann[indices[3]],
            ];
        }
        self.kernel.process_forward(&self.input, &mut self.spectrum);
    }

    #[inline]
    fn inverse(&mut self, columns: &[ColumnBatch4; COLUMN_BATCHES]) {
        transpose_columns_to_rows(columns, self.index, &mut self.spectrum);
        self.kernel
            .process_inverse(&self.spectrum, &mut self.output);
    }

    #[cfg(feature = "pipelined-inverse-reduction-60x36")]
    #[inline]
    fn inverse_published(
        &mut self,
        columns: &[ColumnBatch4; COLUMN_BATCHES],
        slot: &InverseRowSlot,
        epoch: u64,
    ) {
        transpose_columns_to_rows(columns, self.index, &mut self.spectrum);
        // SAFETY: the worker-only modulo-three partition assigns each row
        // task and its matching slot to exactly one worker. The caller does
        // not read this slot until the release store below is acquired.
        let output = unsafe { &mut *slot.value.get() };
        self.kernel.process_inverse(&self.spectrum, output);
        slot.ready_epoch.store(epoch, Ordering::Release);
    }

    fn poison(&mut self, salt: u32) {
        self.kernel
            .poison_scratch(salt ^ 0x3100 ^ (self.index as u32 * 0x101));
        poison_real_rows(&mut self.input, salt ^ 0xa100 ^ self.index as u32);
        poison_row_spectrum(&mut self.spectrum, salt ^ 0xb200 ^ (self.index as u32 * 3));
        poison_real_rows(&mut self.output, salt ^ 0xc300 ^ (self.index as u32 * 7));
    }
}

#[cfg(all(
    feature = "composite-preprocess-forward-60x36",
    any(test, not(feature = "wake-crop-pipeline-60x36"))
))]
const COMPOSITE_PHASE_CROP: u8 = 0;
#[cfg(all(
    feature = "composite-preprocess-forward-60x36",
    any(test, not(feature = "wake-crop-pipeline-60x36"))
))]
const COMPOSITE_PHASE_FORWARD: u8 = 1;
#[cfg(all(
    feature = "composite-preprocess-forward-60x36",
    any(test, not(feature = "wake-crop-pipeline-60x36"))
))]
const COMPOSITE_PHASE_ABORT: u8 = 2;

#[cfg(all(
    feature = "composite-preprocess-forward-60x36",
    any(test, not(feature = "wake-crop-pipeline-60x36"))
))]
#[repr(align(64))]
struct CompositeReady(AtomicU8);

/// Shared state for one crop/reduction/row-RFFT executor epoch.
///
/// Four runtime tasks first write disjoint crop rows. Their release updates to
/// `crop_ready` let lane zero reconstruct the complete log-value slice and run
/// both original row-major `f64` accumulation chains. Lane zero then publishes
/// the two original `f32` normalization parameters and releases every lane into
/// its unchanged modulo-four row-RFFT ownership.
#[cfg(all(
    feature = "composite-preprocess-forward-60x36",
    any(test, not(feature = "wake-crop-pipeline-60x36"))
))]
struct CompositeForwardContext<'window> {
    rows: *mut RowTask,
    log_values: *const f32,
    hann: &'window [f32],
    epsilon: f64,
    crop_ready: [CompositeReady; LANES],
    crop_panicked: AtomicU8,
    phase: AtomicU8,
    mean_bits: AtomicU32,
    denominator_bits: AtomicU32,
    #[cfg(test)]
    panic_crop_lane: Option<usize>,
}

// SAFETY: one runtime dispatch invokes each lane exactly once. Raw crop tasks
// address disjoint output rows and store no Rust references to that output.
// Row task `i` is touched only by lane `i % 4`. The raw log buffer is read only
// after lane zero acquires all four crop-ready bits, and normalization
// parameters are read only after the phase release.
#[cfg(all(
    feature = "composite-preprocess-forward-60x36",
    any(test, not(feature = "wake-crop-pipeline-60x36"))
))]
unsafe impl Sync for CompositeForwardContext<'_> {}

#[cfg(all(
    feature = "composite-preprocess-forward-60x36",
    any(test, not(feature = "wake-crop-pipeline-60x36"))
))]
impl CompositeForwardContext<'_> {
    #[inline]
    fn run_lane(&self, lane: usize, crop: &mut RawCropLogRowsTask<'_>) {
        assert!(lane < LANES, "composite preprocessing lane outside 0..4");

        let crop_panic = catch_unwind(AssertUnwindSafe(|| {
            #[cfg(test)]
            if self.panic_crop_lane == Some(lane) {
                panic!("injected composite crop panic on lane {lane}");
            }
            // SAFETY: the tracker-created raw tasks point into one live
            // exclusive fixed buffer and the runtime invokes each disjoint
            // task exactly once.
            unsafe { crop.run() };
        }))
        .err();
        if crop_panic.is_some() {
            self.crop_panicked.fetch_or(1_u8 << lane, Ordering::Relaxed);
        }
        self.crop_ready[lane].0.store(1, Ordering::Release);

        if lane != 0 {
            if let Some(payload) = crop_panic {
                resume_unwind(payload);
            }
            loop {
                match self.phase.load(Ordering::Acquire) {
                    COMPOSITE_PHASE_CROP => std::hint::spin_loop(),
                    COMPOSITE_PHASE_FORWARD => break,
                    COMPOSITE_PHASE_ABORT => return,
                    phase => panic!("invalid composite preprocessing phase {phase}"),
                }
            }
            self.forward_owned_rows(lane);
            return;
        }

        while !self
            .crop_ready
            .iter()
            .all(|ready| ready.0.load(Ordering::Acquire) == 1)
        {
            std::hint::spin_loop();
        }
        if self.crop_panicked.load(Ordering::Relaxed) != 0 {
            self.phase.store(COMPOSITE_PHASE_ABORT, Ordering::Release);
            if let Some(payload) = crop_panic {
                resume_unwind(payload);
            }
            panic!("composite preprocessing worker crop panicked");
        }
        debug_assert!(crop_panic.is_none());

        let reduction = catch_unwind(AssertUnwindSafe(|| {
            // SAFETY: the caller acquired every lane's crop-ready release, so
            // all disjoint writes are complete. No lane touches its crop output
            // after publishing readiness, and the pointer covers exactly the
            // fixed 60x36 buffer for the lifetime of this dispatch.
            let log_values = unsafe { std::slice::from_raw_parts(self.log_values, SPATIAL_LEN) };
            reduce_log_values_row_major(log_values, self.epsilon)
                .expect("composite preprocessing requires exactly 60x36 log values")
        }));
        let reduction = match reduction {
            Ok(reduction) => reduction,
            Err(payload) => {
                self.phase.store(COMPOSITE_PHASE_ABORT, Ordering::Release);
                resume_unwind(payload);
            }
        };
        self.mean_bits
            .store(reduction.mean_f32.to_bits(), Ordering::Relaxed);
        self.denominator_bits
            .store(reduction.denominator_f32.to_bits(), Ordering::Relaxed);
        self.phase.store(COMPOSITE_PHASE_FORWARD, Ordering::Release);
        self.forward_owned_rows(0);
    }

    #[inline]
    fn forward_owned_rows(&self, lane: usize) {
        let mean = f32::from_bits(self.mean_bits.load(Ordering::Relaxed));
        let denominator = f32::from_bits(self.denominator_bits.load(Ordering::Relaxed));
        // SAFETY: phase acquire/release makes every crop write and both
        // normalization fields visible. Static modulo-four ownership gives
        // this lane sole mutable access to each selected row task.
        let log_values = unsafe { std::slice::from_raw_parts(self.log_values, SPATIAL_LEN) };
        let mut index = lane;
        while index < ROW_BATCHES {
            // SAFETY: `rows` points to all nine persistent tasks and no other
            // lane selects an index congruent to `lane` modulo four.
            let row = unsafe { &mut *self.rows.add(index) };
            debug_assert_eq!(row.index, index);
            row.forward_normalized(log_values, self.hann, mean, denominator);
            index += LANES;
        }
    }
}

struct ColumnTask {
    index: usize,
    kernel: Kernel36x4,
    batch: *mut ColumnBatch4,
}

// SAFETY: `batch` is null outside a column dispatch. `bind_columns` assigns
// every task a distinct batch, and `FourCoreRuntime::dispatch` does not
// return until every task and completion barrier has finished.
unsafe impl Send for ColumnTask {}

impl ColumnTask {
    fn new(index: usize) -> Self {
        Self {
            index,
            kernel: Kernel36x4::new(),
            batch: ptr::null_mut(),
        }
    }

    #[inline]
    fn forward(&mut self, rows: &[RowTask; ROW_BATCHES]) {
        // SAFETY: `bind_columns` assigns this task sole ownership of its
        // output batch for the complete dispatch.
        let batch = unsafe { &mut *self.batch };
        transpose_rows_to_column(rows, self.index, batch);
        self.kernel.process_forward(batch);
    }

    #[inline]
    fn inverse(&mut self) {
        // SAFETY: `bind_columns` assigns this task sole ownership of its
        // spectrum batch for the complete dispatch.
        let batch = unsafe { &mut *self.batch };
        self.kernel.process_inverse(batch);
    }

    #[cfg(any(
        feature = "parallel-correlated-inverse-60x36",
        feature = "fused-correlated-inverse-cfft36-60x36"
    ))]
    #[inline]
    fn correlated_inverse(&mut self, sample: &ColumnBatch4, filter: &ColumnBatch4) {
        // SAFETY: `bind_columns` assigns this task sole ownership of its
        // response batch for the complete dispatch. `sample` and `filter`
        // are immutable matching batches from separate spectra.
        let response = unsafe { &mut *self.batch };
        #[cfg(feature = "fused-correlated-inverse-cfft36-60x36")]
        self.kernel.process_correlated_inverse(
            sample,
            filter,
            response,
            self.index == COLUMN_BATCHES - 1,
        );
        #[cfg(all(
            feature = "parallel-correlated-inverse-60x36",
            not(feature = "fused-correlated-inverse-cfft36-60x36")
        ))]
        {
            correlate_padded_batch(sample, filter, response, self.index);
            self.kernel.process_inverse(response);
        }
    }

    fn poison(&mut self, salt: u32) {
        self.kernel
            .poison_scratch(salt ^ 0x2800 ^ (self.index as u32 * 0x101));
    }
}

/// One independently published four-row inverse result.
///
/// `RealRows4` is exactly 15 cache lines; the 64-byte alignment puts the
/// readiness word on a separate trailing line and keeps adjacent slots from
/// false-sharing their publication state.
#[cfg(feature = "pipelined-inverse-reduction-60x36")]
#[repr(C, align(64))]
struct InverseRowSlot {
    value: UnsafeCell<RealRows4>,
    ready_epoch: AtomicU64,
}

#[cfg(feature = "pipelined-inverse-reduction-60x36")]
impl InverseRowSlot {
    fn new() -> Self {
        Self {
            value: UnsafeCell::new(RealRows4::default()),
            ready_epoch: AtomicU64::new(0),
        }
    }

    fn poison(&mut self, salt: u32) {
        poison_real_rows(self.value.get_mut(), salt);
        self.ready_epoch.store(0, Ordering::Relaxed);
    }
}

// SAFETY: every dispatch maps slot `i` exclusively to row task `i`. The only
// concurrent reader waits for the slot's release publication before touching
// the value, and no writer revisits a published slot during that dispatch.
#[cfg(feature = "pipelined-inverse-reduction-60x36")]
unsafe impl Sync for InverseRowSlot {}

/// Persistent fixed-size FFT state driven by a caller-owned runtime.
pub struct ParallelWholeLayoutFft2 {
    rows: [RowTask; ROW_BATCHES],
    columns: [ColumnTask; COLUMN_BATCHES],
    #[cfg(feature = "pipelined-inverse-reduction-60x36")]
    inverse_slots: [InverseRowSlot; ROW_BATCHES],
    #[cfg(feature = "pipelined-inverse-reduction-60x36")]
    inverse_epoch: u64,
}

impl Default for ParallelWholeLayoutFft2 {
    fn default() -> Self {
        Self::new()
    }
}

impl ParallelWholeLayoutFft2 {
    pub fn new() -> Self {
        Self {
            rows: std::array::from_fn(RowTask::new),
            columns: std::array::from_fn(ColumnTask::new),
            #[cfg(feature = "pipelined-inverse-reduction-60x36")]
            inverse_slots: std::array::from_fn(|_| InverseRowSlot::new()),
            #[cfg(feature = "pipelined-inverse-reduction-60x36")]
            inverse_epoch: 0,
        }
    }

    pub const fn backend_name() -> &'static str {
        #[cfg(target_arch = "aarch64")]
        {
            "aarch64-neon-runtime-dispatched"
        }
        #[cfg(not(target_arch = "aarch64"))]
        {
            "portable-runtime-dispatched-test"
        }
    }

    /// Complete unnormalized real-to-complex 60x36 transform.
    ///
    /// Both dispatches, all worker work, and both completion barriers finish
    /// before this method returns.
    pub fn forward(
        &mut self,
        runtime: &mut FourCoreRuntime,
        input: &[f32],
        output: &mut PaddedSpectrum,
    ) {
        assert_eq!(input.len(), SPATIAL_LEN);
        runtime.dispatch(&mut self.rows, |index, task| {
            debug_assert_eq!(index, task.index);
            task.forward(input);
        });

        bind_columns(&mut self.columns, &mut output.batches);
        let rows = &self.rows;
        runtime.dispatch(&mut self.columns, |index, task| {
            debug_assert_eq!(index, task.index);
            task.forward(rows);
        });
        clear_columns(&mut self.columns);
    }

    /// Normalize/window fixed log values while loading the existing forward
    /// row tasks, then complete the unchanged 60x36 transform.
    ///
    /// The row expression is deliberately identical to the retained serial
    /// pass: `((value - mean) / denominator) * hann`. The caller must compute
    /// `mean` and `denominator` with the retained serial row-major f64
    /// reductions before entering this method.
    #[cfg(feature = "fused-normalize-forward-60x36")]
    pub fn forward_normalized(
        &mut self,
        runtime: &mut FourCoreRuntime,
        log_values: &[f32],
        hann: &[f32],
        mean: f32,
        denominator: f32,
        output: &mut PaddedSpectrum,
    ) {
        assert_eq!(log_values.len(), SPATIAL_LEN);
        assert_eq!(hann.len(), SPATIAL_LEN);
        runtime.dispatch(&mut self.rows, |index, task| {
            debug_assert_eq!(index, task.index);
            task.forward_normalized(log_values, hann, mean, denominator);
        });

        bind_columns(&mut self.columns, &mut output.batches);
        let rows = &self.rows;
        runtime.dispatch(&mut self.columns, |index, task| {
            debug_assert_eq!(index, task.index);
            task.forward(rows);
        });
        clear_columns(&mut self.columns);
    }

    /// Crop/log fixed rows, preserve both caller-side serial reductions, and
    /// execute normalized forward rows in one four-lane runtime epoch.
    ///
    /// The column transform remains a second normal dispatch. Compared with
    /// the rejected Experiment 055 composition, this removes the transition
    /// from a completed crop epoch into a separately published row epoch; it
    /// does not remove the mathematically required crop/reduction phase gate.
    ///
    /// # Safety
    ///
    /// `log_values` must point to the same complete 60x36 allocation addressed
    /// by the four disjoint raw outputs in `crop_tasks`. That allocation, every
    /// crop task input, and `hann` must remain live until this method returns.
    /// No caller may access an output row while its crop runs. The tasks must
    /// have been created by `bind_raw_crop_log_rows` for this allocation.
    #[cfg(all(
        feature = "composite-preprocess-forward-60x36",
        any(test, not(feature = "wake-crop-pipeline-60x36"))
    ))]
    pub(crate) unsafe fn forward_normalized_after_crop(
        &mut self,
        runtime: &mut FourCoreRuntime,
        crop_tasks: &mut [RawCropLogRowsTask<'_>; LANES],
        log_values: *const f32,
        hann: &[f32],
        epsilon: f64,
        output: &mut PaddedSpectrum,
    ) {
        #[cfg(test)]
        unsafe {
            self.forward_normalized_after_crop_impl(
                runtime, crop_tasks, log_values, hann, epsilon, output, None,
            );
        }
        #[cfg(not(test))]
        unsafe {
            self.forward_normalized_after_crop_impl(
                runtime, crop_tasks, log_values, hann, epsilon, output,
            );
        }
    }

    #[cfg(all(
        feature = "composite-preprocess-forward-60x36",
        any(test, not(feature = "wake-crop-pipeline-60x36"))
    ))]
    #[allow(clippy::too_many_arguments)]
    unsafe fn forward_normalized_after_crop_impl(
        &mut self,
        runtime: &mut FourCoreRuntime,
        crop_tasks: &mut [RawCropLogRowsTask<'_>; LANES],
        log_values: *const f32,
        hann: &[f32],
        epsilon: f64,
        output: &mut PaddedSpectrum,
        #[cfg(test)] panic_crop_lane: Option<usize>,
    ) {
        assert_eq!(
            runtime.mode(),
            ExecutionMode::PersistentFourCore,
            "composite preprocessing requires the validated four-lane runtime"
        );
        assert!(!log_values.is_null());
        assert_eq!(hann.len(), SPATIAL_LEN);

        let context = CompositeForwardContext {
            rows: self.rows.as_mut_ptr(),
            log_values,
            hann,
            epsilon,
            crop_ready: std::array::from_fn(|_| CompositeReady(AtomicU8::new(0))),
            crop_panicked: AtomicU8::new(0),
            phase: AtomicU8::new(COMPOSITE_PHASE_CROP),
            mean_bits: AtomicU32::new(0),
            denominator_bits: AtomicU32::new(0),
            #[cfg(test)]
            panic_crop_lane,
        };
        runtime.dispatch(crop_tasks, |lane, task| context.run_lane(lane, task));

        bind_columns(&mut self.columns, &mut output.batches);
        let rows = &self.rows;
        runtime.dispatch(&mut self.columns, |index, task| {
            debug_assert_eq!(index, task.index);
            task.forward(rows);
        });
        clear_columns(&mut self.columns);
    }

    #[cfg(all(test, feature = "composite-preprocess-forward-60x36"))]
    #[allow(clippy::too_many_arguments)]
    unsafe fn forward_normalized_after_crop_with_injected_panic(
        &mut self,
        runtime: &mut FourCoreRuntime,
        crop_tasks: &mut [RawCropLogRowsTask<'_>; LANES],
        log_values: *const f32,
        hann: &[f32],
        epsilon: f64,
        output: &mut PaddedSpectrum,
        panic_crop_lane: usize,
    ) {
        unsafe {
            self.forward_normalized_after_crop_impl(
                runtime,
                crop_tasks,
                log_values,
                hann,
                epsilon,
                output,
                Some(panic_crop_lane),
            );
        }
    }

    /// Complete unnormalized complex-to-real 60x36 transform.
    ///
    /// Only the two FFT stages are dispatched. The final scatter remains on
    /// the caller.
    pub fn inverse(
        &mut self,
        runtime: &mut FourCoreRuntime,
        spectrum: &mut PaddedSpectrum,
        output: &mut [f32],
    ) {
        self.inverse_transform(runtime, spectrum, output);
    }

    /// Complete inverse plus the production-style scaled response reduction.
    ///
    /// The reduction is one caller-side row-major loop. Its maximum tie
    /// behavior and f64 addition order match the retained serial operation.
    pub fn inverse_reduced(
        &mut self,
        runtime: &mut FourCoreRuntime,
        spectrum: &mut PaddedSpectrum,
        output: &mut [f32],
    ) -> InverseReduction {
        self.inverse_transform(runtime, spectrum, output);
        reduce_scaled(output, 1.0 / ROUND_TRIP_SCALE)
    }

    /// Correlate `sample * conj(filter)` and perform the complete unnormalized
    /// inverse transform.
    ///
    /// Each existing inverse-column task owns one disjoint output batch. With
    /// the deep CFFT fusion enabled, correlation values are loaded in the
    /// inverse input permutation and feed radix-4 directly; the final padded
    /// lane is replaced with positive zero before inverse arithmetic. The row
    /// inverse and caller-side row-major scatter remain unchanged.
    #[cfg(any(
        feature = "parallel-correlated-inverse-60x36",
        feature = "fused-correlated-inverse-cfft36-60x36"
    ))]
    pub fn correlated_inverse(
        &mut self,
        runtime: &mut FourCoreRuntime,
        sample: &PaddedSpectrum,
        filter: &PaddedSpectrum,
        response: &mut PaddedSpectrum,
        output: &mut [f32],
    ) {
        self.correlated_inverse_transform(runtime, sample, filter, response, output);
    }

    /// Fused correlation/inverse plus the unchanged caller-side reduction.
    #[cfg(any(
        feature = "parallel-correlated-inverse-60x36",
        feature = "fused-correlated-inverse-cfft36-60x36"
    ))]
    pub fn correlated_inverse_reduced(
        &mut self,
        runtime: &mut FourCoreRuntime,
        sample: &PaddedSpectrum,
        filter: &PaddedSpectrum,
        response: &mut PaddedSpectrum,
        output: &mut [f32],
    ) -> InverseReduction {
        self.correlated_inverse_transform(runtime, sample, filter, response, output);
        reduce_scaled(output, 1.0 / ROUND_TRIP_SCALE)
    }

    /// Fuse correlation into inverse columns, then overlap worker-only inverse
    /// rows with the unchanged serial row-major caller reduction.
    ///
    /// This deliberately does not materialize a spatial response. It returns
    /// exactly the statistics that the production tracker consumes, with the
    /// same f32 scale, strict maximum comparison, and f64 addition order as
    /// [`reduce_scaled`].
    #[cfg(feature = "pipelined-inverse-reduction-60x36")]
    pub fn correlated_inverse_reduced_pipelined(
        &mut self,
        runtime: &mut FourCoreRuntime,
        sample: &PaddedSpectrum,
        filter: &PaddedSpectrum,
        response: &mut PaddedSpectrum,
    ) -> InverseReduction {
        self.correlated_inverse_columns(runtime, sample, filter, response);

        self.inverse_epoch = self
            .inverse_epoch
            .checked_add(1)
            .expect("parallel inverse pipeline exhausted its publication epoch");
        let inverse_epoch = self.inverse_epoch;
        let columns = &response.batches;
        let slots = &self.inverse_slots;
        runtime.dispatch_workers_with_caller(
            &mut self.rows,
            |index, task| {
                debug_assert_eq!(index, task.index);
                task.inverse_published(columns, &slots[index], inverse_epoch);
            },
            |progress| reduce_published_rows(slots, progress, inverse_epoch),
        )
    }

    fn inverse_transform(
        &mut self,
        runtime: &mut FourCoreRuntime,
        spectrum: &mut PaddedSpectrum,
        output: &mut [f32],
    ) {
        assert_eq!(output.len(), SPATIAL_LEN);

        bind_columns(&mut self.columns, &mut spectrum.batches);
        runtime.dispatch(&mut self.columns, |index, task| {
            debug_assert_eq!(index, task.index);
            task.inverse();
        });
        clear_columns(&mut self.columns);

        let columns = &spectrum.batches;
        runtime.dispatch(&mut self.rows, |index, task| {
            debug_assert_eq!(index, task.index);
            task.inverse(columns);
        });

        // Keep the production row-major store order on the caller.
        for row_task in &self.rows {
            let row_base = row_task.index * LANES;
            for x in 0..WIDTH {
                let values = row_task.output.values[x];
                output[row_base * WIDTH + x] = values[0];
                output[(row_base + 1) * WIDTH + x] = values[1];
                output[(row_base + 2) * WIDTH + x] = values[2];
                output[(row_base + 3) * WIDTH + x] = values[3];
            }
        }
    }

    #[cfg(any(
        feature = "parallel-correlated-inverse-60x36",
        feature = "fused-correlated-inverse-cfft36-60x36"
    ))]
    fn correlated_inverse_transform(
        &mut self,
        runtime: &mut FourCoreRuntime,
        sample: &PaddedSpectrum,
        filter: &PaddedSpectrum,
        response: &mut PaddedSpectrum,
        output: &mut [f32],
    ) {
        assert_eq!(output.len(), SPATIAL_LEN);

        self.correlated_inverse_columns(runtime, sample, filter, response);

        let columns = &response.batches;
        runtime.dispatch(&mut self.rows, |index, task| {
            debug_assert_eq!(index, task.index);
            task.inverse(columns);
        });

        // Keep the production row-major store order on the caller.
        for row_task in &self.rows {
            let row_base = row_task.index * LANES;
            for x in 0..WIDTH {
                let values = row_task.output.values[x];
                output[row_base * WIDTH + x] = values[0];
                output[(row_base + 1) * WIDTH + x] = values[1];
                output[(row_base + 2) * WIDTH + x] = values[2];
                output[(row_base + 3) * WIDTH + x] = values[3];
            }
        }
    }

    #[cfg(any(
        feature = "parallel-correlated-inverse-60x36",
        feature = "fused-correlated-inverse-cfft36-60x36"
    ))]
    fn correlated_inverse_columns(
        &mut self,
        runtime: &mut FourCoreRuntime,
        sample: &PaddedSpectrum,
        filter: &PaddedSpectrum,
        response: &mut PaddedSpectrum,
    ) {
        bind_columns(&mut self.columns, &mut response.batches);
        let sample_batches = &sample.batches;
        let filter_batches = &filter.batches;
        runtime.dispatch(&mut self.columns, |index, task| {
            debug_assert_eq!(index, task.index);
            task.correlated_inverse(&sample_batches[index], &filter_batches[index]);
        });
        clear_columns(&mut self.columns);
    }

    /// Poison every persistent kernel and staging buffer for overwrite tests.
    pub fn poison_scratch(&mut self, salt: u32) {
        for row in &mut self.rows {
            row.poison(salt);
        }
        for column in &mut self.columns {
            column.poison(salt);
        }
        #[cfg(feature = "pipelined-inverse-reduction-60x36")]
        for (index, slot) in self.inverse_slots.iter_mut().enumerate() {
            slot.poison(salt ^ 0xd400 ^ (index as u32 * 11));
        }
    }
}

/// Serial scaled maximum/moments reduction in production row-major order.
pub fn reduce_scaled(values: &[f32], scale: f32) -> InverseReduction {
    let mut maximum = f32::NEG_INFINITY;
    let mut maximum_index = 0usize;
    let mut sum = 0.0f64;
    let mut sum_of_squares = 0.0f64;
    for (index, &value) in values.iter().enumerate() {
        let value = value * scale;
        if value > maximum {
            maximum = value;
            maximum_index = index;
        }
        let value = value as f64;
        sum += value;
        sum_of_squares += value * value;
    }
    InverseReduction {
        maximum,
        maximum_index,
        sum,
        sum_of_squares,
    }
}

#[cfg(feature = "pipelined-inverse-reduction-60x36")]
fn reduce_published_rows(
    slots: &[InverseRowSlot; ROW_BATCHES],
    progress: &WorkerJobProgress<'_>,
    epoch: u64,
) -> InverseReduction {
    let scale = 1.0 / ROUND_TRIP_SCALE;
    let mut maximum = f32::NEG_INFINITY;
    let mut maximum_index = 0usize;
    let mut sum = 0.0f64;
    let mut sum_of_squares = 0.0f64;

    // Task, lane, x is the exact row-major order produced by first scattering
    // each four-row batch and then iterating the spatial response slice.
    for (task_index, slot) in slots.iter().enumerate() {
        progress.wait_until(&slot.ready_epoch, epoch);
        // SAFETY: wait_until acquired this slot's release publication. Its
        // sole worker writer has finished and never revisits the slot in this
        // dispatch.
        let rows = unsafe { &*slot.value.get() };
        for lane in 0..LANES {
            let row = task_index * LANES + lane;
            for x in 0..WIDTH {
                let index = row * WIDTH + x;
                let value = rows.values[x][lane] * scale;
                if value > maximum {
                    maximum = value;
                    maximum_index = index;
                }
                let value = value as f64;
                sum += value;
                sum_of_squares += value * value;
            }
        }
    }

    InverseReduction {
        maximum,
        maximum_index,
        sum,
        sum_of_squares,
    }
}

fn bind_columns(
    tasks: &mut [ColumnTask; COLUMN_BATCHES],
    batches: &mut [ColumnBatch4; COLUMN_BATCHES],
) {
    for (task, batch) in tasks.iter_mut().zip(batches.iter_mut()) {
        task.batch = ptr::from_mut(batch);
    }
}

fn clear_columns(tasks: &mut [ColumnTask; COLUMN_BATCHES]) {
    for task in tasks {
        task.batch = ptr::null_mut();
    }
}

#[inline(always)]
fn transpose_rows_to_column(
    rows: &[RowTask; ROW_BATCHES],
    column_index: usize,
    column: &mut ColumnBatch4,
) {
    let kx_base = column_index * LANES;
    for row in rows {
        let ky_base = row.index * LANES;
        let mut re = [[0.0; LANES]; LANES];
        let mut im = [[0.0; LANES]; LANES];
        for kx_lane in 0..LANES {
            let kx = kx_base + kx_lane;
            if kx < UNIQUE_LEN {
                re[kx_lane] = row.spectrum.re[kx];
                im[kx_lane] = row.spectrum.im[kx];
            }
        }
        let re = transpose4x4(re);
        let im = transpose4x4(im);
        column.re[ky_base..ky_base + LANES].copy_from_slice(&re);
        column.im[ky_base..ky_base + LANES].copy_from_slice(&im);
    }
}

#[inline(always)]
fn transpose_columns_to_rows(
    columns: &[ColumnBatch4; COLUMN_BATCHES],
    row_index: usize,
    rows: &mut RowSpectrum4,
) {
    let ky_base = row_index * LANES;
    for (column_index, column) in columns.iter().enumerate() {
        let kx_base = column_index * LANES;
        let re = transpose4x4([
            column.re[ky_base],
            column.re[ky_base + 1],
            column.re[ky_base + 2],
            column.re[ky_base + 3],
        ]);
        let im = transpose4x4([
            column.im[ky_base],
            column.im[ky_base + 1],
            column.im[ky_base + 2],
            column.im[ky_base + 3],
        ]);
        for kx_lane in 0..LANES {
            let kx = kx_base + kx_lane;
            if kx < UNIQUE_LEN {
                rows.re[kx] = re[kx_lane];
                rows.im[kx] = im[kx_lane];
            }
        }
    }
}

#[cfg(target_arch = "aarch64")]
#[inline(always)]
fn transpose4x4(input: [[f32; LANES]; LANES]) -> [[f32; LANES]; LANES] {
    use core::arch::aarch64::{
        float32x4_t, vcombine_f32, vget_high_f32, vget_low_f32, vld1q_f32, vst1q_f32, vtrn1q_f32,
        vtrn2q_f32,
    };

    // SAFETY: every load/store spans one `[f32; 4]`; NEON is mandatory on
    // AArch64 and these intrinsics accept unaligned pointers.
    unsafe {
        let a = vld1q_f32(input[0].as_ptr());
        let b = vld1q_f32(input[1].as_ptr());
        let c = vld1q_f32(input[2].as_ptr());
        let d = vld1q_f32(input[3].as_ptr());
        let ab_low = vtrn1q_f32(a, b);
        let ab_high = vtrn2q_f32(a, b);
        let cd_low = vtrn1q_f32(c, d);
        let cd_high = vtrn2q_f32(c, d);
        let values: [float32x4_t; LANES] = [
            vcombine_f32(vget_low_f32(ab_low), vget_low_f32(cd_low)),
            vcombine_f32(vget_low_f32(ab_high), vget_low_f32(cd_high)),
            vcombine_f32(vget_high_f32(ab_low), vget_high_f32(cd_low)),
            vcombine_f32(vget_high_f32(ab_high), vget_high_f32(cd_high)),
        ];
        let mut output = [[0.0; LANES]; LANES];
        for index in 0..LANES {
            vst1q_f32(output[index].as_mut_ptr(), values[index]);
        }
        output
    }
}

#[cfg(not(target_arch = "aarch64"))]
#[inline(always)]
fn transpose4x4(input: [[f32; LANES]; LANES]) -> [[f32; LANES]; LANES] {
    let mut output = [[0.0; LANES]; LANES];
    for y in 0..LANES {
        for x in 0..LANES {
            output[y][x] = input[x][y];
        }
    }
    output
}

fn poison_real_rows(rows: &mut RealRows4, salt: u32) {
    for index in 0..WIDTH {
        for lane in 0..LANES {
            let payload = ((index as u32 * 17 + lane as u32 * 29 + salt) & 0x003f_ffff) | 1;
            rows.values[index][lane] = f32::from_bits(0x7fc0_0000 | payload);
        }
    }
}

fn poison_row_spectrum(spectrum: &mut RowSpectrum4, salt: u32) {
    for index in 0..UNIQUE_LEN {
        for lane in 0..LANES {
            let re_payload = ((index as u32 * 31 + lane as u32 * 7 + salt) & 0x003f_ffff) | 1;
            let im_payload = ((index as u32 * 13 + lane as u32 * 37 + salt) & 0x003f_ffff) | 1;
            spectrum.re[index][lane] = f32::from_bits(0x7fc0_0000 | re_payload);
            spectrum.im[index][lane] = f32::from_bits(0x7fc0_0000 | im_payload);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::four_core_runtime::ExecutionMode;
    use mosse_exp034_whole_layout_fft2::{WholeLayoutFft2, HEIGHT};
    #[cfg(feature = "parallel-correlated-inverse-60x36")]
    use mosse_exp044_parallel_tail_kernels::bind_correlation_batches;
    #[cfg(feature = "composite-preprocess-forward-60x36")]
    use mosse_exp044_parallel_tail_kernels::bind_raw_crop_log_rows;
    #[cfg(feature = "wake-crop-pipeline-60x36")]
    use mosse_exp044_parallel_tail_kernels::bind_worker_crop_log_rows;
    #[cfg(any(
        feature = "composite-preprocess-forward-60x36",
        all(
            feature = "parallel-tail-preprocess-60x36",
            feature = "fused-normalize-forward-60x36"
        ),
        feature = "wake-crop-pipeline-60x36"
    ))]
    use mosse_exp044_parallel_tail_kernels::{
        bind_crop_log_rows, reduce_log_values_row_major, BgrFrame as TailBgrFrame,
    };

    #[test]
    fn serial_runtime_chain_matches_experiment_034_bit_for_bit() {
        let mut runtime = FourCoreRuntime::from_requested_cores(1);
        assert_eq!(runtime.mode(), ExecutionMode::SingleThread);
        let mut parallel = ParallelWholeLayoutFft2::new();

        for (fixture, input) in fixtures().into_iter().enumerate() {
            let mut serial = WholeLayoutFft2::new();
            let mut serial_spectrum = PaddedSpectrum::default();
            let mut parallel_spectrum = PaddedSpectrum::default();
            parallel_spectrum.poison_all(0x4300_0000 ^ fixture as u32);

            serial.forward(&input, &mut serial_spectrum);
            parallel.forward(&mut runtime, &input, &mut parallel_spectrum);
            require_spectrum_bits(
                &parallel_spectrum,
                &serial_spectrum,
                &format!("fixture={fixture} forward"),
            );
            assert!(parallel_spectrum.padding_is_positive_zero());

            let mut serial_inverse_spectrum = serial_spectrum;
            let mut parallel_inverse_spectrum = parallel_spectrum;
            let mut serial_output = vec![f32::NAN; SPATIAL_LEN];
            let mut parallel_output = vec![f32::from_bits(0x7fc0_4300); SPATIAL_LEN];
            serial.inverse(&mut serial_inverse_spectrum, &mut serial_output);
            let expected_reduction = reduce_scaled(&serial_output, 1.0 / ROUND_TRIP_SCALE);
            let actual_reduction = parallel.inverse_reduced(
                &mut runtime,
                &mut parallel_inverse_spectrum,
                &mut parallel_output,
            );

            require_spectrum_bits(
                &parallel_inverse_spectrum,
                &serial_inverse_spectrum,
                &format!("fixture={fixture} inverse spectrum"),
            );
            require_spatial_bits(
                &parallel_output,
                &serial_output,
                &format!("fixture={fixture} inverse output"),
            );
            assert!(
                actual_reduction.bit_identical(expected_reduction),
                "fixture={fixture} reduction actual={actual_reduction:?} \
                 expected={expected_reduction:?}"
            );
        }
    }

    #[test]
    fn dirty_persistent_state_cannot_change_transform_or_reduction_bits() {
        let input = deterministic_input(0x043d_1a7a_cafe_beef, 17.0);
        let mut runtime = FourCoreRuntime::from_requested_cores(1);
        let mut clean = ParallelWholeLayoutFft2::new();
        let mut dirty = ParallelWholeLayoutFft2::new();
        dirty.poison_scratch(0x1234_5678);

        let mut clean_spectrum = PaddedSpectrum::default();
        let mut dirty_spectrum = PaddedSpectrum::default();
        dirty_spectrum.poison_all(0x55aa_9911);
        clean.forward(&mut runtime, &input, &mut clean_spectrum);
        dirty.forward(&mut runtime, &input, &mut dirty_spectrum);
        require_spectrum_bits(&dirty_spectrum, &clean_spectrum, "dirty forward");

        let mut clean_output = vec![f32::NAN; SPATIAL_LEN];
        let mut dirty_output = vec![f32::from_bits(0x7fc0_1234); SPATIAL_LEN];
        dirty.poison_scratch(0xa5a5_3c3c);
        let clean_reduction =
            clean.inverse_reduced(&mut runtime, &mut clean_spectrum, &mut clean_output);
        let dirty_reduction =
            dirty.inverse_reduced(&mut runtime, &mut dirty_spectrum, &mut dirty_output);
        require_spectrum_bits(&dirty_spectrum, &clean_spectrum, "dirty inverse spectrum");
        require_spatial_bits(&dirty_output, &clean_output, "dirty inverse output");
        assert!(dirty_reduction.bit_identical(clean_reduction));
    }

    #[cfg(feature = "fused-normalize-forward-60x36")]
    #[test]
    fn randomized_fused_normalize_forward_matches_serial_expression_on_four_lanes() {
        let mut runtime = FourCoreRuntime::test_parallel_unconfigured();
        let activity = runtime.begin_activity();
        let cases = [
            (17.0, 0.0, 0.75),
            (0.03125, -0.0, 1.0e-5),
            (
                f32::MIN_POSITIVE * 8.0,
                f32::from_bits(0x0000_0001),
                f32::MIN_POSITIVE,
            ),
            (
                f32::MIN_POSITIVE * 8.0,
                f32::from_bits(0x8000_0001),
                f32::MIN_POSITIVE,
            ),
            (1.0e20, -1.0e20, 3.0e19),
            (1.0e-20, 1.0e-20, 3.0e-21),
        ];

        for (case, &(scale, mean, denominator)) in cases.iter().enumerate() {
            let mut log_values = deterministic_input(0x0550_0000_feed_0000 ^ case as u64, scale);
            let mut hann =
                deterministic_hann(0x055a_0000_beef_0000 ^ (case as u64).rotate_left(17));
            inject_normalize_edge_bits(&mut log_values, &mut hann, scale);
            let log_bits: Vec<_> = log_values.iter().map(|value| value.to_bits()).collect();
            let hann_bits: Vec<_> = hann.iter().map(|value| value.to_bits()).collect();

            let mut normalized = log_values.clone();
            for (value, &window) in normalized.iter_mut().zip(&hann) {
                *value = ((*value - mean) / denominator) * window;
            }

            let mut expected = ParallelWholeLayoutFft2::new();
            let mut actual = ParallelWholeLayoutFft2::new();
            expected.poison_scratch(0x0550_1000 ^ case as u32);
            actual.poison_scratch(0xa55a_e000 ^ case as u32);
            let mut expected_spectrum = PaddedSpectrum::default();
            let mut actual_spectrum = PaddedSpectrum::default();
            expected_spectrum.poison_all(0x0550_2000 ^ case as u32);
            actual_spectrum.poison_all(0xa55a_d000 ^ case as u32);

            expected.forward(&mut runtime, &normalized, &mut expected_spectrum);
            actual.forward_normalized(
                &mut runtime,
                &log_values,
                &hann,
                mean,
                denominator,
                &mut actual_spectrum,
            );

            require_spectrum_bits(
                &actual_spectrum,
                &expected_spectrum,
                &format!(
                    "case={case} scale={scale:?} mean_bits={:#010x} denominator_bits={:#010x}",
                    mean.to_bits(),
                    denominator.to_bits()
                ),
            );
            assert!(actual_spectrum.padding_is_positive_zero());
            assert_eq!(
                log_values
                    .iter()
                    .map(|value| value.to_bits())
                    .collect::<Vec<_>>(),
                log_bits,
                "case={case} fused path rewrote log values"
            );
            assert_eq!(
                hann.iter().map(|value| value.to_bits()).collect::<Vec<_>>(),
                hann_bits,
                "case={case} fused path rewrote Hann values"
            );
        }

        drop(activity);
        assert!(runtime.shutdown().clean());
    }

    #[cfg(all(
        feature = "parallel-tail-preprocess-60x36",
        feature = "fused-normalize-forward-60x36"
    ))]
    #[test]
    fn composed_parallel_crop_reduction_and_fused_forward_is_bit_exact() {
        const EPSILON: f64 = 1.0e-5;
        let log_lut: [f32; 256] = std::array::from_fn(|pixel| (pixel as f32 + 1.0).ln());
        let mut runtime = FourCoreRuntime::test_parallel_unconfigured();
        let activity = runtime.begin_activity();

        for case in 0..12u64 {
            let frame_width = WIDTH + 9 + (case as usize % 7);
            let frame_height = HEIGHT + 7 + (case as usize % 5);
            let stride = frame_width * 3 + 1 + (case as usize * 11 % 23);
            let mut state = 0x055c_0000_d15c_a11eu64 ^ case.wrapping_mul(0x9e37_79b9);
            let mut frame_data = vec![0xa5; stride * frame_height + 19];
            for byte in &mut frame_data {
                state = splitmix64(state);
                *byte = (state >> 56) as u8;
            }
            let frame = TailBgrFrame::new(&frame_data, frame_width, frame_height, stride).unwrap();
            let origin_x = 1 + case as usize % (frame_width - WIDTH - 1);
            let origin_y = 1 + (case as usize * 3) % (frame_height - HEIGHT - 1);

            let dirty = f32::from_bits(0x7fc0_0000 | (case as u32 + 1));
            let mut expected_log = vec![dirty; SPATIAL_LEN];
            let mut actual_log = vec![dirty; SPATIAL_LEN];
            {
                let mut tasks =
                    bind_crop_log_rows(frame, origin_x, origin_y, &log_lut, &mut expected_log)
                        .unwrap();
                for task in &mut tasks {
                    task.run();
                }
            }
            {
                let mut tasks =
                    bind_crop_log_rows(frame, origin_x, origin_y, &log_lut, &mut actual_log)
                        .unwrap();
                runtime.dispatch(&mut tasks, |_, task| task.run());
            }
            require_spatial_bits(
                &actual_log,
                &expected_log,
                &format!("case={case} composed crop/log"),
            );

            let expected_reduction = reduce_log_values_row_major(&expected_log, EPSILON).unwrap();
            let actual_reduction = reduce_log_values_row_major(&actual_log, EPSILON).unwrap();
            assert!(
                actual_reduction.bit_identical(expected_reduction),
                "case={case} composed reduction actual={actual_reduction:?} \
                 expected={expected_reduction:?}"
            );

            let mut hann = deterministic_hann(0x055c_9000_beef_0000 ^ case.rotate_left(29));
            hann[0] = 0.0;
            hann[SPATIAL_LEN - 1] = -0.0;
            let mut expected_normalized = expected_log;
            for (value, &window) in expected_normalized.iter_mut().zip(&hann) {
                *value = ((*value - expected_reduction.mean_f32)
                    / expected_reduction.denominator_f32)
                    * window;
            }

            let actual_log_bits: Vec<_> = actual_log.iter().map(|value| value.to_bits()).collect();
            let mut expected_fft = ParallelWholeLayoutFft2::new();
            let mut actual_fft = ParallelWholeLayoutFft2::new();
            expected_fft.poison_scratch(0x055c_1000 ^ case as u32);
            actual_fft.poison_scratch(0xa55c_e000 ^ case as u32);
            let mut expected_spectrum = PaddedSpectrum::default();
            let mut actual_spectrum = PaddedSpectrum::default();
            expected_spectrum.poison_all(0x055c_2000 ^ case as u32);
            actual_spectrum.poison_all(0xa55c_d000 ^ case as u32);
            expected_fft.forward(&mut runtime, &expected_normalized, &mut expected_spectrum);
            actual_fft.forward_normalized(
                &mut runtime,
                &actual_log,
                &hann,
                actual_reduction.mean_f32,
                actual_reduction.denominator_f32,
                &mut actual_spectrum,
            );

            require_spectrum_bits(
                &actual_spectrum,
                &expected_spectrum,
                &format!("case={case} composed normalized forward"),
            );
            assert_eq!(
                actual_log
                    .iter()
                    .map(|value| value.to_bits())
                    .collect::<Vec<_>>(),
                actual_log_bits,
                "case={case} fused forward rewrote parallel crop/log output"
            );
        }

        drop(activity);
        assert!(runtime.shutdown().clean());
    }

    #[cfg(feature = "composite-preprocess-forward-60x36")]
    #[test]
    fn composite_crop_reduction_row_forward_is_exact_and_uses_two_epochs() {
        const EPSILON: f64 = 1.0e-5;
        let log_lut: [f32; 256] = std::array::from_fn(|pixel| (pixel as f32 + 1.0).ln());
        let mut runtime = FourCoreRuntime::test_parallel_unconfigured();
        let activity = runtime.begin_activity();

        for case in 0..16u64 {
            let frame_width = WIDTH + 2 + (case as usize % 9);
            let frame_height = HEIGHT + 2 + (case as usize % 7);
            let stride = frame_width * 3 + 1 + (case as usize * 17 % 31);
            let mut state = 0x0640_c0de_d15c_a11eu64 ^ case.wrapping_mul(0x9e37_79b9);
            let mut frame_data = vec![0xa5; stride * frame_height + 23];
            for byte in &mut frame_data {
                state = splitmix64(state);
                *byte = (state >> 56) as u8;
            }
            let frame = TailBgrFrame::new(&frame_data, frame_width, frame_height, stride).unwrap();
            let maximum_x = frame_width - WIDTH - 1;
            let maximum_y = frame_height - HEIGHT - 1;
            let origin_x = if case % 2 == 0 { 0 } else { maximum_x };
            let origin_y = if case % 4 < 2 { 0 } else { maximum_y };

            let expected_dirty = f32::from_bits(0x7fc6_0000 | (case as u32 + 1));
            let actual_dirty = f32::from_bits(0xffc6_0000 | (case as u32 + 1));
            let mut expected_log = vec![expected_dirty; SPATIAL_LEN];
            let mut actual_log = vec![actual_dirty; SPATIAL_LEN];
            {
                let mut tasks =
                    bind_crop_log_rows(frame, origin_x, origin_y, &log_lut, &mut expected_log)
                        .unwrap();
                for task in &mut tasks {
                    task.run();
                }
            }
            let expected_reduction = reduce_log_values_row_major(&expected_log, EPSILON).unwrap();
            let mut hann = deterministic_hann(0x0640_9000_beef_0000 ^ case.rotate_left(23));
            hann[0] = 0.0;
            hann[SPATIAL_LEN - 1] = -0.0;
            let mut expected_normalized = expected_log.clone();
            for (value, &window) in expected_normalized.iter_mut().zip(&hann) {
                *value = ((*value - expected_reduction.mean_f32)
                    / expected_reduction.denominator_f32)
                    * window;
            }
            let mut expected_fft = WholeLayoutFft2::new();
            let mut expected_spectrum = PaddedSpectrum::default();
            expected_fft.forward(&expected_normalized, &mut expected_spectrum);

            let actual_log_ptr = actual_log.as_mut_ptr();
            let actual_log_len = actual_log.len();
            let mut actual_fft = ParallelWholeLayoutFft2::new();
            actual_fft.poison_scratch(0xa640_e000 ^ case as u32);
            let mut actual_spectrum = PaddedSpectrum::default();
            actual_spectrum.poison_all(0xa640_d000 ^ case as u32);
            let epoch_before = runtime.test_dispatch_epoch();
            {
                let mut crop_tasks = unsafe {
                    // SAFETY: `actual_log` stays live and exclusive for this
                    // complete composite dispatch.
                    bind_raw_crop_log_rows(
                        frame,
                        origin_x,
                        origin_y,
                        &log_lut,
                        actual_log_ptr,
                        actual_log_len,
                    )
                    .unwrap()
                };
                // SAFETY: the raw tasks and pointer address the same complete
                // live exclusive allocation, and all inputs outlive the call.
                unsafe {
                    actual_fft.forward_normalized_after_crop(
                        &mut runtime,
                        &mut crop_tasks,
                        actual_log_ptr,
                        &hann,
                        EPSILON,
                        &mut actual_spectrum,
                    );
                }
            }
            assert_eq!(
                runtime.test_dispatch_epoch() - epoch_before,
                2,
                "case={case} must use one composite row epoch and one column epoch"
            );

            require_spatial_bits(
                &actual_log,
                &expected_log,
                &format!("case={case} composite raw logs"),
            );
            require_spectrum_bits(
                &actual_spectrum,
                &expected_spectrum,
                &format!("case={case} composite normalized forward"),
            );
            assert!(actual_spectrum.padding_is_positive_zero());
        }

        drop(activity);
        assert!(runtime.shutdown().clean());
    }

    #[cfg(feature = "composite-preprocess-forward-60x36")]
    #[test]
    fn composite_crop_panic_aborts_phase_waiters_and_tears_down_cleanly() {
        const EPSILON: f64 = 1.0e-5;
        let width = WIDTH + 4;
        let height = HEIGHT + 4;
        let stride = width * 3 + 5;
        let frame_data = vec![0x5a; stride * height + 11];
        let frame = TailBgrFrame::new(&frame_data, width, height, stride).unwrap();
        let log_lut: [f32; 256] = std::array::from_fn(|pixel| (pixel as f32 + 1.0).ln());
        let hann = deterministic_hann(0x0640_f00d_dead_beef);
        let mut log_values = vec![f32::from_bits(0x7fc6_4321); SPATIAL_LEN];
        let log_values_ptr = log_values.as_mut_ptr();
        let log_values_len = log_values.len();
        // SAFETY: `log_values` remains live and exclusively owned through the
        // composite call. The binder partitions it into disjoint lane ranges.
        let mut crop_tasks = unsafe {
            bind_raw_crop_log_rows(frame, 1, 1, &log_lut, log_values_ptr, log_values_len).unwrap()
        };
        let mut runtime = FourCoreRuntime::test_parallel_unconfigured();
        let activity = runtime.begin_activity();
        let mut fft = ParallelWholeLayoutFft2::new();
        let mut spectrum = PaddedSpectrum::default();

        let panic = catch_unwind(AssertUnwindSafe(|| {
            // SAFETY: this uses the same valid pointer/task relationship as
            // production; only lane one's crop body is deliberately replaced
            // with a panic to exercise the abort publication.
            unsafe {
                fft.forward_normalized_after_crop_with_injected_panic(
                    &mut runtime,
                    &mut crop_tasks,
                    log_values_ptr,
                    &hann,
                    EPSILON,
                    &mut spectrum,
                    1,
                );
            }
        }));
        assert!(panic.is_err());

        drop(activity);
        assert!(runtime.shutdown().clean());
    }

    #[cfg(feature = "wake-crop-pipeline-60x36")]
    #[test]
    fn publish_before_wake_crop_reduction_forward_flow_is_bit_exact() {
        const EPSILON: f64 = 1.0e-5;
        let log_lut: [f32; 256] = std::array::from_fn(|pixel| (pixel as f32 + 1.0).ln());
        let mut runtime = FourCoreRuntime::test_parallel_unconfigured();

        for case in 0..16u64 {
            let frame_width = WIDTH + 2 + (case as usize % 11);
            let frame_height = HEIGHT + 2 + (case as usize % 7);
            let stride = frame_width * 3 + 1 + (case as usize * 13 % 29);
            let mut state = 0x0580_c20f_d15c_a11eu64 ^ case.wrapping_mul(0x9e37_79b9);
            let mut frame_data = vec![0xa5; stride * frame_height + 31];
            for byte in &mut frame_data {
                state = splitmix64(state);
                *byte = (state >> 56) as u8;
            }
            let frame = TailBgrFrame::new(&frame_data, frame_width, frame_height, stride).unwrap();
            let maximum_x = frame_width - WIDTH - 1;
            let maximum_y = frame_height - HEIGHT - 1;
            let origin_x = if case % 2 == 0 { 0 } else { maximum_x };
            let origin_y = if case % 4 < 2 { 0 } else { maximum_y };

            let expected_dirty = f32::from_bits(0x7fc5_0000 | (case as u32 + 1));
            let actual_dirty = f32::from_bits(0xffc8_0000 | (case as u32 + 1));
            let mut expected_log = vec![expected_dirty; SPATIAL_LEN];
            let mut actual_log = vec![actual_dirty; SPATIAL_LEN];
            {
                let mut tasks =
                    bind_crop_log_rows(frame, origin_x, origin_y, &log_lut, &mut expected_log)
                        .unwrap();
                for task in &mut tasks {
                    task.run();
                }
            }
            let activity = {
                let mut tasks =
                    bind_worker_crop_log_rows(frame, origin_x, origin_y, &log_lut, &mut actual_log)
                        .unwrap();
                runtime.begin_activity_with_worker_job(&mut tasks, |_, task| task.run())
            };
            require_spatial_bits(
                &actual_log,
                &expected_log,
                &format!("case={case} publish-before-wake crop"),
            );

            let expected_reduction = reduce_log_values_row_major(&expected_log, EPSILON).unwrap();
            let actual_reduction = reduce_log_values_row_major(&actual_log, EPSILON).unwrap();
            assert!(
                actual_reduction.bit_identical(expected_reduction),
                "case={case} reduction actual={actual_reduction:?} \
                 expected={expected_reduction:?}"
            );

            let mut hann = deterministic_hann(0x0580_9000_beef_0000 ^ case.rotate_left(27));
            hann[0] = 0.0;
            hann[SPATIAL_LEN - 1] = -0.0;
            let mut expected_normalized = expected_log;
            for (value, &window) in expected_normalized.iter_mut().zip(&hann) {
                *value = ((*value - expected_reduction.mean_f32)
                    / expected_reduction.denominator_f32)
                    * window;
            }

            let mut expected_fft = WholeLayoutFft2::new();
            let mut expected_spectrum = PaddedSpectrum::default();
            expected_fft.forward(&expected_normalized, &mut expected_spectrum);
            let actual_log_bits: Vec<_> = actual_log.iter().map(|value| value.to_bits()).collect();
            let mut actual_fft = ParallelWholeLayoutFft2::new();
            actual_fft.poison_scratch(0xa580_e000 ^ case as u32);
            let mut actual_spectrum = PaddedSpectrum::default();
            actual_spectrum.poison_all(0xa580_d000 ^ case as u32);
            actual_fft.forward_normalized(
                &mut runtime,
                &actual_log,
                &hann,
                actual_reduction.mean_f32,
                actual_reduction.denominator_f32,
                &mut actual_spectrum,
            );

            require_spectrum_bits(
                &actual_spectrum,
                &expected_spectrum,
                &format!("case={case} publish-before-wake normalized forward"),
            );
            assert_eq!(
                actual_log
                    .iter()
                    .map(|value| value.to_bits())
                    .collect::<Vec<_>>(),
                actual_log_bits,
                "case={case} fused forward rewrote worker crop output"
            );
            drop(activity);
        }

        assert!(runtime.shutdown().clean());
    }

    #[test]
    fn unreduced_inverse_matches_serial_and_leaves_output_unscaled() {
        let input = deterministic_input(0x0431_0000_feed_beef, 0.75);
        let mut serial = WholeLayoutFft2::new();
        let mut serial_spectrum = PaddedSpectrum::default();
        serial.forward(&input, &mut serial_spectrum);
        let mut parallel_spectrum = serial_spectrum.clone();

        let mut serial_output = vec![f32::NAN; SPATIAL_LEN];
        serial.inverse(&mut serial_spectrum, &mut serial_output);
        let mut runtime = FourCoreRuntime::from_requested_cores(1);
        let mut parallel = ParallelWholeLayoutFft2::new();
        let mut parallel_output = vec![f32::NAN; SPATIAL_LEN];
        parallel.inverse(&mut runtime, &mut parallel_spectrum, &mut parallel_output);

        require_spectrum_bits(
            &parallel_spectrum,
            &serial_spectrum,
            "unreduced inverse spectrum",
        );
        require_spatial_bits(&parallel_output, &serial_output, "unreduced inverse output");
    }

    #[cfg(feature = "parallel-correlated-inverse-60x36")]
    #[test]
    fn randomized_fused_correlation_inverse_matches_standalone_bits_and_reduction() {
        let mut runtime = FourCoreRuntime::test_parallel_unconfigured();
        let activity = runtime.begin_activity();

        for case in 0..16u64 {
            let mut sample =
                deterministic_spectrum(0x44c1_0000_0000_0000 ^ case, 0.25 + case as f32);
            let mut filter = deterministic_spectrum(
                0x44f1_0000_0000_0000 ^ case.wrapping_mul(0x9e37_79b9),
                1.0 / (case as f32 + 1.0),
            );
            inject_correlation_edge_bits(&mut sample, &mut filter, case as u32);

            let mut standalone_response = PaddedSpectrum::default();
            standalone_response.poison_all(0x5100_0000 ^ case as u32);
            {
                let mut tasks =
                    bind_correlation_batches(&sample, &filter, &mut standalone_response);
                for task in &mut tasks {
                    task.run();
                }
            }
            assert!(standalone_response.padding_is_positive_zero());

            let mut fused_response = PaddedSpectrum::default();
            fused_response.poison_all(0xa200_0000 ^ case as u32);
            let mut standalone_output =
                vec![f32::from_bits(0x7fc0_1100 | case as u32); SPATIAL_LEN];
            let mut fused_output = vec![f32::from_bits(0xffc0_2200 | case as u32); SPATIAL_LEN];
            let mut standalone = ParallelWholeLayoutFft2::new();
            let mut fused = ParallelWholeLayoutFft2::new();
            standalone.poison_scratch(0x3100_0000 ^ case as u32);
            fused.poison_scratch(0xc400_0000 ^ case as u32);

            let expected_reduction = standalone.inverse_reduced(
                &mut runtime,
                &mut standalone_response,
                &mut standalone_output,
            );
            let actual_reduction = fused.correlated_inverse_reduced(
                &mut runtime,
                &sample,
                &filter,
                &mut fused_response,
                &mut fused_output,
            );

            require_spectrum_bits(
                &fused_response,
                &standalone_response,
                &format!("case={case} fused mutated response"),
            );
            require_spatial_bits(
                &fused_output,
                &standalone_output,
                &format!("case={case} fused inverse output"),
            );
            assert!(
                actual_reduction.bit_identical(expected_reduction),
                "case={case} fused reduction actual={actual_reduction:?} \
                expected={expected_reduction:?}"
            );
        }

        drop(activity);
        assert!(runtime.shutdown().clean());
    }

    #[cfg(feature = "parallel-correlated-inverse-60x36")]
    #[test]
    fn fused_correlation_inverse_is_independent_of_response_and_scratch_poison() {
        let mut runtime = FourCoreRuntime::from_requested_cores(1);
        let mut sample = deterministic_spectrum(0x44c2_7a11_dead_beef, 13.0);
        let mut filter = deterministic_spectrum(0x44f2_0dd5_cafe_babe, 0.03125);
        inject_correlation_edge_bits(&mut sample, &mut filter, 0x7788);

        let mut clean_response = PaddedSpectrum::default();
        let mut dirty_response = PaddedSpectrum::default();
        dirty_response.poison_all(0xdeaf_4402);
        let mut clean_output = vec![0.0; SPATIAL_LEN];
        let mut dirty_output = vec![f32::from_bits(0x7fc0_4402); SPATIAL_LEN];
        let mut clean = ParallelWholeLayoutFft2::new();
        let mut dirty = ParallelWholeLayoutFft2::new();
        clean.poison_scratch(0x0000_4402);
        dirty.poison_scratch(0xffff_4402);

        let clean_reduction = clean.correlated_inverse_reduced(
            &mut runtime,
            &sample,
            &filter,
            &mut clean_response,
            &mut clean_output,
        );
        let dirty_reduction = dirty.correlated_inverse_reduced(
            &mut runtime,
            &sample,
            &filter,
            &mut dirty_response,
            &mut dirty_output,
        );

        require_spectrum_bits(
            &dirty_response,
            &clean_response,
            "poisoned fused mutated response",
        );
        require_spatial_bits(&dirty_output, &clean_output, "poisoned fused output");
        assert!(dirty_reduction.bit_identical(clean_reduction));
    }

    #[cfg(feature = "fused-correlated-inverse-cfft36-60x36")]
    #[test]
    fn deep_cfft_correlation_inverse_matches_scalar_oracle_on_real_four_lanes() {
        let mut runtime = FourCoreRuntime::test_parallel_unconfigured();
        let activity = runtime.begin_activity();

        for case in 0..8u64 {
            let mut sample =
                deterministic_spectrum(0x5900_c011_0000_0000 ^ case, 0.125 + case as f32);
            let mut filter = deterministic_spectrum(
                0x5900_f117_0000_0000 ^ case.wrapping_mul(0x9e37_79b9),
                1.0 / (case as f32 + 1.0),
            );
            inject_correlation_edge_bits(&mut sample, &mut filter, 0x5900 ^ case as u32);

            // Materialize the retained exact correlation with scalar source,
            // repair the invalid padded lane, then use the serial whole-layout
            // inverse as the independent integration oracle.
            let mut expected_response = scalar_correlated_response(&sample, &filter);
            assert!(expected_response.padding_is_positive_zero());
            let mut expected_output = vec![f32::from_bits(0x7fc0_5900 | case as u32); SPATIAL_LEN];
            let mut oracle = WholeLayoutFft2::new();
            oracle.inverse(&mut expected_response, &mut expected_output);
            let expected_reduction = reduce_scaled(&expected_output, 1.0 / ROUND_TRIP_SCALE);

            for poison in [0x0590_0000 ^ case as u32, 0xf590_ffff ^ case as u32] {
                let mut actual_response = PaddedSpectrum::default();
                actual_response.poison_all(poison.rotate_left(7));
                let mut actual_output =
                    vec![f32::from_bits(0xffc0_5900 | case as u32); SPATIAL_LEN];
                let mut actual = ParallelWholeLayoutFft2::new();
                actual.poison_scratch(poison);

                let actual_reduction = actual.correlated_inverse_reduced(
                    &mut runtime,
                    &sample,
                    &filter,
                    &mut actual_response,
                    &mut actual_output,
                );

                require_spectrum_bits(
                    &actual_response,
                    &expected_response,
                    &format!("case={case} poison={poison:#010x} deep inverse columns"),
                );
                require_spatial_bits(
                    &actual_output,
                    &expected_output,
                    &format!("case={case} poison={poison:#010x} deep inverse output"),
                );
                assert!(
                    actual_reduction.bit_identical(expected_reduction),
                    "case={case} poison={poison:#010x} deep reduction \
                     actual={actual_reduction:?} expected={expected_reduction:?}"
                );
            }
        }

        drop(activity);
        assert!(runtime.shutdown().clean());
    }

    #[cfg(feature = "pipelined-inverse-reduction-60x36")]
    #[test]
    fn pipelined_inverse_reduction_matches_materialized_row_major_oracle() {
        let mut runtime = FourCoreRuntime::test_parallel_unconfigured();
        let activity = runtime.begin_activity();
        let mut actual = ParallelWholeLayoutFft2::new();
        actual.poison_scratch(0x0610_5eed);

        for case in 0..8u64 {
            let mut sample =
                deterministic_spectrum(0x6100_c011_0000_0000 ^ case, 0.0625 + case as f32);
            let mut filter = deterministic_spectrum(
                0x6100_f117_0000_0000 ^ case.wrapping_mul(0x9e37_79b9),
                1.0 / (case as f32 + 0.5),
            );
            inject_correlation_edge_bits(&mut sample, &mut filter, 0x6100 ^ case as u32);

            let mut expected_response = scalar_correlated_response(&sample, &filter);
            let mut expected_output = vec![f32::from_bits(0x7fc0_6100 | case as u32); SPATIAL_LEN];
            let mut oracle = WholeLayoutFft2::new();
            oracle.inverse(&mut expected_response, &mut expected_output);
            let expected_reduction = reduce_scaled(&expected_output, 1.0 / ROUND_TRIP_SCALE);

            for poison in [0x0610_0000 ^ case as u32, 0xf610_ffff ^ case as u32] {
                let mut actual_response = PaddedSpectrum::default();
                actual_response.poison_all(poison.rotate_left(11));

                let actual_reduction = actual.correlated_inverse_reduced_pipelined(
                    &mut runtime,
                    &sample,
                    &filter,
                    &mut actual_response,
                );

                require_spectrum_bits(
                    &actual_response,
                    &expected_response,
                    &format!("case={case} poison={poison:#010x} pipelined inverse columns"),
                );
                assert!(
                    actual_reduction.bit_identical(expected_reduction),
                    "case={case} poison={poison:#010x} pipelined reduction \
                     actual={actual_reduction:?} expected={expected_reduction:?}"
                );
            }
        }

        drop(activity);
        assert!(runtime.shutdown().clean());
    }

    #[cfg(feature = "pipelined-inverse-reduction-60x36")]
    #[test]
    fn pipelined_inverse_reduction_preserves_single_thread_exactness() {
        let mut sample = deterministic_spectrum(0x6110_c011_dead_beef, 3.25);
        let mut filter = deterministic_spectrum(0x6110_f117_cafe_babe, 0.03125);
        inject_correlation_edge_bits(&mut sample, &mut filter, 0x6110);

        let mut expected_response = scalar_correlated_response(&sample, &filter);
        let mut expected_output = vec![f32::NAN; SPATIAL_LEN];
        let mut oracle = WholeLayoutFft2::new();
        oracle.inverse(&mut expected_response, &mut expected_output);
        let expected_reduction = reduce_scaled(&expected_output, 1.0 / ROUND_TRIP_SCALE);

        let mut actual_response = PaddedSpectrum::default();
        actual_response.poison_all(0xa611_5eed);
        let mut actual = ParallelWholeLayoutFft2::new();
        actual.poison_scratch(0x5611_0bad);
        let mut runtime = FourCoreRuntime::from_requested_cores(1);
        let actual_reduction = actual.correlated_inverse_reduced_pipelined(
            &mut runtime,
            &sample,
            &filter,
            &mut actual_response,
        );

        require_spectrum_bits(
            &actual_response,
            &expected_response,
            "single-thread pipelined inverse columns",
        );
        assert!(actual_reduction.bit_identical(expected_reduction));
        assert!(runtime.shutdown().clean());
    }

    fn fixtures() -> Vec<Vec<f32>> {
        let zero = vec![0.0; SPATIAL_LEN];

        let mut impulse = vec![0.0; SPATIAL_LEN];
        impulse[17 * WIDTH + 23] = -0.75;
        impulse[(HEIGHT - 1) * WIDTH + (WIDTH - 1)] = 0.5;

        vec![
            zero,
            impulse,
            deterministic_input(0x0430_0000_0000_0001, 0.001),
            deterministic_input(0x0430_0000_0000_0002, 0.75),
            deterministic_input(0x0430_0000_0000_0003, 1_000.0),
        ]
    }

    fn deterministic_input(mut state: u64, scale: f32) -> Vec<f32> {
        let mut output = vec![0.0; SPATIAL_LEN];
        for (index, value) in output.iter_mut().enumerate() {
            state = splitmix64(state ^ index as u64);
            let fraction = ((state >> 40) as u32) as f32 * (1.0 / 16_777_216.0);
            let random = fraction * 2.0 - 1.0;
            let x = (index % WIDTH) as f32;
            let y = (index / WIDTH) as f32;
            *value = (random * 0.7 + (x * 0.13).sin() * 0.2 + (y * 0.19).cos() * 0.1) * scale;
        }
        output
    }

    #[cfg(feature = "fused-normalize-forward-60x36")]
    fn deterministic_hann(mut state: u64) -> Vec<f32> {
        let mut output = vec![0.0; SPATIAL_LEN];
        for (index, value) in output.iter_mut().enumerate() {
            state = splitmix64(state ^ (index as u64).wrapping_mul(0x9e37_79b9));
            *value = ((state >> 40) as u32) as f32 * (1.0 / 16_777_216.0);
        }
        output
    }

    #[cfg(feature = "fused-normalize-forward-60x36")]
    fn inject_normalize_edge_bits(log_values: &mut [f32], hann: &mut [f32], scale: f32) {
        for (index, bits) in [
            0x0000_0000,
            0x8000_0000,
            0x0000_0001,
            0x8000_0001,
            0x0080_0000,
            0x8080_0000,
        ]
        .into_iter()
        .enumerate()
        {
            log_values[index * 137] = f32::from_bits(bits);
        }
        log_values[SPATIAL_LEN - 1] = scale;
        log_values[SPATIAL_LEN - WIDTH] = -scale;

        hann[0] = 0.0;
        hann[137] = -0.0;
        hann[274] = f32::from_bits(0x0000_0001);
        hann[411] = f32::from_bits(0x8000_0001);
        hann[SPATIAL_LEN - 1] = 1.0;
    }

    #[cfg(any(
        feature = "parallel-correlated-inverse-60x36",
        feature = "fused-correlated-inverse-cfft36-60x36"
    ))]
    fn deterministic_spectrum(mut state: u64, scale: f32) -> PaddedSpectrum {
        let mut output = PaddedSpectrum::default();
        for batch in 0..COLUMN_BATCHES {
            for ky in 0..HEIGHT {
                for lane in 0..LANES {
                    state = splitmix64(
                        state
                            ^ ((batch * HEIGHT * LANES + ky * LANES + lane) as u64)
                                .wrapping_mul(0x9e37_79b9),
                    );
                    let re_fraction = ((state >> 40) as u32) as f32 * (1.0 / 16_777_216.0);
                    state = splitmix64(state);
                    let im_fraction = ((state >> 40) as u32) as f32 * (1.0 / 16_777_216.0);
                    output.batches[batch].re[ky][lane] = (re_fraction * 2.0 - 1.0) * scale;
                    output.batches[batch].im[ky][lane] = (im_fraction * 2.0 - 1.0) * scale;
                }
            }
        }
        output
    }

    #[cfg(any(
        feature = "parallel-correlated-inverse-60x36",
        feature = "fused-correlated-inverse-cfft36-60x36"
    ))]
    fn inject_correlation_edge_bits(
        sample: &mut PaddedSpectrum,
        filter: &mut PaddedSpectrum,
        salt: u32,
    ) {
        for &(kx, ky, sample_re, sample_im, filter_re, filter_im) in &[
            (0, 0, 0.0, -0.0, -0.0, 0.0),
            (3, 7, -0.0, 0.0, 0.0, -0.0),
            (17, 23, 1.0, -0.0, -0.0, -1.0),
            (30, 35, -0.0, -1.0, 1.0, 0.0),
        ] {
            let batch = kx / LANES;
            let lane = kx % LANES;
            sample.batches[batch].re[ky][lane] = sample_re;
            sample.batches[batch].im[ky][lane] = sample_im;
            filter.batches[batch].re[ky][lane] = filter_re;
            filter.batches[batch].im[ky][lane] = filter_im;
        }

        let last = COLUMN_BATCHES - 1;
        let padding = LANES - 1;
        for ky in 0..HEIGHT {
            sample.batches[last].re[ky][padding] = if ky % 2 == 0 {
                -0.0
            } else {
                f32::from_bits(0x7fc0_0000 | ((salt ^ ky as u32) & 0x003f_ffff) | 1)
            };
            sample.batches[last].im[ky][padding] =
                f32::from_bits(0xffc0_0000 | ((salt.wrapping_add(ky as u32)) & 0x003f_ffff) | 1);
            filter.batches[last].re[ky][padding] = f32::INFINITY;
            filter.batches[last].im[ky][padding] = -0.0;
        }
    }

    #[cfg(feature = "fused-correlated-inverse-cfft36-60x36")]
    fn scalar_correlated_response(
        sample: &PaddedSpectrum,
        filter: &PaddedSpectrum,
    ) -> PaddedSpectrum {
        let mut response = PaddedSpectrum::default();
        for batch in 0..COLUMN_BATCHES {
            for ky in 0..HEIGHT {
                for lane in 0..LANES {
                    // Match the retained Experiment 044 scalar/non-FMA
                    // operation order exactly, including conjugation by an
                    // explicit sign change before either product.
                    let sample_re = sample.batches[batch].re[ky][lane];
                    let sample_im = sample.batches[batch].im[ky][lane];
                    let filter_re = filter.batches[batch].re[ky][lane];
                    let filter_im = -filter.batches[batch].im[ky][lane];
                    let re_left = sample_re * filter_re;
                    let re_right = sample_im * filter_im;
                    let im_left = sample_re * filter_im;
                    let im_right = sample_im * filter_re;
                    response.batches[batch].re[ky][lane] = re_left - re_right;
                    response.batches[batch].im[ky][lane] = im_left + im_right;
                }
            }
        }

        let last = COLUMN_BATCHES - 1;
        let padding = LANES - 1;
        for ky in 0..HEIGHT {
            response.batches[last].re[ky][padding] = 0.0;
            response.batches[last].im[ky][padding] = 0.0;
        }
        response
    }

    fn splitmix64(mut value: u64) -> u64 {
        value = value.wrapping_add(0x9e37_79b9_7f4a_7c15);
        value = (value ^ (value >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
        value = (value ^ (value >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
        value ^ (value >> 31)
    }

    fn require_spectrum_bits(actual: &PaddedSpectrum, expected: &PaddedSpectrum, context: &str) {
        for batch in 0..COLUMN_BATCHES {
            for ky in 0..HEIGHT {
                for lane in 0..LANES {
                    for (component, left, right) in [
                        (
                            "re",
                            actual.batches[batch].re[ky][lane],
                            expected.batches[batch].re[ky][lane],
                        ),
                        (
                            "im",
                            actual.batches[batch].im[ky][lane],
                            expected.batches[batch].im[ky][lane],
                        ),
                    ] {
                        assert_eq!(
                            left.to_bits(),
                            right.to_bits(),
                            "{context}: batch={batch} ky={ky} lane={lane} \
                             component={component} actual={left:?} expected={right:?}"
                        );
                    }
                }
            }
        }
    }

    fn require_spatial_bits(actual: &[f32], expected: &[f32], context: &str) {
        assert_eq!(actual.len(), expected.len());
        for (index, (&left, &right)) in actual.iter().zip(expected).enumerate() {
            assert_eq!(
                left.to_bits(),
                right.to_bits(),
                "{context}: index={index} actual={left:?} expected={right:?}"
            );
        }
    }
}
