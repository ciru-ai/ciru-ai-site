Place the Linux AArch64 preview libmosse_core.so in this directory before
building the AArch64 wheel. The loader requires the exact filename
libmosse_core.so.
