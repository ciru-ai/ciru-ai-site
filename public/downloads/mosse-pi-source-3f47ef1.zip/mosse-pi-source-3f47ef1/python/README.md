# mosse-pi Python preview

This is the early pure-Python NumPy wrapper for the native exact MOSSE
tracker. The Python API is stable across later optimized
`libmosse_core.so` replacements:

```python
from mosse_pi import MosseTracker

tracker = MosseTracker(initial_frame, (x, y, width, height), mode="auto")
success, (x, y, width, height) = tracker.update(next_frame)
tracker.close()
```

This package remains preview-versioned while its API is exercised externally.
The bundled AArch64 native library is the same production build that passed
the final exact five-pair Pi qualification at a median 11,632.121609
tracker-only FPS (5.014305x the frozen 2,319.787518-FPS baseline). Multicore
is exposed honestly when the watchdog-safe implementation activates; it is
not simulated in Python and there is no single-thread-only substitute hidden
behind the API.

## Install and native library

Requirements:

- Linux x86_64 with glibc 2.28 or newer, or Linux AArch64 with glibc 2.34
  or newer;
- Python 3.9 or newer;
- NumPy 1.24 or newer (including NumPy 2.x);
- a `libmosse_core.so` with the additive mode/backend C ABI documented below.

The NumPy API example needs no additional package. The video/camera and
wrapper-latency examples also need OpenCV (`python3-opencv` from the OS, or
`python3 -m pip install opencv-python`).

From this directory:

```bash
python3 -m pip install --force-reinstall ./mosse_pi-*.whl
```

The loader checks:

```text
mosse_pi/native/linux-x86_64/libmosse_core.so
mosse_pi/native/linux-aarch64/libmosse_core.so
```

inside the installed package. During development, select an external build
without copying it:

```bash
export MOSSE_CORE_LIBRARY=/absolute/path/to/libmosse_core.so
```

The loaded path, architecture, package version, and SHA-256 are available as
`tracker.native_library_info`. If the library has a sibling
`build_info.json`, the same object also reports its source commit, Cargo
features, Rust compiler, and glibc identity. Missing or malformed optional
metadata never prevents loading an otherwise valid library. A missing
library, unsupported architecture, load failure, or missing preview ABI
produces a specific exception.

The preview ABI expected by this wrapper is:

```c
uint32_t mosse_abi_version(void); /* must return 1 */
mosse_status mosse_create_with_mode(
    const mosse_config* config, int32_t mode, mosse_handle** output);
mosse_status mosse_get_backend_status(
    const mosse_handle* handle, int32_t* output);
```

Modes are `AUTO=0`, `SINGLE=1`, and `MULTICORE=2`. Backends are
`UNINITIALIZED=0`, `GENERIC_SINGLE=1`, `FIXED_SINGLE=2`, and
`FIXED_MULTICORE=3`. Existing `mosse_init`, `mosse_update`, and
`mosse_destroy` signatures are unchanged.

## Modes and fallback

- `mode="auto"` asks the library for its fastest validated safe mode.
  `tracker.selected_mode` and `tracker.backend` disclose the result. A
  capability failure may select a real single-thread fallback.
- `mode="multicore"` requires `FIXED_MULTICORE`; initialization raises
  `MulticoreUnavailableError` and cleans up if native startup falls back.
- `mode="single"` forces the exact single-thread implementation.

The qualified Pi/AArch64 production backend is specialized for an internally
rounded FFT window of exactly `60x36` and uses the fixed four-CPU
continuous-normal-spin layout. Other window sizes make `auto` select the
exact single-thread backend; explicit `multicore` raises
`MulticoreUnavailableError`. For the qualified window, launch the complete
process with CPU0-only affinity **before** OpenCV/FFmpeg creates decoder
threads:

```bash
taskset --cpu-list 0 python3 examples/video_capture.py input.mp4 \
  --roi 100 80 60 36 --mode auto
```

Decoder and application threads inherit CPU 0. During tracker initialization,
the three Rust workers must successfully expand and pin themselves to CPUs
1–3. The caller and all workers stay at `SCHED_OTHER`, real-time priority 0,
and nice value 0. This policy needs no root access, `CAP_SYS_NICE`, FIFO
scheduling, or RT-runtime change, and the wrapper never mutates global
scheduler settings.

The workers continuously poll on CPUs 1–3 for the complete live-handle
lifetime. Run an external, normally scheduled process watchdog and close the
tracker deterministically. `auto` safely reports a single-thread fallback
when native capability or startup checks fail; explicit `multicore` raises
`MulticoreUnavailableError` instead of silently accepting that fallback. Use
`mode="single"` when the CPU-isolated production topology cannot be provided.

## Frames, copying, GIL, and threads

Frames must be `numpy.ndarray`, `uint8`, `HxWx3`, interleaved BGR arrays such
as frames returned by `cv2.VideoCapture.read()`.

- C-contiguous frames are passed zero-copy.
- Positive row-stride views are also zero-copy when channels/pixels remain
  interleaved and the complete ABI byte span belongs to the backing
  allocation.
- Negative, transposed, channel-reversed, or otherwise unsupported layouts
  are copied safely to C-contiguous storage.
- Wrong dtype or shape is rejected rather than silently converted.

`ctypes.CDLL` releases the Python GIL during native init/update/destroy calls.
The ndarray and its complete backing allocation must therefore stay live and
must not be mutated, resized, or freed by another thread for the entire native
init/update call.
Each handle also owns a `threading.Lock`. The native four-core runtime is
caller-thread-bound, so initialization, every update, and live-handle cleanup
must occur on the constructing native thread. Cross-thread use raises
`TrackerThreadError`; use the context manager or explicit `close()` for
deterministic cleanup:

```python
with MosseTracker(frame, roi, mode="auto") as tracker:
    success, box = tracker.update(frame)
```

`close()` is idempotent. A finalizer will clean up only when it runs on the
creator thread; it will never destroy a caller-thread-bound live handle from
the wrong thread.

## OpenCV example

Run:

```bash
python3 examples/video_capture.py input.mp4 --roi 100 80 60 36 --mode auto
python3 examples/video_capture.py 0 --roi 100 80 60 36 --mode auto
python3 examples/video_capture.py input.mp4 --roi 100 80 60 36 \
  --mode auto --no-display --max-frames 10
```

The example reads normal `cv2.VideoCapture` arrays, initializes the ROI,
updates, and draws the returned box. Press `q` to exit. The bounded headless
form is suitable for package smoke tests. On Pi, prefix the complete command
with `taskset --cpu-list 0` to establish the qualified production topology
before `VideoCapture` starts.

For a minimal copy-paste example using only generated NumPy frames:

```bash
python3 examples/numpy_api.py --mode auto
```

## Build/reproduction and wheels

After the additive ABI is present, build the library on its target host so
the existing architecture-selected Rust paths are retained. The AArch64
preview uses Rust 1.97.1, a fresh target directory, one release codegen unit,
LTO disabled, no inherited Rust/Cargo target or release-profile overrides,
and the exact qualified normal-spin feature composition. The x86_64
compatibility artifact uses the ordinary Rust release profile in a pinned
manylinux build environment. `build_preview.sh` stages exactly one
architecture, embeds its build identity, produces the wheel and raw shared
library, and writes SHA-256 manifests without modifying the source package:

```bash
MOSSE_PREVIEW_SOURCE_COMMIT="$(git rev-parse HEAD)" ./build_preview.sh
```

AArch64/Pi preview:

```bash
RUST_197_BIN="${RUST_197_BIN:-$HOME/.rustup/toolchains/1.97.1-aarch64-unknown-linux-gnu/bin}"
test -x "$RUST_197_BIN/rustc"
MOSSE_CARGO_TARGET="$(mktemp -d)"
env -u RUSTFLAGS -u CARGO_ENCODED_RUSTFLAGS \
  -u RUSTC -u RUSTC_WRAPPER -u RUSTC_WORKSPACE_WRAPPER \
  -u CARGO_BUILD_TARGET -u CARGO_TARGET_DIR \
  -u CARGO_TARGET_AARCH64_UNKNOWN_LINUX_GNU_RUSTFLAGS \
  -u CARGO_TARGET_AARCH64_UNKNOWN_LINUX_GNU_LINKER \
  -u CARGO_PROFILE_RELEASE_OPT_LEVEL -u CARGO_PROFILE_RELEASE_DEBUG \
  -u CARGO_PROFILE_RELEASE_SPLIT_DEBUGINFO -u CARGO_PROFILE_RELEASE_STRIP \
  -u CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS \
  -u CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS -u CARGO_PROFILE_RELEASE_LTO \
  -u CARGO_PROFILE_RELEASE_PANIC -u CARGO_PROFILE_RELEASE_INCREMENTAL \
  -u CARGO_PROFILE_RELEASE_CODEGEN_UNITS -u CARGO_PROFILE_RELEASE_RPATH \
  PATH="$RUST_197_BIN:$PATH" CARGO_TARGET_DIR="$MOSSE_CARGO_TARGET" \
  CARGO_PROFILE_RELEASE_CODEGEN_UNITS=1 \
  CARGO_PROFILE_RELEASE_LTO=false \
  cargo build --manifest-path ../rust/Cargo.toml --release --locked \
  --lib --no-default-features \
  --features shared-activity-futex-wake,normal-spin-four-core-runtime,fused-correlated-inverse-cfft36-60x36,composite-preprocess-forward-60x36,parallel-model-blend-filter-60x36
install -Dm755 "$MOSSE_CARGO_TARGET/release/libmosse_core.so" \
  src/mosse_pi/native/linux-aarch64/libmosse_core.so
# Put generated source_commit/features/rustc/glibc metadata beside the .so.
sha256sum src/mosse_pi/native/linux-aarch64/libmosse_core.so
```

Linux x86_64 preview:

```bash
MOSSE_CARGO_TARGET="$(mktemp -d)"
env -u RUSTFLAGS -u CARGO_ENCODED_RUSTFLAGS \
  -u RUSTC -u RUSTC_WRAPPER -u RUSTC_WORKSPACE_WRAPPER \
  -u CARGO_BUILD_TARGET -u CARGO_TARGET_DIR \
  -u CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_RUSTFLAGS \
  -u CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER \
  -u CARGO_PROFILE_RELEASE_OPT_LEVEL -u CARGO_PROFILE_RELEASE_DEBUG \
  -u CARGO_PROFILE_RELEASE_SPLIT_DEBUGINFO -u CARGO_PROFILE_RELEASE_STRIP \
  -u CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS \
  -u CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS -u CARGO_PROFILE_RELEASE_LTO \
  -u CARGO_PROFILE_RELEASE_PANIC -u CARGO_PROFILE_RELEASE_INCREMENTAL \
  -u CARGO_PROFILE_RELEASE_CODEGEN_UNITS -u CARGO_PROFILE_RELEASE_RPATH \
  CARGO_TARGET_DIR="$MOSSE_CARGO_TARGET" \
  cargo build --manifest-path ../rust/Cargo.toml --release --locked \
  --lib --no-default-features
install -Dm755 "$MOSSE_CARGO_TARGET/release/libmosse_core.so" \
  src/mosse_pi/native/linux-x86_64/libmosse_core.so
# Put generated source_commit/features/rustc/glibc metadata beside the .so.
sha256sum src/mosse_pi/native/linux-x86_64/libmosse_core.so
```

Build a platform-tagged wheel on each target host. The published x86_64
preview is repaired and inspected with `auditwheel` in its pinned manylinux
container; a Nix-host library with absolute store RUNPATHs is not
distributed:

```bash
python3 -m pip install build
python3 -m build --wheel
sha256sum dist/*.whl
```

Do not put incompatible `.so` files into one wheel and relabel it. Build/test
the x86_64 and AArch64 wheels on their corresponding Linux architecture (or a
verified architecture-specific build environment).

## Source-checkout tests and latency boundary

```bash
# Run these commands from the full source checkout, not the binary bundle.
python3 -m pip install -e '.[test]'
python3 -m pytest -q
```

The fake-ABI suite exercises modes, fallback, frame layouts, copying,
lifecycle, and threading without pretending a native artifact exists. The
real-native smoke test skips clearly when no library is installed.

The established headline benchmark times the **native tracker-only update
boundary**. Python measurements must be labeled separately:

- `native tracker-only`: the existing Rust/C benchmark;
- `Python wrapper call`: `perf_counter_ns()` immediately around
  `tracker.update(frame)`, including validation, ctypes, and any required
  copy;
- `Python end-to-end`: decode plus wrapper call plus application work.

Never substitute Python-call or decode timing for the native scoring boundary.
Use `examples/measure_wrapper_latency.py` to report the wrapper-call metric
separately.
