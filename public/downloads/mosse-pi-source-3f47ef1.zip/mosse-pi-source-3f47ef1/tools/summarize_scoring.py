#!/usr/bin/env python3
"""Summarize measured runs from a Pi 4 scoring manifest."""

from __future__ import annotations

import argparse
import json
import math
import re
import statistics
import sys
from pathlib import Path
from typing import Any, Iterable, Sequence


TRACKER_ORDER = {"opencv": 0, "rust": 1}
SUMMARY_TRACKER_NAMES = {
    "opencv": {"opencv", "opencv_legacy_mosse"},
    "rust": {"rust", "rust_mosse_scalar"},
}
THROTTLED_PATTERN = re.compile(r"throttled=(0x[0-9a-f]+|[0-9]+)", re.IGNORECASE)
TEMPERATURE_PATTERN = re.compile(
    r"temp=([+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+))",
    re.IGNORECASE,
)


class SummaryError(ValueError):
    """Raised when the manifest itself cannot be summarized."""


def _is_number(value: Any) -> bool:
    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(value)
    )


def _is_non_negative_integer(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value >= 0


def _median(values: Sequence[float]) -> float | None:
    return float(statistics.median(values)) if values else None


def _mean(values: Sequence[float]) -> float | None:
    return math.fsum(values) / len(values) if values else None


def _range(values: Sequence[float | int]) -> dict[str, Any]:
    return {
        "sample_count": len(values),
        "min": min(values) if values else None,
        "max": max(values) if values else None,
        "stable": len(set(values)) == 1 if values else None,
    }


def _resolve_artifact(manifest_path: Path, path_text: str) -> Path:
    path = Path(path_text)
    if not path.is_absolute():
        path = manifest_path.parent / path
    return path.resolve()


def _read_json(path: Path) -> Any:
    with path.open(encoding="utf-8") as stream:
        return json.load(stream)


def _load_artifact(
    manifest_path: Path,
    path_text: Any,
    description: str,
    warnings: list[str],
) -> Any | None:
    if not isinstance(path_text, str) or not path_text:
        warnings.append(f"{description}: artifact path is missing")
        return None
    path = _resolve_artifact(manifest_path, path_text)
    try:
        return _read_json(path)
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        warnings.append(
            f"{description}: cannot read {path}: {type(error).__name__}: {error}"
        )
        return None


def _runtime_state(
    manifest_path: Path,
    run: dict[str, Any],
    key: str,
    description: str,
    warnings: list[str],
) -> dict[str, Any] | None:
    embedded = run.get(key)
    if isinstance(embedded, dict) and "artifact_error" not in embedded:
        return embedded

    artifacts = run.get("artifacts")
    if not isinstance(artifacts, dict):
        return None
    loaded = _load_artifact(
        manifest_path, artifacts.get(key), description, warnings
    )
    return loaded if isinstance(loaded, dict) else None


def _temperatures(state: dict[str, Any]) -> list[float]:
    values: list[float] = []
    zones = state.get("thermal_zones")
    if isinstance(zones, list):
        for zone in zones:
            if not isinstance(zone, dict):
                continue
            celsius = zone.get("celsius")
            if _is_number(celsius):
                values.append(float(celsius))
                continue
            millidegrees = zone.get("millidegrees_celsius")
            if _is_number(millidegrees):
                values.append(float(millidegrees) / 1000.0)

    command = state.get("vcgencmd_measure_temp")
    if isinstance(command, dict) and isinstance(command.get("output"), str):
        match = TEMPERATURE_PATTERN.search(command["output"])
        if match:
            value = float(match.group(1))
            if math.isfinite(value):
                values.append(value)
    return values


def _throttle_mask(state: dict[str, Any]) -> int | None:
    command = state.get("vcgencmd_get_throttled")
    if not isinstance(command, dict):
        return None
    if command.get("available") is False or command.get("exit_code") not in (
        0,
        None,
    ):
        return None
    output = command.get("output")
    if not isinstance(output, str):
        return None
    match = THROTTLED_PATTERN.search(output)
    if not match:
        return None
    text = match.group(1)
    return int(text, 16 if text.lower().startswith("0x") else 10)


def _new_group() -> dict[str, Any]:
    return {
        "manifest_run_count": 0,
        "failed_run_count": 0,
        "invalid_run_count": 0,
        "invalid_summary_count": 0,
        "summaries": [],
        "runs": [],
        "tracker_fps": [],
        "latency_median_ns": [],
        "latency_p95_ns": [],
        "attempted_updates": [],
        "successful_updates": [],
        "failed_updates": [],
        "success_fractions": [],
        "temperatures": [],
        "throttle_masks": [],
        "throttle_unknown_samples": 0,
    }


def _run_label(run: dict[str, Any], fallback: int) -> str:
    sequence = run.get("sequence", fallback)
    return f"measured run {sequence}"


def _add_summary_metrics(
    group: dict[str, Any],
    run: dict[str, Any],
    summary: dict[str, Any],
    label: str,
    warnings: list[str],
) -> None:
    group["summaries"].append(summary)

    fps = summary.get("tracker_only_fps")
    normalized_fps: float | None = None
    if _is_number(fps) and fps > 0:
        normalized_fps = float(fps)
        group["tracker_fps"].append(normalized_fps)
    else:
        warnings.append(f"{label}: invalid tracker_only_fps")

    latency = summary.get("latency_ns")
    normalized_latency: dict[str, float | None] = {}
    if not isinstance(latency, dict):
        warnings.append(f"{label}: latency_ns is missing or invalid")
    else:
        for field in ("min", "mean", "median", "p95", "p99", "max"):
            value = latency.get(field)
            normalized_latency[field] = (
                float(value)
                if _is_number(value) and value >= 0
                else None
            )
        median_latency = latency.get("median")
        if _is_number(median_latency) and median_latency >= 0:
            group["latency_median_ns"].append(float(median_latency))
        else:
            warnings.append(f"{label}: invalid latency_ns.median")
        p95_latency = latency.get("p95")
        if _is_number(p95_latency) and p95_latency >= 0:
            group["latency_p95_ns"].append(float(p95_latency))
        else:
            warnings.append(f"{label}: invalid latency_ns.p95")

    count_fields = (
        ("attempted_updates", group["attempted_updates"]),
        ("successful_updates", group["successful_updates"]),
        ("failed_updates", group["failed_updates"]),
    )
    counts: dict[str, int] = {}
    for field, destination in count_fields:
        value = summary.get(field)
        if _is_non_negative_integer(value):
            destination.append(value)
            counts[field] = value
        else:
            warnings.append(f"{label}: invalid {field}")

    if {
        "attempted_updates",
        "successful_updates",
        "failed_updates",
    }.issubset(counts):
        attempted = counts["attempted_updates"]
        successful = counts["successful_updates"]
        failed = counts["failed_updates"]
        if successful + failed != attempted:
            warnings.append(
                f"{label}: successful_updates + failed_updates does not equal "
                "attempted_updates"
            )
        if attempted > 0:
            group["success_fractions"].append(successful / attempted)

    group["runs"].append(
        {
            "sequence": run.get("sequence"),
            "pair_index": run.get("pair_index"),
            "global_pair_index": run.get("global_pair_index"),
            "order_in_pair": run.get("order_in_pair"),
            "tracker_thread_count": run.get("tracker_thread_count"),
            "tracker_only_fps": normalized_fps,
            "latency_ns": normalized_latency,
            "attempted_updates": summary.get("attempted_updates"),
            "successful_updates": summary.get("successful_updates"),
            "failed_updates": summary.get("failed_updates"),
            "decoded_frames": summary.get("decoded_frames"),
            "frame_sequence_checksum": summary.get(
                "frame_sequence_checksum"
            ),
        }
    )


def _aggregate_group(group: dict[str, Any]) -> dict[str, Any]:
    success_range = _range(group["successful_updates"])
    failure_range = _range(group["failed_updates"])
    attempted_range = _range(group["attempted_updates"])
    stable_values = (
        success_range["stable"],
        failure_range["stable"],
        attempted_range["stable"],
    )
    run_count = len(group["summaries"])
    count_samples_complete = all(
        result["sample_count"] == run_count
        for result in (success_range, failure_range, attempted_range)
    )
    summary_metrics_complete = all(
        len(group[field]) == run_count
        for field in (
            "tracker_fps",
            "latency_median_ns",
            "latency_p95_ns",
            "attempted_updates",
            "successful_updates",
            "failed_updates",
        )
    )

    masks = group["throttle_masks"]
    unique_masks = sorted(set(masks))
    return {
        "run_count": run_count,
        "manifest_run_count": group["manifest_run_count"],
        "failed_run_count": group["failed_run_count"],
        "invalid_run_count": group["invalid_run_count"],
        "invalid_summary_count": group["invalid_summary_count"],
        "summary_metrics_complete": summary_metrics_complete,
        "runs": sorted(
            group["runs"],
            key=lambda run: (
                run.get("pair_index")
                if _is_non_negative_integer(run.get("pair_index"))
                else sys.maxsize,
                run.get("sequence")
                if _is_non_negative_integer(run.get("sequence"))
                else sys.maxsize,
            ),
        ),
        "tracker_fps": {
            "sample_count": len(group["tracker_fps"]),
            "mean": _mean(group["tracker_fps"]),
            "median": _median(group["tracker_fps"]),
        },
        "latency_ns": {
            "aggregation": "median across per-run summary values",
            "median": _median(group["latency_median_ns"]),
            "median_sample_count": len(group["latency_median_ns"]),
            "p95": _median(group["latency_p95_ns"]),
            "p95_sample_count": len(group["latency_p95_ns"]),
        },
        "update_stability": {
            "stable": (
                all(value is True for value in stable_values)
                if count_samples_complete
                and all(value is not None for value in stable_values)
                else None
            ),
            "attempted_updates": attempted_range,
            "successful_updates": success_range,
            "failed_updates": failure_range,
            "success_fraction": _range(group["success_fractions"]),
        },
        "temperature_celsius": _range(group["temperatures"]),
        "throttling": {
            "observed": any(mask != 0 for mask in masks) if masks else None,
            "sample_count": len(masks),
            "nonzero_sample_count": sum(mask != 0 for mask in masks),
            "unknown_sample_count": group["throttle_unknown_samples"],
            "masks": [f"0x{mask:x}" for mask in unique_masks],
        },
    }


def _ratio(numerator: Any, denominator: Any) -> float | None:
    if (
        _is_number(numerator)
        and _is_number(denominator)
        and denominator > 0
    ):
        return float(numerator) / float(denominator)
    return None


def _tracker_sort_key(name: str) -> tuple[int, str]:
    return (TRACKER_ORDER.get(name, len(TRACKER_ORDER)), name)


def _is_positive_integer(value: Any) -> bool:
    return _is_non_negative_integer(value) and value > 0


def _configuration_label(
    configuration: tuple[int, int], manifest_schema: int
) -> str:
    opencv_threads, rust_cores = configuration
    if manifest_schema == 1:
        return f"threads={opencv_threads}"
    return (
        f"opencv_threads={opencv_threads} rust_cores={rust_cores}"
    )


def _planned_configurations(
    manifest_schema: int,
    parameters: Any,
    warnings: list[str],
) -> tuple[int | None, list[tuple[int, int]]]:
    if not isinstance(parameters, dict):
        warnings.append("manifest parameters is missing or invalid")
        return None, []

    if manifest_schema == 1:
        pair_field = "measured_pairs_per_thread_count"
        thread_field = "thread_counts"
    else:
        pair_field = "measured_pairs_per_configuration"
        thread_field = "rust_core_counts"

    expected_pairs: int | None = None
    candidate_pairs = parameters.get(pair_field)
    if _is_positive_integer(candidate_pairs):
        expected_pairs = candidate_pairs
    else:
        warnings.append(f"parameters.{pair_field} is missing or invalid")

    if manifest_schema == 1:
        candidate_threads = parameters.get(thread_field)
        planned = (
            [(value, value) for value in candidate_threads]
            if isinstance(candidate_threads, list)
            else []
        )
        planned = [
            configuration
            for configuration in planned
            if _is_positive_integer(configuration[0])
        ]
        planned = list(dict.fromkeys(planned))
        if not planned:
            warnings.append("parameters.thread_counts is missing or invalid")
        return expected_pairs, planned

    planned: list[tuple[int, int]] = []
    pairings = parameters.get("core_pairings")
    if isinstance(pairings, list):
        for index, pairing in enumerate(pairings, start=1):
            if not isinstance(pairing, dict):
                warnings.append(
                    f"parameters.core_pairings[{index}] is invalid"
                )
                continue
            opencv_threads = pairing.get("opencv_threads")
            rust_cores = pairing.get("rust_cores")
            if not (
                _is_positive_integer(opencv_threads)
                and _is_positive_integer(rust_cores)
            ):
                warnings.append(
                    f"parameters.core_pairings[{index}] is invalid"
                )
                continue
            planned.append((opencv_threads, rust_cores))

    if not planned:
        opencv_threads = parameters.get("opencv_thread_count")
        rust_core_counts = parameters.get(thread_field)
        if _is_positive_integer(opencv_threads) and isinstance(
            rust_core_counts, list
        ):
            planned = [
                (opencv_threads, value)
                for value in rust_core_counts
                if _is_positive_integer(value)
            ]

    unique_planned = list(dict.fromkeys(planned))
    if len(unique_planned) != len(planned):
        warnings.append("parameters contain duplicate core configurations")
    if not unique_planned:
        warnings.append(
            "parameters.core_pairings/rust_core_counts is missing or invalid"
        )
    return expected_pairs, unique_planned


def _run_configuration(
    run: dict[str, Any],
    manifest_schema: int,
) -> tuple[int, int] | None:
    if manifest_schema == 1:
        thread_count = run.get("thread_count")
        if _is_positive_integer(thread_count):
            return (thread_count, thread_count)
        return None

    opencv_threads = run.get("opencv_thread_count")
    rust_cores = run.get("rust_thread_count")
    if (
        _is_positive_integer(opencv_threads)
        and _is_positive_integer(rust_cores)
    ):
        return (opencv_threads, rust_cores)
    return None


def _parity_configuration(
    parity: dict[str, Any],
    manifest_schema: int,
) -> tuple[int, int] | None:
    if manifest_schema == 1:
        thread_count = parity.get("thread_count")
        if _is_positive_integer(thread_count):
            return (thread_count, thread_count)
        return None

    opencv_threads = parity.get("opencv_thread_count")
    rust_cores = parity.get("rust_thread_count")
    if (
        _is_positive_integer(opencv_threads)
        and _is_positive_integer(rust_cores)
    ):
        return (opencv_threads, rust_cores)
    return None


def _same_artifact(
    manifest_path: Path, left: Any, right: Any
) -> bool:
    return (
        isinstance(left, str)
        and bool(left)
        and isinstance(right, str)
        and bool(right)
        and _resolve_artifact(manifest_path, left)
        == _resolve_artifact(manifest_path, right)
    )


def _comparison_exactness(comparison: dict[str, Any]) -> dict[str, Any]:
    frame_identity = comparison.get("frame_identity")
    success = comparison.get("success")
    center = comparison.get("center_distance_pixels")
    overlap = comparison.get("iou")
    size_delta = comparison.get("absolute_size_delta_pixels")
    gates = comparison.get("gates")
    frame_identity = frame_identity if isinstance(frame_identity, dict) else {}
    success = success if isinstance(success, dict) else {}
    center = center if isinstance(center, dict) else {}
    overlap = overlap if isinstance(overlap, dict) else {}
    size_delta = size_delta if isinstance(size_delta, dict) else {}
    gates = gates if isinstance(gates, dict) else {}

    exact_fields = (
        frame_identity.get("checksums_match"),
        success.get("mismatch_count"),
        center.get("max"),
        overlap.get("min"),
        size_delta.get("max_width"),
        size_delta.get("max_height"),
    )
    exact: bool | None
    if (
        isinstance(exact_fields[0], bool)
        and _is_non_negative_integer(exact_fields[1])
        and _is_number(exact_fields[2])
        and _is_number(exact_fields[3])
        and _is_number(exact_fields[4])
        and _is_number(exact_fields[5])
    ):
        exact = (
            exact_fields[0]
            and exact_fields[1] == 0
            and exact_fields[2] == 0
            and exact_fields[3] == 1
            and exact_fields[4] == 0
            and exact_fields[5] == 0
        )
    else:
        exact = None

    return {
        "frame_identity": dict(frame_identity),
        "success": dict(success),
        "mutually_successful_frames": comparison.get(
            "mutually_successful_frames"
        ),
        "center_distance_pixels": dict(center),
        "iou": dict(overlap),
        "absolute_size_delta_pixels": dict(size_delta),
        "gates": dict(gates),
        "exact": exact,
    }


def _aggregate_exactness(
    parity_records: list[dict[str, Any]],
    expected_pairs: int | None,
    required: bool,
) -> dict[str, Any]:
    valid_records = [
        record for record in parity_records if record.get("comparison_valid")
    ]
    exact_values = [record.get("exact") for record in valid_records]
    checksum_values = [
        record.get("frame_identity", {}).get("checksums_match")
        for record in valid_records
    ]
    mismatch_values = [
        record.get("success", {}).get("mismatch_count")
        for record in valid_records
    ]
    center_max_values = [
        record.get("center_distance_pixels", {}).get("max")
        for record in valid_records
    ]
    iou_min_values = [
        record.get("iou", {}).get("min") for record in valid_records
    ]
    width_max_values = [
        record.get("absolute_size_delta_pixels", {}).get("max_width")
        for record in valid_records
    ]
    height_max_values = [
        record.get("absolute_size_delta_pixels", {}).get("max_height")
        for record in valid_records
    ]

    complete = (
        len(parity_records) == expected_pairs
        and len(valid_records) == expected_pairs
        if required and expected_pairs is not None
        else None
    )
    all_exact: bool | None
    if not valid_records or any(value is None for value in exact_values):
        all_exact = None
    else:
        all_exact = all(value is True for value in exact_values)

    return {
        "available": bool(parity_records),
        "required": required,
        "complete": complete,
        "comparison_count": len(parity_records),
        "valid_comparison_count": len(valid_records),
        "all_gates_pass": (
            all(record.get("all_gates_pass") is True for record in valid_records)
            if valid_records
            else None
        ),
        "all_exact": all_exact,
        "checksums_match": (
            all(value is True for value in checksum_values)
            if checksum_values
            and all(isinstance(value, bool) for value in checksum_values)
            else None
        ),
        "total_success_mismatches": (
            sum(mismatch_values)
            if mismatch_values
            and all(_is_non_negative_integer(value) for value in mismatch_values)
            else None
        ),
        "max_center_distance_pixels": (
            max(center_max_values)
            if center_max_values
            and all(_is_number(value) for value in center_max_values)
            else None
        ),
        "min_iou": (
            min(iou_min_values)
            if iou_min_values
            and all(_is_number(value) for value in iou_min_values)
            else None
        ),
        "max_width_delta_pixels": (
            max(width_max_values)
            if width_max_values
            and all(_is_number(value) for value in width_max_values)
            else None
        ),
        "max_height_delta_pixels": (
            max(height_max_values)
            if height_max_values
            and all(_is_number(value) for value in height_max_values)
            else None
        ),
        "pairs": sorted(
            parity_records,
            key=lambda record: record.get("pair_index", sys.maxsize),
        ),
    }


def summarize_manifest(manifest_path: Path) -> dict[str, Any]:
    """Return aggregate scoring data without requiring a completed suite."""

    manifest_path = manifest_path.resolve()
    try:
        manifest = _read_json(manifest_path)
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise SummaryError(
            f"cannot read manifest {manifest_path}: "
            f"{type(error).__name__}: {error}"
        ) from error
    if not isinstance(manifest, dict):
        raise SummaryError(f"{manifest_path}: manifest root must be an object")

    warnings: list[str] = []
    status = manifest.get("status")
    if status != "completed":
        warnings.append(
            f"manifest status is {status!r}; available measured runs are partial"
        )
    manifest_schema = manifest.get("schema_version")
    schema_supported = manifest_schema in (1, 2)
    if not schema_supported:
        warnings.append(
            f"unexpected manifest schema_version "
            f"{manifest_schema!r}; attempting schema 1 interpretation"
        )
        manifest_schema = 1

    runs = manifest.get("runs")
    if not isinstance(runs, list):
        warnings.append("manifest runs is missing or invalid")
        runs = []

    expected_pairs, planned_configurations = _planned_configurations(
        manifest_schema, manifest.get("parameters"), warnings
    )
    groups: dict[tuple[tuple[int, int], str], dict[str, Any]] = {}
    for configuration in planned_configurations:
        for tracker in TRACKER_ORDER:
            groups[(configuration, tracker)] = _new_group()

    pair_members: dict[
        tuple[int, int], dict[int, dict[str, list[dict[str, Any]]]]
    ] = {}
    structure_valid = schema_supported

    measured_manifest_runs = 0
    for fallback, run in enumerate(runs, start=1):
        if not isinstance(run, dict):
            warnings.append(f"run entry {fallback} is not an object")
            continue
        if run.get("phase") != "measured":
            continue
        measured_manifest_runs += 1
        label = _run_label(run, fallback)
        configuration = _run_configuration(run, manifest_schema)
        tracker = run.get("tracker")
        if (
            configuration is None
            or tracker not in TRACKER_ORDER
        ):
            warnings.append(
                f"{label}: invalid core configuration or tracker"
            )
            structure_valid = False
            continue

        group = groups.setdefault((configuration, tracker), _new_group())
        group["manifest_run_count"] += 1
        if configuration not in planned_configurations:
            warnings.append(
                f"{label}: unplanned "
                f"{_configuration_label(configuration, manifest_schema)}"
            )
            structure_valid = False

        pair_index = run.get("pair_index")
        if _is_positive_integer(pair_index):
            pair_members.setdefault(configuration, {}).setdefault(
                pair_index, {"opencv": [], "rust": []}
            )[tracker].append(run)
        else:
            warnings.append(f"{label}: invalid pair_index {pair_index!r}")
            structure_valid = False

        for state_key in ("runtime_state_pre", "runtime_state_post"):
            state = _runtime_state(
                manifest_path,
                run,
                state_key,
                f"{label} {state_key}",
                warnings,
            )
            if state is None:
                group["throttle_unknown_samples"] += 1
                continue
            group["temperatures"].extend(_temperatures(state))
            mask = _throttle_mask(state)
            if mask is None:
                group["throttle_unknown_samples"] += 1
            else:
                group["throttle_masks"].append(mask)

        expected_active_threads = (
            configuration[0] if tracker == "opencv" else configuration[1]
        )
        active_threads = (
            run.get("tracker_thread_count")
            if manifest_schema == 2
            else run.get("thread_count")
        )
        if active_threads != expected_active_threads:
            group["invalid_run_count"] += 1
            structure_valid = False
            warnings.append(
                f"{label}: tracker_thread_count {active_threads!r} does not "
                f"match expected {expected_active_threads} for {tracker}"
            )
            continue

        exit_code = run.get("exit_code")
        if exit_code != 0:
            group["failed_run_count"] += 1
            warnings.append(f"{label}: exit_code is {exit_code!r}; run excluded")
            continue

        artifacts = run.get("artifacts")
        if not isinstance(artifacts, dict):
            group["invalid_summary_count"] += 1
            warnings.append(f"{label}: artifacts is missing or invalid")
            continue
        summary = _load_artifact(
            manifest_path,
            artifacts.get("summary_json"),
            f"{label} summary",
            warnings,
        )
        if not isinstance(summary, dict):
            group["invalid_summary_count"] += 1
            if summary is not None:
                warnings.append(f"{label}: summary root must be an object")
            continue
        accepted_summary_names = SUMMARY_TRACKER_NAMES.get(tracker, {tracker})
        if summary.get("tracker") not in accepted_summary_names:
            group["invalid_summary_count"] += 1
            warnings.append(
                f"{label}: summary tracker {summary.get('tracker')!r} "
                f"does not match manifest tracker {tracker!r}"
            )
            continue
        summary_threads = summary.get("opencv_threads_requested")
        if summary_threads != configuration[0]:
            group["invalid_summary_count"] += 1
            warnings.append(
                f"{label}: summary opencv_threads_requested "
                f"{summary_threads!r} does not match "
                f"{configuration[0]}"
            )
            continue

        normalized_run = dict(run)
        normalized_run["tracker_thread_count"] = expected_active_threads
        _add_summary_metrics(
            group, normalized_run, summary, label, warnings
        )

    parity_field = manifest.get("parity_comparisons")
    parity_required = manifest_schema == 2 or isinstance(parity_field, list)
    parity_entries: list[Any]
    if isinstance(parity_field, list):
        parity_entries = parity_field
    else:
        parity_entries = []
        if parity_required:
            warnings.append("manifest parity_comparisons is missing or invalid")
            structure_valid = False

    parity_by_configuration: dict[
        tuple[int, int], dict[int, list[dict[str, Any]]]
    ] = {}
    for fallback, parity in enumerate(parity_entries, start=1):
        if not isinstance(parity, dict):
            warnings.append(f"parity comparison {fallback} is not an object")
            structure_valid = False
            continue
        configuration = _parity_configuration(parity, manifest_schema)
        pair_index = parity.get("pair_index")
        if configuration is None or not _is_positive_integer(pair_index):
            warnings.append(
                f"parity comparison {fallback}: invalid configuration or "
                "pair_index"
            )
            structure_valid = False
            continue

        label = (
            f"{_configuration_label(configuration, manifest_schema)} "
            f"pair={pair_index} parity"
        )
        comparison = _load_artifact(
            manifest_path,
            parity.get("comparison_json"),
            f"{label} comparison",
            warnings,
        )
        comparison_valid = isinstance(comparison, dict)
        if comparison is not None and not isinstance(comparison, dict):
            warnings.append(f"{label}: comparison root must be an object")

        if parity.get("exit_code") != 0:
            warnings.append(
                f"{label}: exit_code is {parity.get('exit_code')!r}"
            )
            comparison_valid = False
        if parity.get("all_gates_pass") is not True:
            warnings.append(
                f"{label}: all_gates_pass is "
                f"{parity.get('all_gates_pass')!r}"
            )
            comparison_valid = False

        exactness = (
            _comparison_exactness(comparison)
            if isinstance(comparison, dict)
            else {
                "frame_identity": {},
                "success": {},
                "mutually_successful_frames": None,
                "center_distance_pixels": {},
                "iou": {},
                "absolute_size_delta_pixels": {},
                "gates": {},
                "exact": None,
            }
        )
        gates = exactness["gates"]
        if (
            not gates
            or not all(isinstance(value, bool) for value in gates.values())
            or not all(gates.values())
        ):
            warnings.append(f"{label}: comparison gates are missing or failed")
            comparison_valid = False

        members = pair_members.get(configuration, {}).get(pair_index, {})
        for tracker, parity_field_name in (
            ("opencv", "opencv_csv"),
            ("rust", "rust_csv"),
        ):
            tracker_runs = members.get(tracker, [])
            run_csv = (
                tracker_runs[0].get("artifacts", {}).get("frames_csv")
                if len(tracker_runs) == 1
                and isinstance(tracker_runs[0].get("artifacts"), dict)
                else None
            )
            if not _same_artifact(
                manifest_path, run_csv, parity.get(parity_field_name)
            ):
                warnings.append(
                    f"{label}: {parity_field_name} does not identify the "
                    f"unique measured {tracker} run"
                )
                comparison_valid = False

        run_global_indexes = {
            candidate.get("global_pair_index")
            for tracker_runs in members.values()
            for candidate in tracker_runs
            if _is_positive_integer(candidate.get("global_pair_index"))
        }
        parity_global_index = parity.get("global_pair_index")
        if (
            run_global_indexes
            and (
                len(run_global_indexes) != 1
                or parity_global_index not in run_global_indexes
            )
        ):
            warnings.append(f"{label}: global_pair_index does not match runs")
            comparison_valid = False

        record = {
            "pair_index": pair_index,
            "global_pair_index": parity_global_index,
            "exit_code": parity.get("exit_code"),
            "all_gates_pass": parity.get("all_gates_pass"),
            "comparison_valid": comparison_valid,
            **exactness,
        }
        parity_by_configuration.setdefault(configuration, {}).setdefault(
            pair_index, []
        ).append(record)
        if not comparison_valid:
            structure_valid = False

    configuration_results: list[dict[str, Any]] = []
    all_configurations = sorted(
        {
            configuration
            for configuration, _ in groups
        }
        | set(pair_members)
        | set(parity_by_configuration)
    )
    aggregation_complete = (
        status == "completed"
        and expected_pairs is not None
        and bool(planned_configurations)
        and structure_valid
    )
    for configuration in all_configurations:
        tracker_results: dict[str, dict[str, Any]] = {}
        tracker_names = sorted(
            (
                tracker
                for candidate_configuration, tracker in groups
                if candidate_configuration == configuration
            ),
            key=_tracker_sort_key,
        )
        for tracker in tracker_names:
            aggregated = _aggregate_group(groups[(configuration, tracker)])
            tracker_results[tracker] = aggregated
            if expected_pairs is not None:
                if aggregated["manifest_run_count"] != expected_pairs:
                    warnings.append(
                        f"{_configuration_label(configuration, manifest_schema)} "
                        f"tracker={tracker}: expected "
                        f"{expected_pairs} measured runs, found "
                        f"{aggregated['manifest_run_count']}"
                    )
                    aggregation_complete = False
                if aggregated["run_count"] != expected_pairs:
                    aggregation_complete = False
            if (
                aggregated["failed_run_count"] > 0
                or aggregated["invalid_run_count"] > 0
                or aggregated["invalid_summary_count"] > 0
                or not aggregated["summary_metrics_complete"]
            ):
                aggregation_complete = False

        expected_pair_indexes = (
            set(range(1, expected_pairs + 1))
            if expected_pairs is not None
            else set()
        )
        actual_pair_indexes = set(pair_members.get(configuration, {}))
        for pair_index in sorted(expected_pair_indexes | actual_pair_indexes):
            members = pair_members.get(configuration, {}).get(
                pair_index, {"opencv": [], "rust": []}
            )
            for tracker in TRACKER_ORDER:
                count = len(members.get(tracker, []))
                if pair_index in expected_pair_indexes and count != 1:
                    warnings.append(
                        f"{_configuration_label(configuration, manifest_schema)} "
                        f"pair={pair_index}: expected one measured {tracker} "
                        f"run, found {count}"
                    )
                    aggregation_complete = False
            if pair_index not in expected_pair_indexes:
                warnings.append(
                    f"{_configuration_label(configuration, manifest_schema)} "
                    f"has unexpected measured pair_index {pair_index}"
                )
                aggregation_complete = False

        parity_records: list[dict[str, Any]] = []
        parity_pairs = parity_by_configuration.get(configuration, {})
        for pair_index in sorted(set(parity_pairs) | expected_pair_indexes):
            records = parity_pairs.get(pair_index, [])
            if parity_required and len(records) != 1:
                warnings.append(
                    f"{_configuration_label(configuration, manifest_schema)} "
                    f"pair={pair_index}: expected one parity comparison, "
                    f"found {len(records)}"
                )
                aggregation_complete = False
            parity_records.extend(records)
            if pair_index not in expected_pair_indexes:
                warnings.append(
                    f"{_configuration_label(configuration, manifest_schema)} "
                    f"has unexpected parity pair_index {pair_index}"
                )
                aggregation_complete = False

        opencv = tracker_results.get("opencv", {})
        rust = tracker_results.get("rust", {})
        opencv_fps = opencv.get("tracker_fps", {})
        rust_fps = rust.get("tracker_fps", {})
        accepted_runs: dict[str, dict[int, list[dict[str, Any]]]] = {
            "opencv": {},
            "rust": {},
        }
        for tracker, result in tracker_results.items():
            for run_result in result.get("runs", []):
                pair_index = run_result.get("pair_index")
                if _is_positive_integer(pair_index):
                    accepted_runs.setdefault(tracker, {}).setdefault(
                        pair_index, []
                    ).append(run_result)

        pair_results: list[dict[str, Any]] = []
        paired_fps_ratios: list[float] = []
        paired_latency_median_ratios: list[float] = []
        paired_latency_p95_ratios: list[float] = []
        for pair_index in sorted(
            expected_pair_indexes | actual_pair_indexes | set(parity_pairs)
        ):
            opencv_runs = accepted_runs.get("opencv", {}).get(pair_index, [])
            rust_runs = accepted_runs.get("rust", {}).get(pair_index, [])
            opencv_run = opencv_runs[0] if len(opencv_runs) == 1 else None
            rust_run = rust_runs[0] if len(rust_runs) == 1 else None
            fps_ratio = _ratio(
                rust_run.get("tracker_only_fps") if rust_run else None,
                opencv_run.get("tracker_only_fps") if opencv_run else None,
            )
            median_latency_ratio = _ratio(
                opencv_run.get("latency_ns", {}).get("median")
                if opencv_run
                else None,
                rust_run.get("latency_ns", {}).get("median")
                if rust_run
                else None,
            )
            p95_latency_ratio = _ratio(
                opencv_run.get("latency_ns", {}).get("p95")
                if opencv_run
                else None,
                rust_run.get("latency_ns", {}).get("p95")
                if rust_run
                else None,
            )
            if fps_ratio is not None:
                paired_fps_ratios.append(fps_ratio)
            if median_latency_ratio is not None:
                paired_latency_median_ratios.append(median_latency_ratio)
            if p95_latency_ratio is not None:
                paired_latency_p95_ratios.append(p95_latency_ratio)
            parity_for_pair = parity_pairs.get(pair_index, [])
            pair_results.append(
                {
                    "pair_index": pair_index,
                    "opencv": opencv_run,
                    "rust": rust_run,
                    "speedup_rust_over_opencv": {
                        "tracker_fps_ratio": fps_ratio,
                        "median_latency_ratio": median_latency_ratio,
                        "p95_latency_ratio": p95_latency_ratio,
                    },
                    "parity": (
                        parity_for_pair[0]
                        if len(parity_for_pair) == 1
                        else None
                    ),
                }
            )

        exactness = _aggregate_exactness(
            parity_records, expected_pairs, parity_required
        )
        if parity_required and exactness["complete"] is not True:
            aggregation_complete = False

        configuration_results.append(
            {
                # Kept for schema-1 consumers. In schema 2 this is the active
                # Rust core count; use the explicit fields for asymmetric runs.
                "thread_count": configuration[1],
                "opencv_thread_count": configuration[0],
                "rust_thread_count": configuration[1],
                "rust_core_count": configuration[1],
                "trackers": tracker_results,
                "pairs": pair_results,
                "speedup_rust_over_opencv": {
                    "mean_tracker_fps_ratio": _ratio(
                        rust_fps.get("mean"), opencv_fps.get("mean")
                    ),
                    "median_tracker_fps_ratio": _ratio(
                        rust_fps.get("median"), opencv_fps.get("median")
                    ),
                    "paired_tracker_fps_ratios": paired_fps_ratios,
                    "median_paired_tracker_fps_ratio": _median(
                        paired_fps_ratios
                    ),
                    "median_paired_latency_median_ratio": _median(
                        paired_latency_median_ratios
                    ),
                    "median_paired_latency_p95_ratio": _median(
                        paired_latency_p95_ratios
                    ),
                },
                "exactness": exactness,
            }
        )

    if not groups:
        aggregation_complete = False
        warnings.append("no measured run groups were found")

    return {
        "schema_version": 1,
        "source_manifest_schema_version": manifest.get("schema_version"),
        "source_manifest": str(manifest_path),
        "suite_id": manifest.get("suite_id"),
        "suite_status": status,
        "manifest_exit_code": manifest.get("exit_code"),
        "aggregation_complete": aggregation_complete,
        "latency_aggregation": (
            "median of each run's reported latency median and p95"
        ),
        "measured_manifest_run_count": measured_manifest_runs,
        "expected_pairs_per_configuration": expected_pairs,
        "warnings": warnings,
        "configurations": configuration_results,
        # Backward-compatible alias for consumers of schema-1 summaries.
        "threads": configuration_results,
    }


def _format_number(value: Any, digits: int = 3) -> str:
    if not _is_number(value):
        return "—"
    return f"{float(value):.{digits}f}"


def _format_temperature(temperature: dict[str, Any]) -> str:
    if not temperature.get("sample_count"):
        return "unknown"
    return (
        f"{_format_number(temperature.get('min'), 1)}–"
        f"{_format_number(temperature.get('max'), 1)}"
    )


def _format_stability(stability: dict[str, Any]) -> str:
    successes = stability.get("successful_updates", {})
    failures = stability.get("failed_updates", {})
    stable = stability.get("stable")
    if stable is None:
        return "unknown"
    if stable:
        return f"stable ({successes.get('min')}/{failures.get('min')})"
    return (
        f"varies (success {successes.get('min')}–{successes.get('max')}; "
        f"failure {failures.get('min')}–{failures.get('max')})"
    )


def _format_throttling(throttling: dict[str, Any]) -> str:
    observed = throttling.get("observed")
    if observed is None:
        return "unknown"
    if observed:
        nonzero = [mask for mask in throttling.get("masks", []) if mask != "0x0"]
        return f"yes ({', '.join(nonzero)})" if nonzero else "yes"
    return "no"


def _escape_cell(value: str) -> str:
    return value.replace("|", "\\|").replace("\n", " ")


def render_markdown(report: dict[str, Any]) -> str:
    """Render a compact Markdown report suitable for terminals and notes."""

    configurations = report.get("configurations", report.get("threads", []))
    asymmetric = any(
        configuration.get("opencv_thread_count")
        != configuration.get("rust_core_count")
        for configuration in configurations
    )
    lines = [
        "# MOSSE Pi 4 scoring summary",
        "",
        f"- Suite: `{report.get('suite_id')}`",
        f"- Manifest status: `{report.get('suite_status')}`",
        f"- Aggregate complete: `{str(report.get('aggregation_complete')).lower()}`",
        "",
    ]
    warnings = report.get("warnings")
    if isinstance(warnings, list) and warnings:
        lines.append("## Warnings")
        lines.append("")
        lines.extend(f"- {_escape_cell(str(warning))}" for warning in warnings)
        lines.append("")

    lines.extend(
        [
            "## Results",
            "",
            (
                "| OpenCV threads | Rust cores | Tracker | Runs | Mean FPS | "
                "Median FPS | Median latency (µs) | Median p95 (µs) | "
                "Success/failure stability | Temperature (°C) | Throttling |"
                if asymmetric
                else "| Threads | Tracker | Runs | Mean FPS | Median FPS | "
                "Median latency (µs) | Median p95 (µs) | "
                "Success/failure stability | Temperature (°C) | Throttling |"
            ),
            (
                "|---:|---:|:---|---:|---:|---:|---:|---:|:---|:---|:---|"
                if asymmetric
                else "|---:|:---|---:|---:|---:|---:|---:|:---|:---|:---|"
            ),
        ]
    )
    for configuration in configurations:
        for tracker, result in configuration.get("trackers", {}).items():
            fps = result.get("tracker_fps", {})
            latency = result.get("latency_ns", {})
            median_us = (
                latency["median"] / 1000.0
                if _is_number(latency.get("median"))
                else None
            )
            p95_us = (
                latency["p95"] / 1000.0
                if _is_number(latency.get("p95"))
                else None
            )
            prefix = (
                str(configuration.get("opencv_thread_count")),
                str(configuration.get("rust_core_count")),
            ) if asymmetric else (str(configuration.get("thread_count")),)
            cells = prefix + (
                tracker,
                str(result.get("run_count")),
                _format_number(fps.get("mean")),
                _format_number(fps.get("median")),
                _format_number(median_us),
                _format_number(p95_us),
                _format_stability(result.get("update_stability", {})),
                _format_temperature(result.get("temperature_celsius", {})),
                _format_throttling(result.get("throttling", {})),
            )
            lines.append("| " + " | ".join(map(_escape_cell, cells)) + " |")

    lines.extend(
        [
            "",
            "## Rust/OpenCV speedup",
            "",
            (
                "| OpenCV threads | Rust cores | Mean FPS ratio | "
                "Median FPS ratio | Median paired FPS ratio |"
                if asymmetric
                else "| Threads | Mean FPS ratio | Median FPS ratio | "
                "Median paired FPS ratio |"
            ),
            (
                "|---:|---:|---:|---:|---:|"
                if asymmetric
                else "|---:|---:|---:|---:|"
            ),
        ]
    )
    for configuration in configurations:
        speedup = configuration.get("speedup_rust_over_opencv", {})
        prefix = (
            str(configuration.get("opencv_thread_count")),
            str(configuration.get("rust_core_count")),
        ) if asymmetric else (str(configuration.get("thread_count")),)
        lines.append(
            "| "
            + " | ".join(
                prefix
                + (
                    _format_number(speedup.get("mean_tracker_fps_ratio")),
                    _format_number(speedup.get("median_tracker_fps_ratio")),
                    _format_number(
                        speedup.get("median_paired_tracker_fps_ratio")
                    ),
                )
            )
            + " |"
        )

    lines.extend(
        [
            "",
            "## Per-pair measured runs",
            "",
            "| OpenCV threads | Rust cores | Pair | OpenCV FPS | "
            "OpenCV median (µs) | OpenCV p95 (µs) | Rust FPS | "
            "Rust median (µs) | Rust p95 (µs) | FPS speedup | Exact |",
            "|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---|",
        ]
    )
    for configuration in configurations:
        for pair in configuration.get("pairs", []):
            opencv = pair.get("opencv") or {}
            rust = pair.get("rust") or {}
            opencv_latency = opencv.get("latency_ns", {})
            rust_latency = rust.get("latency_ns", {})
            parity = pair.get("parity")
            exact = parity.get("exact") if isinstance(parity, dict) else None
            exact_text = (
                "yes" if exact is True else "no" if exact is False else "unknown"
            )
            cells = (
                str(configuration.get("opencv_thread_count")),
                str(configuration.get("rust_core_count")),
                str(pair.get("pair_index")),
                _format_number(opencv.get("tracker_only_fps")),
                _format_number(
                    _ratio(opencv_latency.get("median"), 1000.0)
                ),
                _format_number(_ratio(opencv_latency.get("p95"), 1000.0)),
                _format_number(rust.get("tracker_only_fps")),
                _format_number(_ratio(rust_latency.get("median"), 1000.0)),
                _format_number(_ratio(rust_latency.get("p95"), 1000.0)),
                _format_number(
                    pair.get("speedup_rust_over_opencv", {}).get(
                        "tracker_fps_ratio"
                    )
                ),
                exact_text,
            )
            lines.append("| " + " | ".join(cells) + " |")

    if any(
        configuration.get("exactness", {}).get("available")
        or configuration.get("exactness", {}).get("required")
        for configuration in configurations
    ):
        lines.extend(
            [
                "",
                "## Exactness",
                "",
                "| OpenCV threads | Rust cores | Comparisons | Complete | "
                "Checksums | Success mismatches | Max center delta (px) | "
                "Min IoU | Max size delta W/H (px) | All exact |",
                "|---:|---:|---:|:---|:---|---:|---:|---:|:---|:---|",
            ]
        )
        for configuration in configurations:
            exactness = configuration.get("exactness", {})
            lines.append(
                "| "
                + " | ".join(
                    (
                        str(configuration.get("opencv_thread_count")),
                        str(configuration.get("rust_core_count")),
                        str(exactness.get("comparison_count")),
                        str(exactness.get("complete")).lower(),
                        str(exactness.get("checksums_match")).lower(),
                        str(exactness.get("total_success_mismatches")),
                        _format_number(
                            exactness.get("max_center_distance_pixels"), 6
                        ),
                        _format_number(exactness.get("min_iou"), 6),
                        (
                            f"{_format_number(exactness.get('max_width_delta_pixels'), 6)}/"
                            f"{_format_number(exactness.get('max_height_delta_pixels'), 6)}"
                        ),
                        str(exactness.get("all_exact")).lower(),
                    )
                )
                + " |"
            )
    return "\n".join(lines) + "\n"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Aggregate measured OpenCV/Rust runs from a Pi 4 scoring manifest. "
            "Incomplete suites produce partial output with warnings."
        )
    )
    parser.add_argument("manifest", type=Path, help="path to manifest.json")
    parser.add_argument(
        "--format",
        choices=("markdown", "json"),
        default="markdown",
        help="stdout format (default: markdown)",
    )
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        report = summarize_manifest(args.manifest)
    except SummaryError as error:
        print(f"error: {error}", file=sys.stderr)
        return 2

    if args.format == "json":
        json.dump(report, sys.stdout, indent=2, sort_keys=True, allow_nan=False)
        sys.stdout.write("\n")
    else:
        sys.stdout.write(render_markdown(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
