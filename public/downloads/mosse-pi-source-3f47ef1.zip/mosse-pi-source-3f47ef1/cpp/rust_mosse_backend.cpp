#include "mosse/tracker_backend.hpp"

#include "mosse/rust_ffi.h"

#include <cmath>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <stdexcept>
#include <string>
#include <type_traits>

namespace mosse {
namespace {

static_assert(std::is_standard_layout_v<MosseRect>);
static_assert(sizeof(MosseRect) == 32U);
static_assert(offsetof(MosseRect, width) == 16U);
static_assert(sizeof(MosseConfig) == 40U);
static_assert(offsetof(MosseConfig, random_seed) == 24U);
static_assert(offsetof(MosseConfig, training_warps) == 32U);
static_assert(sizeof(MosseDiagnostics) == 80U);
static_assert(offsetof(MosseDiagnostics, updates) == 8U);
static_assert(offsetof(MosseDiagnostics, center_x) == 32U);
static_assert(offsetof(MosseDiagnostics, response_stddev) == 72U);

std::string status_name(const MosseStatus status) {
  switch (status) {
  case MOSSE_STATUS_OK:
    return "ok";
  case MOSSE_STATUS_NULL_POINTER:
    return "null pointer";
  case MOSSE_STATUS_INVALID_CONFIG:
    return "invalid configuration";
  case MOSSE_STATUS_INVALID_FRAME:
    return "invalid frame";
  case MOSSE_STATUS_INVALID_BOUNDING_BOX:
    return "invalid bounding box";
  case MOSSE_STATUS_WINDOW_TOO_LARGE:
    return "tracker window too large";
  case MOSSE_STATUS_NOT_INITIALIZED:
    return "tracker not initialized";
  case MOSSE_STATUS_PANIC:
    return "Rust panic contained at FFI boundary";
  default:
    return "unknown status " + std::to_string(status);
  }
}

void require_ok(const MosseStatus status, const char *operation) {
  if (status != MOSSE_STATUS_OK) {
    throw std::runtime_error(std::string("Rust MOSSE ") + operation +
                             " failed: " + status_name(status));
  }
}

void validate_bgr_frame(const cv::Mat &frame) {
  if (frame.empty() || frame.dims != 2 || frame.type() != CV_8UC3 ||
      frame.cols <= 0 || frame.rows <= 0) {
    throw std::runtime_error(
        "Rust MOSSE requires a non-empty two-dimensional CV_8UC3 frame");
  }
}

bool valid_bbox(const cv::Rect2d &bbox) {
  return std::isfinite(bbox.x) && std::isfinite(bbox.y) &&
         std::isfinite(bbox.width) && std::isfinite(bbox.height) &&
         bbox.width > 0.0 && bbox.height > 0.0;
}

MosseRect to_ffi_rect(const cv::Rect2d &bbox) {
  return {bbox.x, bbox.y, bbox.width, bbox.height};
}

cv::Rect2d from_ffi_rect(const MosseRect &bbox) {
  return {bbox.x, bbox.y, bbox.width, bbox.height};
}

struct RustHandleDeleter {
  void operator()(MosseHandle *handle) const noexcept {
    if (handle != nullptr) {
      static_cast<void>(mosse_destroy(handle));
    }
  }
};

class RustMosseBackend final : public TrackerBackend {
public:
  RustMosseBackend() {
    MosseConfig config{};
    require_ok(mosse_default_config(&config), "default configuration");

    MosseHandle *raw_handle = nullptr;
    const MosseStatus status = mosse_create(&config, &raw_handle);
    if (status != MOSSE_STATUS_OK) {
      if (raw_handle != nullptr) {
        static_cast<void>(mosse_destroy(raw_handle));
      }
      require_ok(status, "creation");
    }
    if (raw_handle == nullptr) {
      throw std::runtime_error(
          "Rust MOSSE creation returned success with a null handle");
    }
    handle_.reset(raw_handle);
  }

  [[nodiscard]] std::string name() const override {
    return "rust_mosse_scalar";
  }

  bool initialize(const cv::Mat &first_frame,
                  const cv::Rect2d &initial_roi) override {
    if (initialized_) {
      throw std::runtime_error("Rust MOSSE backend is already initialized");
    }
    validate_bgr_frame(first_frame);
    if (!valid_bbox(initial_roi)) {
      throw std::runtime_error(
          "Cannot initialize Rust MOSSE with an invalid ROI");
    }

    require_ok(mosse_init(handle_.get(), first_frame.data,
                          static_cast<std::size_t>(first_frame.cols),
                          static_cast<std::size_t>(first_frame.rows),
                          first_frame.step[0], to_ffi_rect(initial_roi)),
               "initialization");
    bbox_ = initial_roi;
    initialized_ = true;
    return true;
  }

  TrackerUpdate update(const cv::Mat &frame) override {
    if (!initialized_) {
      throw std::runtime_error(
          "Rust MOSSE update called before initialization");
    }
    validate_bgr_frame(frame);

    MosseRect output_bbox = to_ffi_rect(bbox_);
    std::uint8_t output_success = 0;
    require_ok(mosse_update(handle_.get(), frame.data,
                            static_cast<std::size_t>(frame.cols),
                            static_cast<std::size_t>(frame.rows), frame.step[0],
                            &output_bbox, &output_success),
               "update");

    if (output_success > 1U) {
      throw std::runtime_error(
          "Rust MOSSE returned a non-boolean success value");
    }

    const cv::Rect2d candidate = from_ffi_rect(output_bbox);
    if (output_success != 0U) {
      if (!valid_bbox(candidate)) {
        throw std::runtime_error(
            "Rust MOSSE returned success with an invalid bounding box");
      }
      bbox_ = candidate;
    }
    return {output_success != 0U, bbox_};
  }

private:
  std::unique_ptr<MosseHandle, RustHandleDeleter> handle_;
  cv::Rect2d bbox_;
  bool initialized_{false};
};

} // namespace

std::unique_ptr<TrackerBackend> create_rust_mosse_backend() {
  return std::make_unique<RustMosseBackend>();
}

} // namespace mosse
