use std::{error::Error, fmt};

use rustfft::num_complex::Complex32;

#[cfg(feature = "phase-profile")]
mod phase_profile {
    use std::{
        cell::Cell,
        sync::{
            atomic::{AtomicU64, Ordering},
            OnceLock,
        },
        time::Instant,
    };

    #[allow(dead_code)]
    #[derive(Clone, Copy)]
    pub(super) enum Phase {
        ActivityBegin,
        LocalizationPreprocess,
        LocalizationForward,
        Correlation,
        InverseFft,
        InverseReduction,
        ResponseStats,
        ModelPreprocess,
        ModelForward,
        ModelBlendAndFilter,
        ActivityPark,
    }

    static ACTIVITY_BEGIN_NS: AtomicU64 = AtomicU64::new(0);
    static LOCALIZATION_PREPROCESS_NS: AtomicU64 = AtomicU64::new(0);
    static LOCALIZATION_FORWARD_NS: AtomicU64 = AtomicU64::new(0);
    static CORRELATION_NS: AtomicU64 = AtomicU64::new(0);
    static INVERSE_FFT_NS: AtomicU64 = AtomicU64::new(0);
    static INVERSE_REDUCTION_NS: AtomicU64 = AtomicU64::new(0);
    static RESPONSE_STATS_NS: AtomicU64 = AtomicU64::new(0);
    static MODEL_PREPROCESS_NS: AtomicU64 = AtomicU64::new(0);
    static MODEL_FORWARD_NS: AtomicU64 = AtomicU64::new(0);
    static MODEL_BLEND_AND_FILTER_NS: AtomicU64 = AtomicU64::new(0);
    static ACTIVITY_PARK_NS: AtomicU64 = AtomicU64::new(0);
    static TOTAL_NS: AtomicU64 = AtomicU64::new(0);
    static UPDATES: AtomicU64 = AtomicU64::new(0);
    static SUCCESSES: AtomicU64 = AtomicU64::new(0);
    static FAILURES: AtomicU64 = AtomicU64::new(0);
    static ENABLED: OnceLock<bool> = OnceLock::new();

    thread_local! {
        static UPDATE_ACTIVE: Cell<bool> = const { Cell::new(false) };
    }

    fn enabled() -> bool {
        *ENABLED.get_or_init(|| std::env::var_os("MOSSE_PROFILE_PHASES").is_some())
    }

    fn counter(phase: Phase) -> &'static AtomicU64 {
        match phase {
            Phase::ActivityBegin => &ACTIVITY_BEGIN_NS,
            Phase::LocalizationPreprocess => &LOCALIZATION_PREPROCESS_NS,
            Phase::LocalizationForward => &LOCALIZATION_FORWARD_NS,
            Phase::Correlation => &CORRELATION_NS,
            Phase::InverseFft => &INVERSE_FFT_NS,
            Phase::InverseReduction => &INVERSE_REDUCTION_NS,
            Phase::ResponseStats => &RESPONSE_STATS_NS,
            Phase::ModelPreprocess => &MODEL_PREPROCESS_NS,
            Phase::ModelForward => &MODEL_FORWARD_NS,
            Phase::ModelBlendAndFilter => &MODEL_BLEND_AND_FILTER_NS,
            Phase::ActivityPark => &ACTIVITY_PARK_NS,
        }
    }

    fn elapsed_ns(start: Instant) -> u64 {
        u64::try_from(start.elapsed().as_nanos()).unwrap_or(u64::MAX)
    }

    pub(super) struct UpdateGuard {
        start: Option<Instant>,
    }

    impl Drop for UpdateGuard {
        fn drop(&mut self) {
            let Some(start) = self.start.take() else {
                return;
            };
            TOTAL_NS.fetch_add(elapsed_ns(start), Ordering::Relaxed);
            UPDATES.fetch_add(1, Ordering::Relaxed);
            UPDATE_ACTIVE.with(|active| active.set(false));
        }
    }

    pub(super) fn begin_update() -> UpdateGuard {
        if !enabled() {
            return UpdateGuard { start: None };
        }
        UPDATE_ACTIVE.with(|active| {
            assert!(!active.replace(true), "nested MOSSE phase-profile update");
        });
        UpdateGuard {
            start: Some(Instant::now()),
        }
    }

    pub(super) fn start() -> Option<Instant> {
        UPDATE_ACTIVE.with(Cell::get).then(Instant::now)
    }

    pub(super) fn record(phase: Phase, start: Option<Instant>) {
        if let Some(start) = start {
            counter(phase).fetch_add(elapsed_ns(start), Ordering::Relaxed);
        }
    }

    pub(super) fn record_outcome(success: bool) {
        if !UPDATE_ACTIVE.with(Cell::get) {
            return;
        }
        if success {
            SUCCESSES.fetch_add(1, Ordering::Relaxed);
        } else {
            FAILURES.fetch_add(1, Ordering::Relaxed);
        }
    }

    pub(super) fn report() {
        if !enabled() {
            return;
        }
        let updates = UPDATES.load(Ordering::Relaxed);
        if updates == 0 {
            return;
        }
        let activity_begin = ACTIVITY_BEGIN_NS.load(Ordering::Relaxed);
        let localization_preprocess = LOCALIZATION_PREPROCESS_NS.load(Ordering::Relaxed);
        let localization_forward = LOCALIZATION_FORWARD_NS.load(Ordering::Relaxed);
        let correlation = CORRELATION_NS.load(Ordering::Relaxed);
        let inverse_fft = INVERSE_FFT_NS.load(Ordering::Relaxed);
        let inverse_reduction = INVERSE_REDUCTION_NS.load(Ordering::Relaxed);
        let response_stats = RESPONSE_STATS_NS.load(Ordering::Relaxed);
        let model_preprocess = MODEL_PREPROCESS_NS.load(Ordering::Relaxed);
        let model_forward = MODEL_FORWARD_NS.load(Ordering::Relaxed);
        let model_blend_and_filter = MODEL_BLEND_AND_FILTER_NS.load(Ordering::Relaxed);
        let activity_park = ACTIVITY_PARK_NS.load(Ordering::Relaxed);
        let total = TOTAL_NS.load(Ordering::Relaxed);
        let accounted = activity_begin
            .saturating_add(localization_preprocess)
            .saturating_add(localization_forward)
            .saturating_add(correlation)
            .saturating_add(inverse_fft)
            .saturating_add(inverse_reduction)
            .saturating_add(response_stats)
            .saturating_add(model_preprocess)
            .saturating_add(model_forward)
            .saturating_add(model_blend_and_filter)
            .saturating_add(activity_park);
        let residual = total.saturating_sub(accounted);
        eprintln!(
            "mosse_phase_profile updates={updates} successes={} failures={} \
             total_ns={total} activity_begin_ns={activity_begin} \
             localization_preprocess_ns={localization_preprocess} \
             localization_forward_ns={localization_forward} \
             correlation_ns={correlation} inverse_fft_ns={inverse_fft} \
             inverse_reduction_ns={inverse_reduction} \
             response_stats_ns={response_stats} \
             model_preprocess_ns={model_preprocess} \
             model_forward_ns={model_forward} \
             model_blend_and_filter_ns={model_blend_and_filter} \
             activity_park_ns={activity_park} residual_ns={residual}",
            SUCCESSES.load(Ordering::Relaxed),
            FAILURES.load(Ordering::Relaxed),
        );
    }
}

use crate::fft2::{Fft2, InverseReduction};
#[cfg(all(
    target_os = "linux",
    target_arch = "aarch64",
    feature = "parallel-whole-layout-60x36"
))]
use crate::{
    four_core_runtime::{ActiveFourCoreScope, ExecutionMode, FourCoreRuntime, WorkerActivityMode},
    parallel_whole_layout::ParallelWholeLayoutFft2,
};
#[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
use mosse_exp034_whole_layout_fft2::{
    PaddedSpectrum, WholeLayoutFft2, COLUMN_BATCHES as PADDED_COLUMN_BATCHES,
    HEIGHT as PADDED_HEIGHT, LANES as PADDED_LANES, SPATIAL_LEN as PADDED_SPATIAL_LEN,
    WIDTH as PADDED_WIDTH,
};
#[cfg(all(
    test,
    not(target_arch = "aarch64"),
    feature = "parallel-model-blend-filter-60x36"
))]
use mosse_exp034_whole_layout_fft2::{
    PaddedSpectrum, COLUMN_BATCHES as PADDED_COLUMN_BATCHES, HEIGHT as PADDED_HEIGHT,
    LANES as PADDED_LANES,
};
#[cfg(all(
    feature = "composite-preprocess-forward-60x36",
    not(feature = "wake-crop-pipeline-60x36"),
    target_os = "linux",
    target_arch = "aarch64"
))]
use mosse_exp044_parallel_tail_kernels::bind_raw_crop_log_rows;
#[cfg(all(
    feature = "wake-crop-pipeline-60x36",
    target_os = "linux",
    target_arch = "aarch64"
))]
use mosse_exp044_parallel_tail_kernels::bind_worker_crop_log_rows;
#[cfg(all(
    feature = "wake-crop-pipeline-60x36",
    not(feature = "parallel-tail-preprocess-60x36"),
    target_os = "linux",
    target_arch = "aarch64"
))]
use mosse_exp044_parallel_tail_kernels::reduce_log_values_row_major;
#[cfg(all(
    feature = "wake-crop-pipeline-60x36",
    not(any(
        feature = "parallel-tail-preprocess-60x36",
        feature = "composite-preprocess-forward-60x36"
    )),
    target_os = "linux",
    target_arch = "aarch64"
))]
use mosse_exp044_parallel_tail_kernels::BgrFrame as TailBgrFrame;
#[cfg(any(
    all(
        feature = "parallel-tail-preprocess-60x36",
        any(test, all(target_os = "linux", target_arch = "aarch64"))
    ),
    all(
        feature = "composite-preprocess-forward-60x36",
        target_os = "linux",
        target_arch = "aarch64"
    )
))]
use mosse_exp044_parallel_tail_kernels::BgrFrame as TailBgrFrame;
#[cfg(all(
    feature = "parallel-tail-preprocess-60x36",
    any(test, all(target_os = "linux", target_arch = "aarch64"))
))]
use mosse_exp044_parallel_tail_kernels::{
    bind_crop_log_rows, bind_normalize_hann_rows, reduce_log_values_row_major,
};
#[cfg(all(
    feature = "parallel-model-blend-filter-60x36",
    any(test, all(target_os = "linux", target_arch = "aarch64"))
))]
use mosse_exp056_parallel_model_blend_filter::bind_blend_filter_batches;

const DEFAULT_EPSILON: f64 = 1.0e-5;
const DEFAULT_LEARNING_RATE: f64 = 0.2;
const DEFAULT_PSR_THRESHOLD: f64 = 5.7;
const DEFAULT_TRAINING_WARPS: u32 = 8;
const DEFAULT_RANDOM_SEED: u64 = 8_031_965;
const GAUSSIAN_SIGMA: f64 = 2.0;
const MAX_WINDOW_PIXELS: usize = 16 * 1024 * 1024;

/// Axis-aligned floating-point rectangle shared by the Rust and C APIs.
#[repr(C)]
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Rect {
    pub x: f64,
    pub y: f64,
    pub width: f64,
    pub height: f64,
}

/// Runtime parameters matching OpenCV's legacy MOSSE defaults.
#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct MosseConfig {
    pub learning_rate: f64,
    pub epsilon: f64,
    pub psr_threshold: f64,
    pub random_seed: u64,
    pub training_warps: u32,
    pub reserved: u32,
}

impl Default for MosseConfig {
    fn default() -> Self {
        Self {
            learning_rate: DEFAULT_LEARNING_RATE,
            epsilon: DEFAULT_EPSILON,
            psr_threshold: DEFAULT_PSR_THRESHOLD,
            random_seed: DEFAULT_RANDOM_SEED,
            training_warps: DEFAULT_TRAINING_WARPS,
            reserved: 0,
        }
    }
}

impl MosseConfig {
    fn validate(self) -> Result<Self, TrackerError> {
        if !self.learning_rate.is_finite()
            || self.learning_rate < 0.0
            || self.learning_rate > 1.0
            || !self.epsilon.is_finite()
            || self.epsilon <= 0.0
            || !self.psr_threshold.is_finite()
            || self.psr_threshold < 0.0
            || self.training_warps == 0
        {
            return Err(TrackerError::InvalidConfig);
        }
        Ok(self)
    }
}

/// Last attempted update's scalar diagnostics.
#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct Diagnostics {
    pub initialized: u8,
    pub last_success: u8,
    pub reserved: [u8; 6],
    pub updates: u64,
    pub window_width: u32,
    pub window_height: u32,
    pub delta_x: i32,
    pub delta_y: i32,
    pub center_x: f64,
    pub center_y: f64,
    pub psr: f64,
    pub peak: f64,
    pub response_mean: f64,
    pub response_stddev: f64,
}

impl Default for Diagnostics {
    fn default() -> Self {
        Self {
            initialized: 0,
            last_success: 0,
            reserved: [0; 6],
            updates: 0,
            window_width: 0,
            window_height: 0,
            delta_x: 0,
            delta_y: 0,
            center_x: 0.0,
            center_y: 0.0,
            psr: 0.0,
            peak: 0.0,
            response_mean: 0.0,
            response_stddev: 0.0,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum TrackerError {
    InvalidConfig,
    InvalidFrame,
    InvalidBoundingBox,
    WindowTooLarge,
    NotInitialized,
}

impl fmt::Display for TrackerError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let message = match self {
            Self::InvalidConfig => "invalid MOSSE configuration",
            Self::InvalidFrame => "invalid BGR8 frame dimensions, stride, or storage",
            Self::InvalidBoundingBox => "invalid initial bounding box",
            Self::WindowTooLarge => "tracker window is too large",
            Self::NotInitialized => "tracker has not been initialized",
        };
        f.write_str(message)
    }
}

impl Error for TrackerError {}

/// Borrowed BGR8 image. `stride` is measured in bytes.
#[derive(Clone, Copy, Debug)]
pub struct BgrFrame<'a> {
    data: &'a [u8],
    width: usize,
    height: usize,
    stride: usize,
}

impl<'a> BgrFrame<'a> {
    pub fn new(
        data: &'a [u8],
        width: usize,
        height: usize,
        stride: usize,
    ) -> Result<Self, TrackerError> {
        let row_bytes = width.checked_mul(3).ok_or(TrackerError::InvalidFrame)?;
        if width == 0 || height == 0 || stride < row_bytes {
            return Err(TrackerError::InvalidFrame);
        }
        let required = stride
            .checked_mul(height - 1)
            .and_then(|prefix| prefix.checked_add(row_bytes))
            .ok_or(TrackerError::InvalidFrame)?;
        if data.len() < required {
            return Err(TrackerError::InvalidFrame);
        }
        Ok(Self {
            data,
            width,
            height,
            stride,
        })
    }

    pub fn data(&self) -> &'a [u8] {
        self.data
    }

    pub fn width(&self) -> usize {
        self.width
    }

    pub fn height(&self) -> usize {
        self.height
    }

    pub fn stride(&self) -> usize {
        self.stride
    }

    #[inline]
    fn channel(&self, x: usize, y: usize, channel: usize) -> u8 {
        self.data[y * self.stride + x * 3 + channel]
    }
}

#[derive(Clone, Copy, Debug)]
pub struct UpdateResult {
    pub success: bool,
    pub bounding_box: Rect,
    pub diagnostics: Diagnostics,
}

/// Effective spectral backend after tracker initialization.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum TrackerBackendStatus {
    Uninitialized,
    GenericSingleThread,
    FixedPaddedSingleThread,
    FixedPaddedFourCore,
}

/// Requested execution mode for an explicitly configured tracker.
///
/// This selection is stored on the tracker and never mutates process-global
/// environment. [`MosseTracker::new`] deliberately retains the legacy
/// environment-selected behavior used by the benchmark harness.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum TrackerMode {
    /// Attempt the validated four-core backend on supported fixed-layout
    /// Linux/AArch64 builds, otherwise use a safe single-thread backend.
    Auto,
    /// Force single-thread execution, including for the fixed padded layout.
    Single,
    /// Request the validated four-core backend and safely fall back if its
    /// platform, capability, affinity, or scheduling checks fail.
    Multicore,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum BackendRequest {
    LegacyEnvironment,
    Explicit(TrackerMode),
}

#[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
struct GenericSpectralWorkspace {
    fft: Fft2,
    goal_spectrum: Vec<Complex32>,
    numerator: Vec<Complex32>,
    denominator: Vec<Complex32>,
    filter: Vec<Complex32>,
    spectrum: Vec<Complex32>,
    response_spectrum: Vec<Complex32>,
}

#[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
enum FixedPaddedFft {
    Serial(WholeLayoutFft2),
    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "parallel-whole-layout-60x36"
    ))]
    Parallel {
        runtime: FourCoreRuntime,
        fft: ParallelWholeLayoutFft2,
    },
}

#[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
impl FixedPaddedFft {
    fn new(request: BackendRequest) -> Self {
        #[cfg(all(
            target_os = "linux",
            target_arch = "aarch64",
            feature = "parallel-whole-layout-60x36"
        ))]
        {
            let runtime = match request {
                BackendRequest::LegacyEnvironment => FourCoreRuntime::from_environment(),
                BackendRequest::Explicit(TrackerMode::Single) => {
                    FourCoreRuntime::from_requested_cores(1)
                }
                BackendRequest::Explicit(TrackerMode::Auto | TrackerMode::Multicore) => {
                    FourCoreRuntime::from_requested_cores(4)
                }
            };
            if runtime.mode() == ExecutionMode::PersistentFourCore {
                return Self::Parallel {
                    runtime,
                    fft: ParallelWholeLayoutFft2::new(),
                };
            }
        }
        #[cfg(not(all(
            target_os = "linux",
            target_arch = "aarch64",
            feature = "parallel-whole-layout-60x36"
        )))]
        let _ = request;
        Self::Serial(WholeLayoutFft2::new())
    }

    fn status(&self) -> TrackerBackendStatus {
        match self {
            Self::Serial(_) => TrackerBackendStatus::FixedPaddedSingleThread,
            #[cfg(all(
                target_os = "linux",
                target_arch = "aarch64",
                feature = "parallel-whole-layout-60x36"
            ))]
            Self::Parallel { .. } => TrackerBackendStatus::FixedPaddedFourCore,
        }
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "parallel-whole-layout-60x36"
    ))]
    fn worker_activity_mode(&self) -> Option<WorkerActivityMode> {
        match self {
            Self::Serial(_) => None,
            Self::Parallel { runtime, .. } => runtime.worker_activity_mode(),
        }
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "parallel-whole-layout-60x36"
    ))]
    fn begin_activity(&mut self) -> Option<ActiveFourCoreScope> {
        match self {
            Self::Serial(_) => None,
            Self::Parallel { runtime, .. } => Some(runtime.begin_activity()),
        }
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "wake-crop-pipeline-60x36"
    ))]
    fn try_begin_activity_with_worker_crop(
        &mut self,
        frame: BgrFrame<'_>,
        origin_x: usize,
        origin_y: usize,
        log_lut: &[f32; 256],
        values: &mut [f32],
    ) -> Option<ActiveFourCoreScope> {
        let Self::Parallel { runtime, .. } = self else {
            return None;
        };
        let frame = TailBgrFrame::new(frame.data(), frame.width(), frame.height(), frame.stride())
            .expect("validated tracker frame must bind as a crop-pipeline frame");
        let mut tasks = bind_worker_crop_log_rows(frame, origin_x, origin_y, log_lut, values)
            .expect("fixed half-pixel tracker crop must bind as three disjoint worker tasks");
        Some(runtime.begin_activity_with_worker_job(&mut tasks, |_, task| task.run()))
    }

    fn forward(&mut self, input: &[f32], output: &mut PaddedSpectrum) {
        match self {
            Self::Serial(fft) => fft.forward(input, output),
            #[cfg(all(
                target_os = "linux",
                target_arch = "aarch64",
                feature = "parallel-whole-layout-60x36"
            ))]
            Self::Parallel { runtime, fft } => fft.forward(runtime, input, output),
        }
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "fused-normalize-forward-60x36"
    ))]
    fn can_fuse_normalize_forward(&self) -> bool {
        matches!(self, Self::Parallel { .. })
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "fused-normalize-forward-60x36"
    ))]
    fn try_forward_normalized(
        &mut self,
        log_values: &[f32],
        hann: &[f32],
        normalization: FusedNormalization,
        output: &mut PaddedSpectrum,
    ) -> bool {
        let Self::Parallel { runtime, fft } = self else {
            return false;
        };
        fft.forward_normalized(
            runtime,
            log_values,
            hann,
            normalization.mean,
            normalization.denominator,
            output,
        );
        true
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "composite-preprocess-forward-60x36",
        not(feature = "wake-crop-pipeline-60x36")
    ))]
    #[allow(clippy::too_many_arguments)]
    fn try_composite_preprocess_forward(
        &mut self,
        frame: BgrFrame<'_>,
        origin_x: usize,
        origin_y: usize,
        log_lut: &[f32; 256],
        log_values: &mut [f32],
        hann: &[f32],
        epsilon: f64,
        output: &mut PaddedSpectrum,
    ) -> bool {
        let Self::Parallel { runtime, fft } = self else {
            return false;
        };
        let frame = TailBgrFrame::new(frame.data(), frame.width(), frame.height(), frame.stride())
            .expect("validated tracker frame must bind as a composite-preprocessing frame");
        let log_values_ptr = log_values.as_mut_ptr();
        let log_values_len = log_values.len();
        // SAFETY: this method exclusively owns the complete fixed output
        // buffer until the composite dispatch returns. The raw binder stores
        // no Rust references and assigns each task a disjoint row range.
        let mut tasks = unsafe {
            bind_raw_crop_log_rows(
                frame,
                origin_x,
                origin_y,
                log_lut,
                log_values_ptr,
                log_values_len,
            )
            .expect("fixed half-pixel tracker crop must bind as four disjoint raw row tasks")
        };
        // SAFETY: `log_values_ptr` addresses the same live exclusive allocation
        // as the four raw task outputs. The composite method acquires every
        // task's completion release before reading, and no temporary mutable
        // slice created by a task survives `run`.
        unsafe {
            fft.forward_normalized_after_crop(
                runtime,
                &mut tasks,
                log_values_ptr,
                hann,
                epsilon,
                output,
            );
        }
        true
    }

    fn inverse(&mut self, spectrum: &mut PaddedSpectrum, output: &mut [f32]) {
        match self {
            Self::Serial(fft) => fft.inverse(spectrum, output),
            #[cfg(all(
                target_os = "linux",
                target_arch = "aarch64",
                feature = "parallel-whole-layout-60x36"
            ))]
            Self::Parallel { runtime, fft } => fft.inverse(runtime, spectrum, output),
        }
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        any(
            feature = "parallel-correlated-inverse-60x36",
            feature = "fused-correlated-inverse-cfft36-60x36"
        )
    ))]
    fn try_correlated_inverse(
        &mut self,
        sample: &PaddedSpectrum,
        filter: &PaddedSpectrum,
        response: &mut PaddedSpectrum,
        output: &mut [f32],
    ) -> bool {
        let Self::Parallel { runtime, fft } = self else {
            return false;
        };
        fft.correlated_inverse(runtime, sample, filter, response, output);
        true
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "pipelined-inverse-reduction-60x36"
    ))]
    fn try_correlated_inverse_reduced_pipelined(
        &mut self,
        sample: &PaddedSpectrum,
        filter: &PaddedSpectrum,
        response: &mut PaddedSpectrum,
    ) -> Option<InverseReduction> {
        let Self::Parallel { runtime, fft } = self else {
            return None;
        };
        let reduction = fft.correlated_inverse_reduced_pipelined(runtime, sample, filter, response);
        Some(InverseReduction {
            maximum: reduction.maximum,
            maximum_index: reduction.maximum_index,
            sum: reduction.sum,
            sum_of_squares: reduction.sum_of_squares,
        })
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "parallel-model-blend-filter-60x36"
    ))]
    #[allow(clippy::too_many_arguments)]
    fn try_parallel_model_blend_filter(
        &mut self,
        goal: &PaddedSpectrum,
        sample: &PaddedSpectrum,
        numerator: &mut PaddedSpectrum,
        denominator: &mut PaddedSpectrum,
        filter: &mut PaddedSpectrum,
        rate: f32,
    ) -> bool {
        let Self::Parallel { runtime, .. } = self else {
            return false;
        };
        dispatch_parallel_model_blend_filter(
            runtime,
            goal,
            sample,
            numerator,
            denominator,
            filter,
            rate,
        );
        true
    }

    /// Run the fixed half-pixel crop and normalization tails on the parked
    /// caller-plus-three-worker executor.
    ///
    /// Only disjoint complete rows are dispatched. Both floating-point
    /// reductions remain on the caller in the original row-major order.
    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "parallel-tail-preprocess-60x36"
    ))]
    #[allow(clippy::too_many_arguments)]
    fn try_parallel_preprocess(
        &mut self,
        frame: BgrFrame<'_>,
        origin_x: usize,
        origin_y: usize,
        log_lut: &[f32; 256],
        values: &mut [f32],
        hann: &[f32],
        epsilon: f64,
    ) -> bool {
        let Self::Parallel { runtime, .. } = self else {
            return false;
        };
        let frame = TailBgrFrame::new(frame.data(), frame.width(), frame.height(), frame.stride())
            .expect("validated tracker frame must bind as a tail-kernel frame");

        {
            let mut tasks = bind_crop_log_rows(frame, origin_x, origin_y, log_lut, values)
                .expect("fixed half-pixel tracker crop must bind as four disjoint row tasks");
            runtime.dispatch(&mut tasks, |_, task| task.run());
        }

        let reduction = reduce_log_values_row_major(values, epsilon)
            .expect("fixed tracker preprocessing buffer must contain 60x36 values");
        {
            let mut tasks = bind_normalize_hann_rows(values, hann, reduction)
                .expect("fixed tracker normalization must bind as four disjoint row tasks");
            runtime.dispatch(&mut tasks, |_, task| task.run());
        }
        true
    }

    /// Run only the fixed half-pixel crop/log tasks, leaving both reductions
    /// and normalize/Hann work to the caller-selected composition.
    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "parallel-tail-preprocess-60x36",
        feature = "fused-normalize-forward-60x36",
        not(feature = "wake-crop-pipeline-60x36")
    ))]
    fn try_parallel_crop_log(
        &mut self,
        frame: BgrFrame<'_>,
        origin_x: usize,
        origin_y: usize,
        log_lut: &[f32; 256],
        values: &mut [f32],
    ) -> bool {
        let Self::Parallel { runtime, .. } = self else {
            return false;
        };
        let frame = TailBgrFrame::new(frame.data(), frame.width(), frame.height(), frame.stride())
            .expect("validated tracker frame must bind as a tail-kernel frame");
        let mut tasks = bind_crop_log_rows(frame, origin_x, origin_y, log_lut, values)
            .expect("fixed half-pixel tracker crop must bind as four disjoint row tasks");
        runtime.dispatch(&mut tasks, |_, task| task.run());
        true
    }
}

#[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
struct FixedPaddedSpectralWorkspace {
    fft: FixedPaddedFft,
    goal_spectrum: PaddedSpectrum,
    numerator: PaddedSpectrum,
    denominator: PaddedSpectrum,
    filter: PaddedSpectrum,
    spectrum: PaddedSpectrum,
    response_spectrum: PaddedSpectrum,
}

#[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
enum SpectralWorkspace {
    Generic(Box<GenericSpectralWorkspace>),
    FixedPadded(Box<FixedPaddedSpectralWorkspace>),
}

#[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
impl SpectralWorkspace {
    fn new(width: usize, height: usize, request: BackendRequest) -> Self {
        if width == PADDED_WIDTH && height == PADDED_HEIGHT {
            Self::FixedPadded(Box::new(FixedPaddedSpectralWorkspace {
                fft: FixedPaddedFft::new(request),
                goal_spectrum: PaddedSpectrum::default(),
                numerator: PaddedSpectrum::default(),
                denominator: PaddedSpectrum::default(),
                filter: PaddedSpectrum::default(),
                spectrum: PaddedSpectrum::default(),
                response_spectrum: PaddedSpectrum::default(),
            }))
        } else {
            let fft = Fft2::new(width, height);
            let spectrum_len = fft.spectrum_len();
            debug_assert_eq!(spectrum_len, fft.spectrum_width() * height);
            let zeros = || vec![Complex32::new(0.0, 0.0); spectrum_len];
            Self::Generic(Box::new(GenericSpectralWorkspace {
                fft,
                goal_spectrum: zeros(),
                numerator: zeros(),
                denominator: zeros(),
                filter: zeros(),
                spectrum: zeros(),
                response_spectrum: zeros(),
            }))
        }
    }

    fn forward_goal(&mut self, input: &mut [f32]) {
        match self {
            Self::Generic(workspace) => workspace
                .fft
                .forward_real(input, &mut workspace.goal_spectrum),
            Self::FixedPadded(workspace) => {
                workspace.fft.forward(input, &mut workspace.goal_spectrum)
            }
        }
    }

    fn backend_status(&self) -> TrackerBackendStatus {
        match self {
            Self::Generic(_) => TrackerBackendStatus::GenericSingleThread,
            Self::FixedPadded(workspace) => workspace.fft.status(),
        }
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "parallel-whole-layout-60x36"
    ))]
    fn worker_activity_mode(&self) -> Option<WorkerActivityMode> {
        match self {
            Self::Generic(_) => None,
            Self::FixedPadded(workspace) => workspace.fft.worker_activity_mode(),
        }
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "parallel-whole-layout-60x36"
    ))]
    fn begin_activity(&mut self) -> Option<ActiveFourCoreScope> {
        match self {
            Self::Generic(_) => None,
            Self::FixedPadded(workspace) => workspace.fft.begin_activity(),
        }
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "wake-crop-pipeline-60x36"
    ))]
    fn try_begin_activity_with_worker_crop(
        &mut self,
        frame: BgrFrame<'_>,
        origin_x: usize,
        origin_y: usize,
        log_lut: &[f32; 256],
        values: &mut [f32],
    ) -> Option<ActiveFourCoreScope> {
        match self {
            Self::Generic(_) => None,
            Self::FixedPadded(workspace) => workspace
                .fft
                .try_begin_activity_with_worker_crop(frame, origin_x, origin_y, log_lut, values),
        }
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "fused-normalize-forward-60x36"
    ))]
    fn can_fuse_normalize_forward(&self) -> bool {
        match self {
            Self::Generic(_) => false,
            Self::FixedPadded(workspace) => workspace.fft.can_fuse_normalize_forward(),
        }
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "fused-normalize-forward-60x36"
    ))]
    fn try_forward_sample_normalized(
        &mut self,
        log_values: &[f32],
        hann: &[f32],
        normalization: FusedNormalization,
    ) -> bool {
        match self {
            Self::Generic(_) => false,
            Self::FixedPadded(workspace) => workspace.fft.try_forward_normalized(
                log_values,
                hann,
                normalization,
                &mut workspace.spectrum,
            ),
        }
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "composite-preprocess-forward-60x36",
        not(feature = "wake-crop-pipeline-60x36")
    ))]
    #[allow(clippy::too_many_arguments)]
    fn try_composite_preprocess_forward(
        &mut self,
        frame: BgrFrame<'_>,
        origin_x: usize,
        origin_y: usize,
        log_lut: &[f32; 256],
        log_values: &mut [f32],
        hann: &[f32],
        epsilon: f64,
    ) -> bool {
        match self {
            Self::Generic(_) => false,
            Self::FixedPadded(workspace) => workspace.fft.try_composite_preprocess_forward(
                frame,
                origin_x,
                origin_y,
                log_lut,
                log_values,
                hann,
                epsilon,
                &mut workspace.spectrum,
            ),
        }
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "parallel-tail-preprocess-60x36"
    ))]
    #[allow(clippy::too_many_arguments)]
    fn try_parallel_preprocess(
        &mut self,
        frame: BgrFrame<'_>,
        origin_x: usize,
        origin_y: usize,
        log_lut: &[f32; 256],
        values: &mut [f32],
        hann: &[f32],
        epsilon: f64,
    ) -> bool {
        match self {
            Self::Generic(_) => false,
            Self::FixedPadded(workspace) => workspace
                .fft
                .try_parallel_preprocess(frame, origin_x, origin_y, log_lut, values, hann, epsilon),
        }
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "parallel-tail-preprocess-60x36",
        feature = "fused-normalize-forward-60x36",
        not(feature = "wake-crop-pipeline-60x36")
    ))]
    fn try_parallel_crop_log(
        &mut self,
        frame: BgrFrame<'_>,
        origin_x: usize,
        origin_y: usize,
        log_lut: &[f32; 256],
        values: &mut [f32],
    ) -> bool {
        match self {
            Self::Generic(_) => false,
            Self::FixedPadded(workspace) => workspace
                .fft
                .try_parallel_crop_log(frame, origin_x, origin_y, log_lut, values),
        }
    }

    fn forward_model(&mut self, input: &mut [f32]) {
        match self {
            Self::Generic(workspace) => workspace.fft.forward_real(input, &mut workspace.spectrum),
            Self::FixedPadded(workspace) => workspace.fft.forward(input, &mut workspace.spectrum),
        }
    }

    fn forward_localization(&mut self, input: &mut [f32]) {
        match self {
            Self::Generic(workspace) => workspace
                .fft
                .forward_real_localization(input, &mut workspace.spectrum),
            Self::FixedPadded(workspace) => workspace.fft.forward(input, &mut workspace.spectrum),
        }
    }

    fn accumulate_current_sample(&mut self) {
        match self {
            Self::Generic(workspace) => {
                for i in 0..workspace.spectrum.len() {
                    let sample = workspace.spectrum[i];
                    workspace.numerator[i] += workspace.goal_spectrum[i] * sample.conj();
                    workspace.denominator[i] += sample * sample.conj();
                }
            }
            Self::FixedPadded(workspace) => padded_accumulate_current_sample(workspace),
        }
    }

    fn reconstruct_filter(&mut self) {
        match self {
            Self::Generic(workspace) => reconstruct_filter(
                &workspace.numerator,
                &workspace.denominator,
                &mut workspace.filter,
            ),
            Self::FixedPadded(workspace) => padded_reconstruct_filter(workspace),
        }
    }

    fn localize_inverse(&mut self, output: &mut [f32]) -> InverseReduction {
        match self {
            Self::Generic(workspace) => {
                #[cfg(feature = "phase-profile")]
                let correlation_started = phase_profile::start();
                multiply_localization_spectrum(
                    &workspace.spectrum,
                    &workspace.filter,
                    &mut workspace.response_spectrum,
                );
                #[cfg(feature = "phase-profile")]
                phase_profile::record(phase_profile::Phase::Correlation, correlation_started);
                #[cfg(feature = "phase-profile")]
                {
                    let inverse_started = phase_profile::start();
                    workspace
                        .fft
                        .profile_inverse_real_unscaled(&mut workspace.response_spectrum, output);
                    phase_profile::record(phase_profile::Phase::InverseFft, inverse_started);
                    let reduction_started = phase_profile::start();
                    let reduction = workspace.fft.profile_reduce_inverse_output(output);
                    phase_profile::record(
                        phase_profile::Phase::InverseReduction,
                        reduction_started,
                    );
                    reduction
                }
                #[cfg(not(feature = "phase-profile"))]
                workspace
                    .fft
                    .inverse_real_reduced(&mut workspace.response_spectrum, output)
            }
            Self::FixedPadded(workspace) => {
                #[cfg(all(
                    target_os = "linux",
                    target_arch = "aarch64",
                    feature = "pipelined-inverse-reduction-60x36"
                ))]
                {
                    #[cfg(feature = "phase-profile")]
                    let pipelined_started = phase_profile::start();
                    if let Some(reduction) = workspace.fft.try_correlated_inverse_reduced_pipelined(
                        &workspace.spectrum,
                        &workspace.filter,
                        &mut workspace.response_spectrum,
                    ) {
                        // The inverse row dispatch and exact caller reduction
                        // overlap and cannot be separated without perturbing
                        // the pipeline. Account their combined wall interval
                        // under inverse FFT and leave inverse reduction zero.
                        #[cfg(feature = "phase-profile")]
                        phase_profile::record(phase_profile::Phase::InverseFft, pipelined_started);
                        return reduction;
                    }
                }

                #[cfg(all(
                    target_os = "linux",
                    target_arch = "aarch64",
                    any(
                        feature = "parallel-correlated-inverse-60x36",
                        feature = "fused-correlated-inverse-cfft36-60x36"
                    )
                ))]
                {
                    #[cfg(feature = "phase-profile")]
                    let fused_started = phase_profile::start();
                    if workspace.fft.try_correlated_inverse(
                        &workspace.spectrum,
                        &workspace.filter,
                        &mut workspace.response_spectrum,
                        output,
                    ) {
                        // Correlation and inverse columns intentionally share
                        // one dispatch, so the phase profiler records their
                        // inseparable fused interval as inverse FFT time.
                        #[cfg(feature = "phase-profile")]
                        phase_profile::record(phase_profile::Phase::InverseFft, fused_started);
                        #[cfg(feature = "phase-profile")]
                        let reduction_started = phase_profile::start();
                        let reduction = reduce_fixed_inverse_output(output);
                        #[cfg(feature = "phase-profile")]
                        phase_profile::record(
                            phase_profile::Phase::InverseReduction,
                            reduction_started,
                        );
                        return reduction;
                    }
                }

                #[cfg(feature = "phase-profile")]
                let correlation_started = phase_profile::start();
                padded_multiply_localization_spectrum(workspace);
                #[cfg(feature = "phase-profile")]
                phase_profile::record(phase_profile::Phase::Correlation, correlation_started);
                #[cfg(feature = "phase-profile")]
                let inverse_started = phase_profile::start();
                workspace
                    .fft
                    .inverse(&mut workspace.response_spectrum, output);
                #[cfg(feature = "phase-profile")]
                phase_profile::record(phase_profile::Phase::InverseFft, inverse_started);
                #[cfg(feature = "phase-profile")]
                let reduction_started = phase_profile::start();
                let reduction = reduce_fixed_inverse_output(output);
                #[cfg(feature = "phase-profile")]
                phase_profile::record(phase_profile::Phase::InverseReduction, reduction_started);
                reduction
            }
        }
    }

    fn blend_current_sample(&mut self, rate: f32) {
        match self {
            Self::Generic(workspace) => {
                let keep = 1.0 - rate;
                for i in 0..workspace.spectrum.len() {
                    let sample = workspace.spectrum[i];
                    let numerator_new = workspace.goal_spectrum[i] * sample.conj();
                    let denominator_new = sample * sample.conj();
                    workspace.numerator[i] = workspace.numerator[i] * keep + numerator_new * rate;
                    workspace.denominator[i] =
                        workspace.denominator[i] * keep + denominator_new * rate;
                }
                reconstruct_filter(
                    &workspace.numerator,
                    &workspace.denominator,
                    &mut workspace.filter,
                );
            }
            Self::FixedPadded(workspace) => {
                #[cfg(all(
                    target_os = "linux",
                    target_arch = "aarch64",
                    feature = "parallel-model-blend-filter-60x36"
                ))]
                if workspace.fft.try_parallel_model_blend_filter(
                    &workspace.goal_spectrum,
                    &workspace.spectrum,
                    &mut workspace.numerator,
                    &mut workspace.denominator,
                    &mut workspace.filter,
                    rate,
                ) {
                    return;
                }
                padded_blend_current_sample(workspace, rate);
            }
        }
    }

    #[cfg(test)]
    fn test_spectrum(&self) -> Vec<Complex32> {
        match self {
            Self::Generic(workspace) => workspace.spectrum.clone(),
            Self::FixedPadded(workspace) => workspace.spectrum.to_column_major_valid(),
        }
    }

    #[cfg(test)]
    fn test_numerator(&self) -> Vec<Complex32> {
        match self {
            Self::Generic(workspace) => workspace.numerator.clone(),
            Self::FixedPadded(workspace) => workspace.numerator.to_column_major_valid(),
        }
    }

    #[cfg(test)]
    fn test_denominator(&self) -> Vec<Complex32> {
        match self {
            Self::Generic(workspace) => workspace.denominator.clone(),
            Self::FixedPadded(workspace) => workspace.denominator.to_column_major_valid(),
        }
    }

    #[cfg(test)]
    fn test_filter(&self) -> Vec<Complex32> {
        match self {
            Self::Generic(workspace) => workspace.filter.clone(),
            Self::FixedPadded(workspace) => workspace.filter.to_column_major_valid(),
        }
    }
}

struct Workspace {
    width: usize,
    height: usize,
    #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
    fft: Fft2,
    hann: Vec<f32>,
    #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
    goal_spectrum: Vec<Complex32>,
    #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
    numerator: Vec<Complex32>,
    #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
    denominator: Vec<Complex32>,
    #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
    filter: Vec<Complex32>,
    #[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
    spectral: SpectralWorkspace,
    frame_gray: Vec<u8>,
    patch_gray: Vec<u8>,
    warped_gray: Vec<u8>,
    preprocessed: Vec<f32>,
    #[cfg(all(
        feature = "overlap-model-raw-log-60x36",
        target_os = "linux",
        target_arch = "aarch64"
    ))]
    localization_raw_log_provenance: Option<RawLogProvenance>,
    #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
    spectrum: Vec<Complex32>,
    #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
    response_spectrum: Vec<Complex32>,
    response: Vec<f32>,
}

impl Workspace {
    fn new(
        width: usize,
        height: usize,
        frame_pixels: usize,
        backend_request: BackendRequest,
    ) -> Result<Self, TrackerError> {
        let len = width
            .checked_mul(height)
            .ok_or(TrackerError::WindowTooLarge)?;
        if len > MAX_WINDOW_PIXELS {
            return Err(TrackerError::WindowTooLarge);
        }
        #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
        let fft = Fft2::new(width, height);
        #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
        debug_assert_eq!(fft.spatial_len(), len);
        #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
        debug_assert_eq!(fft.spectrum_len(), fft.spectrum_width() * height);
        #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
        let spectrum_len = fft.spectrum_len();
        #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
        let zeros = || vec![Complex32::new(0.0, 0.0); spectrum_len];
        #[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
        let spectral = SpectralWorkspace::new(width, height, backend_request);
        #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
        let _ = backend_request;
        Ok(Self {
            width,
            height,
            #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
            fft,
            hann: vec![0.0; len],
            #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
            goal_spectrum: zeros(),
            #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
            numerator: zeros(),
            #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
            denominator: zeros(),
            #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
            filter: zeros(),
            #[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
            spectral,
            frame_gray: vec![0; frame_pixels],
            patch_gray: vec![0; len],
            warped_gray: vec![0; len],
            preprocessed: vec![0.0; len],
            #[cfg(all(
                feature = "overlap-model-raw-log-60x36",
                target_os = "linux",
                target_arch = "aarch64"
            ))]
            localization_raw_log_provenance: None,
            #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
            spectrum: zeros(),
            #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
            response_spectrum: zeros(),
            response: vec![0.0; len],
        })
    }

    fn backend_status(&self) -> TrackerBackendStatus {
        #[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
        {
            self.spectral.backend_status()
        }
        #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
        {
            TrackerBackendStatus::GenericSingleThread
        }
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "parallel-whole-layout-60x36"
    ))]
    fn worker_activity_mode(&self) -> Option<WorkerActivityMode> {
        self.spectral.worker_activity_mode()
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "parallel-whole-layout-60x36"
    ))]
    fn begin_parallel_activity(&mut self) -> Option<ActiveFourCoreScope> {
        self.spectral.begin_activity()
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "parallel-whole-layout-60x36"
    ))]
    fn begin_update_activity(
        &mut self,
        frame: BgrFrame<'_>,
        center_x: f64,
        center_y: f64,
        log_lut: &[f32; 256],
    ) -> (Option<ActiveFourCoreScope>, bool) {
        #[cfg(feature = "wake-crop-pipeline-60x36")]
        {
            let start_x = center_x - 0.5 * (self.width - 1) as f64;
            let start_y = center_y - 0.5 * (self.height - 1) as f64;
            if let Some((origin_x, origin_y)) = half_pixel_interior_origin(
                start_x,
                start_y,
                self.width,
                self.height,
                frame.width(),
                frame.height(),
            ) {
                if let Some(activity) = self.spectral.try_begin_activity_with_worker_crop(
                    frame,
                    origin_x,
                    origin_y,
                    log_lut,
                    &mut self.preprocessed,
                ) {
                    return (Some(activity), true);
                }
            }
        }
        #[cfg(not(feature = "wake-crop-pipeline-60x36"))]
        let _ = (frame, center_x, center_y, log_lut);

        (self.spectral.begin_activity(), false)
    }

    fn forward_goal_spectrum(&mut self) {
        #[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
        self.spectral.forward_goal(&mut self.response);
        #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
        self.fft
            .forward_real(&mut self.response, &mut self.goal_spectrum);
    }

    fn forward_model_spectrum(&mut self) {
        #[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
        self.spectral.forward_model(&mut self.preprocessed);
        #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
        self.fft
            .forward_real(&mut self.preprocessed, &mut self.spectrum);
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "fused-normalize-forward-60x36"
    ))]
    fn can_fuse_normalize_forward(&self) -> bool {
        self.spectral.can_fuse_normalize_forward()
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "fused-normalize-forward-60x36"
    ))]
    fn forward_sample_spectrum_normalized(&mut self, normalization: FusedNormalization) -> bool {
        self.spectral
            .try_forward_sample_normalized(&self.preprocessed, &self.hann, normalization)
    }

    #[cfg(target_arch = "aarch64")]
    fn forward_localization_spectrum(&mut self) {
        #[cfg(feature = "padded-spectrum-60x36")]
        self.spectral.forward_localization(&mut self.preprocessed);
        #[cfg(not(feature = "padded-spectrum-60x36"))]
        self.fft
            .forward_real_localization(&mut self.preprocessed, &mut self.spectrum);
    }

    fn accumulate_current_sample(&mut self) {
        #[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
        self.spectral.accumulate_current_sample();
        #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
        for i in 0..self.spectrum.len() {
            let sample = self.spectrum[i];
            self.numerator[i] += self.goal_spectrum[i] * sample.conj();
            self.denominator[i] += sample * sample.conj();
        }
    }

    fn reconstruct_filter(&mut self) {
        #[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
        self.spectral.reconstruct_filter();
        #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
        reconstruct_filter(&self.numerator, &self.denominator, &mut self.filter);
    }

    fn localize_inverse(&mut self) -> InverseReduction {
        #[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
        {
            self.spectral.localize_inverse(&mut self.response)
        }
        #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
        {
            multiply_localization_spectrum(
                &self.spectrum,
                &self.filter,
                &mut self.response_spectrum,
            );
            self.fft
                .inverse_real_reduced(&mut self.response_spectrum, &mut self.response)
        }
    }

    fn blend_current_sample(&mut self, rate: f32) {
        #[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
        self.spectral.blend_current_sample(rate);
        #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
        {
            let keep = 1.0 - rate;
            for i in 0..self.spectrum.len() {
                let sample = self.spectrum[i];
                let numerator_new = self.goal_spectrum[i] * sample.conj();
                let denominator_new = sample * sample.conj();
                self.numerator[i] = self.numerator[i] * keep + numerator_new * rate;
                self.denominator[i] = self.denominator[i] * keep + denominator_new * rate;
            }
            reconstruct_filter(&self.numerator, &self.denominator, &mut self.filter);
        }
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "composite-preprocess-forward-60x36",
        not(feature = "wake-crop-pipeline-60x36")
    ))]
    #[allow(clippy::too_many_arguments)]
    fn try_prepare_hot_spectrum_composite(
        &mut self,
        frame: BgrFrame<'_>,
        center_x: f64,
        center_y: f64,
        log_lut: &[f32; 256],
        epsilon: f64,
    ) -> bool {
        let start_x = center_x - 0.5 * (self.width - 1) as f64;
        let start_y = center_y - 0.5 * (self.height - 1) as f64;
        let Some((origin_x, origin_y)) = half_pixel_interior_origin(
            start_x,
            start_y,
            self.width,
            self.height,
            frame.width(),
            frame.height(),
        ) else {
            return false;
        };
        self.spectral.try_composite_preprocess_forward(
            frame,
            origin_x,
            origin_y,
            log_lut,
            &mut self.preprocessed,
            &self.hann,
            epsilon,
        )
    }

    #[allow(clippy::too_many_arguments)]
    fn preprocess_hot_patch(
        &mut self,
        frame: BgrFrame<'_>,
        center_x: f64,
        center_y: f64,
        log_lut: &[f32; 256],
        epsilon: f64,
    ) {
        #[cfg(all(
            target_os = "linux",
            target_arch = "aarch64",
            feature = "parallel-tail-preprocess-60x36"
        ))]
        {
            let start_x = center_x - 0.5 * (self.width - 1) as f64;
            let start_y = center_y - 0.5 * (self.height - 1) as f64;
            if let Some((origin_x, origin_y)) = half_pixel_interior_origin(
                start_x,
                start_y,
                self.width,
                self.height,
                frame.width(),
                frame.height(),
            ) {
                if self.spectral.try_parallel_preprocess(
                    frame,
                    origin_x,
                    origin_y,
                    log_lut,
                    &mut self.preprocessed,
                    &self.hann,
                    epsilon,
                ) {
                    return;
                }
            }
        }

        let (_, log_moments) = get_rect_subpix_bgr_to_log(
            frame,
            center_x,
            center_y,
            self.width,
            self.height,
            log_lut,
            &mut self.preprocessed,
        );
        finish_hot_preprocess(&mut self.preprocessed, &self.hann, log_moments, epsilon);
    }

    #[cfg(all(
        target_os = "linux",
        target_arch = "aarch64",
        feature = "fused-normalize-forward-60x36"
    ))]
    #[allow(clippy::too_many_arguments)]
    fn preprocess_hot_patch_for_fused_forward(
        &mut self,
        frame: BgrFrame<'_>,
        center_x: f64,
        center_y: f64,
        log_lut: &[f32; 256],
        epsilon: f64,
    ) -> FusedNormalization {
        #[cfg(all(
            feature = "parallel-tail-preprocess-60x36",
            not(feature = "wake-crop-pipeline-60x36")
        ))]
        {
            let start_x = center_x - 0.5 * (self.width - 1) as f64;
            let start_y = center_y - 0.5 * (self.height - 1) as f64;
            if let Some((origin_x, origin_y)) = half_pixel_interior_origin(
                start_x,
                start_y,
                self.width,
                self.height,
                frame.width(),
                frame.height(),
            ) {
                if self.spectral.try_parallel_crop_log(
                    frame,
                    origin_x,
                    origin_y,
                    log_lut,
                    &mut self.preprocessed,
                ) {
                    // In this explicit feature composition the crop/log rows
                    // run in parallel, then both f64 reductions remain one
                    // caller-side row-major chain. The old tail-only feature
                    // still performs its separate normalize dispatch.
                    let reduction = reduce_log_values_row_major(&self.preprocessed, epsilon)
                        .expect("fixed tracker preprocessing buffer must contain 60x36 values");
                    return FusedNormalization {
                        mean: reduction.mean_f32,
                        denominator: reduction.denominator_f32,
                    };
                }
            }
        }

        // Preserve the retained serial BGR crop/log path and its dependent f64
        // sum. Only the final f32 normalize/Hann stores move into row tasks.
        let (_, log_moments) = get_rect_subpix_bgr_to_log(
            frame,
            center_x,
            center_y,
            self.width,
            self.height,
            log_lut,
            &mut self.preprocessed,
        );
        fused_normalization_parameters(&self.preprocessed, log_moments.sum, epsilon)
    }

    fn prepare_hot_spectrum(
        &mut self,
        frame: BgrFrame<'_>,
        center_x: f64,
        center_y: f64,
        log_lut: &[f32; 256],
        epsilon: f64,
    ) {
        #[cfg(all(
            feature = "overlap-model-raw-log-60x36",
            target_os = "linux",
            target_arch = "aarch64"
        ))]
        {
            // Any caller reaching the retained full preprocessing path has
            // declined overlap reuse. Invalidate the old raw-log provenance
            // before this buffer is overwritten or normalized in place.
            self.localization_raw_log_provenance = None;
        }
        #[cfg(feature = "phase-profile")]
        let preprocess_started = phase_profile::start();
        #[cfg(all(
            target_os = "linux",
            target_arch = "aarch64",
            feature = "composite-preprocess-forward-60x36",
            not(feature = "wake-crop-pipeline-60x36")
        ))]
        if self.try_prepare_hot_spectrum_composite(frame, center_x, center_y, log_lut, epsilon) {
            // The crop, both reductions, normalized row transform, and column
            // transform form one indivisible composite interval. Charge the
            // complete interval to forward instead of inventing a split.
            #[cfg(feature = "phase-profile")]
            phase_profile::record(phase_profile::Phase::ModelForward, preprocess_started);
            return;
        }
        #[cfg(all(
            target_os = "linux",
            target_arch = "aarch64",
            feature = "fused-normalize-forward-60x36"
        ))]
        if self.can_fuse_normalize_forward() {
            let normalization = self.preprocess_hot_patch_for_fused_forward(
                frame, center_x, center_y, log_lut, epsilon,
            );
            #[cfg(feature = "phase-profile")]
            phase_profile::record(phase_profile::Phase::ModelPreprocess, preprocess_started);

            // This interval now honestly includes the fused f32
            // normalize/Hann expressions executed by the forward row tasks.
            #[cfg(feature = "phase-profile")]
            let forward_started = phase_profile::start();
            let fused = self.forward_sample_spectrum_normalized(normalization);
            assert!(fused, "validated fused forward backend became unavailable");
            #[cfg(feature = "phase-profile")]
            phase_profile::record(phase_profile::Phase::ModelForward, forward_started);
            return;
        }

        self.preprocess_hot_patch(frame, center_x, center_y, log_lut, epsilon);
        #[cfg(feature = "phase-profile")]
        phase_profile::record(phase_profile::Phase::ModelPreprocess, preprocess_started);
        #[cfg(feature = "phase-profile")]
        let forward_started = phase_profile::start();
        self.forward_model_spectrum();
        #[cfg(feature = "phase-profile")]
        phase_profile::record(phase_profile::Phase::ModelForward, forward_started);
    }

    #[cfg(all(
        feature = "overlap-model-raw-log-60x36",
        target_os = "linux",
        target_arch = "aarch64"
    ))]
    #[allow(clippy::too_many_arguments)]
    fn try_prepare_hot_spectrum_from_localization_raw_logs(
        &mut self,
        frame: BgrFrame<'_>,
        old_center_x: f64,
        old_center_y: f64,
        new_center_x: f64,
        new_center_y: f64,
        delta_x: i32,
        delta_y: i32,
        log_lut: &[f32; 256],
        epsilon: f64,
    ) -> bool {
        if !raw_log_reuse_backend_supported(self.backend_status(), self.width, self.height) {
            return false;
        }
        let Some(provenance) = self.localization_raw_log_provenance else {
            return false;
        };

        #[cfg(feature = "phase-profile")]
        let preprocess_started = phase_profile::start();
        let Some(reduction) = try_reuse_model_raw_logs(
            frame,
            provenance,
            old_center_x,
            old_center_y,
            new_center_x,
            new_center_y,
            delta_x,
            delta_y,
            self.width,
            self.height,
            log_lut,
            &mut self.preprocessed,
            epsilon,
        ) else {
            return false;
        };
        debug_assert!(reduction.sum.is_finite());
        debug_assert!(reduction.sampled_values > 0);
        self.localization_raw_log_provenance = None;
        #[cfg(feature = "phase-profile")]
        phase_profile::record(phase_profile::Phase::ModelPreprocess, preprocess_started);

        #[cfg(feature = "phase-profile")]
        let forward_started = phase_profile::start();
        let fused = self.forward_sample_spectrum_normalized(FusedNormalization {
            mean: reduction.mean,
            denominator: reduction.denominator,
        });
        assert!(fused, "validated fused forward backend became unavailable");
        #[cfg(feature = "phase-profile")]
        phase_profile::record(phase_profile::Phase::ModelForward, forward_started);
        true
    }

    #[cfg(target_arch = "aarch64")]
    fn prepare_localization_spectrum(
        &mut self,
        frame: BgrFrame<'_>,
        center_x: f64,
        center_y: f64,
        log_lut: &[f32; 256],
        epsilon: f64,
        localization_crop_ready: bool,
    ) {
        #[cfg(all(
            feature = "overlap-model-raw-log-60x36",
            target_os = "linux",
            target_arch = "aarch64"
        ))]
        {
            // Provenance is per localization call. A failure or unsupported
            // sampling path must never inherit raw logs from a prior frame.
            self.localization_raw_log_provenance = None;
        }
        #[cfg(feature = "phase-profile")]
        let preprocess_started = phase_profile::start();
        #[cfg(all(
            feature = "wake-crop-pipeline-60x36",
            target_os = "linux",
            target_arch = "aarch64"
        ))]
        if localization_crop_ready {
            #[cfg(feature = "overlap-model-raw-log-60x36")]
            let raw_log_provenance =
                RawLogProvenance::for_center(frame, center_x, center_y, self.width, self.height);
            assert!(
                self.can_fuse_normalize_forward(),
                "published localization crop requires the fixed parallel forward backend"
            );
            // The worker crop and its completion barrier were charged to
            // ActivityBegin. Keep both complete f64 accumulation chains here
            // on the caller in strict row-major order.
            let reduction = reduce_log_values_row_major(&self.preprocessed, epsilon)
                .expect("published localization crop must contain 60x36 log values");
            let normalization = FusedNormalization {
                mean: reduction.mean_f32,
                denominator: reduction.denominator_f32,
            };
            #[cfg(feature = "phase-profile")]
            phase_profile::record(
                phase_profile::Phase::LocalizationPreprocess,
                preprocess_started,
            );

            #[cfg(feature = "phase-profile")]
            let forward_started = phase_profile::start();
            let fused = self.forward_sample_spectrum_normalized(normalization);
            assert!(fused, "validated fused forward backend became unavailable");
            #[cfg(feature = "phase-profile")]
            phase_profile::record(phase_profile::Phase::LocalizationForward, forward_started);
            #[cfg(feature = "overlap-model-raw-log-60x36")]
            {
                self.localization_raw_log_provenance = raw_log_provenance;
            }
            return;
        }
        #[cfg(not(all(
            feature = "wake-crop-pipeline-60x36",
            target_os = "linux",
            target_arch = "aarch64"
        )))]
        let _ = localization_crop_ready;

        #[cfg(all(
            target_os = "linux",
            target_arch = "aarch64",
            feature = "composite-preprocess-forward-60x36",
            not(feature = "wake-crop-pipeline-60x36")
        ))]
        {
            #[cfg(feature = "overlap-model-raw-log-60x36")]
            let raw_log_provenance =
                RawLogProvenance::for_center(frame, center_x, center_y, self.width, self.height);
            if self.try_prepare_hot_spectrum_composite(frame, center_x, center_y, log_lut, epsilon)
            {
                // The composite epoch intentionally has no observable
                // preprocess/row boundary. Attribute its complete crop,
                // reductions, row FFT, and column FFT interval to forward.
                #[cfg(feature = "phase-profile")]
                phase_profile::record(
                    phase_profile::Phase::LocalizationForward,
                    preprocess_started,
                );
                #[cfg(feature = "overlap-model-raw-log-60x36")]
                {
                    self.localization_raw_log_provenance = raw_log_provenance;
                }
                return;
            }
        }

        #[cfg(all(
            target_os = "linux",
            target_arch = "aarch64",
            feature = "fused-normalize-forward-60x36"
        ))]
        if self.can_fuse_normalize_forward() {
            #[cfg(feature = "overlap-model-raw-log-60x36")]
            let raw_log_provenance =
                RawLogProvenance::for_center(frame, center_x, center_y, self.width, self.height);
            let normalization = self.preprocess_hot_patch_for_fused_forward(
                frame, center_x, center_y, log_lut, epsilon,
            );
            #[cfg(feature = "phase-profile")]
            phase_profile::record(
                phase_profile::Phase::LocalizationPreprocess,
                preprocess_started,
            );

            // This interval now honestly includes the fused f32
            // normalize/Hann expressions executed by the forward row tasks.
            #[cfg(feature = "phase-profile")]
            let forward_started = phase_profile::start();
            let fused = self.forward_sample_spectrum_normalized(normalization);
            assert!(fused, "validated fused forward backend became unavailable");
            #[cfg(feature = "phase-profile")]
            phase_profile::record(phase_profile::Phase::LocalizationForward, forward_started);
            #[cfg(feature = "overlap-model-raw-log-60x36")]
            {
                self.localization_raw_log_provenance = raw_log_provenance;
            }
            return;
        }

        self.preprocess_hot_patch(frame, center_x, center_y, log_lut, epsilon);
        #[cfg(feature = "phase-profile")]
        phase_profile::record(
            phase_profile::Phase::LocalizationPreprocess,
            preprocess_started,
        );
        #[cfg(feature = "phase-profile")]
        let forward_started = phase_profile::start();
        self.forward_localization_spectrum();
        #[cfg(feature = "phase-profile")]
        phase_profile::record(phase_profile::Phase::LocalizationForward, forward_started);
    }

    #[cfg(test)]
    fn test_spectrum(&self) -> Vec<Complex32> {
        #[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
        {
            self.spectral.test_spectrum()
        }
        #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
        {
            self.spectrum.clone()
        }
    }

    #[cfg(test)]
    fn test_numerator(&self) -> Vec<Complex32> {
        #[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
        {
            self.spectral.test_numerator()
        }
        #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
        {
            self.numerator.clone()
        }
    }

    #[cfg(test)]
    fn test_denominator(&self) -> Vec<Complex32> {
        #[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
        {
            self.spectral.test_denominator()
        }
        #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
        {
            self.denominator.clone()
        }
    }

    #[cfg(test)]
    fn test_filter(&self) -> Vec<Complex32> {
        #[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
        {
            self.spectral.test_filter()
        }
        #[cfg(not(all(target_arch = "aarch64", feature = "padded-spectrum-60x36")))]
        {
            self.filter.clone()
        }
    }
}

/// Scalar, allocation-free-on-update MOSSE reference tracker.
pub struct MosseTracker {
    config: MosseConfig,
    backend_request: BackendRequest,
    log_lut: [f32; 256],
    initialized: bool,
    center_x: f64,
    center_y: f64,
    window_width: usize,
    window_height: usize,
    workspace: Option<Workspace>,
    diagnostics: Diagnostics,
}

impl MosseTracker {
    /// Construct a tracker with the benchmark-compatible environment-selected
    /// backend policy.
    pub fn new(config: MosseConfig) -> Result<Self, TrackerError> {
        Self::new_with_backend_request(config, BackendRequest::LegacyEnvironment)
    }

    /// Construct a tracker with an explicit per-tracker execution mode.
    pub fn new_with_mode(config: MosseConfig, mode: TrackerMode) -> Result<Self, TrackerError> {
        Self::new_with_backend_request(config, BackendRequest::Explicit(mode))
    }

    fn new_with_backend_request(
        config: MosseConfig,
        backend_request: BackendRequest,
    ) -> Result<Self, TrackerError> {
        let config = config.validate()?;
        Ok(Self {
            config,
            backend_request,
            log_lut: create_log_lut(),
            initialized: false,
            center_x: 0.0,
            center_y: 0.0,
            window_width: 0,
            window_height: 0,
            workspace: None,
            diagnostics: Diagnostics::default(),
        })
    }

    pub fn config(&self) -> MosseConfig {
        self.config
    }

    pub fn is_initialized(&self) -> bool {
        self.initialized
    }

    pub fn diagnostics(&self) -> Diagnostics {
        self.diagnostics
    }

    pub fn backend_status(&self) -> TrackerBackendStatus {
        self.workspace.as_ref().map_or(
            TrackerBackendStatus::Uninitialized,
            Workspace::backend_status,
        )
    }

    /// Initializes the tracker and returns the internally rounded FFT window.
    pub fn init(&mut self, frame: BgrFrame<'_>, bounding_box: Rect) -> Result<Rect, TrackerError> {
        validate_bounding_box(frame, bounding_box)?;

        // OpenCV truncates the requested dimensions before getOptimalDFTSize.
        let requested_width = bounding_box.width as usize;
        let requested_height = bounding_box.height as usize;
        let width = optimal_dft_size(requested_width).ok_or(TrackerError::InvalidBoundingBox)?;
        let height = optimal_dft_size(requested_height).ok_or(TrackerError::InvalidBoundingBox)?;
        if width <= 1 || height <= 1 {
            return Err(TrackerError::InvalidBoundingBox);
        }

        let frame_pixels = frame
            .width
            .checked_mul(frame.height)
            .ok_or(TrackerError::InvalidFrame)?;
        let mut workspace = Workspace::new(width, height, frame_pixels, self.backend_request)?;
        // Persistent FIFO workers block outside a complete tracker call. This
        // owned guard keeps them awake across every initialization FFT and
        // waits for all three parked acknowledgements before `init` returns.
        #[cfg(all(
            target_os = "linux",
            target_arch = "aarch64",
            feature = "parallel-whole-layout-60x36"
        ))]
        let _parallel_activity = workspace.begin_parallel_activity();

        // This deliberately mirrors legacy TrackerMOSSE's integer x1/y1 and w/2.
        let x1 = ((2.0 * bounding_box.x + bounding_box.width - width as f64) * 0.5).floor();
        let y1 = ((2.0 * bounding_box.y + bounding_box.height - height as f64) * 0.5).floor();
        let center_x = x1 + (width / 2) as f64;
        let center_y = y1 + (height / 2) as f64;

        bgr_frame_to_gray(frame, &mut workspace.frame_gray);
        get_rect_subpix_gray(
            &workspace.frame_gray,
            frame.width,
            frame.height,
            center_x,
            center_y,
            width,
            height,
            &mut workspace.patch_gray,
        );
        create_hann_window(width, height, &mut workspace.hann);
        gaussian_goal(width, height, GAUSSIAN_SIGMA, &mut workspace.response);
        workspace.forward_goal_spectrum();

        for _ in 0..self.config.training_warps {
            random_warp(
                &workspace.patch_gray,
                &mut workspace.warped_gray,
                width,
                height,
                self.config.random_seed,
            );
            preprocess(
                &workspace.warped_gray,
                &workspace.hann,
                &self.log_lut,
                self.config.epsilon,
                &mut workspace.preprocessed,
            );
            workspace.forward_model_spectrum();
            workspace.accumulate_current_sample();
        }
        workspace.reconstruct_filter();

        if std::env::var_os("MOSSE_REPORT_BACKEND").is_some() {
            eprintln!("mosse_tracker_backend={:?}", workspace.backend_status());
            #[cfg(all(
                target_os = "linux",
                target_arch = "aarch64",
                feature = "parallel-whole-layout-60x36"
            ))]
            if let Some(mode) = workspace.worker_activity_mode() {
                eprintln!("mosse_worker_activity_mode={mode:?}");
                if mode == WorkerActivityMode::ContinuousNormalSpin {
                    eprintln!("mosse_normal_spin_launch_hint=taskset-cpu-list-0");
                }
            }
        }

        // Publish the new state only after all validation and initialization succeeds.
        self.initialized = true;
        self.center_x = center_x;
        self.center_y = center_y;
        self.window_width = width;
        self.window_height = height;
        self.workspace = Some(workspace);
        self.diagnostics = Diagnostics {
            initialized: 1,
            last_success: 1,
            updates: 0,
            window_width: width as u32,
            window_height: height as u32,
            center_x,
            center_y,
            ..Diagnostics::default()
        };
        Ok(self.current_rect())
    }

    pub fn update(&mut self, frame: BgrFrame<'_>) -> Result<UpdateResult, TrackerError> {
        if !self.initialized {
            return Err(TrackerError::NotInitialized);
        }

        #[cfg(all(
            feature = "overlap-model-raw-log-60x36",
            target_os = "linux",
            target_arch = "aarch64"
        ))]
        let localization_center = (self.center_x, self.center_y);

        #[cfg(feature = "phase-profile")]
        let _phase_update = phase_profile::begin_update();

        // Worker wakeup and the final parked-acknowledgement barrier are inside
        // this public call, hence inside the native benchmark's existing
        // update timer. With the crop pipeline enabled, ActivityBegin also
        // includes the worker-only localization crop and its completion
        // barrier. The caller remains SCHED_OTHER throughout.
        #[cfg(all(
            target_os = "linux",
            target_arch = "aarch64",
            feature = "parallel-whole-layout-60x36"
        ))]
        #[cfg(feature = "phase-profile")]
        let activity_begin_started = phase_profile::start();
        #[cfg(all(
            target_os = "linux",
            target_arch = "aarch64",
            feature = "parallel-whole-layout-60x36"
        ))]
        let (parallel_activity, localization_crop_ready) = self
            .workspace
            .as_mut()
            .map(|workspace| {
                workspace.begin_update_activity(frame, self.center_x, self.center_y, &self.log_lut)
            })
            .unwrap_or((None, false));
        #[cfg(not(all(
            target_os = "linux",
            target_arch = "aarch64",
            feature = "parallel-whole-layout-60x36"
        )))]
        let localization_crop_ready = false;
        #[cfg(all(
            feature = "phase-profile",
            target_os = "linux",
            target_arch = "aarch64",
            feature = "parallel-whole-layout-60x36"
        ))]
        phase_profile::record(phase_profile::Phase::ActivityBegin, activity_begin_started);

        let stats = self.localize(frame, localization_crop_ready);
        let success = stats.psr.is_finite() && stats.psr >= self.config.psr_threshold;

        self.diagnostics.updates = self.diagnostics.updates.saturating_add(1);
        self.diagnostics.last_success = u8::from(success);
        self.diagnostics.delta_x = stats.delta_x;
        self.diagnostics.delta_y = stats.delta_y;
        self.diagnostics.psr = stats.psr;
        self.diagnostics.peak = stats.peak;
        self.diagnostics.response_mean = stats.mean;
        self.diagnostics.response_stddev = stats.stddev;

        if success {
            self.center_x += stats.delta_x as f64;
            self.center_y += stats.delta_y as f64;
            if !can_reuse_localization_spectrum(success, stats.delta_x, stats.delta_y) {
                #[cfg(all(
                    feature = "overlap-model-raw-log-60x36",
                    target_os = "linux",
                    target_arch = "aarch64"
                ))]
                let prepared_from_raw_log_overlap = self
                    .try_prepare_model_spectrum_from_localization_raw_logs(
                        frame,
                        localization_center.0,
                        localization_center.1,
                        stats.delta_x,
                        stats.delta_y,
                    );
                #[cfg(not(all(
                    feature = "overlap-model-raw-log-60x36",
                    target_os = "linux",
                    target_arch = "aarch64"
                )))]
                let prepared_from_raw_log_overlap = false;

                if !prepared_from_raw_log_overlap {
                    self.prepare_model_spectrum(frame);
                }
            }
            self.blend_current_spectrum_into_model();
        }
        #[cfg(feature = "phase-profile")]
        phase_profile::record_outcome(success);

        self.diagnostics.center_x = self.center_x;
        self.diagnostics.center_y = self.center_y;
        let bounding_box = self.current_rect();
        let result = UpdateResult {
            success,
            bounding_box,
            diagnostics: self.diagnostics,
        };
        #[cfg(all(
            feature = "overlap-model-raw-log-60x36",
            target_os = "linux",
            target_arch = "aarch64"
        ))]
        if let Some(workspace) = self.workspace.as_mut() {
            // Zero motion reuses the spectrum, failures do not train, and a
            // fallback full crop already invalidates provenance. Clear every
            // remaining case before the next frame as a final safety boundary.
            workspace.localization_raw_log_provenance = None;
        }
        #[cfg(all(
            feature = "phase-profile",
            target_os = "linux",
            target_arch = "aarch64",
            feature = "parallel-whole-layout-60x36"
        ))]
        let activity_park_started = phase_profile::start();
        #[cfg(all(
            target_os = "linux",
            target_arch = "aarch64",
            feature = "parallel-whole-layout-60x36"
        ))]
        drop(parallel_activity);
        #[cfg(all(
            feature = "phase-profile",
            target_os = "linux",
            target_arch = "aarch64",
            feature = "parallel-whole-layout-60x36"
        ))]
        phase_profile::record(phase_profile::Phase::ActivityPark, activity_park_started);
        Ok(result)
    }

    fn current_rect(&self) -> Rect {
        Rect {
            x: self.center_x - 0.5 * self.window_width as f64,
            y: self.center_y - 0.5 * self.window_height as f64,
            width: self.window_width as f64,
            height: self.window_height as f64,
        }
    }

    fn localize(&mut self, frame: BgrFrame<'_>, localization_crop_ready: bool) -> ResponseStats {
        let workspace = self
            .workspace
            .as_mut()
            .expect("initialized tracker must own a workspace");
        #[cfg(target_arch = "aarch64")]
        workspace.prepare_localization_spectrum(
            frame,
            self.center_x,
            self.center_y,
            &self.log_lut,
            self.config.epsilon,
            localization_crop_ready,
        );
        #[cfg(not(target_arch = "aarch64"))]
        let _ = localization_crop_ready;
        #[cfg(not(target_arch = "aarch64"))]
        workspace.prepare_hot_spectrum(
            frame,
            self.center_x,
            self.center_y,
            &self.log_lut,
            self.config.epsilon,
        );
        let reduction = workspace.localize_inverse();
        #[cfg(feature = "phase-profile")]
        let stats_started = phase_profile::start();
        let stats = response_stats_from_reduction(
            reduction,
            workspace.width,
            workspace.height,
            self.config.epsilon,
        );
        #[cfg(feature = "phase-profile")]
        phase_profile::record(phase_profile::Phase::ResponseStats, stats_started);
        stats
    }

    fn prepare_model_spectrum(&mut self, frame: BgrFrame<'_>) {
        let workspace = self
            .workspace
            .as_mut()
            .expect("initialized tracker must own a workspace");
        workspace.prepare_hot_spectrum(
            frame,
            self.center_x,
            self.center_y,
            &self.log_lut,
            self.config.epsilon,
        );
    }

    #[cfg(all(
        feature = "overlap-model-raw-log-60x36",
        target_os = "linux",
        target_arch = "aarch64"
    ))]
    fn try_prepare_model_spectrum_from_localization_raw_logs(
        &mut self,
        frame: BgrFrame<'_>,
        old_center_x: f64,
        old_center_y: f64,
        delta_x: i32,
        delta_y: i32,
    ) -> bool {
        let workspace = self
            .workspace
            .as_mut()
            .expect("initialized tracker must own a workspace");
        workspace.try_prepare_hot_spectrum_from_localization_raw_logs(
            frame,
            old_center_x,
            old_center_y,
            self.center_x,
            self.center_y,
            delta_x,
            delta_y,
            &self.log_lut,
            self.config.epsilon,
        )
    }

    fn blend_current_spectrum_into_model(&mut self) {
        let workspace = self
            .workspace
            .as_mut()
            .expect("initialized tracker must own a workspace");
        let rate = self.config.learning_rate as f32;
        #[cfg(feature = "phase-profile")]
        let blend_started = phase_profile::start();
        workspace.blend_current_sample(rate);
        #[cfg(feature = "phase-profile")]
        phase_profile::record(phase_profile::Phase::ModelBlendAndFilter, blend_started);
    }
}

#[cfg(feature = "phase-profile")]
impl Drop for MosseTracker {
    fn drop(&mut self) {
        phase_profile::report();
    }
}

impl Default for MosseTracker {
    fn default() -> Self {
        Self::new(MosseConfig::default()).expect("default MOSSE config must be valid")
    }
}

#[derive(Clone, Copy, Debug)]
struct ResponseStats {
    peak: f64,
    mean: f64,
    stddev: f64,
    psr: f64,
    delta_x: i32,
    delta_y: i32,
}

/// Dispatch one exact model blend/filter task per padded spectrum batch.
///
/// The production caller already holds the tracker-wide activity scope, so
/// this helper accounts only for the publication and completion barrier of
/// this phase. Tests drive the same helper through the real unconfigured
/// four-lane runtime.
#[cfg(all(
    feature = "parallel-model-blend-filter-60x36",
    any(test, all(target_os = "linux", target_arch = "aarch64"))
))]
#[allow(clippy::too_many_arguments)]
fn dispatch_parallel_model_blend_filter(
    runtime: &mut crate::four_core_runtime::FourCoreRuntime,
    goal: &PaddedSpectrum,
    sample: &PaddedSpectrum,
    numerator: &mut PaddedSpectrum,
    denominator: &mut PaddedSpectrum,
    filter: &mut PaddedSpectrum,
    rate: f32,
) {
    let mut tasks = bind_blend_filter_batches(goal, sample, numerator, denominator, filter, rate);
    runtime.dispatch(&mut tasks, |_, task| task.run());
}

#[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
#[inline(always)]
fn padded_value(spectrum: &PaddedSpectrum, batch: usize, ky: usize, lane: usize) -> Complex32 {
    Complex32::new(
        spectrum.batches[batch].re[ky][lane],
        spectrum.batches[batch].im[ky][lane],
    )
}

#[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
#[inline(always)]
fn padded_store(
    spectrum: &mut PaddedSpectrum,
    batch: usize,
    ky: usize,
    lane: usize,
    value: Complex32,
) {
    spectrum.batches[batch].re[ky][lane] = value.re;
    spectrum.batches[batch].im[ky][lane] = value.im;
}

#[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
fn padded_accumulate_current_sample(workspace: &mut FixedPaddedSpectralWorkspace) {
    for batch in 0..PADDED_COLUMN_BATCHES {
        for ky in 0..PADDED_HEIGHT {
            for lane in 0..PADDED_LANES {
                let sample = padded_value(&workspace.spectrum, batch, ky, lane);
                let goal = padded_value(&workspace.goal_spectrum, batch, ky, lane);
                let numerator_new = goal * sample.conj();
                let denominator_new = sample * sample.conj();
                let numerator = padded_value(&workspace.numerator, batch, ky, lane);
                let denominator = padded_value(&workspace.denominator, batch, ky, lane);
                padded_store(
                    &mut workspace.numerator,
                    batch,
                    ky,
                    lane,
                    numerator + numerator_new,
                );
                padded_store(
                    &mut workspace.denominator,
                    batch,
                    ky,
                    lane,
                    denominator + denominator_new,
                );
            }
        }
    }
}

#[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
fn padded_reconstruct_filter(workspace: &mut FixedPaddedSpectralWorkspace) {
    for batch in 0..PADDED_COLUMN_BATCHES {
        for ky in 0..PADDED_HEIGHT {
            for lane in 0..PADDED_LANES {
                let lhs = padded_value(&workspace.numerator, batch, ky, lane);
                let rhs = padded_value(&workspace.denominator, batch, ky, lane);
                let divisor = rhs.re * rhs.re + rhs.im * rhs.im;
                let value = if divisor > 0.0 && divisor.is_finite() {
                    Complex32::new(
                        (lhs.re * rhs.re + lhs.im * rhs.im) / divisor,
                        -(lhs.im * rhs.re + lhs.re * rhs.im) / divisor,
                    )
                } else {
                    Complex32::new(0.0, 0.0)
                };
                padded_store(&mut workspace.filter, batch, ky, lane, value);
            }
        }
    }
}

#[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
#[target_feature(enable = "neon")]
unsafe fn padded_multiply_localization_spectrum_neon(
    sample: &PaddedSpectrum,
    filter: &PaddedSpectrum,
    response: &mut PaddedSpectrum,
) {
    use core::arch::aarch64::{vaddq_f32, vld1q_f32, vmulq_f32, vnegq_f32, vst1q_f32, vsubq_f32};

    for batch in 0..PADDED_COLUMN_BATCHES {
        for ky in 0..PADDED_HEIGHT {
            // SAFETY: each source and destination is exactly one `[f32; 4]`.
            // AArch64 always provides NEON, and this function has the matching
            // target feature.
            unsafe {
                let sample_re = vld1q_f32(sample.batches[batch].re[ky].as_ptr());
                let sample_im = vld1q_f32(sample.batches[batch].im[ky].as_ptr());
                let filter_re = vld1q_f32(filter.batches[batch].re[ky].as_ptr());
                let filter_im = vnegq_f32(vld1q_f32(filter.batches[batch].im[ky].as_ptr()));
                let response_re = vsubq_f32(
                    vmulq_f32(sample_re, filter_re),
                    vmulq_f32(sample_im, filter_im),
                );
                let response_im = vaddq_f32(
                    vmulq_f32(sample_re, filter_im),
                    vmulq_f32(sample_im, filter_re),
                );
                vst1q_f32(response.batches[batch].re[ky].as_mut_ptr(), response_re);
                vst1q_f32(response.batches[batch].im[ky].as_mut_ptr(), response_im);
            }
        }
    }
}

#[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
fn padded_multiply_localization_spectrum(workspace: &mut FixedPaddedSpectralWorkspace) {
    // SAFETY: NEON is mandatory on AArch64. Every load/store in the helper is
    // bounded to one fixed four-lane row of the persistent padded layout.
    unsafe {
        padded_multiply_localization_spectrum_neon(
            &workspace.spectrum,
            &workspace.filter,
            &mut workspace.response_spectrum,
        );
    }
}

#[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
fn padded_blend_current_sample(workspace: &mut FixedPaddedSpectralWorkspace, rate: f32) {
    let keep = 1.0 - rate;
    for batch in 0..PADDED_COLUMN_BATCHES {
        for ky in 0..PADDED_HEIGHT {
            for lane in 0..PADDED_LANES {
                let sample = padded_value(&workspace.spectrum, batch, ky, lane);
                let goal = padded_value(&workspace.goal_spectrum, batch, ky, lane);
                let numerator_new = goal * sample.conj();
                let denominator_new = sample * sample.conj();
                let numerator = padded_value(&workspace.numerator, batch, ky, lane);
                let denominator = padded_value(&workspace.denominator, batch, ky, lane);
                padded_store(
                    &mut workspace.numerator,
                    batch,
                    ky,
                    lane,
                    numerator * keep + numerator_new * rate,
                );
                padded_store(
                    &mut workspace.denominator,
                    batch,
                    ky,
                    lane,
                    denominator * keep + denominator_new * rate,
                );
            }
        }
    }
    padded_reconstruct_filter(workspace);
}

#[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
fn reduce_fixed_inverse_output(unscaled: &[f32]) -> InverseReduction {
    debug_assert_eq!(unscaled.len(), PADDED_SPATIAL_LEN);
    let scale = 1.0 / PADDED_SPATIAL_LEN as f32;
    let mut maximum = f32::NEG_INFINITY;
    let mut maximum_index = 0usize;
    let mut sum = 0.0f64;
    let mut sum_of_squares = 0.0f64;
    for (index, &value) in unscaled.iter().enumerate() {
        let value = value * scale;
        if value > maximum {
            maximum = value;
            maximum_index = index;
        }
        let value = value as f64;
        sum += value;
        sum_of_squares += value * value;
    }
    InverseReduction {
        maximum,
        maximum_index,
        sum,
        sum_of_squares,
    }
}

fn multiply_localization_spectrum_scalar(
    sample: &[Complex32],
    filter: &[Complex32],
    response: &mut [Complex32],
) {
    debug_assert_eq!(sample.len(), filter.len());
    debug_assert_eq!(sample.len(), response.len());
    for i in 0..response.len() {
        response[i] = sample[i] * filter[i].conj();
    }
}

#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
unsafe fn multiply_localization_spectrum_neon(
    sample: &[Complex32],
    filter: &[Complex32],
    response: &mut [Complex32],
) {
    use core::arch::aarch64::{
        float32x4x2_t, vaddq_f32, vld2q_f32, vmulq_f32, vnegq_f32, vst2q_f32, vsubq_f32,
    };

    assert_eq!(sample.len(), filter.len());
    assert_eq!(sample.len(), response.len());
    let vectorized_len = sample.len() / 4 * 4;
    let mut index = 0;
    while index < vectorized_len {
        // SAFETY: the equal-length assertions above and `index + 4 <=
        // vectorized_len` keep both four-complex loads in bounds. Complex32 is
        // an interleaved pair of f32 values.
        let (sample_parts, filter_parts) = unsafe {
            (
                vld2q_f32(sample.as_ptr().add(index).cast::<f32>()),
                vld2q_f32(filter.as_ptr().add(index).cast::<f32>()),
            )
        };
        let conjugated_filter_im = vnegq_f32(filter_parts.1);
        let real_left = vmulq_f32(sample_parts.0, filter_parts.0);
        let real_right = vmulq_f32(sample_parts.1, conjugated_filter_im);
        let response_re = vsubq_f32(real_left, real_right);
        let imaginary_left = vmulq_f32(sample_parts.0, conjugated_filter_im);
        let imaginary_right = vmulq_f32(sample_parts.1, filter_parts.0);
        let response_im = vaddq_f32(imaginary_left, imaginary_right);

        // SAFETY: the same loop bound keeps this four-complex store in bounds,
        // and the mutable response borrow cannot alias either input borrow.
        unsafe {
            vst2q_f32(
                response.as_mut_ptr().add(index).cast::<f32>(),
                float32x4x2_t(response_re, response_im),
            );
        }
        index += 4;
    }

    multiply_localization_spectrum_scalar(
        &sample[vectorized_len..],
        &filter[vectorized_len..],
        &mut response[vectorized_len..],
    );
}

fn multiply_localization_spectrum(
    sample: &[Complex32],
    filter: &[Complex32],
    response: &mut [Complex32],
) {
    assert_eq!(sample.len(), filter.len());
    assert_eq!(sample.len(), response.len());

    #[cfg(target_arch = "aarch64")]
    {
        if std::arch::is_aarch64_feature_detected!("neon") {
            // SAFETY: feature detection establishes NEON support; the helper
            // validates equal slice lengths before its bounded loads/stores.
            unsafe {
                multiply_localization_spectrum_neon(sample, filter, response);
            }
        } else {
            multiply_localization_spectrum_scalar(sample, filter, response);
        }
    }
    #[cfg(not(target_arch = "aarch64"))]
    {
        multiply_localization_spectrum_scalar(sample, filter, response);
    }
}

fn can_reuse_localization_spectrum(success: bool, delta_x: i32, delta_y: i32) -> bool {
    success && delta_x == 0 && delta_y == 0
}

fn validate_bounding_box(frame: BgrFrame<'_>, rect: Rect) -> Result<(), TrackerError> {
    let values = [rect.x, rect.y, rect.width, rect.height];
    if values.iter().any(|value| !value.is_finite())
        || rect.width < 2.0
        || rect.height < 2.0
        || rect.width >= usize::MAX as f64
        || rect.height >= usize::MAX as f64
    {
        return Err(TrackerError::InvalidBoundingBox);
    }

    // Keep coordinate conversion and interpolation arithmetic in a conservative range.
    let coordinate_limit = i32::MAX as f64 * 0.25;
    let center_x = rect.x + 0.5 * rect.width;
    let center_y = rect.y + 0.5 * rect.height;
    if center_x.abs() > coordinate_limit
        || center_y.abs() > coordinate_limit
        || rect.width > coordinate_limit
        || rect.height > coordinate_limit
    {
        return Err(TrackerError::InvalidBoundingBox);
    }

    // OpenCV supports partially out-of-frame rectangles through border replication, but an ROI
    // completely detached from the image is almost certainly a caller error.
    if rect.x >= frame.width as f64
        || rect.y >= frame.height as f64
        || rect.x + rect.width <= 0.0
        || rect.y + rect.height <= 0.0
    {
        return Err(TrackerError::InvalidBoundingBox);
    }
    Ok(())
}

pub(crate) fn optimal_dft_size(value: usize) -> Option<usize> {
    if value == 0 {
        return None;
    }
    let mut candidate = value;
    loop {
        let mut remainder = candidate;
        for factor in [2, 3, 5] {
            while (remainder / factor) * factor == remainder {
                remainder /= factor;
            }
        }
        if remainder == 1 {
            return Some(candidate);
        }
        candidate = candidate.checked_add(1)?;
    }
}

fn create_hann_window(width: usize, height: usize, output: &mut [f32]) {
    debug_assert_eq!(output.len(), width * height);
    let x_scale = 2.0 * std::f64::consts::PI / (width - 1) as f64;
    let y_scale = 2.0 * std::f64::consts::PI / (height - 1) as f64;
    let x_window: Vec<f64> = (0..width)
        .map(|x| 0.5 * (1.0 - (x_scale * x as f64).cos()))
        .collect();
    for y in 0..height {
        let wy = 0.5 * (1.0 - (y_scale * y as f64).cos());
        for x in 0..width {
            output[y * width + x] = (wy * x_window[x]).sqrt() as f32;
        }
    }
}

fn gaussian_goal(width: usize, height: usize, sigma: f64, output: &mut [f32]) {
    debug_assert_eq!(output.len(), width * height);
    output.fill(0.0);
    output[(height / 2) * width + width / 2] = 1.0;

    // OpenCV's automatic CV_32F Gaussian kernel uses approximately 4 sigma per side.
    let radius = (sigma * 4.0).round() as isize;
    let mut kernel: Vec<f64> = (-radius..=radius)
        .map(|offset| (-0.5 * (offset as f64 / sigma).powi(2)).exp())
        .collect();
    let kernel_sum: f64 = kernel.iter().sum();
    for value in &mut kernel {
        *value /= kernel_sum;
    }

    let mut temporary = vec![0.0f32; output.len()];
    for y in 0..height {
        for x in 0..width {
            let mut sum = 0.0;
            for (kernel_index, &weight) in kernel.iter().enumerate() {
                let offset = kernel_index as isize - radius;
                let source_x = border_reflect_101(x as isize + offset, width);
                sum += output[y * width + source_x] as f64 * weight;
            }
            temporary[y * width + x] = sum as f32;
        }
    }
    for y in 0..height {
        for x in 0..width {
            let mut sum = 0.0;
            for (kernel_index, &weight) in kernel.iter().enumerate() {
                let offset = kernel_index as isize - radius;
                let source_y = border_reflect_101(y as isize + offset, height);
                sum += temporary[source_y * width + x] as f64 * weight;
            }
            output[y * width + x] = sum as f32;
        }
    }

    let maximum = output.iter().copied().fold(0.0f32, f32::max);
    if maximum > 0.0 {
        for value in output {
            *value /= maximum;
        }
    }
}

fn create_log_lut() -> [f32; 256] {
    std::array::from_fn(|pixel| (pixel as f32 + 1.0).ln())
}

#[derive(Clone, Copy, Debug)]
struct LogMoments {
    sum: f64,
    #[cfg(target_arch = "x86_64")]
    square_sum: f64,
}

#[cfg(all(
    target_os = "linux",
    target_arch = "aarch64",
    feature = "fused-normalize-forward-60x36"
))]
#[derive(Clone, Copy, Debug)]
struct FusedNormalization {
    mean: f32,
    denominator: f32,
}

impl LogMoments {
    #[inline(always)]
    fn new() -> Self {
        Self {
            sum: 0.0,
            #[cfg(target_arch = "x86_64")]
            square_sum: 0.0,
        }
    }

    #[inline(always)]
    fn add(&mut self, value: f32) {
        let value = value as f64;
        self.sum += value;
        #[cfg(target_arch = "x86_64")]
        {
            self.square_sum += value * value;
        }
    }
}

fn lookup_log_values_and_sum(input: &[u8], log_lut: &[f32; 256], output: &mut [f32]) -> f64 {
    debug_assert_eq!(input.len(), output.len());

    let mut sum = 0.0f64;
    for (dst, &pixel) in output.iter_mut().zip(input) {
        let value = log_lut[pixel as usize];
        *dst = value;
        sum += value as f64;
    }
    sum
}

fn preprocess(input: &[u8], hann: &[f32], log_lut: &[f32; 256], epsilon: f64, output: &mut [f32]) {
    debug_assert_eq!(input.len(), hann.len());
    debug_assert_eq!(input.len(), output.len());

    let sum = lookup_log_values_and_sum(input, log_lut, output);
    finish_preprocess_from_log_sum(output, hann, sum, epsilon);
}

fn finish_preprocess_from_log_sum(log_values: &mut [f32], hann: &[f32], sum: f64, epsilon: f64) {
    debug_assert_eq!(log_values.len(), hann.len());

    let mean = sum / log_values.len() as f64;
    let mut squared_deviation_sum = 0.0f64;
    for &value in log_values.iter() {
        let deviation = value as f64 - mean;
        squared_deviation_sum += deviation * deviation;
    }
    let stddev = (squared_deviation_sum / log_values.len() as f64).sqrt();
    let denominator = (stddev + epsilon) as f32;
    let mean = mean as f32;
    for i in 0..log_values.len() {
        log_values[i] = ((log_values[i] - mean) / denominator) * hann[i];
    }
}

#[cfg(all(
    target_os = "linux",
    target_arch = "aarch64",
    feature = "fused-normalize-forward-60x36"
))]
fn fused_normalization_parameters(
    log_values: &[f32],
    sum: f64,
    epsilon: f64,
) -> FusedNormalization {
    let mean = sum / log_values.len() as f64;
    let mut squared_deviation_sum = 0.0f64;
    // This remains one caller-side row-major dependent accumulation so its
    // f64 addition order is identical to `finish_preprocess_from_log_sum`.
    for &value in log_values {
        let deviation = value as f64 - mean;
        squared_deviation_sum += deviation * deviation;
    }
    let stddev = (squared_deviation_sum / log_values.len() as f64).sqrt();
    FusedNormalization {
        denominator: (stddev + epsilon) as f32,
        mean: mean as f32,
    }
}

fn finish_hot_preprocess(log_values: &mut [f32], hann: &[f32], moments: LogMoments, epsilon: f64) {
    #[cfg(not(target_arch = "x86_64"))]
    {
        finish_preprocess_from_log_sum(log_values, hann, moments.sum, epsilon);
    }

    #[cfg(target_arch = "x86_64")]
    {
        debug_assert_eq!(log_values.len(), hann.len());

        let count = log_values.len() as f64;
        let mean = moments.sum / count;
        let variance = (moments.square_sum / count - mean * mean).max(0.0);
        let denominator = (variance.sqrt() + epsilon) as f32;
        let mean = mean as f32;
        for i in 0..log_values.len() {
            log_values[i] = ((log_values[i] - mean) / denominator) * hann[i];
        }
    }
}

fn reconstruct_filter(
    numerator: &[Complex32],
    denominator: &[Complex32],
    filter: &mut [Complex32],
) {
    debug_assert_eq!(numerator.len(), denominator.len());
    debug_assert_eq!(numerator.len(), filter.len());
    for i in 0..filter.len() {
        let lhs = numerator[i];
        let rhs = denominator[i];
        let divisor = rhs.re * rhs.re + rhs.im * rhs.im;
        filter[i] = if divisor > 0.0 && divisor.is_finite() {
            // Match OpenCV TrackerMOSSE::divDFTs exactly. In normal MOSSE state B is
            // real, so this stores conj(A) / B; correlate() subsequently conjugates H.
            Complex32::new(
                (lhs.re * rhs.re + lhs.im * rhs.im) / divisor,
                -(lhs.im * rhs.re + lhs.re * rhs.im) / divisor,
            )
        } else {
            Complex32::new(0.0, 0.0)
        };
    }
}

fn response_stats_from_reduction(
    reduction: InverseReduction,
    width: usize,
    height: usize,
    epsilon: f64,
) -> ResponseStats {
    let count = (width * height) as f64;
    let mean = reduction.sum / count;
    let variance = (reduction.sum_of_squares / count - mean * mean).max(0.0);
    let stddev = variance.sqrt();
    let peak = reduction.maximum as f64;
    let max_x = reduction.maximum_index % width;
    let max_y = reduction.maximum_index / width;
    ResponseStats {
        peak,
        mean,
        stddev,
        psr: (peak - mean) / (stddev + epsilon),
        delta_x: max_x as i32 - (width / 2) as i32,
        delta_y: max_y as i32 - (height / 2) as i32,
    }
}

#[cfg(test)]
fn response_stats(response: &[f32], width: usize, height: usize, epsilon: f64) -> ResponseStats {
    debug_assert_eq!(response.len(), width * height);
    let mut maximum = f32::NEG_INFINITY;
    let mut maximum_index = 0usize;
    let mut sum = 0.0f64;
    let mut sum_of_squares = 0.0f64;
    for (index, &value) in response.iter().enumerate() {
        if value > maximum {
            maximum = value;
            maximum_index = index;
        }
        let value = value as f64;
        sum += value;
        sum_of_squares += value * value;
    }
    response_stats_from_reduction(
        InverseReduction {
            maximum,
            maximum_index,
            sum,
            sum_of_squares,
        },
        width,
        height,
        epsilon,
    )
}

fn bgr_frame_to_gray(frame: BgrFrame<'_>, output: &mut [u8]) {
    debug_assert_eq!(output.len(), frame.width * frame.height);
    for y in 0..frame.height {
        for x in 0..frame.width {
            output[y * frame.width + x] = bgr_to_gray(
                frame.channel(x, y, 0),
                frame.channel(x, y, 1),
                frame.channel(x, y, 2),
            );
        }
    }
}

#[inline]
fn bgr_to_gray(blue: u8, green: u8, red: u8) -> u8 {
    // OpenCV's fixed-point BT.601 BGR8 conversion coefficients (14-bit shift).
    const BLUE_TO_Y: u32 = 1_868;
    const GREEN_TO_Y: u32 = 9_617;
    const RED_TO_Y: u32 = 4_899;
    const ROUND: u32 = 1 << 13;
    let value = blue as u32 * BLUE_TO_Y + green as u32 * GREEN_TO_Y + red as u32 * RED_TO_Y + ROUND;
    (value >> 14) as u8
}

const FIXED_HOT_PATCH_WIDTH: usize = 60;
const FIXED_HOT_PATCH_HEIGHT: usize = 36;

#[allow(clippy::too_many_arguments)]
fn get_rect_subpix_gray(
    input: &[u8],
    input_width: usize,
    input_height: usize,
    center_x: f64,
    center_y: f64,
    patch_width: usize,
    patch_height: usize,
    output: &mut [u8],
) {
    debug_assert_eq!(input.len(), input_width * input_height);
    debug_assert_eq!(output.len(), patch_width * patch_height);
    let start_x = center_x - 0.5 * (patch_width - 1) as f64;
    let start_y = center_y - 0.5 * (patch_height - 1) as f64;
    for y in 0..patch_height {
        for x in 0..patch_width {
            let value = sample_gray_replicate(
                input,
                input_width,
                input_height,
                start_x + x as f64,
                start_y + y as f64,
            );
            output[y * patch_width + x] = saturating_round_u8(value);
        }
    }
}

#[cfg(test)]
#[allow(clippy::too_many_arguments)]
fn get_rect_subpix_bgr_then_gray(
    frame: BgrFrame<'_>,
    center_x: f64,
    center_y: f64,
    patch_width: usize,
    patch_height: usize,
    patch_gray: &mut [u8],
) -> SubpixelSamplingPath {
    let start_x = center_x - 0.5 * (patch_width - 1) as f64;
    let start_y = center_y - 0.5 * (patch_height - 1) as f64;
    if let Some((origin_x, origin_y)) = half_pixel_interior_origin(
        start_x,
        start_y,
        patch_width,
        patch_height,
        frame.width,
        frame.height,
    ) {
        get_rect_subpix_bgr_then_gray_half_pixel_interior(
            frame,
            origin_x,
            origin_y,
            patch_width,
            patch_height,
            patch_gray,
        );
        SubpixelSamplingPath::HalfPixelInterior
    } else {
        get_rect_subpix_bgr_then_gray_generic(
            frame,
            center_x,
            center_y,
            patch_width,
            patch_height,
            patch_gray,
        );
        SubpixelSamplingPath::Generic
    }
}

#[allow(clippy::too_many_arguments)]
fn get_rect_subpix_bgr_to_log(
    frame: BgrFrame<'_>,
    center_x: f64,
    center_y: f64,
    patch_width: usize,
    patch_height: usize,
    log_lut: &[f32; 256],
    log_values: &mut [f32],
) -> (SubpixelSamplingPath, LogMoments) {
    let start_x = center_x - 0.5 * (patch_width - 1) as f64;
    let start_y = center_y - 0.5 * (patch_height - 1) as f64;
    if let Some((origin_x, origin_y)) = half_pixel_interior_origin(
        start_x,
        start_y,
        patch_width,
        patch_height,
        frame.width,
        frame.height,
    ) {
        let sum = get_rect_subpix_bgr_to_log_half_pixel_interior(
            frame,
            origin_x,
            origin_y,
            patch_width,
            patch_height,
            log_lut,
            log_values,
        );
        (SubpixelSamplingPath::HalfPixelInterior, sum)
    } else {
        let sum = get_rect_subpix_bgr_to_log_generic(
            frame,
            center_x,
            center_y,
            patch_width,
            patch_height,
            log_lut,
            log_values,
        );
        (SubpixelSamplingPath::Generic, sum)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum SubpixelSamplingPath {
    HalfPixelInterior,
    Generic,
}

#[cfg(all(
    feature = "overlap-model-raw-log-60x36",
    any(test, all(target_os = "linux", target_arch = "aarch64"))
))]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct RawLogProvenance {
    origin_x: usize,
    origin_y: usize,
    frame_data: usize,
    frame_len: usize,
    frame_width: usize,
    frame_height: usize,
    frame_stride: usize,
}

#[cfg(all(
    feature = "overlap-model-raw-log-60x36",
    any(test, all(target_os = "linux", target_arch = "aarch64"))
))]
impl RawLogProvenance {
    fn for_center(
        frame: BgrFrame<'_>,
        center_x: f64,
        center_y: f64,
        patch_width: usize,
        patch_height: usize,
    ) -> Option<Self> {
        let start_x = center_x - 0.5 * (patch_width - 1) as f64;
        let start_y = center_y - 0.5 * (patch_height - 1) as f64;
        let (origin_x, origin_y) = half_pixel_interior_origin(
            start_x,
            start_y,
            patch_width,
            patch_height,
            frame.width,
            frame.height,
        )?;
        Some(Self {
            origin_x,
            origin_y,
            frame_data: frame.data.as_ptr() as usize,
            frame_len: frame.data.len(),
            frame_width: frame.width,
            frame_height: frame.height,
            frame_stride: frame.stride,
        })
    }

    fn matches_frame(self, frame: BgrFrame<'_>) -> bool {
        self.frame_data == frame.data.as_ptr() as usize
            && self.frame_len == frame.data.len()
            && self.frame_width == frame.width
            && self.frame_height == frame.height
            && self.frame_stride == frame.stride
    }
}

#[cfg(all(
    feature = "overlap-model-raw-log-60x36",
    any(test, all(target_os = "linux", target_arch = "aarch64"))
))]
#[derive(Clone, Copy, Debug)]
struct RawLogReduction {
    sum: f64,
    mean: f32,
    denominator: f32,
    sampled_values: usize,
}

#[cfg(all(
    feature = "overlap-model-raw-log-60x36",
    any(test, all(target_os = "linux", target_arch = "aarch64"))
))]
fn raw_log_reuse_backend_supported(
    backend: TrackerBackendStatus,
    patch_width: usize,
    patch_height: usize,
) -> bool {
    backend == TrackerBackendStatus::FixedPaddedFourCore
        && patch_width == FIXED_HOT_PATCH_WIDTH
        && patch_height == FIXED_HOT_PATCH_HEIGHT
}

#[cfg(all(
    feature = "overlap-model-raw-log-60x36",
    any(test, all(target_os = "linux", target_arch = "aarch64"))
))]
fn checked_shift_origin(origin: usize, delta: i32) -> Option<usize> {
    if delta >= 0 {
        origin.checked_add(delta as usize)
    } else {
        origin.checked_sub(delta.unsigned_abs() as usize)
    }
}

#[cfg(all(
    feature = "overlap-model-raw-log-60x36",
    any(test, all(target_os = "linux", target_arch = "aarch64"))
))]
#[inline(always)]
fn sample_half_pixel_bgr_log(
    frame: BgrFrame<'_>,
    sample_x: usize,
    sample_y: usize,
    log_lut: &[f32; 256],
) -> f32 {
    let row0 = sample_y * frame.stride;
    let row1 = row0 + frame.stride;
    let top_left = row0 + sample_x * 3;
    let top_right = top_left + 3;
    let bottom_left = row1 + sample_x * 3;
    let bottom_right = bottom_left + 3;

    let blue = rounded_quarter_sum(
        frame.data[top_left],
        frame.data[top_right],
        frame.data[bottom_left],
        frame.data[bottom_right],
    );
    let green = rounded_quarter_sum(
        frame.data[top_left + 1],
        frame.data[top_right + 1],
        frame.data[bottom_left + 1],
        frame.data[bottom_right + 1],
    );
    let red = rounded_quarter_sum(
        frame.data[top_left + 2],
        frame.data[top_right + 2],
        frame.data[bottom_left + 2],
        frame.data[bottom_right + 2],
    );
    log_lut[bgr_to_gray(blue, green, red) as usize]
}

/// Rebase immutable localization raw logs onto a moved model patch.
///
/// Every provenance, geometry, overlap, and origin/delta condition is checked
/// before the first `copy_within`. Returning `None` is therefore a strictly
/// non-mutating request for the retained full model preprocessing path.
#[cfg(all(
    feature = "overlap-model-raw-log-60x36",
    any(test, all(target_os = "linux", target_arch = "aarch64"))
))]
#[allow(clippy::too_many_arguments)]
fn try_reuse_model_raw_logs(
    frame: BgrFrame<'_>,
    provenance: RawLogProvenance,
    old_center_x: f64,
    old_center_y: f64,
    new_center_x: f64,
    new_center_y: f64,
    delta_x: i32,
    delta_y: i32,
    patch_width: usize,
    patch_height: usize,
    log_lut: &[f32; 256],
    log_values: &mut [f32],
    epsilon: f64,
) -> Option<RawLogReduction> {
    if patch_width != FIXED_HOT_PATCH_WIDTH
        || patch_height != FIXED_HOT_PATCH_HEIGHT
        || log_values.len() != patch_width.checked_mul(patch_height)?
        || (delta_x == 0 && delta_y == 0)
        || delta_x.unsigned_abs() as usize >= patch_width
        || delta_y.unsigned_abs() as usize >= patch_height
        || new_center_x != old_center_x + delta_x as f64
        || new_center_y != old_center_y + delta_y as f64
        || !provenance.matches_frame(frame)
    {
        return None;
    }

    let old =
        RawLogProvenance::for_center(frame, old_center_x, old_center_y, patch_width, patch_height)?;
    let new =
        RawLogProvenance::for_center(frame, new_center_x, new_center_y, patch_width, patch_height)?;
    if old != provenance
        || checked_shift_origin(old.origin_x, delta_x)? != new.origin_x
        || checked_shift_origin(old.origin_y, delta_y)? != new.origin_y
    {
        return None;
    }

    let delta_x_abs = delta_x.unsigned_abs() as usize;
    let delta_y_abs = delta_y.unsigned_abs() as usize;
    let overlap_width = patch_width - delta_x_abs;
    let overlap_height = patch_height - delta_y_abs;
    let destination_x_start = if delta_x < 0 { delta_x_abs } else { 0 };
    let destination_y_start = if delta_y < 0 { delta_y_abs } else { 0 };
    let destination_x_end = destination_x_start + overlap_width;
    let destination_y_end = destination_y_start + overlap_height;

    // A positive y displacement reads lower source rows and copies upward, so
    // ascending order cannot overwrite a later source. A negative displacement
    // copies downward and therefore traverses destination rows in reverse.
    if delta_y >= 0 {
        for destination_y in destination_y_start..destination_y_end {
            let source_y = checked_shift_origin(destination_y, delta_y)
                .expect("validated overlap source row must be in range");
            let source_x = checked_shift_origin(destination_x_start, delta_x)
                .expect("validated overlap source column must be in range");
            let source_start = source_y * patch_width + source_x;
            let destination_start = destination_y * patch_width + destination_x_start;
            log_values.copy_within(
                source_start..source_start + overlap_width,
                destination_start,
            );
        }
    } else {
        for destination_y in (destination_y_start..destination_y_end).rev() {
            let source_y = checked_shift_origin(destination_y, delta_y)
                .expect("validated overlap source row must be in range");
            let source_x = checked_shift_origin(destination_x_start, delta_x)
                .expect("validated overlap source column must be in range");
            let source_start = source_y * patch_width + source_x;
            let destination_start = destination_y * patch_width + destination_x_start;
            log_values.copy_within(
                source_start..source_start + overlap_width,
                destination_start,
            );
        }
    }

    // Fill only the entering top/bottom rows and left/right columns. The full
    // reductions deliberately happen afterward in their retained row-major
    // order, independent of this sampling order.
    let mut sampled_values = 0usize;
    for y in 0..patch_height {
        let (left_end, right_start) = if (destination_y_start..destination_y_end).contains(&y) {
            (destination_x_start, destination_x_end)
        } else {
            (patch_width, patch_width)
        };
        for x in 0..left_end {
            log_values[y * patch_width + x] =
                sample_half_pixel_bgr_log(frame, new.origin_x + x, new.origin_y + y, log_lut);
            sampled_values += 1;
        }
        for x in right_start..patch_width {
            log_values[y * patch_width + x] =
                sample_half_pixel_bgr_log(frame, new.origin_x + x, new.origin_y + y, log_lut);
            sampled_values += 1;
        }
    }
    debug_assert_eq!(
        sampled_values,
        patch_width * patch_height - overlap_width * overlap_height
    );

    // These are the same two complete dependent f64 chains used by retained
    // AArch64 preprocessing: sum first, then squared deviation after the mean.
    let mut sum = 0.0f64;
    for &value in log_values.iter() {
        sum += value as f64;
    }
    let mean = sum / log_values.len() as f64;
    let mut squared_deviation_sum = 0.0f64;
    for &value in log_values.iter() {
        let deviation = value as f64 - mean;
        squared_deviation_sum += deviation * deviation;
    }
    let stddev = (squared_deviation_sum / log_values.len() as f64).sqrt();
    Some(RawLogReduction {
        sum,
        mean: mean as f32,
        denominator: (stddev + epsilon) as f32,
        sampled_values,
    })
}

#[allow(clippy::too_many_arguments)]
fn half_pixel_interior_origin(
    start_x: f64,
    start_y: f64,
    patch_width: usize,
    patch_height: usize,
    frame_width: usize,
    frame_height: usize,
) -> Option<(usize, usize)> {
    let floor_x = start_x.floor();
    let floor_y = start_y.floor();
    if start_x - floor_x != 0.5 || start_y - floor_y != 0.5 {
        return None;
    }

    let origin_x = floor_x as isize;
    let origin_y = floor_y as isize;
    if origin_x < 0 || origin_y < 0 {
        return None;
    }
    let origin_x = origin_x as usize;
    let origin_y = origin_y as usize;

    // The last sample reads one pixel to its right and below.
    let right_neighbor = origin_x.checked_add(patch_width)?;
    let bottom_neighbor = origin_y.checked_add(patch_height)?;
    if right_neighbor >= frame_width || bottom_neighbor >= frame_height {
        return None;
    }
    Some((origin_x, origin_y))
}

#[cfg(test)]
#[allow(clippy::too_many_arguments)]
fn get_rect_subpix_bgr_then_gray_half_pixel_interior(
    frame: BgrFrame<'_>,
    origin_x: usize,
    origin_y: usize,
    patch_width: usize,
    patch_height: usize,
    patch_gray: &mut [u8],
) {
    debug_assert_eq!(patch_gray.len(), patch_width * patch_height);
    for y in 0..patch_height {
        let row0 = (origin_y + y) * frame.stride;
        let row1 = row0 + frame.stride;
        for x in 0..patch_width {
            let top_left = row0 + (origin_x + x) * 3;
            let top_right = top_left + 3;
            let bottom_left = row1 + (origin_x + x) * 3;
            let bottom_right = bottom_left + 3;

            let blue = rounded_quarter_sum(
                frame.data[top_left],
                frame.data[top_right],
                frame.data[bottom_left],
                frame.data[bottom_right],
            );
            let green = rounded_quarter_sum(
                frame.data[top_left + 1],
                frame.data[top_right + 1],
                frame.data[bottom_left + 1],
                frame.data[bottom_right + 1],
            );
            let red = rounded_quarter_sum(
                frame.data[top_left + 2],
                frame.data[top_right + 2],
                frame.data[bottom_left + 2],
                frame.data[bottom_right + 2],
            );

            patch_gray[y * patch_width + x] = bgr_to_gray(blue, green, red);
        }
    }
}

#[allow(clippy::too_many_arguments)]
fn get_rect_subpix_bgr_to_log_half_pixel_interior(
    frame: BgrFrame<'_>,
    origin_x: usize,
    origin_y: usize,
    patch_width: usize,
    patch_height: usize,
    log_lut: &[f32; 256],
    log_values: &mut [f32],
) -> LogMoments {
    if patch_width == FIXED_HOT_PATCH_WIDTH && patch_height == FIXED_HOT_PATCH_HEIGHT {
        #[cfg(target_arch = "aarch64")]
        {
            if std::arch::is_aarch64_feature_detected!("neon") {
                // SAFETY: runtime feature detection establishes NEON support.
                // The helper validates the fixed dimensions, interior origin,
                // frame storage, and output length before using raw pointers.
                return unsafe {
                    get_rect_subpix_bgr_to_log_fixed_neon(
                        frame, origin_x, origin_y, log_lut, log_values,
                    )
                };
            }
        }
    }

    get_rect_subpix_bgr_to_log_half_pixel_interior_scalar(
        frame,
        origin_x,
        origin_y,
        patch_width,
        patch_height,
        log_lut,
        log_values,
    )
}

#[allow(clippy::too_many_arguments)]
fn get_rect_subpix_bgr_to_log_half_pixel_interior_scalar(
    frame: BgrFrame<'_>,
    origin_x: usize,
    origin_y: usize,
    patch_width: usize,
    patch_height: usize,
    log_lut: &[f32; 256],
    log_values: &mut [f32],
) -> LogMoments {
    debug_assert_eq!(log_values.len(), patch_width * patch_height);
    let mut moments = LogMoments::new();
    for y in 0..patch_height {
        let row0 = (origin_y + y) * frame.stride;
        let row1 = row0 + frame.stride;
        for x in 0..patch_width {
            let top_left = row0 + (origin_x + x) * 3;
            let top_right = top_left + 3;
            let bottom_left = row1 + (origin_x + x) * 3;
            let bottom_right = bottom_left + 3;

            let blue = rounded_quarter_sum(
                frame.data[top_left],
                frame.data[top_right],
                frame.data[bottom_left],
                frame.data[bottom_right],
            );
            let green = rounded_quarter_sum(
                frame.data[top_left + 1],
                frame.data[top_right + 1],
                frame.data[bottom_left + 1],
                frame.data[bottom_right + 1],
            );
            let red = rounded_quarter_sum(
                frame.data[top_left + 2],
                frame.data[top_right + 2],
                frame.data[bottom_left + 2],
                frame.data[bottom_right + 2],
            );

            let gray = bgr_to_gray(blue, green, red);
            let value = log_lut[gray as usize];
            log_values[y * patch_width + x] = value;
            moments.add(value);
        }
    }
    moments
}

#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
unsafe fn rounded_quarter_sum_8_neon(
    p00: core::arch::aarch64::uint8x8_t,
    p10: core::arch::aarch64::uint8x8_t,
    p01: core::arch::aarch64::uint8x8_t,
    p11: core::arch::aarch64::uint8x8_t,
) -> core::arch::aarch64::uint8x8_t {
    use core::arch::aarch64::{vaddl_u8, vaddq_u16, vdupq_n_u16, vshrn_n_u16};

    let top = vaddl_u8(p00, p10);
    let bottom = vaddl_u8(p01, p11);
    let rounded = vaddq_u16(vaddq_u16(top, bottom), vdupq_n_u16(2));
    vshrn_n_u16::<2>(rounded)
}

#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
unsafe fn bgr_to_gray_8_neon(
    blue: core::arch::aarch64::uint8x8_t,
    green: core::arch::aarch64::uint8x8_t,
    red: core::arch::aarch64::uint8x8_t,
) -> core::arch::aarch64::uint8x8_t {
    use core::arch::aarch64::{
        vaddq_u32, vcombine_u16, vdupq_n_u32, vget_high_u16, vget_low_u16, vmlal_n_u16, vmovl_u8,
        vmovn_u16, vmull_n_u16, vshrn_n_u32,
    };

    const BLUE_TO_Y: u16 = 1_868;
    const GREEN_TO_Y: u16 = 9_617;
    const RED_TO_Y: u16 = 4_899;
    const ROUND: u32 = 1 << 13;

    let blue = vmovl_u8(blue);
    let green = vmovl_u8(green);
    let red = vmovl_u8(red);

    let mut low = vmull_n_u16(vget_low_u16(blue), BLUE_TO_Y);
    low = vmlal_n_u16(low, vget_low_u16(green), GREEN_TO_Y);
    low = vmlal_n_u16(low, vget_low_u16(red), RED_TO_Y);
    low = vaddq_u32(low, vdupq_n_u32(ROUND));

    let mut high = vmull_n_u16(vget_high_u16(blue), BLUE_TO_Y);
    high = vmlal_n_u16(high, vget_high_u16(green), GREEN_TO_Y);
    high = vmlal_n_u16(high, vget_high_u16(red), RED_TO_Y);
    high = vaddq_u32(high, vdupq_n_u32(ROUND));

    vmovn_u16(vcombine_u16(
        vshrn_n_u32::<14>(low),
        vshrn_n_u32::<14>(high),
    ))
}

#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
unsafe fn get_rect_subpix_bgr_to_log_fixed_neon(
    frame: BgrFrame<'_>,
    origin_x: usize,
    origin_y: usize,
    log_lut: &[f32; 256],
    log_values: &mut [f32],
) -> LogMoments {
    use core::arch::aarch64::{vld3_u8, vst1_u8};

    const PIXELS_PER_BLOCK: usize = 8;
    const VECTORIZED_WIDTH: usize = FIXED_HOT_PATCH_WIDTH / PIXELS_PER_BLOCK * PIXELS_PER_BLOCK;
    const OUTPUT_LEN: usize = FIXED_HOT_PATCH_WIDTH * FIXED_HOT_PATCH_HEIGHT;

    assert_eq!(log_values.len(), OUTPUT_LEN);
    let last_x = origin_x
        .checked_add(FIXED_HOT_PATCH_WIDTH)
        .expect("fixed patch x extent overflow");
    let last_y = origin_y
        .checked_add(FIXED_HOT_PATCH_HEIGHT)
        .expect("fixed patch y extent overflow");
    assert!(last_x < frame.width);
    assert!(last_y < frame.height);
    let last_pixel_end = last_y
        .checked_mul(frame.stride)
        .and_then(|row| last_x.checked_mul(3).and_then(|x| row.checked_add(x)))
        .and_then(|pixel| pixel.checked_add(3))
        .expect("fixed patch frame offset overflow");
    assert!(last_pixel_end <= frame.data.len());

    let mut moments = LogMoments::new();
    for y in 0..FIXED_HOT_PATCH_HEIGHT {
        let row0 = (origin_y + y) * frame.stride;
        let row1 = row0 + frame.stride;
        let mut x = 0usize;
        while x < VECTORIZED_WIDTH {
            let top_left = row0 + (origin_x + x) * 3;
            let bottom_left = row1 + (origin_x + x) * 3;

            // SAFETY: the release-mode assertions above prove that the fixed
            // patch and its right/bottom interpolation neighbors are inside
            // the validated frame storage. Each interleaved load reads eight
            // complete BGR pixels; x advances only through blocks ending at
            // output x=55, so the shifted loads end at neighbor x=56.
            let (top, top_right, bottom, bottom_right) = unsafe {
                (
                    vld3_u8(frame.data.as_ptr().add(top_left)),
                    vld3_u8(frame.data.as_ptr().add(top_left + 3)),
                    vld3_u8(frame.data.as_ptr().add(bottom_left)),
                    vld3_u8(frame.data.as_ptr().add(bottom_left + 3)),
                )
            };

            // SAFETY: this function and both helpers are compiled with NEON
            // enabled. Tuple fields 0, 1, and 2 are B, G, and R respectively.
            let gray = unsafe {
                let blue = rounded_quarter_sum_8_neon(top.0, top_right.0, bottom.0, bottom_right.0);
                let green =
                    rounded_quarter_sum_8_neon(top.1, top_right.1, bottom.1, bottom_right.1);
                let red = rounded_quarter_sum_8_neon(top.2, top_right.2, bottom.2, bottom_right.2);
                bgr_to_gray_8_neon(blue, green, red)
            };
            let mut gray_lanes = [0u8; PIXELS_PER_BLOCK];
            // SAFETY: the destination array has exactly eight writable bytes,
            // and this function is compiled with NEON enabled.
            unsafe {
                vst1_u8(gray_lanes.as_mut_ptr(), gray);
            }

            // Keep lookup, output writes, and the dependent f64 reduction in
            // the same lane 0-to-7 order as the scalar row-major loop.
            let output_start = y * FIXED_HOT_PATCH_WIDTH + x;
            for lane in 0..PIXELS_PER_BLOCK {
                let value = log_lut[gray_lanes[lane] as usize];
                log_values[output_start + lane] = value;
                moments.add(value);
            }
            x += PIXELS_PER_BLOCK;
        }

        // Sixty is not divisible by eight; preserve the scalar expression for
        // the final four pixels in every row.
        for x in VECTORIZED_WIDTH..FIXED_HOT_PATCH_WIDTH {
            let top_left = row0 + (origin_x + x) * 3;
            let top_right = top_left + 3;
            let bottom_left = row1 + (origin_x + x) * 3;
            let bottom_right = bottom_left + 3;
            let blue = rounded_quarter_sum(
                frame.data[top_left],
                frame.data[top_right],
                frame.data[bottom_left],
                frame.data[bottom_right],
            );
            let green = rounded_quarter_sum(
                frame.data[top_left + 1],
                frame.data[top_right + 1],
                frame.data[bottom_left + 1],
                frame.data[bottom_right + 1],
            );
            let red = rounded_quarter_sum(
                frame.data[top_left + 2],
                frame.data[top_right + 2],
                frame.data[bottom_left + 2],
                frame.data[bottom_right + 2],
            );
            let value = log_lut[bgr_to_gray(blue, green, red) as usize];
            log_values[y * FIXED_HOT_PATCH_WIDTH + x] = value;
            moments.add(value);
        }
    }
    moments
}

#[inline]
fn rounded_quarter_sum(p00: u8, p10: u8, p01: u8, p11: u8) -> u8 {
    let sum = p00 as u16 + p10 as u16 + p01 as u16 + p11 as u16;
    ((sum + 2) / 4) as u8
}

// Experiment 002's fused generic sampler is retained as the exact test reference.
#[cfg(test)]
#[allow(clippy::too_many_arguments)]
fn get_rect_subpix_bgr_then_gray_generic(
    frame: BgrFrame<'_>,
    center_x: f64,
    center_y: f64,
    patch_width: usize,
    patch_height: usize,
    patch_gray: &mut [u8],
) {
    debug_assert_eq!(patch_gray.len(), patch_width * patch_height);
    let start_x = center_x - 0.5 * (patch_width - 1) as f64;
    let start_y = center_y - 0.5 * (patch_height - 1) as f64;
    for y in 0..patch_height {
        let source_y = start_y + y as f64;
        let y_floor = source_y.floor();
        let y0_raw = y_floor as isize;
        let y1_raw = y0_raw.saturating_add(1);
        let y0 = clamp_index(y0_raw, frame.height);
        let y1 = clamp_index(y1_raw, frame.height);
        let dy = source_y - y_floor;
        let row0 = y0 * frame.stride;
        let row1 = y1 * frame.stride;

        for x in 0..patch_width {
            let source_x = start_x + x as f64;
            let x_floor = source_x.floor();
            let x0_raw = x_floor as isize;
            let x1_raw = x0_raw.saturating_add(1);
            let x0 = clamp_index(x0_raw, frame.width);
            let x1 = clamp_index(x1_raw, frame.width);
            let dx = source_x - x_floor;
            let top_left = row0 + x0 * 3;
            let top_right = row0 + x1 * 3;
            let bottom_left = row1 + x0 * 3;
            let bottom_right = row1 + x1 * 3;

            let blue = saturating_round_u8(bilinear(
                frame.data[top_left] as f64,
                frame.data[top_right] as f64,
                frame.data[bottom_left] as f64,
                frame.data[bottom_right] as f64,
                dx,
                dy,
            ));
            let green = saturating_round_u8(bilinear(
                frame.data[top_left + 1] as f64,
                frame.data[top_right + 1] as f64,
                frame.data[bottom_left + 1] as f64,
                frame.data[bottom_right + 1] as f64,
                dx,
                dy,
            ));
            let red = saturating_round_u8(bilinear(
                frame.data[top_left + 2] as f64,
                frame.data[top_right + 2] as f64,
                frame.data[bottom_left + 2] as f64,
                frame.data[bottom_right + 2] as f64,
                dx,
                dy,
            ));

            let pixel_index = y * patch_width + x;
            patch_gray[pixel_index] = bgr_to_gray(blue, green, red);
        }
    }
}

// Experiment 002's fused generic sampler, with the log lookup and sum folded
// into the unchanged row-major pixel traversal.
#[allow(clippy::too_many_arguments)]
fn get_rect_subpix_bgr_to_log_generic(
    frame: BgrFrame<'_>,
    center_x: f64,
    center_y: f64,
    patch_width: usize,
    patch_height: usize,
    log_lut: &[f32; 256],
    log_values: &mut [f32],
) -> LogMoments {
    debug_assert_eq!(log_values.len(), patch_width * patch_height);
    let start_x = center_x - 0.5 * (patch_width - 1) as f64;
    let start_y = center_y - 0.5 * (patch_height - 1) as f64;
    let mut moments = LogMoments::new();
    for y in 0..patch_height {
        let source_y = start_y + y as f64;
        let y_floor = source_y.floor();
        let y0_raw = y_floor as isize;
        let y1_raw = y0_raw.saturating_add(1);
        let y0 = clamp_index(y0_raw, frame.height);
        let y1 = clamp_index(y1_raw, frame.height);
        let dy = source_y - y_floor;
        let row0 = y0 * frame.stride;
        let row1 = y1 * frame.stride;

        for x in 0..patch_width {
            let source_x = start_x + x as f64;
            let x_floor = source_x.floor();
            let x0_raw = x_floor as isize;
            let x1_raw = x0_raw.saturating_add(1);
            let x0 = clamp_index(x0_raw, frame.width);
            let x1 = clamp_index(x1_raw, frame.width);
            let dx = source_x - x_floor;
            let top_left = row0 + x0 * 3;
            let top_right = row0 + x1 * 3;
            let bottom_left = row1 + x0 * 3;
            let bottom_right = row1 + x1 * 3;

            let blue = saturating_round_u8(bilinear(
                frame.data[top_left] as f64,
                frame.data[top_right] as f64,
                frame.data[bottom_left] as f64,
                frame.data[bottom_right] as f64,
                dx,
                dy,
            ));
            let green = saturating_round_u8(bilinear(
                frame.data[top_left + 1] as f64,
                frame.data[top_right + 1] as f64,
                frame.data[bottom_left + 1] as f64,
                frame.data[bottom_right + 1] as f64,
                dx,
                dy,
            ));
            let red = saturating_round_u8(bilinear(
                frame.data[top_left + 2] as f64,
                frame.data[top_right + 2] as f64,
                frame.data[bottom_left + 2] as f64,
                frame.data[bottom_right + 2] as f64,
                dx,
                dy,
            ));

            let pixel_index = y * patch_width + x;
            let gray = bgr_to_gray(blue, green, red);
            let value = log_lut[gray as usize];
            log_values[pixel_index] = value;
            moments.add(value);
        }
    }
    moments
}

fn sample_gray_replicate(input: &[u8], width: usize, height: usize, x: f64, y: f64) -> f64 {
    let x0_raw = x.floor() as isize;
    let y0_raw = y.floor() as isize;
    let x1_raw = x0_raw.saturating_add(1);
    let y1_raw = y0_raw.saturating_add(1);
    let x0 = clamp_index(x0_raw, width);
    let x1 = clamp_index(x1_raw, width);
    let y0 = clamp_index(y0_raw, height);
    let y1 = clamp_index(y1_raw, height);
    bilinear(
        input[y0 * width + x0] as f64,
        input[y0 * width + x1] as f64,
        input[y1 * width + x0] as f64,
        input[y1 * width + x1] as f64,
        x - x.floor(),
        y - y.floor(),
    )
}

#[inline]
fn bilinear(v00: f64, v10: f64, v01: f64, v11: f64, dx: f64, dy: f64) -> f64 {
    let top = v00 + (v10 - v00) * dx;
    let bottom = v01 + (v11 - v01) * dx;
    top + (bottom - top) * dy
}

#[inline]
fn saturating_round_u8(value: f64) -> u8 {
    value.round().clamp(0.0, 255.0) as u8
}

#[inline]
fn clamp_index(index: isize, length: usize) -> usize {
    index.clamp(0, length.saturating_sub(1) as isize) as usize
}

fn random_warp(input: &[u8], output: &mut [u8], width: usize, height: usize, seed: u64) {
    debug_assert_eq!(input.len(), width * height);
    debug_assert_eq!(output.len(), input.len());
    let matrix = random_warp_matrix(width, height, seed);

    // OpenCV converts the CV_32F matrix to double and then inverts it for sampling.
    let mut inverse = matrix.map(f64::from);
    let determinant = inverse[0] * inverse[4] - inverse[1] * inverse[3];
    let inverse_determinant = if determinant != 0.0 {
        1.0 / determinant
    } else {
        0.0
    };
    let inverse_00 = inverse[4] * inverse_determinant;
    let inverse_11 = inverse[0] * inverse_determinant;
    inverse[0] = inverse_00;
    inverse[1] *= -inverse_determinant;
    inverse[3] *= -inverse_determinant;
    inverse[4] = inverse_11;
    let inverse_02 = -inverse[0] * inverse[2] - inverse[1] * inverse[5];
    let inverse_12 = -inverse[3] * inverse[2] - inverse[4] * inverse[5];
    inverse[2] = inverse_02;
    inverse[5] = inverse_12;

    // mosseTracker.cpp passes BORDER_REFLECT as warpAffine's fifth argument. Its value is
    // 2, which is INTER_CUBIC; borderMode therefore remains the default BORDER_CONSTANT.
    // Mirror OpenCV's generic CV_8UC1 affine/remap path, including 1/32-pixel coordinate
    // quantization and signed 15-bit interpolation coefficients.
    const AFFINE_BITS: i32 = 10;
    const AFFINE_SCALE: i32 = 1 << AFFINE_BITS;
    const INTER_BITS: i32 = 5;
    const INTER_TAB_SIZE: i32 = 1 << INTER_BITS;
    const ROUND_DELTA: i32 = AFFINE_SCALE / INTER_TAB_SIZE / 2;

    for y in 0..height {
        let x_origin =
            cv_round_i32((inverse[1] * y as f64 + inverse[2]) * AFFINE_SCALE as f64) + ROUND_DELTA;
        let y_origin =
            cv_round_i32((inverse[4] * y as f64 + inverse[5]) * AFFINE_SCALE as f64) + ROUND_DELTA;
        for x in 0..width {
            let x_delta = cv_round_i32(inverse[0] * x as f64 * AFFINE_SCALE as f64);
            let y_delta = cv_round_i32(inverse[3] * x as f64 * AFFINE_SCALE as f64);
            let x_fixed = (x_origin + x_delta) >> (AFFINE_BITS - INTER_BITS);
            let y_fixed = (y_origin + y_delta) >> (AFFINE_BITS - INTER_BITS);
            let base_x = (x_fixed >> INTER_BITS).clamp(i16::MIN as i32, i16::MAX as i32) - 1;
            let base_y = (y_fixed >> INTER_BITS).clamp(i16::MIN as i32, i16::MAX as i32) - 1;
            let fraction_x = (x_fixed & (INTER_TAB_SIZE - 1)) as usize;
            let fraction_y = (y_fixed & (INTER_TAB_SIZE - 1)) as usize;
            let weights = cubic_fixed_weights(fraction_x, fraction_y);

            let mut sum = 0i32;
            for kernel_y in 0..4 {
                let source_y = base_y + kernel_y as i32;
                if !(0..height as i32).contains(&source_y) {
                    continue;
                }
                for kernel_x in 0..4 {
                    let source_x = base_x + kernel_x as i32;
                    if !(0..width as i32).contains(&source_x) {
                        continue;
                    }
                    let pixel = input[source_y as usize * width + source_x as usize] as i32;
                    sum += pixel * weights[kernel_y * 4 + kernel_x] as i32;
                }
            }
            output[y * width + x] =
                ((sum + (1 << 14)) >> 15).clamp(u8::MIN as i32, u8::MAX as i32) as u8;
        }
    }
}

fn random_warp_matrix(width: usize, height: usize, seed: u64) -> [f32; 6] {
    let mut rng = CvRng::new(seed);
    let amount = 0.1;
    let angle = rng.uniform_f64(-amount, amount);
    let cosine = angle.cos();
    let sine = angle.sin();
    // W is Mat_<float> in OpenCV, so round before calculating its translation.
    let m00 = (cosine + rng.uniform_f64(-amount, amount)) as f32;
    let m01 = (-sine + rng.uniform_f64(-amount, amount)) as f32;
    let m10 = (sine + rng.uniform_f64(-amount, amount)) as f32;
    let m11 = (cosine + rng.uniform_f64(-amount, amount)) as f32;
    let center_x = (width / 2) as f32;
    let center_y = (height / 2) as f32;
    let transformed_center_x = m00 * center_x + m01 * center_y;
    let transformed_center_y = m10 * center_x + m11 * center_y;
    let m02 = center_x - transformed_center_x;
    let m12 = center_y - transformed_center_y;
    [m00, m01, m02, m10, m11, m12]
}

fn cubic_fixed_weights(fraction_x: usize, fraction_y: usize) -> [i16; 16] {
    const INTER_TAB_SIZE: f32 = 32.0;
    const REMAP_COEFFICIENT_SCALE: f32 = 32_768.0;
    let horizontal = cubic_coefficients(fraction_x as f32 / INTER_TAB_SIZE);
    let vertical = cubic_coefficients(fraction_y as f32 / INTER_TAB_SIZE);
    let mut weights = [0i16; 16];
    let mut sum = 0i32;
    for (y, &vertical_weight) in vertical.iter().enumerate() {
        for (x, &horizontal_weight) in horizontal.iter().enumerate() {
            let index = y * 4 + x;
            let value = vertical_weight * horizontal_weight * REMAP_COEFFICIENT_SCALE;
            weights[index] = cv_round_i16(value);
            sum += weights[index] as i32;
        }
    }

    // Match initInterTab2D's correction so all fixed coefficients sum to 2^15.
    if sum != REMAP_COEFFICIENT_SCALE as i32 {
        let difference = sum - REMAP_COEFFICIENT_SCALE as i32;
        let mut minimum_index = 2 * 4 + 2;
        let mut maximum_index = minimum_index;
        for y in 2..4 {
            for x in 2..4 {
                let index = y * 4 + x;
                if weights[index] < weights[minimum_index] {
                    minimum_index = index;
                } else if weights[index] > weights[maximum_index] {
                    maximum_index = index;
                }
            }
        }
        let adjusted_index = if difference < 0 {
            maximum_index
        } else {
            minimum_index
        };
        weights[adjusted_index] = (weights[adjusted_index] as i32 - difference) as i16;
    }
    weights
}

fn cubic_coefficients(x: f32) -> [f32; 4] {
    const A: f32 = -0.75;
    let x_plus_one = x + 1.0;
    let one_minus_x = 1.0 - x;
    let first = ((A * x_plus_one - 5.0 * A) * x_plus_one + 8.0 * A) * x_plus_one - 4.0 * A;
    let second = ((A + 2.0) * x - (A + 3.0)) * x * x + 1.0;
    let third = ((A + 2.0) * one_minus_x - (A + 3.0)) * one_minus_x * one_minus_x + 1.0;
    let fourth = 1.0 - first - second - third;
    [first, second, third, fourth]
}

fn cv_round_i32(value: f64) -> i32 {
    value
        .round_ties_even()
        .clamp(i32::MIN as f64, i32::MAX as f64) as i32
}

fn cv_round_i16(value: f32) -> i16 {
    value
        .round_ties_even()
        .clamp(i16::MIN as f32, i16::MAX as f32) as i16
}

fn border_reflect_101(mut index: isize, length: usize) -> usize {
    if length <= 1 {
        return 0;
    }
    let length = length as isize;
    while index < 0 || index >= length {
        index = if index < 0 {
            -index
        } else {
            2 * length - index - 2
        };
    }
    index as usize
}

struct CvRng {
    state: u64,
}

impl CvRng {
    fn new(seed: u64) -> Self {
        Self {
            state: if seed != 0 { seed } else { u32::MAX as u64 },
        }
    }

    fn next_u32(&mut self) -> u32 {
        const COEFFICIENT: u64 = 4_164_903_690;
        self.state = (self.state as u32 as u64)
            .wrapping_mul(COEFFICIENT)
            .wrapping_add(self.state >> 32);
        self.state as u32
    }

    fn uniform_f64(&mut self, lower: f64, upper: f64) -> f64 {
        const SCALE: f64 = 5.421_010_862_427_522e-20;
        let high = self.next_u32() as u64;
        let low = self.next_u32() as u64;
        let unit = ((high << 32) | low) as f64 * SCALE;
        unit * (upper - lower) + lower
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
    fn assert_fixed_padding_is_positive_zero(workspace: &Workspace, label: &str) {
        let SpectralWorkspace::FixedPadded(spectral) = &workspace.spectral else {
            panic!("{label}: expected fixed padded spectral workspace");
        };
        for (name, spectrum) in [
            ("goal", &spectral.goal_spectrum),
            ("current", &spectral.spectrum),
            ("numerator", &spectral.numerator),
            ("denominator", &spectral.denominator),
            ("filter", &spectral.filter),
            ("response", &spectral.response_spectrum),
        ] {
            assert!(
                spectrum.padding_is_positive_zero(),
                "{label}: {name} padding"
            );
        }
    }

    #[cfg(all(target_arch = "aarch64", feature = "padded-spectrum-60x36"))]
    #[test]
    fn fixed_geometry_uses_padded_backend_and_preserves_all_six_padding_lanes() {
        let mut workspace = Workspace::new(
            PADDED_WIDTH,
            PADDED_HEIGHT,
            PADDED_SPATIAL_LEN,
            BackendRequest::Explicit(TrackerMode::Single),
        )
        .unwrap();
        assert_fixed_padding_is_positive_zero(&workspace, "construction");

        for index in 0..PADDED_SPATIAL_LEN {
            workspace.response[index] = ((index * 17 + 3) as f32 * 0.013).sin();
            workspace.preprocessed[index] = ((index * 29 + 5) as f32 * 0.007).cos();
        }
        workspace.forward_goal_spectrum();
        assert_fixed_padding_is_positive_zero(&workspace, "goal transform");
        workspace.forward_model_spectrum();
        assert_fixed_padding_is_positive_zero(&workspace, "model transform");
        workspace.accumulate_current_sample();
        assert_fixed_padding_is_positive_zero(&workspace, "accumulation");
        workspace.reconstruct_filter();
        assert_fixed_padding_is_positive_zero(&workspace, "filter reconstruction");
        let reduction = workspace.localize_inverse();
        assert!(reduction.sum.is_finite());
        assert!(reduction.sum_of_squares.is_finite());
        assert_fixed_padding_is_positive_zero(&workspace, "localization and inverse");
        workspace.blend_current_sample(0.2);
        assert_fixed_padding_is_positive_zero(&workspace, "model blend");

        let generic = Workspace::new(
            PADDED_WIDTH / 2,
            PADDED_HEIGHT,
            PADDED_SPATIAL_LEN,
            BackendRequest::Explicit(TrackerMode::Single),
        )
        .unwrap();
        assert!(matches!(generic.spectral, SpectralWorkspace::Generic(_)));
    }

    #[cfg(feature = "parallel-model-blend-filter-60x36")]
    #[test]
    fn parallel_model_blend_filter_matches_retained_serial_bits_on_real_four_lane_runtime() {
        let mut expected_numerator = model_blend_test_spectrum(0x5701_0000_dead_beef, 5.0);
        let mut expected_denominator = model_blend_test_spectrum(0x5702_0000_cafe_babe, 2.0);
        clear_model_blend_test_padding(&mut expected_numerator);
        clear_model_blend_test_padding(&mut expected_denominator);
        let mut actual_numerator = expected_numerator.clone();
        let mut actual_denominator = expected_denominator.clone();
        let mut expected_filter = PaddedSpectrum::default();
        let mut actual_filter = PaddedSpectrum::default();
        let rates = [
            0.2,
            0.0,
            1.0,
            f32::MIN_POSITIVE,
            f32::from_bits(1.0f32.to_bits() - 1),
            -0.0,
            0.2,
            0.2,
        ];

        let mut runtime = crate::four_core_runtime::FourCoreRuntime::test_parallel_unconfigured();
        let activity = runtime.begin_activity();
        for (step, rate) in rates.into_iter().enumerate() {
            let mut goal = model_blend_test_spectrum(
                0x5710_0000_0000_0000 ^ step as u64,
                1.0 + step as f32 * 0.25,
            );
            let mut sample = model_blend_test_spectrum(
                0x5720_0000_0000_0000 ^ (step as u64).wrapping_mul(0x9e37_79b9),
                0.5 + step as f32 * 0.125,
            );
            clear_model_blend_test_padding(&mut goal);
            clear_model_blend_test_padding(&mut sample);

            // Filter is output-only for this phase. Different quiet-NaN
            // payloads prove both compositions overwrite every padded field,
            // while numerator and denominator carry dirty state from every
            // preceding step.
            expected_filter.poison_all(0x5711_0000 ^ step as u32);
            actual_filter.poison_all(0xa722_0000 ^ step as u32);
            retained_serial_model_blend_filter_for_test(
                &goal,
                &sample,
                &mut expected_numerator,
                &mut expected_denominator,
                &mut expected_filter,
                rate,
            );
            dispatch_parallel_model_blend_filter(
                &mut runtime,
                &goal,
                &sample,
                &mut actual_numerator,
                &mut actual_denominator,
                &mut actual_filter,
                rate,
            );

            assert_model_blend_spectrum_bits(
                &actual_numerator,
                &expected_numerator,
                &format!("step={step} numerator"),
            );
            assert_model_blend_spectrum_bits(
                &actual_denominator,
                &expected_denominator,
                &format!("step={step} denominator"),
            );
            assert_model_blend_spectrum_bits(
                &actual_filter,
                &expected_filter,
                &format!("step={step} filter"),
            );
            assert!(
                actual_numerator.padding_is_positive_zero(),
                "step={step} numerator padding"
            );
            assert!(
                actual_denominator.padding_is_positive_zero(),
                "step={step} denominator padding"
            );
            assert!(
                actual_filter.padding_is_positive_zero(),
                "step={step} filter padding"
            );
        }
        drop(activity);
        assert!(runtime.shutdown().clean());
    }

    #[cfg(feature = "parallel-model-blend-filter-60x36")]
    fn retained_serial_model_blend_filter_for_test(
        goal: &PaddedSpectrum,
        sample: &PaddedSpectrum,
        numerator: &mut PaddedSpectrum,
        denominator: &mut PaddedSpectrum,
        filter: &mut PaddedSpectrum,
        rate: f32,
    ) {
        let keep = 1.0 - rate;
        for batch in 0..PADDED_COLUMN_BATCHES {
            for ky in 0..PADDED_HEIGHT {
                for lane in 0..PADDED_LANES {
                    let sample_value = model_blend_test_value(sample, batch, ky, lane);
                    let goal_value = model_blend_test_value(goal, batch, ky, lane);
                    let numerator_new = goal_value * sample_value.conj();
                    let denominator_new = sample_value * sample_value.conj();
                    let numerator_value = model_blend_test_value(numerator, batch, ky, lane);
                    let denominator_value = model_blend_test_value(denominator, batch, ky, lane);
                    model_blend_test_store(
                        numerator,
                        batch,
                        ky,
                        lane,
                        numerator_value * keep + numerator_new * rate,
                    );
                    model_blend_test_store(
                        denominator,
                        batch,
                        ky,
                        lane,
                        denominator_value * keep + denominator_new * rate,
                    );
                }
            }
        }

        for batch in 0..PADDED_COLUMN_BATCHES {
            for ky in 0..PADDED_HEIGHT {
                for lane in 0..PADDED_LANES {
                    let lhs = model_blend_test_value(numerator, batch, ky, lane);
                    let rhs = model_blend_test_value(denominator, batch, ky, lane);
                    let divisor = rhs.re * rhs.re + rhs.im * rhs.im;
                    let value = if divisor > 0.0 && divisor.is_finite() {
                        Complex32::new(
                            (lhs.re * rhs.re + lhs.im * rhs.im) / divisor,
                            -(lhs.im * rhs.re + lhs.re * rhs.im) / divisor,
                        )
                    } else {
                        Complex32::new(0.0, 0.0)
                    };
                    model_blend_test_store(filter, batch, ky, lane, value);
                }
            }
        }
    }

    #[cfg(feature = "parallel-model-blend-filter-60x36")]
    fn model_blend_test_spectrum(mut state: u64, scale: f32) -> PaddedSpectrum {
        let mut spectrum = PaddedSpectrum::default();
        for batch in 0..PADDED_COLUMN_BATCHES {
            for ky in 0..PADDED_HEIGHT {
                for lane in 0..PADDED_LANES {
                    state = model_blend_splitmix64(
                        state
                            ^ ((batch * PADDED_HEIGHT * PADDED_LANES + ky * PADDED_LANES + lane)
                                as u64)
                                .wrapping_mul(0x9e37_79b9),
                    );
                    let re = ((state >> 40) as u32) as f32 * (1.0 / 16_777_216.0);
                    state = model_blend_splitmix64(state);
                    let im = ((state >> 40) as u32) as f32 * (1.0 / 16_777_216.0);
                    spectrum.batches[batch].re[ky][lane] = (re * 2.0 - 1.0) * scale;
                    spectrum.batches[batch].im[ky][lane] = (im * 2.0 - 1.0) * scale;
                }
            }
        }
        spectrum
    }

    #[cfg(feature = "parallel-model-blend-filter-60x36")]
    fn model_blend_splitmix64(mut value: u64) -> u64 {
        value = value.wrapping_add(0x9e37_79b9_7f4a_7c15);
        value = (value ^ (value >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
        value = (value ^ (value >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
        value ^ (value >> 31)
    }

    #[cfg(feature = "parallel-model-blend-filter-60x36")]
    fn clear_model_blend_test_padding(spectrum: &mut PaddedSpectrum) {
        let last_batch = PADDED_COLUMN_BATCHES - 1;
        let padding_lane = PADDED_LANES - 1;
        for ky in 0..PADDED_HEIGHT {
            spectrum.batches[last_batch].re[ky][padding_lane] = 0.0;
            spectrum.batches[last_batch].im[ky][padding_lane] = 0.0;
        }
    }

    #[cfg(feature = "parallel-model-blend-filter-60x36")]
    fn model_blend_test_value(
        spectrum: &PaddedSpectrum,
        batch: usize,
        ky: usize,
        lane: usize,
    ) -> Complex32 {
        Complex32::new(
            spectrum.batches[batch].re[ky][lane],
            spectrum.batches[batch].im[ky][lane],
        )
    }

    #[cfg(feature = "parallel-model-blend-filter-60x36")]
    fn model_blend_test_store(
        spectrum: &mut PaddedSpectrum,
        batch: usize,
        ky: usize,
        lane: usize,
        value: Complex32,
    ) {
        spectrum.batches[batch].re[ky][lane] = value.re;
        spectrum.batches[batch].im[ky][lane] = value.im;
    }

    #[cfg(feature = "parallel-model-blend-filter-60x36")]
    fn assert_model_blend_spectrum_bits(
        actual: &PaddedSpectrum,
        expected: &PaddedSpectrum,
        context: &str,
    ) {
        for batch in 0..PADDED_COLUMN_BATCHES {
            for ky in 0..PADDED_HEIGHT {
                for lane in 0..PADDED_LANES {
                    for (component, actual, expected) in [
                        (
                            "re",
                            actual.batches[batch].re[ky][lane],
                            expected.batches[batch].re[ky][lane],
                        ),
                        (
                            "im",
                            actual.batches[batch].im[ky][lane],
                            expected.batches[batch].im[ky][lane],
                        ),
                    ] {
                        assert_eq!(
                            actual.to_bits(),
                            expected.to_bits(),
                            "{context}: batch={batch} ky={ky} lane={lane} \
                             component={component} actual={actual:?} expected={expected:?}"
                        );
                    }
                }
            }
        }
    }

    fn log_moments_from_values(values: &[f32]) -> LogMoments {
        let mut moments = LogMoments::new();
        for &value in values {
            moments.add(value);
        }
        moments
    }

    fn assert_log_moments_bits(actual: LogMoments, expected: LogMoments, label: &str) {
        assert_eq!(actual.sum.to_bits(), expected.sum.to_bits(), "{label} sum");
        #[cfg(target_arch = "x86_64")]
        assert_eq!(
            actual.square_sum.to_bits(),
            expected.square_sum.to_bits(),
            "{label} square sum"
        );
    }

    fn update_with_forced_model_recompute(
        tracker: &mut MosseTracker,
        frame: BgrFrame<'_>,
    ) -> UpdateResult {
        assert!(tracker.initialized);

        let stats = tracker.localize(frame, false);
        let success = stats.psr.is_finite() && stats.psr >= tracker.config.psr_threshold;

        tracker.diagnostics.updates = tracker.diagnostics.updates.saturating_add(1);
        tracker.diagnostics.last_success = u8::from(success);
        tracker.diagnostics.delta_x = stats.delta_x;
        tracker.diagnostics.delta_y = stats.delta_y;
        tracker.diagnostics.psr = stats.psr;
        tracker.diagnostics.peak = stats.peak;
        tracker.diagnostics.response_mean = stats.mean;
        tracker.diagnostics.response_stddev = stats.stddev;

        if success {
            tracker.center_x += stats.delta_x as f64;
            tracker.center_y += stats.delta_y as f64;
            tracker.prepare_model_spectrum(frame);
            tracker.blend_current_spectrum_into_model();
        }

        tracker.diagnostics.center_x = tracker.center_x;
        tracker.diagnostics.center_y = tracker.center_y;
        UpdateResult {
            success,
            bounding_box: tracker.current_rect(),
            diagnostics: tracker.diagnostics,
        }
    }

    fn assert_complex_bits_eq(actual: &[Complex32], expected: &[Complex32], label: &str) {
        assert_eq!(actual.len(), expected.len(), "{label} length");
        for (index, (&actual, &expected)) in actual.iter().zip(expected).enumerate() {
            assert_eq!(
                (actual.re.to_bits(), actual.im.to_bits()),
                (expected.re.to_bits(), expected.im.to_bits()),
                "{label} index {index}"
            );
        }
    }

    fn assert_update_result_bits_eq(actual: UpdateResult, expected: UpdateResult) {
        assert_eq!(actual.success, expected.success);
        assert_eq!(
            (
                actual.bounding_box.x.to_bits(),
                actual.bounding_box.y.to_bits(),
                actual.bounding_box.width.to_bits(),
                actual.bounding_box.height.to_bits(),
            ),
            (
                expected.bounding_box.x.to_bits(),
                expected.bounding_box.y.to_bits(),
                expected.bounding_box.width.to_bits(),
                expected.bounding_box.height.to_bits(),
            )
        );

        let actual = actual.diagnostics;
        let expected = expected.diagnostics;
        assert_eq!(actual.initialized, expected.initialized);
        assert_eq!(actual.last_success, expected.last_success);
        assert_eq!(actual.reserved, expected.reserved);
        assert_eq!(actual.updates, expected.updates);
        assert_eq!(actual.window_width, expected.window_width);
        assert_eq!(actual.window_height, expected.window_height);
        assert_eq!(actual.delta_x, expected.delta_x);
        assert_eq!(actual.delta_y, expected.delta_y);
        assert_eq!(actual.center_x.to_bits(), expected.center_x.to_bits());
        assert_eq!(actual.center_y.to_bits(), expected.center_y.to_bits());
        assert_eq!(actual.psr.to_bits(), expected.psr.to_bits());
        assert_eq!(actual.peak.to_bits(), expected.peak.to_bits());
        assert_eq!(
            actual.response_mean.to_bits(),
            expected.response_mean.to_bits()
        );
        assert_eq!(
            actual.response_stddev.to_bits(),
            expected.response_stddev.to_bits()
        );
    }

    fn assert_response_stats_bits_eq(actual: ResponseStats, expected: ResponseStats, label: &str) {
        assert_eq!(
            actual.peak.to_bits(),
            expected.peak.to_bits(),
            "{label} peak"
        );
        assert_eq!(
            actual.mean.to_bits(),
            expected.mean.to_bits(),
            "{label} mean"
        );
        assert_eq!(
            actual.stddev.to_bits(),
            expected.stddev.to_bits(),
            "{label} standard deviation"
        );
        assert_eq!(actual.psr.to_bits(), expected.psr.to_bits(), "{label} PSR");
        assert_eq!(actual.delta_x, expected.delta_x, "{label} delta x");
        assert_eq!(actual.delta_y, expected.delta_y, "{label} delta y");
    }

    fn assert_tracker_model_bits_eq(actual: &MosseTracker, expected: &MosseTracker) {
        let actual = actual.workspace.as_ref().unwrap();
        let expected = expected.workspace.as_ref().unwrap();
        assert_complex_bits_eq(
            &actual.test_spectrum(),
            &expected.test_spectrum(),
            "spectrum",
        );
        assert_complex_bits_eq(
            &actual.test_numerator(),
            &expected.test_numerator(),
            "numerator",
        );
        assert_complex_bits_eq(
            &actual.test_denominator(),
            &expected.test_denominator(),
            "denominator",
        );
        assert_complex_bits_eq(&actual.test_filter(), &expected.test_filter(), "filter");
    }

    fn preprocess_with_direct_log(input: &[u8], hann: &[f32], epsilon: f64, output: &mut [f32]) {
        let mut sum = 0.0f64;
        for (dst, &pixel) in output.iter_mut().zip(input) {
            let value = (pixel as f32 + 1.0).ln();
            *dst = value;
            sum += value as f64;
        }
        let mean = sum / output.len() as f64;
        let mut squared_deviation_sum = 0.0f64;
        for &value in output.iter() {
            let deviation = value as f64 - mean;
            squared_deviation_sum += deviation * deviation;
        }
        let stddev = (squared_deviation_sum / output.len() as f64).sqrt();
        let denominator = (stddev + epsilon) as f32;
        let mean = mean as f32;
        for i in 0..output.len() {
            output[i] = ((output[i] - mean) / denominator) * hann[i];
        }
    }

    fn solid_bgr(width: usize, height: usize, value: u8) -> Vec<u8> {
        vec![value; width * height * 3]
    }

    fn patterned_bgr(width: usize, height: usize) -> Vec<u8> {
        let mut image = vec![20u8; width * height * 3];
        for y in 20..44 {
            for x in 18..46 {
                let index = (y * width + x) * 3;
                image[index] = ((x * 7 + y * 3) % 255) as u8;
                image[index + 1] = ((x * 11 + y * 5) % 255) as u8;
                image[index + 2] = ((x * 13 + y * 17) % 255) as u8;
            }
        }
        image
    }

    fn shift_bgr_right(input: &[u8], width: usize, height: usize, shift: usize) -> Vec<u8> {
        let mut shifted = vec![20u8; width * height * 3];
        for y in 0..height {
            for x in 0..width - shift {
                let source = (y * width + x) * 3;
                let destination = (y * width + x + shift) * 3;
                shifted[destination..destination + 3].copy_from_slice(&input[source..source + 3]);
            }
        }
        shifted
    }

    fn subpixel_test_bgr(width: usize, height: usize, stride: usize) -> Vec<u8> {
        let mut image = vec![0xa5; stride * height];
        for y in 0..height {
            for x in 0..width {
                let index = y * stride + x * 3;
                image[index] = ((x * 37 + y * 53 + x * y * 11 + 17) % 256) as u8;
                image[index + 1] = ((x * 71 + y * 29 + x * y * 7 + 43) % 256) as u8;
                image[index + 2] = ((x * 19 + y * 97 + x * y * 13 + 89) % 256) as u8;
            }
        }
        image
    }

    #[cfg(feature = "overlap-model-raw-log-60x36")]
    fn assert_f32_slice_bits_eq(actual: &[f32], expected: &[f32], label: &str) {
        assert_eq!(actual.len(), expected.len(), "{label} length");
        for (index, (&actual, &expected)) in actual.iter().zip(expected).enumerate() {
            assert_eq!(
                actual.to_bits(),
                expected.to_bits(),
                "{label} index={index} actual={actual:?} expected={expected:?}"
            );
        }
    }

    #[cfg(feature = "overlap-model-raw-log-60x36")]
    fn reference_raw_log_reduction(values: &[f32], epsilon: f64) -> (f64, f32, f32) {
        let mut sum = 0.0f64;
        for &value in values {
            sum += value as f64;
        }
        let mean = sum / values.len() as f64;
        let mut squared_deviation_sum = 0.0f64;
        for &value in values {
            let deviation = value as f64 - mean;
            squared_deviation_sum += deviation * deviation;
        }
        let stddev = (squared_deviation_sum / values.len() as f64).sqrt();
        (sum, mean as f32, (stddev + epsilon) as f32)
    }

    #[cfg(feature = "overlap-model-raw-log-60x36")]
    fn normalize_raw_logs(values: &mut [f32], hann: &[f32], mean: f32, denominator: f32) {
        for (value, &window) in values.iter_mut().zip(hann) {
            *value = ((*value - mean) / denominator) * window;
        }
    }

    #[cfg(feature = "overlap-model-raw-log-60x36")]
    #[test]
    fn overlapping_model_raw_logs_match_full_crop_reductions_and_spectrum_for_every_delta() {
        const FRAME_WIDTH: usize = 180;
        const FRAME_HEIGHT: usize = 128;
        const FRAME_STRIDE: usize = FRAME_WIDTH * 3 + 29;
        const PATCH_LEN: usize = FIXED_HOT_PATCH_WIDTH * FIXED_HOT_PATCH_HEIGHT;
        let pixels = subpixel_test_bgr(FRAME_WIDTH, FRAME_HEIGHT, FRAME_STRIDE);
        let frame =
            BgrFrame::new(&pixels, FRAME_WIDTH, FRAME_HEIGHT, FRAME_STRIDE).expect("test frame");
        let log_lut = create_log_lut();
        let old_center_x = 90.0;
        let old_center_y = 64.0;
        let provenance = RawLogProvenance::for_center(
            frame,
            old_center_x,
            old_center_y,
            FIXED_HOT_PATCH_WIDTH,
            FIXED_HOT_PATCH_HEIGHT,
        )
        .expect("old patch must be half-pixel interior");
        let mut old_raw_logs = vec![f32::from_bits(0x7fc0_6001); PATCH_LEN];
        get_rect_subpix_bgr_to_log_half_pixel_interior_scalar(
            frame,
            provenance.origin_x,
            provenance.origin_y,
            FIXED_HOT_PATCH_WIDTH,
            FIXED_HOT_PATCH_HEIGHT,
            &log_lut,
            &mut old_raw_logs,
        );
        let mut hann = vec![0.0; PATCH_LEN];
        create_hann_window(FIXED_HOT_PATCH_WIDTH, FIXED_HOT_PATCH_HEIGHT, &mut hann);
        let mut expected_fft = Fft2::new(FIXED_HOT_PATCH_WIDTH, FIXED_HOT_PATCH_HEIGHT);
        let mut actual_fft = Fft2::new(FIXED_HOT_PATCH_WIDTH, FIXED_HOT_PATCH_HEIGHT);
        let mut expected_spectrum =
            vec![Complex32::new(f32::NAN, f32::NAN); expected_fft.spectrum_len()];
        let mut actual_spectrum =
            vec![Complex32::new(f32::NEG_INFINITY, f32::INFINITY); actual_fft.spectrum_len()];

        for delta_y in -(FIXED_HOT_PATCH_HEIGHT as i32 / 2)..(FIXED_HOT_PATCH_HEIGHT as i32 / 2) {
            for delta_x in -(FIXED_HOT_PATCH_WIDTH as i32 / 2)..(FIXED_HOT_PATCH_WIDTH as i32 / 2) {
                let mut actual_raw_logs = old_raw_logs.clone();
                let before_bits: Vec<_> = actual_raw_logs
                    .iter()
                    .map(|value| value.to_bits())
                    .collect();
                let reduction = try_reuse_model_raw_logs(
                    frame,
                    provenance,
                    old_center_x,
                    old_center_y,
                    old_center_x + delta_x as f64,
                    old_center_y + delta_y as f64,
                    delta_x,
                    delta_y,
                    FIXED_HOT_PATCH_WIDTH,
                    FIXED_HOT_PATCH_HEIGHT,
                    &log_lut,
                    &mut actual_raw_logs,
                    DEFAULT_EPSILON,
                );
                if delta_x == 0 && delta_y == 0 {
                    assert!(reduction.is_none(), "zero displacement owns spectrum reuse");
                    assert_eq!(
                        actual_raw_logs
                            .iter()
                            .map(|value| value.to_bits())
                            .collect::<Vec<_>>(),
                        before_bits,
                        "zero displacement mutated raw logs"
                    );
                    continue;
                }
                let reduction = reduction.unwrap_or_else(|| {
                    panic!("valid response delta ({delta_x}, {delta_y}) was rejected")
                });

                let new_provenance = RawLogProvenance::for_center(
                    frame,
                    old_center_x + delta_x as f64,
                    old_center_y + delta_y as f64,
                    FIXED_HOT_PATCH_WIDTH,
                    FIXED_HOT_PATCH_HEIGHT,
                )
                .expect("every response delta stays interior in this fixture");
                let mut expected_raw_logs = vec![f32::from_bits(0xffc0_6002); PATCH_LEN];
                let expected_moments = get_rect_subpix_bgr_to_log_half_pixel_interior_scalar(
                    frame,
                    new_provenance.origin_x,
                    new_provenance.origin_y,
                    FIXED_HOT_PATCH_WIDTH,
                    FIXED_HOT_PATCH_HEIGHT,
                    &log_lut,
                    &mut expected_raw_logs,
                );
                let label = format!("delta=({delta_x},{delta_y})");
                assert_f32_slice_bits_eq(&actual_raw_logs, &expected_raw_logs, &label);

                let (expected_sum, expected_mean, expected_denominator) =
                    reference_raw_log_reduction(&expected_raw_logs, DEFAULT_EPSILON);
                assert_eq!(
                    expected_moments.sum.to_bits(),
                    expected_sum.to_bits(),
                    "{label} retained crop sum"
                );
                assert_eq!(
                    reduction.sum.to_bits(),
                    expected_sum.to_bits(),
                    "{label} complete sum"
                );
                assert_eq!(
                    reduction.mean.to_bits(),
                    expected_mean.to_bits(),
                    "{label} mean"
                );
                assert_eq!(
                    reduction.denominator.to_bits(),
                    expected_denominator.to_bits(),
                    "{label} denominator"
                );
                let expected_samples = PATCH_LEN
                    - (FIXED_HOT_PATCH_WIDTH - delta_x.unsigned_abs() as usize)
                        * (FIXED_HOT_PATCH_HEIGHT - delta_y.unsigned_abs() as usize);
                assert_eq!(
                    reduction.sampled_values, expected_samples,
                    "{label} entering sample count"
                );

                let mut expected_normalized = expected_raw_logs;
                let mut actual_normalized = actual_raw_logs;
                normalize_raw_logs(
                    &mut expected_normalized,
                    &hann,
                    expected_mean,
                    expected_denominator,
                );
                normalize_raw_logs(
                    &mut actual_normalized,
                    &hann,
                    reduction.mean,
                    reduction.denominator,
                );
                assert_f32_slice_bits_eq(
                    &actual_normalized,
                    &expected_normalized,
                    &format!("{label} normalized"),
                );
                expected_fft.forward_real(&mut expected_normalized, &mut expected_spectrum);
                actual_fft.forward_real(&mut actual_normalized, &mut actual_spectrum);
                assert_complex_bits_eq(
                    &actual_spectrum,
                    &expected_spectrum,
                    &format!("{label} spectrum"),
                );
            }
        }
    }

    #[cfg(feature = "overlap-model-raw-log-60x36")]
    #[test]
    fn overlapping_model_raw_log_fallbacks_are_non_mutating_and_backend_strict() {
        const FRAME_WIDTH: usize = 160;
        const FRAME_HEIGHT: usize = 96;
        const FRAME_STRIDE: usize = FRAME_WIDTH * 3 + 17;
        const PATCH_LEN: usize = FIXED_HOT_PATCH_WIDTH * FIXED_HOT_PATCH_HEIGHT;
        let pixels = subpixel_test_bgr(FRAME_WIDTH, FRAME_HEIGHT, FRAME_STRIDE);
        let other_pixels = subpixel_test_bgr(FRAME_WIDTH, FRAME_HEIGHT, FRAME_STRIDE);
        let frame =
            BgrFrame::new(&pixels, FRAME_WIDTH, FRAME_HEIGHT, FRAME_STRIDE).expect("test frame");
        let other_frame = BgrFrame::new(&other_pixels, FRAME_WIDTH, FRAME_HEIGHT, FRAME_STRIDE)
            .expect("other test frame");
        let log_lut = create_log_lut();
        let center_x = 80.0;
        let center_y = 48.0;
        let provenance = RawLogProvenance::for_center(
            frame,
            center_x,
            center_y,
            FIXED_HOT_PATCH_WIDTH,
            FIXED_HOT_PATCH_HEIGHT,
        )
        .unwrap();
        let poison: Vec<f32> = (0..PATCH_LEN)
            .map(|index| {
                let payload = (index as u32 & 0x003f_ffff) | 1;
                f32::from_bits(if index & 1 == 0 {
                    0x7fc0_0000 | payload
                } else {
                    0xffc0_0000 | payload
                })
            })
            .collect();

        #[allow(clippy::too_many_arguments)]
        fn assert_rejected_without_mutation(
            label: &str,
            frame: BgrFrame<'_>,
            provenance: RawLogProvenance,
            old_center_x: f64,
            old_center_y: f64,
            new_center_x: f64,
            new_center_y: f64,
            delta_x: i32,
            delta_y: i32,
            patch_width: usize,
            patch_height: usize,
            log_lut: &[f32; 256],
            poison: &[f32],
        ) {
            let mut actual = poison.to_vec();
            let before: Vec<_> = actual.iter().map(|value| value.to_bits()).collect();
            let result = try_reuse_model_raw_logs(
                frame,
                provenance,
                old_center_x,
                old_center_y,
                new_center_x,
                new_center_y,
                delta_x,
                delta_y,
                patch_width,
                patch_height,
                log_lut,
                &mut actual,
                DEFAULT_EPSILON,
            );
            assert!(result.is_none(), "{label} unexpectedly reused");
            assert_eq!(
                actual
                    .iter()
                    .map(|value| value.to_bits())
                    .collect::<Vec<_>>(),
                before,
                "{label} mutated poison before fallback"
            );
        }

        assert_rejected_without_mutation(
            "zero displacement",
            frame,
            provenance,
            center_x,
            center_y,
            center_x,
            center_y,
            0,
            0,
            FIXED_HOT_PATCH_WIDTH,
            FIXED_HOT_PATCH_HEIGHT,
            &log_lut,
            &poison,
        );
        assert_rejected_without_mutation(
            "no x overlap",
            frame,
            provenance,
            center_x,
            center_y,
            center_x + FIXED_HOT_PATCH_WIDTH as f64,
            center_y,
            FIXED_HOT_PATCH_WIDTH as i32,
            0,
            FIXED_HOT_PATCH_WIDTH,
            FIXED_HOT_PATCH_HEIGHT,
            &log_lut,
            &poison,
        );
        assert_rejected_without_mutation(
            "fractional old and new centers",
            frame,
            provenance,
            center_x + 0.25,
            center_y,
            center_x + 1.25,
            center_y,
            1,
            0,
            FIXED_HOT_PATCH_WIDTH,
            FIXED_HOT_PATCH_HEIGHT,
            &log_lut,
            &poison,
        );
        assert_rejected_without_mutation(
            "origin and delta disagree",
            frame,
            provenance,
            center_x,
            center_y,
            center_x + 2.0,
            center_y,
            1,
            0,
            FIXED_HOT_PATCH_WIDTH,
            FIXED_HOT_PATCH_HEIGHT,
            &log_lut,
            &poison,
        );
        let wrong_origin = RawLogProvenance {
            origin_x: provenance.origin_x + 1,
            ..provenance
        };
        assert_rejected_without_mutation(
            "provenance origin mismatch",
            frame,
            wrong_origin,
            center_x,
            center_y,
            center_x + 1.0,
            center_y,
            1,
            0,
            FIXED_HOT_PATCH_WIDTH,
            FIXED_HOT_PATCH_HEIGHT,
            &log_lut,
            &poison,
        );
        assert_rejected_without_mutation(
            "different frame allocation",
            other_frame,
            provenance,
            center_x,
            center_y,
            center_x + 1.0,
            center_y,
            1,
            0,
            FIXED_HOT_PATCH_WIDTH,
            FIXED_HOT_PATCH_HEIGHT,
            &log_lut,
            &poison,
        );
        let border_center_x = FIXED_HOT_PATCH_WIDTH as f64 * 0.5;
        let border_provenance = RawLogProvenance::for_center(
            frame,
            border_center_x,
            center_y,
            FIXED_HOT_PATCH_WIDTH,
            FIXED_HOT_PATCH_HEIGHT,
        )
        .expect("origin zero is the first valid interior origin");
        assert_rejected_without_mutation(
            "new patch crosses left border",
            frame,
            border_provenance,
            border_center_x,
            center_y,
            border_center_x - 1.0,
            center_y,
            -1,
            0,
            FIXED_HOT_PATCH_WIDTH,
            FIXED_HOT_PATCH_HEIGHT,
            &log_lut,
            &poison,
        );
        assert_rejected_without_mutation(
            "generic dimensions",
            frame,
            provenance,
            center_x,
            center_y,
            center_x + 1.0,
            center_y,
            1,
            0,
            FIXED_HOT_PATCH_WIDTH - 1,
            FIXED_HOT_PATCH_HEIGHT,
            &log_lut,
            &poison[..(FIXED_HOT_PATCH_WIDTH - 1) * FIXED_HOT_PATCH_HEIGHT],
        );

        assert!(raw_log_reuse_backend_supported(
            TrackerBackendStatus::FixedPaddedFourCore,
            FIXED_HOT_PATCH_WIDTH,
            FIXED_HOT_PATCH_HEIGHT
        ));
        for backend in [
            TrackerBackendStatus::Uninitialized,
            TrackerBackendStatus::GenericSingleThread,
            TrackerBackendStatus::FixedPaddedSingleThread,
        ] {
            assert!(
                !raw_log_reuse_backend_supported(
                    backend,
                    FIXED_HOT_PATCH_WIDTH,
                    FIXED_HOT_PATCH_HEIGHT
                ),
                "{backend:?} must retain full preprocessing"
            );
        }
        assert!(!raw_log_reuse_backend_supported(
            TrackerBackendStatus::FixedPaddedFourCore,
            FIXED_HOT_PATCH_WIDTH - 1,
            FIXED_HOT_PATCH_HEIGHT
        ));
    }

    #[cfg(feature = "overlap-model-raw-log-60x36")]
    #[test]
    fn overlapping_model_raw_log_model_update_matches_full_tracker_state() {
        const FRAME_WIDTH: usize = 160;
        const FRAME_HEIGHT: usize = 112;
        const PATCH_LEN: usize = FIXED_HOT_PATCH_WIDTH * FIXED_HOT_PATCH_HEIGHT;
        let pixels = subpixel_test_bgr(FRAME_WIDTH, FRAME_HEIGHT, FRAME_WIDTH * 3);
        let frame = BgrFrame::new(&pixels, FRAME_WIDTH, FRAME_HEIGHT, FRAME_WIDTH * 3).unwrap();
        let config = MosseConfig {
            psr_threshold: 0.0,
            ..MosseConfig::default()
        };
        let initial_box = Rect {
            x: 48.0,
            y: 36.0,
            width: 59.0,
            height: 35.0,
        };

        for (delta_x, delta_y) in [(3, 2), (-4, 1), (2, -3), (-1, -2)] {
            let mut reused = MosseTracker::new(config).unwrap();
            let mut recomputed = MosseTracker::new(config).unwrap();
            reused.init(frame, initial_box).unwrap();
            recomputed.init(frame, initial_box).unwrap();
            assert_eq!(
                (reused.window_width, reused.window_height),
                (FIXED_HOT_PATCH_WIDTH, FIXED_HOT_PATCH_HEIGHT)
            );

            let reused_stats = reused.localize(frame, false);
            let recomputed_stats = recomputed.localize(frame, false);
            assert_response_stats_bits_eq(
                reused_stats,
                recomputed_stats,
                &format!("localization before forced delta ({delta_x},{delta_y})"),
            );

            let old_center_x = reused.center_x;
            let old_center_y = reused.center_y;
            let provenance = RawLogProvenance::for_center(
                frame,
                old_center_x,
                old_center_y,
                FIXED_HOT_PATCH_WIDTH,
                FIXED_HOT_PATCH_HEIGHT,
            )
            .unwrap();
            {
                let workspace = reused.workspace.as_mut().unwrap();
                let mut moments = LogMoments::new();
                let actual = get_rect_subpix_bgr_to_log_half_pixel_interior_scalar(
                    frame,
                    provenance.origin_x,
                    provenance.origin_y,
                    FIXED_HOT_PATCH_WIDTH,
                    FIXED_HOT_PATCH_HEIGHT,
                    &reused.log_lut,
                    &mut workspace.preprocessed,
                );
                moments.sum = actual.sum;
                assert!(moments.sum.is_finite());
            }

            reused.center_x += delta_x as f64;
            reused.center_y += delta_y as f64;
            recomputed.center_x += delta_x as f64;
            recomputed.center_y += delta_y as f64;

            let reduction = {
                let workspace = reused.workspace.as_mut().unwrap();
                try_reuse_model_raw_logs(
                    frame,
                    provenance,
                    old_center_x,
                    old_center_y,
                    reused.center_x,
                    reused.center_y,
                    delta_x,
                    delta_y,
                    workspace.width,
                    workspace.height,
                    &reused.log_lut,
                    &mut workspace.preprocessed,
                    reused.config.epsilon,
                )
                .expect("forced moving update must reuse raw-log overlap")
            };
            {
                let workspace = reused.workspace.as_mut().unwrap();
                normalize_raw_logs(
                    &mut workspace.preprocessed,
                    &workspace.hann,
                    reduction.mean,
                    reduction.denominator,
                );
                workspace.forward_model_spectrum();
            }
            {
                let workspace = recomputed.workspace.as_mut().unwrap();
                let (_, moments) = get_rect_subpix_bgr_to_log(
                    frame,
                    recomputed.center_x,
                    recomputed.center_y,
                    workspace.width,
                    workspace.height,
                    &recomputed.log_lut,
                    &mut workspace.preprocessed,
                );
                let (sum, mean, denominator) =
                    reference_raw_log_reduction(&workspace.preprocessed, recomputed.config.epsilon);
                assert_eq!(moments.sum.to_bits(), sum.to_bits());
                normalize_raw_logs(
                    &mut workspace.preprocessed,
                    &workspace.hann,
                    mean,
                    denominator,
                );
                workspace.forward_model_spectrum();
            }

            assert_complex_bits_eq(
                &reused.workspace.as_ref().unwrap().test_spectrum(),
                &recomputed.workspace.as_ref().unwrap().test_spectrum(),
                &format!("prepared spectrum delta ({delta_x},{delta_y})"),
            );
            reused.blend_current_spectrum_into_model();
            recomputed.blend_current_spectrum_into_model();
            reused.diagnostics.delta_x = delta_x;
            reused.diagnostics.delta_y = delta_y;
            reused.diagnostics.center_x = reused.center_x;
            reused.diagnostics.center_y = reused.center_y;
            recomputed.diagnostics = reused.diagnostics;

            assert_tracker_model_bits_eq(&reused, &recomputed);
            assert_eq!(reused.center_x.to_bits(), recomputed.center_x.to_bits());
            assert_eq!(reused.center_y.to_bits(), recomputed.center_y.to_bits());
            assert_eq!(
                (
                    reused.current_rect().x.to_bits(),
                    reused.current_rect().y.to_bits()
                ),
                (
                    recomputed.current_rect().x.to_bits(),
                    recomputed.current_rect().y.to_bits()
                )
            );
            assert_eq!(reduction.sum.to_bits(), {
                let values = {
                    let new_provenance = RawLogProvenance::for_center(
                        frame,
                        reused.center_x,
                        reused.center_y,
                        FIXED_HOT_PATCH_WIDTH,
                        FIXED_HOT_PATCH_HEIGHT,
                    )
                    .unwrap();
                    let mut values = vec![0.0; PATCH_LEN];
                    get_rect_subpix_bgr_to_log_half_pixel_interior_scalar(
                        frame,
                        new_provenance.origin_x,
                        new_provenance.origin_y,
                        FIXED_HOT_PATCH_WIDTH,
                        FIXED_HOT_PATCH_HEIGHT,
                        &reused.log_lut,
                        &mut values,
                    );
                    values
                };
                reference_raw_log_reduction(&values, reused.config.epsilon)
                    .0
                    .to_bits()
            });
        }
    }

    // Preserved implementation from before experiment 002. Keep this test-only
    // reference mechanically simple so the fused sampler remains checked against
    // the prior per-channel coordinate/clamp and temporary-BGR behavior.
    #[allow(clippy::too_many_arguments)]
    fn get_rect_subpix_bgr_then_gray_reference(
        frame: BgrFrame<'_>,
        center_x: f64,
        center_y: f64,
        patch_width: usize,
        patch_height: usize,
        patch_bgr: &mut [u8],
        patch_gray: &mut [u8],
    ) {
        let start_x = center_x - 0.5 * (patch_width - 1) as f64;
        let start_y = center_y - 0.5 * (patch_height - 1) as f64;
        for y in 0..patch_height {
            for x in 0..patch_width {
                let pixel_index = y * patch_width + x;
                for channel in 0..3 {
                    let value = sample_bgr_replicate_reference(
                        frame,
                        start_x + x as f64,
                        start_y + y as f64,
                        channel,
                    );
                    patch_bgr[pixel_index * 3 + channel] = saturating_round_u8(value);
                }
                patch_gray[pixel_index] = bgr_to_gray(
                    patch_bgr[pixel_index * 3],
                    patch_bgr[pixel_index * 3 + 1],
                    patch_bgr[pixel_index * 3 + 2],
                );
            }
        }
    }

    fn sample_bgr_replicate_reference(frame: BgrFrame<'_>, x: f64, y: f64, channel: usize) -> f64 {
        let x0_raw = x.floor() as isize;
        let y0_raw = y.floor() as isize;
        let x1_raw = x0_raw.saturating_add(1);
        let y1_raw = y0_raw.saturating_add(1);
        let x0 = clamp_index(x0_raw, frame.width);
        let x1 = clamp_index(x1_raw, frame.width);
        let y0 = clamp_index(y0_raw, frame.height);
        let y1 = clamp_index(y1_raw, frame.height);
        bilinear(
            frame.channel(x0, y0, channel) as f64,
            frame.channel(x1, y0, channel) as f64,
            frame.channel(x0, y1, channel) as f64,
            frame.channel(x1, y1, channel) as f64,
            x - x.floor(),
            y - y.floor(),
        )
    }

    fn assert_fused_subpixel_matches_reference(
        frame: BgrFrame<'_>,
        center_x: f64,
        center_y: f64,
        patch_width: usize,
        patch_height: usize,
    ) -> SubpixelSamplingPath {
        let patch_pixels = patch_width * patch_height;
        let mut reference_bgr = vec![0; patch_pixels * 3];
        let mut expected = vec![0; patch_pixels];
        let mut actual = vec![0; patch_pixels];
        get_rect_subpix_bgr_then_gray_reference(
            frame,
            center_x,
            center_y,
            patch_width,
            patch_height,
            &mut reference_bgr,
            &mut expected,
        );
        let path = get_rect_subpix_bgr_then_gray(
            frame,
            center_x,
            center_y,
            patch_width,
            patch_height,
            &mut actual,
        );
        assert_eq!(actual, expected);

        let log_lut = create_log_lut();
        let mut expected_logs = vec![0.0; patch_pixels];
        let expected_sum = lookup_log_values_and_sum(&expected, &log_lut, &mut expected_logs);
        let mut actual_logs = vec![f32::from_bits(0x7fa1_2345); patch_pixels];
        let (log_path, actual_sum) = get_rect_subpix_bgr_to_log(
            frame,
            center_x,
            center_y,
            patch_width,
            patch_height,
            &log_lut,
            &mut actual_logs,
        );
        assert_eq!(log_path, path);
        for (index, (&actual, &expected)) in actual_logs.iter().zip(&expected_logs).enumerate() {
            assert_eq!(
                actual.to_bits(),
                expected.to_bits(),
                "fused log index {index}"
            );
        }
        assert_eq!(
            expected_sum.to_bits(),
            log_moments_from_values(&expected_logs).sum.to_bits()
        );
        assert_log_moments_bits(
            actual_sum,
            log_moments_from_values(&expected_logs),
            "fused subpixel",
        );
        path
    }

    #[test]
    fn rounded_quarter_sum_matches_f64_bilinear_for_every_possible_sum() {
        for sum in 0u16..=4 * u8::MAX as u16 {
            let mut remaining = sum;
            let mut pixels = [0u8; 4];
            for pixel in &mut pixels {
                let value = remaining.min(u8::MAX as u16);
                *pixel = value as u8;
                remaining -= value;
            }
            assert_eq!(remaining, 0);

            let integer = rounded_quarter_sum(pixels[0], pixels[1], pixels[2], pixels[3]);
            let bilinear_rounded = saturating_round_u8(bilinear(
                pixels[0] as f64,
                pixels[1] as f64,
                pixels[2] as f64,
                pixels[3] as f64,
                0.5,
                0.5,
            ));
            let positive_rounded = (sum as f64 / 4.0).round() as u8;
            assert_eq!(integer, bilinear_rounded, "sum {sum}");
            assert_eq!(integer, positive_rounded, "sum {sum}");
        }
    }

    #[test]
    fn half_pixel_interior_fast_path_handles_padded_stride() {
        let width = 11;
        let height = 9;
        let stride = width * 3 + 7;
        let pixels = subpixel_test_bgr(width, height, stride);
        let frame = BgrFrame::new(&pixels, width, height, stride).unwrap();

        assert_eq!(
            assert_fused_subpixel_matches_reference(frame, 5.0, 4.0, 6, 4),
            SubpixelSamplingPath::HalfPixelInterior
        );
    }

    #[test]
    fn fixed_hot_log_dispatch_and_scalar_fallback_match_bit_for_bit() {
        let width = 96;
        let height = 73;
        let stride = width * 3 + 11;
        let pixels = subpixel_test_bgr(width, height, stride);
        let frame = BgrFrame::new(&pixels, width, height, stride).unwrap();
        let log_lut = create_log_lut();
        let dirty = f32::from_bits(0x7fa1_2345);

        // Reuse dirty output buffers across the first and last legal fixed
        // origins so the portable dispatcher is also checked consecutively.
        let fixed_len = FIXED_HOT_PATCH_WIDTH * FIXED_HOT_PATCH_HEIGHT;
        let mut expected = vec![dirty; fixed_len];
        let mut actual = vec![dirty; fixed_len];
        for (origin_x, origin_y) in [
            (0, 0),
            (
                width - FIXED_HOT_PATCH_WIDTH - 1,
                height - FIXED_HOT_PATCH_HEIGHT - 1,
            ),
        ] {
            expected.fill(dirty);
            actual.fill(f32::from_bits(0x7fc5_4321));
            let expected_sum = get_rect_subpix_bgr_to_log_half_pixel_interior_scalar(
                frame,
                origin_x,
                origin_y,
                FIXED_HOT_PATCH_WIDTH,
                FIXED_HOT_PATCH_HEIGHT,
                &log_lut,
                &mut expected,
            );
            let actual_sum = get_rect_subpix_bgr_to_log_half_pixel_interior(
                frame,
                origin_x,
                origin_y,
                FIXED_HOT_PATCH_WIDTH,
                FIXED_HOT_PATCH_HEIGHT,
                &log_lut,
                &mut actual,
            );
            for (index, (&actual, &expected)) in actual.iter().zip(&expected).enumerate() {
                assert_eq!(
                    actual.to_bits(),
                    expected.to_bits(),
                    "fixed dispatcher origin ({origin_x}, {origin_y}) index {index}"
                );
            }
            assert_log_moments_bits(
                actual_sum,
                expected_sum,
                &format!("fixed dispatcher origin ({origin_x}, {origin_y})"),
            );
        }

        // A non-fixed half-pixel interior patch must retain the scalar fallback.
        let fallback_width = 52;
        let fallback_height = 32;
        let fallback_len = fallback_width * fallback_height;
        let mut fallback_expected = vec![dirty; fallback_len];
        let mut fallback_actual = vec![f32::from_bits(0x7fc5_4321); fallback_len];
        let expected_sum = get_rect_subpix_bgr_to_log_half_pixel_interior_scalar(
            frame,
            7,
            9,
            fallback_width,
            fallback_height,
            &log_lut,
            &mut fallback_expected,
        );
        let actual_sum = get_rect_subpix_bgr_to_log_half_pixel_interior(
            frame,
            7,
            9,
            fallback_width,
            fallback_height,
            &log_lut,
            &mut fallback_actual,
        );
        for (index, (&actual, &expected)) in
            fallback_actual.iter().zip(&fallback_expected).enumerate()
        {
            assert_eq!(
                actual.to_bits(),
                expected.to_bits(),
                "scalar fallback index {index}"
            );
        }
        assert_log_moments_bits(actual_sum, expected_sum, "scalar fallback");
    }

    #[cfg(feature = "parallel-tail-preprocess-60x36")]
    #[test]
    fn parallel_tail_preprocess_matches_serial_row_major_path_bit_for_bit() {
        let width = 113;
        let height = 79;
        let stride = width * 3 + 17;
        let pixels = subpixel_test_bgr(width, height, stride);
        let frame = BgrFrame::new(&pixels, width, height, stride).unwrap();
        let tail_frame = TailBgrFrame::new(frame.data(), width, height, stride).unwrap();
        let log_lut = create_log_lut();
        let mut hann = vec![0.0; FIXED_HOT_PATCH_WIDTH * FIXED_HOT_PATCH_HEIGHT];
        create_hann_window(FIXED_HOT_PATCH_WIDTH, FIXED_HOT_PATCH_HEIGHT, &mut hann);
        let origin_x = 19;
        let origin_y = 23;
        let center_x = (origin_x + FIXED_HOT_PATCH_WIDTH / 2) as f64;
        let center_y = (origin_y + FIXED_HOT_PATCH_HEIGHT / 2) as f64;
        let dirty = f32::from_bits(0x7fa1_2345);
        let mut expected = vec![dirty; hann.len()];
        let mut actual = vec![dirty; hann.len()];

        let (path, serial_moments) = get_rect_subpix_bgr_to_log(
            frame,
            center_x,
            center_y,
            FIXED_HOT_PATCH_WIDTH,
            FIXED_HOT_PATCH_HEIGHT,
            &log_lut,
            &mut expected,
        );
        assert_eq!(path, SubpixelSamplingPath::HalfPixelInterior);
        finish_preprocess_from_log_sum(&mut expected, &hann, serial_moments.sum, DEFAULT_EPSILON);

        let mut runtime = crate::four_core_runtime::FourCoreRuntime::test_parallel_unconfigured();
        let activity = runtime.begin_activity();
        {
            let mut tasks =
                bind_crop_log_rows(tail_frame, origin_x, origin_y, &log_lut, &mut actual).unwrap();
            runtime.dispatch(&mut tasks, |_, task| task.run());
        }
        let reduction = reduce_log_values_row_major(&actual, DEFAULT_EPSILON).unwrap();
        assert_eq!(reduction.sum.to_bits(), serial_moments.sum.to_bits());
        {
            let mut tasks = bind_normalize_hann_rows(&mut actual, &hann, reduction).unwrap();
            runtime.dispatch(&mut tasks, |_, task| task.run());
        }
        drop(activity);
        assert!(runtime.shutdown().clean());

        for (index, (&actual, &expected)) in actual.iter().zip(&expected).enumerate() {
            assert_eq!(
                actual.to_bits(),
                expected.to_bits(),
                "parallel tail preprocessed index {index}"
            );
        }
    }

    #[cfg(target_arch = "aarch64")]
    #[test]
    fn neon_fixed_hot_crop_matches_scalar_for_randomized_padded_frames() {
        if !std::arch::is_aarch64_feature_detected!("neon") {
            return;
        }

        let width = 97;
        let height = 75;
        let stride = width * 3 + 17;
        let log_lut = create_log_lut();
        let output_len = FIXED_HOT_PATCH_WIDTH * FIXED_HOT_PATCH_HEIGHT;
        let dirty_expected = f32::from_bits(0x7fa1_2345);
        let dirty_actual = f32::from_bits(0x7fc5_4321);
        let mut expected = vec![dirty_expected; output_len];
        let mut actual = vec![dirty_actual; output_len];
        let mut state = 0xd1b5_4a32_d192_ed03u64;

        // Multiple frames and reused output buffers exercise consecutive calls.
        for frame_index in 0..4 {
            let mut pixels = vec![0u8; stride * height];
            for byte in &mut pixels {
                state = state
                    .wrapping_mul(6_364_136_223_846_793_005)
                    .wrapping_add(1_442_695_040_888_963_407);
                *byte = (state >> 56) as u8;
            }
            let frame = BgrFrame::new(&pixels, width, height, stride).unwrap();

            for (origin_x, origin_y) in [
                (0, 0),
                (
                    width - FIXED_HOT_PATCH_WIDTH - 1,
                    height - FIXED_HOT_PATCH_HEIGHT - 1,
                ),
                (13, 17),
            ] {
                expected.fill(dirty_expected);
                actual.fill(dirty_actual);
                let expected_sum = get_rect_subpix_bgr_to_log_half_pixel_interior_scalar(
                    frame,
                    origin_x,
                    origin_y,
                    FIXED_HOT_PATCH_WIDTH,
                    FIXED_HOT_PATCH_HEIGHT,
                    &log_lut,
                    &mut expected,
                );
                // SAFETY: this test checked runtime NEON support, and the frame,
                // fixed dimensions, origins, and output length satisfy the
                // helper's release-mode guards.
                let actual_sum = unsafe {
                    get_rect_subpix_bgr_to_log_fixed_neon(
                        frame,
                        origin_x,
                        origin_y,
                        &log_lut,
                        &mut actual,
                    )
                };

                for (index, (&actual, &expected)) in actual.iter().zip(&expected).enumerate() {
                    assert_eq!(
                        actual.to_bits(),
                        expected.to_bits(),
                        "frame {frame_index} origin ({origin_x}, {origin_y}) index {index}"
                    );
                }
                assert_log_moments_bits(
                    actual_sum,
                    expected_sum,
                    &format!("frame {frame_index} origin ({origin_x}, {origin_y})"),
                );
            }
        }
    }

    #[test]
    fn half_pixel_dispatch_respects_every_frame_boundary() {
        let width = 11;
        let height = 9;
        let stride = width * 3 + 5;
        let pixels = subpixel_test_bgr(width, height, stride);
        let frame = BgrFrame::new(&pixels, width, height, stride).unwrap();

        // The first and last valid half-pixel origins retain their right/bottom neighbor.
        for (center_x, center_y) in [(2.0, 2.0), (8.0, 6.0)] {
            assert_eq!(
                assert_fused_subpixel_matches_reference(frame, center_x, center_y, 4, 4),
                SubpixelSamplingPath::HalfPixelInterior
            );
        }

        // Moving one pixel farther toward any edge requires replicated-border fallback.
        for (center_x, center_y) in [(1.0, 2.0), (9.0, 2.0), (2.0, 1.0), (2.0, 7.0)] {
            assert_eq!(
                assert_fused_subpixel_matches_reference(frame, center_x, center_y, 4, 4),
                SubpixelSamplingPath::Generic
            );
        }
    }

    #[test]
    fn fused_subpixel_gray_matches_reference_for_interior_integer_patch() {
        let width = 11;
        let height = 9;
        let stride = width * 3 + 5;
        let pixels = subpixel_test_bgr(width, height, stride);
        let frame = BgrFrame::new(&pixels, width, height, stride).unwrap();

        assert_eq!(
            assert_fused_subpixel_matches_reference(frame, 5.0, 4.0, 5, 3),
            SubpixelSamplingPath::Generic
        );
    }

    #[test]
    fn fused_subpixel_gray_matches_reference_for_fractional_patch() {
        let width = 11;
        let height = 9;
        let stride = width * 3 + 5;
        let pixels = subpixel_test_bgr(width, height, stride);
        let frame = BgrFrame::new(&pixels, width, height, stride).unwrap();

        assert_eq!(
            assert_fused_subpixel_matches_reference(frame, 5.25, 4.75, 6, 4),
            SubpixelSamplingPath::Generic
        );
    }

    #[test]
    fn fused_subpixel_gray_matches_reference_at_replicated_borders() {
        let width = 11;
        let height = 9;
        let stride = width * 3 + 5;
        let pixels = subpixel_test_bgr(width, height, stride);
        let frame = BgrFrame::new(&pixels, width, height, stride).unwrap();

        for (center_x, center_y) in [
            (-0.25, -0.75),
            (width as f64 - 0.25, height as f64 - 0.6),
            (-0.5, height as f64 - 0.5),
            (width as f64 - 0.5, -0.5),
        ] {
            assert_eq!(
                assert_fused_subpixel_matches_reference(frame, center_x, center_y, 5, 5),
                SubpixelSamplingPath::Generic
            );
        }
    }

    #[test]
    fn hot_prepared_spectrum_matches_legacy_pipeline_across_dirty_calls() {
        let frame_width = 96;
        let frame_height = 72;
        let stride = frame_width * 3 + 7;
        let patch_width = 60;
        let patch_height = 36;
        let patch_pixels = patch_width * patch_height;
        let pixels = subpixel_test_bgr(frame_width, frame_height, stride);
        let frame = BgrFrame::new(&pixels, frame_width, frame_height, stride).unwrap();
        let log_lut = create_log_lut();
        let mut hann = vec![0.0; patch_pixels];
        create_hann_window(patch_width, patch_height, &mut hann);

        let mut legacy_fft = Fft2::new(patch_width, patch_height);
        let mut fused_fft = Fft2::new(patch_width, patch_height);
        let spectrum_len = legacy_fft.spectrum_len();
        let dirty = f32::from_bits(0x7fa1_2345);
        let mut legacy_gray = vec![0; patch_pixels];
        let mut legacy_preprocessed = vec![dirty; patch_pixels];
        let mut fused_preprocessed = vec![dirty; patch_pixels];
        let mut legacy_spectrum = vec![Complex32::new(dirty, -17.0); spectrum_len];
        let mut fused_spectrum = vec![Complex32::new(23.0, dirty); spectrum_len];

        for (label, center_x, center_y, expected_path) in [
            (
                "half-pixel",
                48.0,
                36.0,
                SubpixelSamplingPath::HalfPixelInterior,
            ),
            ("integer generic", 48.5, 36.5, SubpixelSamplingPath::Generic),
            (
                "fractional generic",
                48.25,
                36.75,
                SubpixelSamplingPath::Generic,
            ),
            (
                "replicated border",
                -0.25,
                -0.75,
                SubpixelSamplingPath::Generic,
            ),
        ] {
            legacy_gray.fill(0xa5);
            legacy_preprocessed.fill(dirty);
            fused_preprocessed.fill(dirty);
            legacy_spectrum.fill(Complex32::new(dirty, -31.0));
            fused_spectrum.fill(Complex32::new(37.0, dirty));

            let legacy_path = get_rect_subpix_bgr_then_gray(
                frame,
                center_x,
                center_y,
                patch_width,
                patch_height,
                &mut legacy_gray,
            );
            assert_eq!(legacy_path, expected_path, "{label} legacy path");
            preprocess(
                &legacy_gray,
                &hann,
                &log_lut,
                DEFAULT_EPSILON,
                &mut legacy_preprocessed,
            );

            let (fused_path, fused_sum) = get_rect_subpix_bgr_to_log(
                frame,
                center_x,
                center_y,
                patch_width,
                patch_height,
                &log_lut,
                &mut fused_preprocessed,
            );
            assert_eq!(fused_path, expected_path, "{label} fused path");
            finish_preprocess_from_log_sum(
                &mut fused_preprocessed,
                &hann,
                fused_sum.sum,
                DEFAULT_EPSILON,
            );

            for (index, (&actual, &expected)) in fused_preprocessed
                .iter()
                .zip(&legacy_preprocessed)
                .enumerate()
            {
                assert_eq!(
                    actual.to_bits(),
                    expected.to_bits(),
                    "{label} preprocessed index {index}"
                );
            }

            legacy_fft.forward_real(&mut legacy_preprocessed, &mut legacy_spectrum);
            fused_fft.forward_real(&mut fused_preprocessed, &mut fused_spectrum);
            assert_complex_bits_eq(
                &fused_spectrum,
                &legacy_spectrum,
                &format!("{label} spectrum"),
            );
        }
    }

    #[cfg(target_arch = "x86_64")]
    #[test]
    fn onepass_log_moments_match_two_pass_preprocessing_within_f32_noise() {
        let width = FIXED_HOT_PATCH_WIDTH;
        let height = FIXED_HOT_PATCH_HEIGHT;
        let len = width * height;
        let log_lut = create_log_lut();
        let mut hann = vec![0.0; len];
        create_hann_window(width, height, &mut hann);

        let mut state = 0x6a09_e667_f3bc_c909u64;
        for family in 0..4 {
            let mut pixels = vec![0u8; len];
            for (index, pixel) in pixels.iter_mut().enumerate() {
                *pixel = match family {
                    0 => 0,
                    1 => u8::MAX,
                    2 => index.wrapping_mul(37).wrapping_add(index / width * 11) as u8,
                    _ => {
                        state = state
                            .wrapping_mul(6_364_136_223_846_793_005)
                            .wrapping_add(1_442_695_040_888_963_407);
                        (state >> 56) as u8
                    }
                };
            }

            let mut onepass = vec![0.0; len];
            let sum = lookup_log_values_and_sum(&pixels, &log_lut, &mut onepass);
            let moments = log_moments_from_values(&onepass);
            assert_eq!(moments.sum.to_bits(), sum.to_bits());
            let mut two_pass = onepass.clone();

            finish_preprocess_from_log_sum(&mut two_pass, &hann, sum, DEFAULT_EPSILON);
            finish_hot_preprocess(&mut onepass, &hann, moments, DEFAULT_EPSILON);

            let maximum_error = onepass
                .iter()
                .zip(&two_pass)
                .map(|(&actual, &expected)| (actual - expected).abs())
                .fold(0.0f32, f32::max);
            assert!(
                maximum_error <= 2.0e-6,
                "family {family} maximum error {maximum_error}"
            );
        }
    }

    #[test]
    fn optimal_sizes_match_235_factorization() {
        assert_eq!(optimal_dft_size(1), Some(1));
        assert_eq!(optimal_dft_size(31), Some(32));
        assert_eq!(optimal_dft_size(33), Some(36));
        assert_eq!(optimal_dft_size(63), Some(64));
        assert_eq!(optimal_dft_size(65), Some(72));
    }

    #[test]
    fn tracker_log_lut_matches_direct_expression_for_every_u8() {
        let tracker = MosseTracker::default();

        for pixel in u8::MIN..=u8::MAX {
            assert_eq!(
                tracker.log_lut[pixel as usize].to_bits(),
                (pixel as f32 + 1.0).ln().to_bits(),
                "pixel {pixel}"
            );
        }
    }

    #[test]
    fn reduced_inverse_response_diagnostics_match_legacy_composition_bit_for_bit() {
        let width = 60;
        let height = 36;
        let deterministic: Vec<f32> = (0..width * height)
            .map(|index| {
                let integer = ((index * 73 + (index / width) * 29 + 17) % 251) as f32;
                (integer - 125.0) / 37.0
            })
            .collect();
        let mut impulse = vec![0.0; width * height];
        impulse[17 * width + 29] = 1.0;
        let signals = [("deterministic", deterministic), ("impulse", impulse)];
        let mut forward = Fft2::new(width, height);
        let mut legacy_inverse = Fft2::new(width, height);
        let mut reduced_inverse = Fft2::new(width, height);

        for (label, mut signal) in signals {
            let mut spectrum = vec![Complex32::new(0.0, 0.0); forward.spectrum_len()];
            forward.forward_real(&mut signal, &mut spectrum);
            let mut legacy_spectrum = spectrum.clone();
            let mut reduced_spectrum = spectrum;
            let mut normalized_response = vec![f32::NAN; width * height];
            let mut unscaled_response = vec![f32::NEG_INFINITY; width * height];

            legacy_inverse.inverse_real(&mut legacy_spectrum, &mut normalized_response);
            let expected = response_stats(&normalized_response, width, height, DEFAULT_EPSILON);
            let reduction =
                reduced_inverse.inverse_real_reduced(&mut reduced_spectrum, &mut unscaled_response);
            let actual = response_stats_from_reduction(reduction, width, height, DEFAULT_EPSILON);
            assert_response_stats_bits_eq(actual, expected, label);
        }
    }

    #[test]
    fn lookup_preprocessing_matches_direct_log_bit_for_bit() {
        let tracker = MosseTracker::default();
        let input: Vec<u8> = (u8::MIN..=u8::MAX).collect();
        let mut hann = vec![0.0; input.len()];
        create_hann_window(16, 16, &mut hann);
        let mut expected = vec![0.0; input.len()];
        let mut actual = vec![0.0; input.len()];

        preprocess_with_direct_log(&input, &hann, DEFAULT_EPSILON, &mut expected);
        preprocess(
            &input,
            &hann,
            &tracker.log_lut,
            DEFAULT_EPSILON,
            &mut actual,
        );

        for (index, (&expected, &actual)) in expected.iter().zip(&actual).enumerate() {
            assert_eq!(
                actual.to_bits(),
                expected.to_bits(),
                "preprocessed index {index}"
            );
        }
    }

    fn localization_spectrum_test_inputs(length: usize) -> (Vec<Complex32>, Vec<Complex32>) {
        let values = [
            0.0,
            -0.0,
            f32::from_bits(1),
            f32::from_bits(0x8000_0001),
            1.0,
            -1.0,
            3.25,
            -7.5,
            f32::INFINITY,
            f32::NEG_INFINITY,
            f32::from_bits(0x7fc0_0123),
            f32::from_bits(0xffc0_0456),
        ];
        let sample = (0..length)
            .map(|index| {
                Complex32::new(
                    values[(index * 5 + 1) % values.len()],
                    values[(index * 7 + 2) % values.len()],
                )
            })
            .collect();
        let filter = (0..length)
            .map(|index| {
                Complex32::new(
                    values[(index * 11 + 3) % values.len()],
                    values[(index * 13 + 4) % values.len()],
                )
            })
            .collect();
        (sample, filter)
    }

    #[test]
    fn scalar_localization_spectrum_matches_complex_conjugate_product_bit_for_bit() {
        for length in [0, 1, 3, 4, 5, 1_116] {
            let (sample, filter) = localization_spectrum_test_inputs(length);
            let expected: Vec<_> = sample
                .iter()
                .zip(&filter)
                .map(|(&sample, &filter)| sample * filter.conj())
                .collect();
            let mut actual = vec![Complex32::new(37.0, -41.0); length];

            multiply_localization_spectrum_scalar(&sample, &filter, &mut actual);

            assert_complex_bits_eq(
                &actual,
                &expected,
                &format!("scalar localization length {length}"),
            );
        }
    }

    #[test]
    fn localization_spectrum_dispatch_matches_scalar_bit_for_bit() {
        for length in [0, 1, 3, 4, 5, 1_116] {
            let (sample, filter) = localization_spectrum_test_inputs(length);
            let mut expected = vec![Complex32::new(-17.0, 19.0); length];
            let mut actual = vec![Complex32::new(23.0, -29.0); length];
            multiply_localization_spectrum_scalar(&sample, &filter, &mut expected);

            multiply_localization_spectrum(&sample, &filter, &mut actual);

            assert_complex_bits_eq(
                &actual,
                &expected,
                &format!("localization dispatch length {length}"),
            );
        }
    }

    #[cfg(target_arch = "aarch64")]
    #[test]
    fn neon_localization_spectrum_matches_scalar_bit_for_bit() {
        for length in [0, 1, 3, 4, 5, 1_116] {
            let (sample, filter) = localization_spectrum_test_inputs(length);
            let mut expected = vec![Complex32::new(-31.0, 43.0); length];
            let mut actual = vec![Complex32::new(47.0, -53.0); length];
            multiply_localization_spectrum_scalar(&sample, &filter, &mut expected);

            unsafe {
                multiply_localization_spectrum_neon(&sample, &filter, &mut actual);
            }

            assert_complex_bits_eq(
                &actual,
                &expected,
                &format!("NEON localization length {length}"),
            );
        }
    }

    #[test]
    fn localization_spectrum_matches_same_center_recompute_and_survives_model_blend() {
        let pixels = patterned_bgr(64, 64);
        let frame = BgrFrame::new(&pixels, 64, 64, 64 * 3).unwrap();
        let mut tracker = MosseTracker::default();
        tracker
            .init(
                frame,
                Rect {
                    x: 18.0,
                    y: 20.0,
                    width: 28.0,
                    height: 24.0,
                },
            )
            .unwrap();

        tracker.localize(frame, false);
        let localized_spectrum = tracker.workspace.as_ref().unwrap().test_spectrum();

        tracker.prepare_model_spectrum(frame);
        let recomputed_spectrum = tracker.workspace.as_ref().unwrap().test_spectrum();
        assert_complex_bits_eq(
            &localized_spectrum,
            &recomputed_spectrum,
            "same-center spectrum",
        );

        tracker.blend_current_spectrum_into_model();
        assert_complex_bits_eq(
            &tracker.workspace.as_ref().unwrap().test_spectrum(),
            &recomputed_spectrum,
            "spectrum after model blend",
        );
    }

    #[test]
    fn zero_displacement_reuse_matches_forced_recompute_across_updates() {
        let pixels = patterned_bgr(64, 64);
        let frame = BgrFrame::new(&pixels, 64, 64, 64 * 3).unwrap();
        let config = MosseConfig {
            psr_threshold: 0.0,
            ..MosseConfig::default()
        };
        let initial_box = Rect {
            x: 18.0,
            y: 20.0,
            width: 28.0,
            height: 24.0,
        };
        let mut reused = MosseTracker::new(config).unwrap();
        let mut recomputed = MosseTracker::new(config).unwrap();
        reused.init(frame, initial_box).unwrap();
        recomputed.init(frame, initial_box).unwrap();

        let mut zero_displacement_updates = 0;
        for _ in 0..4 {
            let actual = reused.update(frame).unwrap();
            let expected = update_with_forced_model_recompute(&mut recomputed, frame);
            if actual.success && actual.diagnostics.delta_x == 0 && actual.diagnostics.delta_y == 0
            {
                zero_displacement_updates += 1;
            }
            assert_update_result_bits_eq(actual, expected);
            assert_tracker_model_bits_eq(&reused, &recomputed);
        }
        assert!(zero_displacement_updates > 0);
    }

    #[test]
    fn nonzero_displacement_success_matches_forced_recompute() {
        let pixels = patterned_bgr(64, 64);
        let shifted_pixels = shift_bgr_right(&pixels, 64, 64, 2);
        let initial_frame = BgrFrame::new(&pixels, 64, 64, 64 * 3).unwrap();
        let shifted_frame = BgrFrame::new(&shifted_pixels, 64, 64, 64 * 3).unwrap();
        let config = MosseConfig {
            psr_threshold: 0.0,
            ..MosseConfig::default()
        };
        let initial_box = Rect {
            x: 18.0,
            y: 20.0,
            width: 28.0,
            height: 24.0,
        };
        let mut reused = MosseTracker::new(config).unwrap();
        let mut recomputed = MosseTracker::new(config).unwrap();
        reused.init(initial_frame, initial_box).unwrap();
        recomputed.init(initial_frame, initial_box).unwrap();

        let actual = reused.update(shifted_frame).unwrap();
        let expected = update_with_forced_model_recompute(&mut recomputed, shifted_frame);

        assert!(actual.success);
        assert_ne!(
            (actual.diagnostics.delta_x, actual.diagnostics.delta_y),
            (0, 0)
        );
        assert_update_result_bits_eq(actual, expected);
        assert_tracker_model_bits_eq(&reused, &recomputed);
    }

    #[test]
    fn spectrum_reuse_requires_success_and_zero_displacement() {
        assert!(can_reuse_localization_spectrum(true, 0, 0));
        for (success, delta_x, delta_y) in [
            (false, 0, 0),
            (true, 1, 0),
            (true, -1, 0),
            (true, 0, 1),
            (true, 0, -1),
            (false, 1, 1),
        ] {
            assert!(!can_reuse_localization_spectrum(success, delta_x, delta_y));
        }
    }

    #[test]
    fn opencv_rng_double_sequence_and_zero_seed_match_golden_values() {
        // Generated from OpenCV 4.10 operations.hpp's two-draw RNG::operator double.
        let expected_raw = [
            0xaa6c_0ba2_3e0c_f312,
            0x5532_527e_630b_db97,
            0x1928_d128_5d5e_a687,
            0x1bb7_7bac_73dd_2875,
            0x74f4_7041_214f_74fb,
        ];
        let mut raw_rng = CvRng::new(DEFAULT_RANDOM_SEED);
        for expected in expected_raw {
            let actual = ((raw_rng.next_u32() as u64) << 32) | raw_rng.next_u32() as u64;
            assert_eq!(actual, expected);
        }

        let expected_bits = [
            0x3fa0_f804_a74c_052c,
            0xbfa1_1f12_33d8_61a8,
            0xbfb4_916f_c4ba_2045,
            0xbfb4_0e80_dd82_6d5f,
            0xbf81_ac19_3164_4db0,
        ];
        let mut rng = CvRng::new(DEFAULT_RANDOM_SEED);
        for expected in expected_bits {
            assert_eq!(rng.uniform_f64(-0.1, 0.1).to_bits(), expected);
        }

        let mut zero_seed = CvRng::new(0);
        assert_eq!(zero_seed.next_u32(), 0x07c0_9cf6);
    }

    #[test]
    fn random_warp_float_matrix_matches_opencv_golden_bits() {
        let matrix = random_warp_matrix(8, 8, DEFAULT_RANDOM_SEED);
        let actual_bits = matrix.map(f32::to_bits);
        assert_eq!(
            actual_bits,
            [
                0x3f77_4c7a,
                0xbde8_6862,
                0x3f17_0248,
                0xbd39_2e45,
                0x3f7d_a680,
                0x3e5e_c640,
            ]
        );
    }

    #[test]
    fn random_warp_matches_opencv_cubic_constant_border_golden_patch() {
        // Captured from generic OpenCV warpAffine with IPP/OpenCL disabled and
        // flags=BORDER_REFLECT (therefore INTER_CUBIC with default constant border).
        let mut input = [0u8; 64];
        for y in 0..8 {
            for x in 0..8 {
                input[y * 8 + x] = ((x * 37 + y * 53 + x * y * 11 + 17) % 256) as u8;
            }
        }
        let expected = [
            1, 20, 56, 94, 142, 185, 252, 106, 21, 82, 131, 219, 73, 24, 87, 155, 60, 147, 249, 98,
            73, 148, 228, 52, 110, 255, 102, 105, 207, 20, 83, 149, 222, 92, 113, 221, 41, 136,
            190, 22, 53, 105, 214, 45, 160, 211, 73, 124, 73, 165, 33, 158, 206, 98, 151, 15, 173,
            230, 124, 183, 101, 128, 83, 91,
        ];
        let mut output = [0u8; 64];

        random_warp(&input, &mut output, 8, 8, DEFAULT_RANDOM_SEED);

        assert_eq!(output, expected);
    }

    #[test]
    fn rejects_invalid_frame_storage() {
        assert_eq!(
            BgrFrame::new(&[0; 12], 4, 1, 11).unwrap_err(),
            TrackerError::InvalidFrame
        );
        assert_eq!(
            BgrFrame::new(&[0; 11], 4, 1, 12).unwrap_err(),
            TrackerError::InvalidFrame
        );
        assert_eq!(
            BgrFrame::new(&[], 0, 1, 0).unwrap_err(),
            TrackerError::InvalidFrame
        );
    }

    #[test]
    fn hann_window_has_zero_edges_and_unit_center_for_odd_shape() {
        let mut hann = vec![0.0; 9 * 7];
        create_hann_window(9, 7, &mut hann);
        assert_eq!(hann[0], 0.0);
        assert!(hann[4] <= f32::EPSILON);
        assert!(hann[3 * 9] <= f32::EPSILON);
        assert!((hann[3 * 9 + 4] - 1.0).abs() < 1.0e-6);
    }

    #[test]
    fn reconstructed_filter_matches_opencv_conjugation_chain() {
        let sample = Complex32::new(2.0, 3.0);
        let goal = Complex32::new(4.0, 0.0);
        let numerator = [goal * sample.conj()];
        let denominator = [sample * sample.conj()];
        let mut filter = [Complex32::new(0.0, 0.0)];

        reconstruct_filter(&numerator, &denominator, &mut filter);
        let response = sample * filter[0].conj();

        assert!((response.re - goal.re).abs() < 1.0e-6);
        assert!((response.im - goal.im).abs() < 1.0e-6);
    }

    #[test]
    fn init_rejects_bad_box_without_destroying_previous_state() {
        let pixels = patterned_bgr(64, 64);
        let frame = BgrFrame::new(&pixels, 64, 64, 64 * 3).unwrap();
        let mut tracker = MosseTracker::default();
        let initial = tracker
            .init(
                frame,
                Rect {
                    x: 18.0,
                    y: 20.0,
                    width: 28.0,
                    height: 24.0,
                },
            )
            .unwrap();
        assert!(tracker.is_initialized());
        assert_eq!(initial.width, 30.0);
        assert_eq!(initial.height, 24.0);

        let error = tracker
            .init(
                frame,
                Rect {
                    x: f64::NAN,
                    y: 0.0,
                    width: 10.0,
                    height: 10.0,
                },
            )
            .unwrap_err();
        assert_eq!(error, TrackerError::InvalidBoundingBox);
        assert!(tracker.is_initialized());
        assert_eq!(tracker.diagnostics().window_width, 30);
    }

    #[test]
    fn constant_image_reports_tracking_failure() {
        let pixels = solid_bgr(64, 64, 127);
        let frame = BgrFrame::new(&pixels, 64, 64, 64 * 3).unwrap();
        let mut tracker = MosseTracker::default();
        let mut recomputed = MosseTracker::default();
        let initial_box = Rect {
            x: 20.0,
            y: 20.0,
            width: 20.0,
            height: 20.0,
        };
        tracker.init(frame, initial_box).unwrap();
        recomputed.init(frame, initial_box).unwrap();

        let (numerator, denominator, filter) = {
            let workspace = tracker.workspace.as_ref().unwrap();
            (
                workspace.test_numerator(),
                workspace.test_denominator(),
                workspace.test_filter(),
            )
        };
        let result = tracker.update(frame).unwrap();
        let expected = update_with_forced_model_recompute(&mut recomputed, frame);
        assert!(!result.success);
        assert_update_result_bits_eq(result, expected);
        assert_tracker_model_bits_eq(&tracker, &recomputed);
        assert_eq!(result.diagnostics.updates, 1);
        assert_eq!(result.diagnostics.last_success, 0);
        assert!(result.diagnostics.psr < DEFAULT_PSR_THRESHOLD);
        let workspace = tracker.workspace.as_ref().unwrap();
        assert_complex_bits_eq(&workspace.test_numerator(), &numerator, "failed numerator");
        assert_complex_bits_eq(
            &workspace.test_denominator(),
            &denominator,
            "failed denominator",
        );
        assert_complex_bits_eq(&workspace.test_filter(), &filter, "failed filter");
    }

    #[test]
    fn textured_image_can_initialize_and_update() {
        let pixels = patterned_bgr(64, 64);
        let frame = BgrFrame::new(&pixels, 64, 64, 64 * 3).unwrap();
        let config = MosseConfig {
            psr_threshold: 0.0,
            ..MosseConfig::default()
        };
        let mut tracker = MosseTracker::new(config).unwrap();
        let initialized_box = tracker
            .init(
                frame,
                Rect {
                    x: 18.0,
                    y: 20.0,
                    width: 28.0,
                    height: 24.0,
                },
            )
            .unwrap();

        let result = tracker.update(frame).unwrap();
        assert!(result.success);
        assert!(result.diagnostics.psr.is_finite());
        assert_eq!(result.bounding_box.width, initialized_box.width);
        assert_eq!(result.bounding_box.height, initialized_box.height);
    }

    #[test]
    fn update_before_init_is_rejected() {
        let pixels = solid_bgr(8, 8, 0);
        let frame = BgrFrame::new(&pixels, 8, 8, 8 * 3).unwrap();
        let mut tracker = MosseTracker::default();
        assert_eq!(
            tracker.update(frame).unwrap_err(),
            TrackerError::NotInitialized
        );
    }
}
