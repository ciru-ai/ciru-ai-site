#!/usr/bin/env python3
"""Minimal copy-paste example using only NumPy frames."""

from __future__ import annotations

import argparse

import numpy as np

from mosse_pi import MosseTracker


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--mode",
        choices=("auto", "single", "multicore"),
        default="auto",
    )
    args = parser.parse_args()

    initial_frame = np.zeros((160, 240, 3), dtype=np.uint8)
    next_frame = np.zeros_like(initial_frame)
    initial_frame[60:96, 70:130] = (40, 180, 240)
    next_frame[61:97, 71:131] = (40, 180, 240)
    roi = (70, 60, 60, 36)

    with MosseTracker(initial_frame, roi, mode=args.mode) as tracker:
        success, box = tracker.update(next_frame)
        print(
            f"requested={tracker.requested_mode} "
            f"selected={tracker.selected_mode} backend={tracker.backend}"
        )
        if tracker.native_library_info is not None:
            native = tracker.native_library_info
            features = ",".join(native.features) or "none"
            print(
                f"native_source={native.source_commit or 'unknown'} "
                f"package_source={native.package_source_commit or 'unknown'} "
                f"native_rust_tree={native.native_rust_tree or 'unknown'} "
                f"retained_qualified_binary={native.native_library_supplied} "
                f"native_sha256={native.sha256} native_features={features}"
            )
        print(f"success={success} box={box}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
