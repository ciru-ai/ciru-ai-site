from __future__ import annotations

import contextlib
import importlib.util
import io
import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "summarize_scoring", ROOT / "tools" / "summarize_scoring.py"
)
assert SPEC is not None and SPEC.loader is not None
SUMMARIZE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = SUMMARIZE
SPEC.loader.exec_module(SUMMARIZE)


def write_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as stream:
        json.dump(payload, stream)


def benchmark_summary(
    tracker: str,
    threads: int,
    fps: float,
    median_ns: int,
    p95_ns: int,
    successful: int,
    failed: int,
) -> dict:
    return {
        "schema_version": 1,
        "tracker": tracker,
        "opencv_threads_requested": threads,
        "tracker_only_fps": fps,
        "latency_ns": {
            "median": median_ns,
            "p95": p95_ns,
        },
        "attempted_updates": successful + failed,
        "successful_updates": successful,
        "failed_updates": failed,
    }


def runtime_state(temperature: float, throttle_mask: str) -> dict:
    return {
        "thermal_zones": [{"type": "cpu-thermal", "celsius": temperature}],
        "vcgencmd_get_throttled": {
            "available": True,
            "exit_code": 0,
            "output": f"throttled={throttle_mask}",
        },
    }


def measured_run(
    sequence: int,
    tracker: str,
    summary_path: str,
    pre_temperature: float,
    post_temperature: float,
    post_throttle: str = "0x0",
) -> dict:
    return {
        "sequence": sequence,
        "phase": "measured",
        "thread_count": 1,
        "pair_index": (sequence + 1) // 2,
        "tracker": tracker,
        "exit_code": 0,
        "artifacts": {"summary_json": summary_path},
        "runtime_state_pre": runtime_state(pre_temperature, "0x0"),
        "runtime_state_post": runtime_state(
            post_temperature, post_throttle
        ),
        # The summarizer must read the artifact instead of trusting this copy.
        "benchmark_summary": {"tracker_only_fps": 999999.0},
    }


def measured_run_v2(
    sequence: int,
    pair_index: int,
    tracker: str,
    summary_path: str,
    frames_path: str,
) -> dict:
    return {
        "sequence": sequence,
        "phase": "measured",
        "opencv_thread_count": 1,
        "rust_thread_count": 4,
        "tracker_thread_count": 1 if tracker == "opencv" else 4,
        "pair_index": pair_index,
        "global_pair_index": pair_index,
        "order_in_pair": 1 if tracker == "opencv" else 2,
        "tracker": tracker,
        "exit_code": 0,
        "artifacts": {
            "summary_json": summary_path,
            "frames_csv": frames_path,
        },
        "runtime_state_pre": runtime_state(45.0, "0x0"),
        "runtime_state_post": runtime_state(46.0, "0x0"),
    }


def exact_comparison() -> dict:
    return {
        "schema_version": 1,
        "frame_identity": {
            "row_count": 4947,
            "attempted_updates": 4946,
            "checksums_match": True,
        },
        "success": {
            "reference_successes": 2219,
            "candidate_successes": 2219,
            "agreement_count": 4946,
            "agreement_fraction": 1.0,
            "mismatch_count": 0,
            "mismatches": [],
        },
        "mutually_successful_frames": 2219,
        "center_distance_pixels": {
            "mean": 0.0,
            "median": 0.0,
            "p95": 0.0,
            "max": 0.0,
            "cumulative": 0.0,
            "within_two_pixels_count": 2219,
            "within_two_pixels_fraction": 1.0,
        },
        "iou": {
            "mean": 1.0,
            "median": 1.0,
            "p05": 1.0,
            "min": 1.0,
        },
        "absolute_size_delta_pixels": {
            "mean_width": 0.0,
            "max_width": 0.0,
            "mean_height": 0.0,
            "max_height": 0.0,
        },
        "gates": {
            "success_agreement_at_least_99_percent": True,
            "centers_within_two_pixels_at_least_99_percent": True,
            "mean_iou_at_least_0_98": True,
        },
    }


class SummarizeScoringTests(unittest.TestCase):
    def test_schema_v2_aggregates_asymmetric_pairs_and_exactness(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            runs = []
            parity = []
            sequence = 0
            for pair_index, (opencv_fps, rust_fps) in enumerate(
                ((2300.0, 11200.0), (2340.0, 11400.0)), start=1
            ):
                for tracker, fps, latency in (
                    ("opencv", opencv_fps, 430_000 - pair_index * 10_000),
                    ("rust", rust_fps, 90_000 - pair_index * 2_000),
                ):
                    sequence += 1
                    summary_path = (
                        f"pair-{pair_index}-{tracker}-summary.json"
                    )
                    frames_path = f"pair-{pair_index}-{tracker}.csv"
                    write_json(
                        root / summary_path,
                        benchmark_summary(
                            tracker,
                            1,
                            fps,
                            latency,
                            latency + 20_000,
                            2219,
                            2727,
                        ),
                    )
                    runs.append(
                        measured_run_v2(
                            sequence,
                            pair_index,
                            tracker,
                            summary_path,
                            frames_path,
                        )
                    )
                comparison_path = f"pair-{pair_index}-comparison.json"
                write_json(root / comparison_path, exact_comparison())
                parity.append(
                    {
                        "opencv_thread_count": 1,
                        "rust_thread_count": 4,
                        "pair_index": pair_index,
                        "global_pair_index": pair_index,
                        "exit_code": 0,
                        "all_gates_pass": True,
                        "opencv_csv": f"pair-{pair_index}-opencv.csv",
                        "rust_csv": f"pair-{pair_index}-rust.csv",
                        "comparison_json": comparison_path,
                    }
                )

            manifest_path = root / "manifest.json"
            write_json(
                manifest_path,
                {
                    "schema_version": 2,
                    "suite_id": "asymmetric-suite",
                    "status": "completed",
                    "exit_code": 0,
                    "parameters": {
                        "measured_pairs_per_configuration": 2,
                        "opencv_thread_count": 1,
                        "rust_core_counts": [4],
                        "core_pairings": [
                            {"opencv_threads": 1, "rust_cores": 4}
                        ],
                    },
                    "runs": [
                        {
                            "phase": "warmup",
                            "tracker": "rust",
                            "benchmark_summary": {
                                "tracker_only_fps": 999999.0
                            },
                        },
                        *runs,
                    ],
                    "parity_comparisons": parity,
                },
            )

            report = SUMMARIZE.summarize_manifest(manifest_path)

            self.assertTrue(report["aggregation_complete"])
            self.assertEqual(report["warnings"], [])
            self.assertEqual(report["measured_manifest_run_count"], 4)
            configuration = report["configurations"][0]
            self.assertEqual(configuration["opencv_thread_count"], 1)
            self.assertEqual(configuration["rust_core_count"], 4)
            self.assertEqual(
                configuration["trackers"]["opencv"]["tracker_fps"]["median"],
                2320.0,
            )
            self.assertEqual(
                configuration["trackers"]["rust"]["tracker_fps"]["median"],
                11300.0,
            )
            self.assertTrue(configuration["exactness"]["complete"])
            self.assertTrue(configuration["exactness"]["all_exact"])
            self.assertEqual(
                configuration["exactness"]["total_success_mismatches"], 0
            )
            self.assertEqual(len(configuration["pairs"]), 2)
            self.assertEqual(
                configuration["pairs"][0]["rust"]["tracker_thread_count"], 4
            )
            self.assertAlmostEqual(
                configuration["speedup_rust_over_opencv"][
                    "median_tracker_fps_ratio"
                ],
                11300.0 / 2320.0,
            )
            markdown = SUMMARIZE.render_markdown(report)
            self.assertIn("## Per-pair measured runs", markdown)
            self.assertIn("| 1 | 4 | 1 | 2300.000 |", markdown)
            self.assertIn("## Exactness", markdown)

    def test_schema_v2_requires_one_parity_record_per_pair(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for tracker in ("opencv", "rust"):
                write_json(
                    root / f"{tracker}.json",
                    benchmark_summary(tracker, 1, 10.0, 1000, 2000, 9, 1),
                )
            manifest_path = root / "manifest.json"
            write_json(
                manifest_path,
                {
                    "schema_version": 2,
                    "status": "completed",
                    "parameters": {
                        "measured_pairs_per_configuration": 1,
                        "core_pairings": [
                            {"opencv_threads": 1, "rust_cores": 4}
                        ],
                    },
                    "runs": [
                        measured_run_v2(
                            1, 1, "opencv", "opencv.json", "opencv.csv"
                        ),
                        measured_run_v2(
                            2, 1, "rust", "rust.json", "rust.csv"
                        ),
                    ],
                    "parity_comparisons": [],
                },
            )

            report = SUMMARIZE.summarize_manifest(manifest_path)

            self.assertFalse(report["aggregation_complete"])
            self.assertIn(
                "expected one parity comparison, found 0",
                "\n".join(report["warnings"]),
            )

    def test_completed_manifest_aggregates_relative_summary_paths(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            summaries = root / "nested" / "summaries"
            write_json(
                summaries / "opencv-1.json",
                benchmark_summary(
                    "opencv_legacy_mosse", 1, 10.0, 1000, 2000, 9, 1
                ),
            )
            write_json(
                summaries / "rust-1.json",
                benchmark_summary(
                    "rust_mosse_scalar", 1, 30.0, 500, 800, 10, 0
                ),
            )
            write_json(
                summaries / "opencv-2.json",
                benchmark_summary("opencv", 1, 20.0, 1200, 2200, 9, 1),
            )
            write_json(
                summaries / "rust-2.json",
                benchmark_summary("rust", 1, 60.0, 600, 900, 9, 1),
            )

            runs = [
                {
                    "sequence": 0,
                    "phase": "warmup",
                    "thread_count": 1,
                    "tracker": "opencv",
                    "exit_code": 0,
                    "artifacts": {
                        "summary_json": "nested/summaries/warmup.json"
                    },
                },
                measured_run(
                    1, "opencv", "nested/summaries/opencv-1.json", 40.0, 41.0
                ),
                measured_run(
                    2, "rust", "nested/summaries/rust-1.json", 42.0, 43.0
                ),
                measured_run(
                    3, "opencv", "nested/summaries/opencv-2.json", 44.0, 45.0
                ),
                measured_run(
                    4,
                    "rust",
                    "nested/summaries/rust-2.json",
                    46.0,
                    47.0,
                    "0x50000",
                ),
            ]
            manifest_path = root / "manifest.json"
            write_json(
                manifest_path,
                {
                    "schema_version": 1,
                    "suite_id": "completed-suite",
                    "status": "completed",
                    "exit_code": 0,
                    "parameters": {
                        "measured_pairs_per_thread_count": 2,
                        "thread_counts": [1],
                    },
                    "runs": runs,
                },
            )

            report = SUMMARIZE.summarize_manifest(manifest_path)

            self.assertTrue(report["aggregation_complete"])
            self.assertEqual(report["measured_manifest_run_count"], 4)
            thread = report["threads"][0]
            opencv = thread["trackers"]["opencv"]
            rust = thread["trackers"]["rust"]
            self.assertEqual(opencv["run_count"], 2)
            self.assertEqual(opencv["tracker_fps"]["mean"], 15.0)
            self.assertEqual(opencv["tracker_fps"]["median"], 15.0)
            self.assertEqual(opencv["latency_ns"]["median"], 1100.0)
            self.assertEqual(opencv["latency_ns"]["p95"], 2100.0)
            self.assertTrue(opencv["update_stability"]["stable"])
            self.assertFalse(rust["update_stability"]["stable"])
            self.assertEqual(
                opencv["temperature_celsius"]["min"], 40.0
            )
            self.assertEqual(
                opencv["temperature_celsius"]["max"], 45.0
            )
            self.assertFalse(opencv["throttling"]["observed"])
            self.assertTrue(rust["throttling"]["observed"])
            self.assertEqual(
                rust["throttling"]["masks"], ["0x0", "0x50000"]
            )
            self.assertEqual(
                thread["speedup_rust_over_opencv"][
                    "median_tracker_fps_ratio"
                ],
                3.0,
            )
            self.assertEqual(report["warnings"], [])

            markdown = SUMMARIZE.render_markdown(report)
            self.assertIn("| 1 | opencv | 2 | 15.000 | 15.000 |", markdown)
            self.assertIn("| 1 | 3.000 | 3.000 |", markdown)
            self.assertIn("yes (0x50000)", markdown)

    def test_failed_manifest_returns_partial_results_and_warnings(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            write_json(
                root / "artifacts" / "opencv.json",
                benchmark_summary("opencv", 1, 12.0, 1000, 1800, 8, 2),
            )
            (root / "artifacts" / "broken.json").write_text(
                "{not json", encoding="utf-8"
            )
            write_json(
                root / "states" / "pre.json", runtime_state(50.0, "0x0")
            )
            write_json(
                root / "states" / "post.json", runtime_state(51.0, "0x0")
            )
            manifest_path = root / "manifest.json"
            write_json(
                manifest_path,
                {
                    "schema_version": 1,
                    "suite_id": "failed-suite",
                    "status": "failed",
                    "exit_code": 70,
                    "parameters": {
                        "measured_pairs_per_thread_count": 2,
                        "thread_counts": [1],
                    },
                    "runs": [
                        {
                            "sequence": 1,
                            "phase": "measured",
                            "thread_count": 1,
                            "tracker": "opencv",
                            "exit_code": 0,
                            "artifacts": {
                                "summary_json": "artifacts/opencv.json",
                                "runtime_state_pre": "states/pre.json",
                                "runtime_state_post": "states/post.json",
                            },
                        },
                        {
                            "sequence": 2,
                            "phase": "measured",
                            "thread_count": 1,
                            "tracker": "rust",
                            "exit_code": 70,
                            "artifacts": {
                                "summary_json": "artifacts/missing.json"
                            },
                        },
                        {
                            "sequence": 3,
                            "phase": "measured",
                            "thread_count": 1,
                            "tracker": "opencv",
                            "exit_code": 0,
                            "artifacts": {
                                "summary_json": "artifacts/broken.json"
                            },
                        },
                    ],
                },
            )

            report = SUMMARIZE.summarize_manifest(manifest_path)

            self.assertFalse(report["aggregation_complete"])
            thread = report["threads"][0]
            opencv = thread["trackers"]["opencv"]
            rust = thread["trackers"]["rust"]
            self.assertEqual(opencv["manifest_run_count"], 2)
            self.assertEqual(opencv["run_count"], 1)
            self.assertEqual(opencv["invalid_summary_count"], 1)
            self.assertEqual(opencv["temperature_celsius"]["min"], 50.0)
            self.assertEqual(opencv["temperature_celsius"]["max"], 51.0)
            self.assertEqual(rust["manifest_run_count"], 1)
            self.assertEqual(rust["run_count"], 0)
            self.assertEqual(rust["failed_run_count"], 1)
            self.assertIsNone(
                thread["speedup_rust_over_opencv"][
                    "median_tracker_fps_ratio"
                ]
            )
            warning_text = "\n".join(report["warnings"])
            self.assertIn("manifest status is 'failed'", warning_text)
            self.assertIn("cannot read", warning_text)
            self.assertIn("expected 2 measured runs, found 1", warning_text)

    def test_cli_emits_valid_json_for_partial_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manifest_path = Path(directory) / "manifest.json"
            write_json(
                manifest_path,
                {
                    "schema_version": 1,
                    "suite_id": "running-suite",
                    "status": "running",
                    "exit_code": 0,
                    "parameters": {
                        "measured_pairs_per_thread_count": 1,
                        "thread_counts": [1],
                    },
                    "runs": [],
                },
            )
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                exit_code = SUMMARIZE.main(
                    [str(manifest_path), "--format", "json"]
                )

            self.assertEqual(exit_code, 0)
            payload = json.loads(output.getvalue())
            self.assertFalse(payload["aggregation_complete"])
            self.assertEqual(payload["threads"][0]["thread_count"], 1)
            self.assertTrue(payload["warnings"])

    def test_non_object_manifest_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manifest_path = Path(directory) / "manifest.json"
            write_json(manifest_path, [])
            with self.assertRaisesRegex(
                SUMMARIZE.SummaryError, "manifest root must be an object"
            ):
                SUMMARIZE.summarize_manifest(manifest_path)


if __name__ == "__main__":
    unittest.main()
