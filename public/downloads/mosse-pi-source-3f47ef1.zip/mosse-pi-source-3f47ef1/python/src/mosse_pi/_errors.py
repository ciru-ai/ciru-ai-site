"""Public exception hierarchy for :mod:`mosse_pi`."""


class MosseError(RuntimeError):
    """Base class for wrapper and native tracker failures."""


class NativeLibraryError(MosseError):
    """The native shared library could not be used."""


class NativeLibraryNotFoundError(NativeLibraryError):
    """No compatible bundled or explicitly selected shared library exists."""


class NativeStatusError(MosseError):
    """A native C ABI call returned a nonzero status."""

    def __init__(self, operation: str, status: int, detail: str) -> None:
        self.operation = operation
        self.status = status
        self.detail = detail
        super().__init__(f"{operation} failed with native status {status}: {detail}")


class InvalidFrameError(MosseError, ValueError):
    """A frame is not a uint8 HxWx3 BGR NumPy array."""


class InvalidBoundingBoxError(MosseError, ValueError):
    """An initialization rectangle is malformed."""


class TrackerClosedError(MosseError):
    """An operation requires a live tracker handle."""


class TrackerThreadError(MosseError):
    """A caller used a live tracker from a different native thread."""


class MulticoreUnavailableError(MosseError):
    """Explicit multicore mode initialized through a single-thread fallback."""
