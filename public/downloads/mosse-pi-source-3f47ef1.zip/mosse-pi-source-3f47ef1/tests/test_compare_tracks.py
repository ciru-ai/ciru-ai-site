from __future__ import annotations

import csv
import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "compare_tracks", ROOT / "tools" / "compare_tracks.py"
)
assert SPEC is not None and SPEC.loader is not None
COMPARE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = COMPARE
SPEC.loader.exec_module(COMPARE)


HEADER = (
    "frame_index",
    "is_initialization",
    "update_attempted",
    "success",
    "bbox_x",
    "bbox_y",
    "bbox_width",
    "bbox_height",
    "update_ns",
    "update_us",
    "frame_checksum_fnv1a64",
)


def write_csv(path: Path, rows: list[tuple]) -> None:
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(HEADER)
        writer.writerows(rows)


class CompareTracksTests(unittest.TestCase):
    def test_metrics_and_gates(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            reference_path = root / "reference.csv"
            candidate_path = root / "candidate.csv"
            write_csv(
                reference_path,
                [
                    (0, 1, 0, 1, 10, 10, 20, 10, 0, 0, "aa"),
                    (1, 0, 1, 1, 10, 10, 20, 10, 1, 0.001, "bb"),
                    (2, 0, 1, 0, 10, 10, 20, 10, 1, 0.001, "cc"),
                ],
            )
            write_csv(
                candidate_path,
                [
                    (0, 1, 0, 1, 10, 10, 20, 10, 0, 0, "aa"),
                    (1, 0, 1, 1, 11, 10, 20, 10, 1, 0.001, "bb"),
                    (2, 0, 1, 1, 11, 10, 20, 10, 1, 0.001, "cc"),
                ],
            )

            result = COMPARE.compare(
                COMPARE.read_frames(reference_path),
                COMPARE.read_frames(candidate_path),
                worst_count=5,
            )

            self.assertEqual(result["frame_identity"]["attempted_updates"], 2)
            self.assertEqual(result["success"]["mismatch_count"], 1)
            self.assertEqual(result["mutually_successful_frames"], 1)
            self.assertEqual(result["center_distance_pixels"]["mean"], 1.0)
            self.assertAlmostEqual(result["iou"]["mean"], 19.0 / 21.0)
            self.assertFalse(
                result["gates"]["success_agreement_at_least_99_percent"]
            )

    def test_checksum_mismatch_is_rejected(self) -> None:
        left = [
            COMPARE.Frame(0, True, True, 0.0, 0.0, 10.0, 10.0, "aa")
        ]
        right = [
            COMPARE.Frame(0, True, True, 0.0, 0.0, 10.0, 10.0, "bb")
        ]
        with self.assertRaisesRegex(ValueError, "checksum differs"):
            COMPARE.compare(left, right, worst_count=1)


if __name__ == "__main__":
    unittest.main()
