from __future__ import annotations

import os

import numpy as np
import pytest

from mosse_pi import MosseTracker, NativeLibraryNotFoundError
from mosse_pi._native import LIBRARY_OVERRIDE_ENV


def test_real_native_library_smoke_when_artifact_is_available() -> None:
    image = np.zeros((64, 96, 3), dtype=np.uint8)
    try:
        tracker = MosseTracker(image, (20, 16, 32, 24), mode="single")
    except NativeLibraryNotFoundError as error:
        if os.environ.get(LIBRARY_OVERRIDE_ENV):
            raise
        pytest.skip(f"native preview artifact not installed: {error}")

    with tracker:
        success, box = tracker.update(image)
        assert isinstance(success, bool)
        assert len(box) == 4
