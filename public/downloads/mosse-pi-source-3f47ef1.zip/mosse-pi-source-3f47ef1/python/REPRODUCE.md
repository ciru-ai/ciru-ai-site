# Reproducing the Linux preview bundles

These commands rebuild the architecture-native shared library and wheel from
a clean source commit. The staged bundle records the exact commit, Rust
version, Cargo lock hash, enabled features, glibc version, and
`SOURCE_DATE_EPOCH` in `build_info.json` and `manifest.json`.

The Python build needs Python 3.9 or newer, `build`, a C toolchain, Cargo,
Rust, GNU coreutils, and network access to the locked Cargo/Python
dependencies. Runtime installation needs Python 3.9 or newer and NumPy 1.24
or newer. The OpenCV example additionally needs `opencv-python`.

## Linux AArch64 / Raspberry Pi native build

Use a clean checkout on the AArch64 target. Rust 1.97.1 is the recorded
preview toolchain:

```bash
git checkout <full-source-commit-from-build_info.json>
python3 -m venv /tmp/mosse-preview-build
. /tmp/mosse-preview-build/bin/activate
python -m pip install --upgrade 'pip' 'build==1.3.0'
rustup toolchain install 1.97.1 --profile minimal
export RUSTUP_TOOLCHAIN=1.97.1
export MOSSE_PREVIEW_SOURCE_COMMIT="$(git rev-parse HEAD)"
export SOURCE_DATE_EPOCH="$(git show -s --format=%ct HEAD)"
./python/build_preview.sh
```

For AArch64, the builder invokes the native release build with one codegen
unit, LTO disabled, no default features, and this exact production preview
feature set:

```text
shared-activity-futex-wake
normal-spin-four-core-runtime
fused-correlated-inverse-cfft36-60x36
composite-preprocess-forward-60x36
parallel-model-blend-filter-60x36
```

The corresponding native command, which `build_preview.sh` issues after
clearing build-affecting environment overrides, is:

```bash
CARGO_PROFILE_RELEASE_CODEGEN_UNITS=1 \
CARGO_PROFILE_RELEASE_LTO=false \
cargo build \
  --manifest-path rust/Cargo.toml \
  --release \
  --locked \
  --lib \
  --no-default-features \
  --features 'shared-activity-futex-wake,normal-spin-four-core-runtime,fused-correlated-inverse-cfft36-60x36,composite-preprocess-forward-60x36,parallel-model-blend-filter-60x36'
```

No generated GPL experiment code is part of this feature set or package.

To package a previously qualified native library byte-for-byte, rather than
relinking the unchanged Rust tree from a different absolute checkout path,
provide the retained binary and its source identities:

```bash
export MOSSE_PREVIEW_NATIVE_LIBRARY=/absolute/path/to/libmosse_core.so
export MOSSE_PREVIEW_NATIVE_SOURCE_COMMIT=<full-native-source-commit>
export MOSSE_PREVIEW_NATIVE_RUST_TREE=<full-rust-tree-object-id>
./python/build_preview.sh
```

The supplied library's SHA-256, native source commit, Rust tree object, and
the fact that a retained binary was supplied are recorded in both
`build_info.json` and `manifest.json`. The package source commit remains
separate, so wrapper-only packaging changes do not masquerade as a native
rebuild.

## Linux x86_64 manylinux 2.28 build

The x86_64 wheel is built in this image by exact digest:

```text
quay.io/pypa/manylinux_2_28_x86_64@sha256:fdb9a9c223b215604dc7b6f7e8fff4b39bfea5fbaa7777a2e5544a60dfa437f8
```

From a clean checkout, create a Git archive and invoke the pinned container:

```bash
commit="$(git rev-parse HEAD)"
epoch="$(git show -s --format=%ct "$commit")"
rust_tree="$(git rev-parse "$commit:rust")"
source_tar="$(mktemp --suffix=.tar)"
output_dir="$(pwd -P)/artifacts/python-preview"
git archive --format=tar "$commit" > "$source_tar"
mkdir -p "$output_dir"

docker run --rm \
  -e MOSSE_PREVIEW_SOURCE_COMMIT="$commit" \
  -e MOSSE_PREVIEW_NATIVE_SOURCE_COMMIT="$commit" \
  -e MOSSE_PREVIEW_NATIVE_RUST_TREE="$rust_tree" \
  -e MOSSE_PREVIEW_OUTPUT_DIR=/output \
  -e MOSSE_PREVIEW_CARGO_TARGET_DIR=/work/cargo-target \
  -e MOSSE_PREVIEW_AUDITWHEEL_PLAT=manylinux_2_28_x86_64 \
  -e SOURCE_DATE_EPOCH="$epoch" \
  -v "$source_tar:/input/source.tar:ro" \
  -v "$output_dir:/output" \
  quay.io/pypa/manylinux_2_28_x86_64@sha256:fdb9a9c223b215604dc7b6f7e8fff4b39bfea5fbaa7777a2e5544a60dfa437f8 \
  bash -euxo pipefail -c '
    mkdir -p /src /work
    tar -xf /input/source.tar -C /src
    curl --proto "=https" --tlsv1.2 -sSf https://sh.rustup.rs |
      sh -s -- -y --profile minimal --default-toolchain 1.97.1
    /opt/python/cp312-cp312/bin/python -m venv /work/pyenv
    /work/pyenv/bin/python -m pip install "build==1.3.0"
    export PATH="/work/pyenv/bin:/root/.cargo/bin:$PATH"
    /src/python/build_preview.sh
  '

rm -f -- "$source_tar"
```

The x86_64 package deliberately uses the generic single-thread native path
and requires glibc 2.28 or newer. The AArch64 package requires glibc 2.34 or
newer and contains both safe single-thread and capability-gated multicore
modes behind the same Python API. Its multicore kernels require the
internally rounded FFT window to be exactly 60x36; `auto` safely selects
single-thread for other sizes and explicit multicore fails clearly.

## Smoke and finalize

Install and exercise the wheel from the staged architecture directory, not
from the source tree. Record the exact host, wheel/library hashes, commands,
selected backend, and results in a non-empty `SMOKE_TEST.md` in that
directory. Both API examples must be run, and the separate latency example
must at least pass `--help`:

```bash
python -m pip install --force-reinstall ./mosse_pi-*.whl
python examples/numpy_api.py --mode auto
python examples/video_capture.py --help
python examples/measure_wrapper_latency.py --help
# Then run video_capture.py against an actual file or camera as documented
# in README.md. On the Pi, launch the process with its documented CPU layout.
```

Finalize only after the smoke record exists:

```bash
SOURCE_DATE_EPOCH="$(python3 -c \
  'import json; print(json.load(open("manifest.json"))["source_date_epoch"])')" \
  /path/to/source/python/finalize_preview.sh "$(pwd -P)"
```

The finalizer regenerates a recursive `manifest.json` and `SHA256SUMS`,
creates the deterministic `.tar.gz`, extracts it to a new temporary
directory, checks every hash there, and confirms that all bundled examples
are present. `manifest.json` and `SHA256SUMS` are excluded from the manifest's
own file map to avoid self-reference; the recursive `SHA256SUMS` covers
`manifest.json`.
