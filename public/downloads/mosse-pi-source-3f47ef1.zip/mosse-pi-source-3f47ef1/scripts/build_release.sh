#!/usr/bin/env bash
#
# Build the native benchmark harness and Rust tracker in release mode.

set -euo pipefail

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
repo_root="$(cd -- "${script_dir}/.." && pwd -P)"
invocation_dir="$(pwd -P)"

build_dir="${MOSSE_BUILD_DIR:-${repo_root}/build/release}"
cargo_manifest="${MOSSE_CARGO_MANIFEST:-${repo_root}/rust/Cargo.toml}"
cargo_target_dir="${CARGO_TARGET_DIR:-${repo_root}/build/cargo-target}"
jobs="${MOSSE_BUILD_JOBS:-}"
rust_target="${CARGO_BUILD_TARGET:-}"
cargo_features="${MOSSE_CARGO_FEATURES:-}"
rust_staticlib=""
cmake_toolchain=""
component="all"
run_tests=1
allow_unlocked=0
enable_rust_backend=1
pi4_production=0
pi4_production_features="shared-activity-futex-wake,normal-spin-four-core-runtime,fused-correlated-inverse-cfft36-60x36,composite-preprocess-forward-60x36,parallel-model-blend-filter-60x36"
pi4_production_toolchain="1.97.1"

usage() {
    cat <<'EOF'
Usage: build_release.sh [options]

Builds the Rust static/shared library and CMake benchmark harness using release
profiles. By default, both test suites run after the build.

Options:
  --build-dir PATH          CMake build directory (default: build/release).
  --cargo-manifest PATH     Cargo.toml path (default: rust/Cargo.toml).
  --cargo-target-dir PATH   Cargo output directory (default: build/cargo-target).
  --rust-target TRIPLE      Optional Cargo target triple.
  --cargo-features LIST     Comma-separated Cargo features for the Rust build.
  --pi4-production          Use the exact Experiment 066 Pi production features
                            and Rust 1.97.1 profile selection.
  --rust-staticlib PATH     Exact prebuilt Rust staticlib path for CMake.
  --cmake-toolchain PATH    Optional CMake toolchain file for cross-compilation.
  --jobs COUNT              Parallel build jobs.
  --component all|rust|cpp  Select which component to build.
  --opencv-only             Build the C++ harness without the Rust backend.
  --no-tests                Build without running Cargo tests or CTest.
  --allow-unlocked          Permit Cargo to resolve without an existing lockfile.
  --help                    Show this help.

Environment:
  RUSTFLAGS, CFLAGS, and CXXFLAGS are honored. Use them for explicit CPU tuning;
  this script does not silently add host-specific flags to portable builds.
  MOSSE_CARGO_FEATURES supplies the same value as --cargo-features.
  Cargo profile overrides such as CARGO_PROFILE_RELEASE_CODEGEN_UNITS are also
  honored. Prefer --pi4-production to reproduce the measured Pi build exactly.
EOF
}

while (($# > 0)); do
    case "$1" in
        --build-dir)
            build_dir="$2"
            shift 2
            ;;
        --cargo-manifest)
            cargo_manifest="$2"
            shift 2
            ;;
        --cargo-target-dir)
            cargo_target_dir="$2"
            shift 2
            ;;
        --rust-target)
            rust_target="$2"
            shift 2
            ;;
        --cargo-features)
            cargo_features="$2"
            shift 2
            ;;
        --pi4-production)
            pi4_production=1
            shift
            ;;
        --rust-staticlib)
            rust_staticlib="$2"
            shift 2
            ;;
        --cmake-toolchain)
            cmake_toolchain="$2"
            shift 2
            ;;
        --jobs)
            jobs="$2"
            shift 2
            ;;
        --component)
            component="$2"
            shift 2
            ;;
        --opencv-only)
            enable_rust_backend=0
            shift
            ;;
        --no-tests)
            run_tests=0
            shift
            ;;
        --allow-unlocked)
            allow_unlocked=1
            shift
            ;;
        --help|-h)
            usage
            exit 0
            ;;
        *)
            echo "error: unknown argument: $1" >&2
            usage >&2
            exit 2
            ;;
    esac
done

case "$component" in
    all|rust|cpp) ;;
    *)
        echo "error: --component must be all, rust, or cpp" >&2
        exit 2
        ;;
esac

if [[ "$component" == "rust" && "$enable_rust_backend" == "0" ]]; then
    echo "error: --opencv-only cannot be combined with --component rust" >&2
    exit 2
fi

if [[ -n "$jobs" && ! "$jobs" =~ ^[1-9][0-9]*$ ]]; then
    echo "error: --jobs must be a positive integer" >&2
    exit 2
fi

if ((pi4_production == 1)); then
    if [[ -n "$cargo_features" && "$cargo_features" != "$pi4_production_features" ]]; then
        echo \
            "error: --pi4-production cannot be combined with a different Cargo feature set" \
            >&2
        exit 2
    fi
    if [[ -n "${CARGO_PROFILE_RELEASE_CODEGEN_UNITS:-}" \
        && "${CARGO_PROFILE_RELEASE_CODEGEN_UNITS}" != "1" ]]; then
        echo \
            "error: --pi4-production requires CARGO_PROFILE_RELEASE_CODEGEN_UNITS=1" \
            >&2
        exit 2
    fi
    if [[ -n "${CARGO_PROFILE_RELEASE_LTO:-}" \
        && "${CARGO_PROFILE_RELEASE_LTO}" != "false" ]]; then
        echo "error: --pi4-production requires CARGO_PROFILE_RELEASE_LTO=false" >&2
        exit 2
    fi
    if [[ -n "${RUSTUP_TOOLCHAIN:-}" \
        && "${RUSTUP_TOOLCHAIN}" != "$pi4_production_toolchain" ]]; then
        echo \
            "error: --pi4-production requires RUSTUP_TOOLCHAIN=$pi4_production_toolchain" \
            >&2
        exit 2
    fi
    cargo_features="$pi4_production_features"
    export CARGO_PROFILE_RELEASE_CODEGEN_UNITS=1
    export CARGO_PROFILE_RELEASE_LTO=false
    export RUSTUP_TOOLCHAIN="$pi4_production_toolchain"
fi

required_commands=()
if [[ "$component" == "all" || "$component" == "cpp" ]]; then
    required_commands+=(cmake ninja)
fi
if [[ "$component" == "rust" \
    || ("$component" == "all" && "$enable_rust_backend" == "1") ]]; then
    required_commands+=(cargo rustc)
fi

for required_command in "${required_commands[@]}"; do
    if ! command -v "$required_command" >/dev/null 2>&1; then
        echo "error: required command is unavailable: $required_command" >&2
        echo "hint: enter the development shell with 'nix develop'" >&2
        exit 1
    fi
done

if ((pi4_production == 1)) \
    && [[ "$component" == "rust" \
        || ("$component" == "all" && "$enable_rust_backend" == "1") ]]; then
    expected_rustc_prefix="rustc ${pi4_production_toolchain} "
    actual_rustc_version="$(rustc --version 2>/dev/null || true)"
    actual_cargo_version="$(cargo --version 2>/dev/null || true)"
    if [[ "$actual_rustc_version" != "$expected_rustc_prefix"* \
        || "$actual_cargo_version" != "cargo ${pi4_production_toolchain} "* ]]; then
        echo \
            "error: --pi4-production requires the Rust $pi4_production_toolchain toolchain" \
            >&2
        echo "actual rustc: ${actual_rustc_version:-unavailable}" >&2
        echo "actual cargo: ${actual_cargo_version:-unavailable}" >&2
        echo \
            "hint: install it with 'rustup toolchain install $pi4_production_toolchain --profile minimal'" \
            >&2
        exit 1
    fi
fi

if [[ -z "${SOURCE_DATE_EPOCH:-}" ]]; then
    SOURCE_DATE_EPOCH="$(
        git -C "$repo_root" log -1 --format=%ct 2>/dev/null || printf '1'
    )"
fi
export SOURCE_DATE_EPOCH
export CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR="$cargo_target_dir"

if [[ -z "$jobs" ]]; then
    jobs="$(getconf _NPROCESSORS_ONLN 2>/dev/null || printf '1')"
fi

echo "Repository:       $repo_root"
echo "CMake build:      $build_dir"
echo "Cargo target dir: $cargo_target_dir"
echo "Parallel jobs:    $jobs"
echo "SOURCE_DATE_EPOCH=$SOURCE_DATE_EPOCH"
if [[ -n "$cargo_features" ]]; then
    echo "Cargo features:   $cargo_features"
else
    echo "Cargo features:   (default)"
fi
if ((pi4_production == 1)); then
    echo \
        "Pi production:    Experiment 066 Rust $pi4_production_toolchain feature/profile selection"
fi

if [[ "$component" == "rust" \
    || ("$component" == "all" && "$enable_rust_backend" == "1") ]]; then
    if [[ ! -f "$cargo_manifest" ]]; then
        echo "error: Cargo manifest not found: $cargo_manifest" >&2
        exit 1
    fi

    cargo_lock="$(dirname -- "$cargo_manifest")/Cargo.lock"
    cargo_common=(
        --manifest-path "$cargo_manifest"
        --release
        --jobs "$jobs"
    )

    if [[ -n "$rust_target" ]]; then
        cargo_common+=(--target "$rust_target")
        echo "Rust target:      $rust_target"
    fi
    if [[ -n "$cargo_features" ]]; then
        cargo_common+=(--features "$cargo_features")
    fi
    if ((pi4_production == 1)); then
        cargo_common+=(--no-default-features)
    fi

    if [[ -f "$cargo_lock" ]]; then
        cargo_common+=(--locked)
    elif ((allow_unlocked == 0)); then
        echo "error: reproducible release build requires $cargo_lock" >&2
        echo \
            "hint: generate and commit it with 'cargo generate-lockfile --manifest-path $cargo_manifest'," \
            >&2
        echo "      or use --allow-unlocked only for initial bring-up." >&2
        exit 1
    else
        echo "warning: building Rust dependencies without a lockfile" >&2
    fi

    echo "Building Rust release artifacts..."
    cargo build "${cargo_common[@]}"

    if ((run_tests == 1)); then
        host_triple="$(rustc -vV | sed -n 's/^host: //p')"
        if [[ -z "$rust_target" || "$rust_target" == "$host_triple" ]]; then
            echo "Running Rust release tests..."
            cargo test "${cargo_common[@]}"
        else
            echo \
                "Skipping Rust tests: target '$rust_target' is not executable on host '$host_triple'." \
                >&2
        fi
    fi
fi

if [[ "$component" == "all" || "$component" == "cpp" ]]; then
    if [[ ! -f "${repo_root}/CMakeLists.txt" ]]; then
        echo "error: CMakeLists.txt not found at repository root" >&2
        exit 1
    fi

    cmake_configure=(
        -S "$repo_root"
        -B "$build_dir"
        -G Ninja
        -DCMAKE_BUILD_TYPE=Release
        -DCMAKE_EXPORT_COMPILE_COMMANDS=ON
        -DBUILD_TESTING=ON
    )

    if ((enable_rust_backend == 1)); then
        if [[ -z "$rust_staticlib" ]]; then
            rust_artifact_dir="$cargo_target_dir"
            if [[ -n "$rust_target" ]]; then
                rust_artifact_dir="${rust_artifact_dir}/${rust_target}"
            fi
            rust_staticlib="${rust_artifact_dir}/release/libmosse_core.a"
        fi
        if [[ "$rust_staticlib" != /* ]]; then
            rust_staticlib="${invocation_dir}/${rust_staticlib}"
        fi

        if [[ ! -f "$rust_staticlib" ]]; then
            echo "error: Rust static library not found: $rust_staticlib" >&2
            echo \
                "hint: build --component all, pass --rust-staticlib PATH, or use --opencv-only." \
                >&2
            exit 1
        fi

        echo "Rust staticlib:   $rust_staticlib"
        cmake_configure+=(
            -DMOSSE_ENABLE_RUST_BACKEND=ON
            "-DMOSSE_RUST_STATICLIB=${rust_staticlib}"
        )
    else
        echo "Rust backend:     disabled (OpenCV-only)"
        cmake_configure+=(
            -DMOSSE_ENABLE_RUST_BACKEND=OFF
        )
    fi

    if [[ -n "$cmake_toolchain" ]]; then
        if [[ ! -f "$cmake_toolchain" ]]; then
            echo "error: CMake toolchain file not found: $cmake_toolchain" >&2
            exit 1
        fi
        cmake_configure+=("-DCMAKE_TOOLCHAIN_FILE=$cmake_toolchain")
    fi

    echo "Configuring C++ release build..."
    cmake "${cmake_configure[@]}"

    echo "Building C++ release artifacts..."
    cmake --build "$build_dir" --parallel "$jobs"

    if ((run_tests == 1)); then
        echo "Running C++ release tests..."
        ctest --test-dir "$build_dir" --output-on-failure
    fi
fi

echo "Release build complete."
