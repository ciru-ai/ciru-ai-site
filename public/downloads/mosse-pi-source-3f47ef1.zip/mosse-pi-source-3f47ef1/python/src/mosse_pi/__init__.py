"""Python API for the preview native MOSSE tracker package."""

from ._errors import (
    InvalidBoundingBoxError,
    InvalidFrameError,
    MosseError,
    MulticoreUnavailableError,
    NativeLibraryError,
    NativeLibraryNotFoundError,
    NativeStatusError,
    TrackerClosedError,
    TrackerThreadError,
)
from ._native import NativeLibraryInfo
from ._version import __version__
from .tracker import MosseTracker

__all__ = [
    "InvalidBoundingBoxError",
    "InvalidFrameError",
    "MosseError",
    "MosseTracker",
    "MulticoreUnavailableError",
    "NativeLibraryError",
    "NativeLibraryInfo",
    "NativeLibraryNotFoundError",
    "NativeStatusError",
    "TrackerClosedError",
    "TrackerThreadError",
    "__version__",
]
