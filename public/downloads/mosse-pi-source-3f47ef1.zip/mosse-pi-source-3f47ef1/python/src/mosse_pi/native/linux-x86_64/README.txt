Place the Linux x86_64 preview libmosse_core.so in this directory before
building the x86_64 wheel. The loader requires the exact filename
libmosse_core.so.
