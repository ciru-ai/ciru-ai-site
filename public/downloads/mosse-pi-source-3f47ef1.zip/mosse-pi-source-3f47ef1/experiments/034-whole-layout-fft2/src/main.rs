use mosse_exp034_whole_layout_fft2::{
    PaddedSpectrum, WholeLayoutFft2, HEIGHT, PADDED_SPECTRUM_LEN, ROUND_TRIP_SCALE, SPATIAL_LEN,
    VALID_SPECTRUM_LEN, WIDTH,
};
use realfft::RealFftPlanner;
use rustfft::{num_complex::Complex32, FftPlanner};
use std::{
    hint::black_box,
    process::ExitCode,
    time::{Duration, Instant},
};

const ABS_TOLERANCE: f32 = 2.0e-2;
const REL_TOLERANCE: f32 = 2.0e-6;
const TIMING_BLOCK: usize = 8;

#[derive(Clone, Copy)]
struct Config {
    correctness_only: bool,
    warmup: usize,
    sample_ms: u64,
    samples: usize,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            correctness_only: false,
            warmup: 100,
            sample_ms: 100,
            samples: 5,
        }
    }
}

struct TimingResult {
    median: f64,
    minimum: f64,
    maximum: f64,
    checksum: f64,
    samples: Vec<f64>,
}

#[derive(Default)]
struct ErrorMetrics {
    values: u64,
    error_energy: f64,
    reference_energy: f64,
    max_abs: f32,
    max_fraction: f32,
}

impl ErrorMetrics {
    fn observe(
        &mut self,
        actual: f32,
        expected: f32,
        reference_scale: f32,
        context: &str,
    ) -> Result<(), String> {
        if !actual.is_finite() || !expected.is_finite() {
            return Err(format!(
                "{context}: non-finite value actual={actual:?} expected={expected:?}"
            ));
        }
        let error = (actual - expected).abs();
        let allowed = ABS_TOLERANCE + REL_TOLERANCE * reference_scale;
        if error > allowed {
            return Err(format!(
                "{context}: actual={actual:.9e} expected={expected:.9e} \
                 error={error:.9e} allowed={allowed:.9e}"
            ));
        }
        self.values += 1;
        self.error_energy += f64::from(error) * f64::from(error);
        self.reference_energy += f64::from(expected) * f64::from(expected);
        self.max_abs = self.max_abs.max(error);
        self.max_fraction = self.max_fraction.max(error / allowed);
        Ok(())
    }

    fn rms_relative(&self) -> f64 {
        (self.error_energy / self.reference_energy.max(f64::MIN_POSITIVE)).sqrt()
    }
}

fn main() -> ExitCode {
    match parse_config().and_then(run) {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            eprintln!("error: {error}");
            ExitCode::FAILURE
        }
    }
}

fn parse_config() -> Result<Config, String> {
    let mut config = Config::default();
    let mut arguments = std::env::args().skip(1);
    while let Some(argument) = arguments.next() {
        match argument.as_str() {
            "--correctness-only" => config.correctness_only = true,
            "--warmup" => {
                config.warmup = arguments
                    .next()
                    .ok_or("--warmup requires a value")?
                    .parse()
                    .map_err(|_| "--warmup must be a nonnegative integer")?;
            }
            "--sample-ms" => {
                config.sample_ms = arguments
                    .next()
                    .ok_or("--sample-ms requires a value")?
                    .parse()
                    .map_err(|_| "--sample-ms must be positive")?;
            }
            "--samples" => {
                config.samples = arguments
                    .next()
                    .ok_or("--samples requires a value")?
                    .parse()
                    .map_err(|_| "--samples must be positive")?;
            }
            "--help" | "-h" => {
                println!(
                    "whole_layout_fft2_probe [--correctness-only] \
                     [--warmup N] [--sample-ms MS] [--samples N]"
                );
                std::process::exit(0);
            }
            _ => return Err(format!("unknown argument: {argument}")),
        }
    }
    if config.sample_ms == 0 || config.samples == 0 {
        return Err("--sample-ms and --samples must be nonzero".into());
    }
    Ok(config)
}

fn run(config: Config) -> Result<(), String> {
    println!("experiment=034-whole-layout-fft2");
    println!("backend={}", WholeLayoutFft2::backend_name());
    println!(
        "geometry={}x{} valid_half_spectrum={} padded_complex={} padding_complex={}",
        WIDTH,
        HEIGHT,
        VALID_SPECTRUM_LEN,
        PADDED_SPECTRUM_LEN,
        PADDED_SPECTRUM_LEN - VALID_SPECTRUM_LEN
    );
    println!(
        "pipeline=9xrfft60_batch4,fused_4x4_row_column_tiles,8xcfft36_batch4 \
         normalization=none roundtrip_scale={}",
        ROUND_TRIP_SCALE
    );
    println!(
        "warning=isolated_whole_fft_ceiling_not_tracker_fps \
         excludes=tracker_preprocess,pointwise_model_ops,response_reduction,ffi"
    );

    let metrics = correctness_gate()?;
    println!(
        "correctness=pass compared_values={} max_abs={:.9e} \
         rms_relative={:.9e} max_tolerance_fraction={:.6}",
        metrics.values,
        metrics.max_abs,
        metrics.rms_relative(),
        metrics.max_fraction
    );
    if config.correctness_only {
        return Ok(());
    }

    println!(
        "timing_scope=complete_fixed_2d_fft \
         forward_includes=row_gather,9xrfft60,all_tiled_transposes,pad_zero,8xcfft36 \
         inverse_includes=8xcfft36,all_tiled_transposes,9xrfft60,row_scatter \
         excludes=fixture_reset warmup={} sample_ms={} samples={} block={}",
        config.warmup, config.sample_ms, config.samples, TIMING_BLOCK
    );
    let forward = time_forward(config);
    let inverse = time_inverse(config);
    print_timing("forward", &forward);
    print_timing("inverse", &inverse);
    Ok(())
}

fn correctness_gate() -> Result<ErrorMetrics, String> {
    let input = deterministic_input(0x0340_f00d_cafe_beef, 0.75);
    let expected_spectrum = oracle_forward(&input)?;
    let forward_scale = complex_reference_scale(&expected_spectrum);
    let mut clean = WholeLayoutFft2::new();
    let mut dirty = WholeLayoutFft2::new();
    dirty.poison_scratch(0x1234_abcd);
    let mut clean_spectrum = PaddedSpectrum::default();
    let mut dirty_spectrum = PaddedSpectrum::default();
    dirty_spectrum.poison_all(0x9911_55aa);
    clean.forward(&input, &mut clean_spectrum);
    dirty.forward(&input, &mut dirty_spectrum);
    require_spectrum_bits(&clean_spectrum, &dirty_spectrum, "forward dirty scratch")?;
    if !clean_spectrum.padding_is_positive_zero() {
        return Err("forward padded column is not exact positive zero".into());
    }

    let mut metrics = ErrorMetrics::default();
    for (index, (&actual, &expected)) in clean_spectrum
        .to_column_major_valid()
        .iter()
        .zip(&expected_spectrum)
        .enumerate()
    {
        metrics.observe(
            actual.re,
            expected.re,
            forward_scale,
            &format!("forward={index} re"),
        )?;
        metrics.observe(
            actual.im,
            expected.im,
            forward_scale,
            &format!("forward={index} im"),
        )?;
    }

    let expected_spatial = oracle_inverse(&expected_spectrum)?;
    let inverse_scale = real_reference_scale(&expected_spatial);
    let mut clean_inverse_input = PaddedSpectrum::from_column_major_valid(&expected_spectrum);
    let mut dirty_inverse_input = clean_inverse_input.clone();
    let mut clean_output = vec![f32::NAN; SPATIAL_LEN];
    let mut dirty_output = vec![f32::from_bits(0x7fc0_3456); SPATIAL_LEN];
    dirty.poison_scratch(0xa5a5_3c3c);
    clean.inverse(&mut clean_inverse_input, &mut clean_output);
    dirty.inverse(&mut dirty_inverse_input, &mut dirty_output);
    require_spectrum_bits(
        &clean_inverse_input,
        &dirty_inverse_input,
        "inverse dirty scratch consumed spectrum",
    )?;
    for index in 0..SPATIAL_LEN {
        if clean_output[index].to_bits() != dirty_output[index].to_bits() {
            return Err(format!("inverse dirty scratch mismatch at {index}"));
        }
        metrics.observe(
            clean_output[index],
            expected_spatial[index],
            inverse_scale,
            &format!("inverse={index}"),
        )?;
    }

    let mut round_trip_spectrum = PaddedSpectrum::default();
    clean.forward(&input, &mut round_trip_spectrum);
    let mut round_trip = vec![f32::NAN; SPATIAL_LEN];
    clean.inverse(&mut round_trip_spectrum, &mut round_trip);
    let round_trip_reference_scale = real_reference_scale(&input) * ROUND_TRIP_SCALE;
    for index in 0..SPATIAL_LEN {
        metrics.observe(
            round_trip[index],
            input[index] * ROUND_TRIP_SCALE,
            round_trip_reference_scale,
            &format!("roundtrip={index}"),
        )?;
    }
    Ok(metrics)
}

fn complex_reference_scale(values: &[Complex32]) -> f32 {
    values.iter().fold(0.0f32, |scale, value| {
        scale.max(value.re.abs()).max(value.im.abs())
    })
}

fn real_reference_scale(values: &[f32]) -> f32 {
    values
        .iter()
        .fold(0.0f32, |scale, value| scale.max(value.abs()))
}

fn require_spectrum_bits(
    actual: &PaddedSpectrum,
    expected: &PaddedSpectrum,
    context: &str,
) -> Result<(), String> {
    for batch in 0..actual.batches.len() {
        for ky in 0..HEIGHT {
            for lane in 0..4 {
                if actual.batches[batch].re[ky][lane].to_bits()
                    != expected.batches[batch].re[ky][lane].to_bits()
                    || actual.batches[batch].im[ky][lane].to_bits()
                        != expected.batches[batch].im[ky][lane].to_bits()
                {
                    return Err(format!(
                        "{context}: mismatch batch={batch} ky={ky} lane={lane}"
                    ));
                }
            }
        }
    }
    Ok(())
}

fn oracle_forward(input: &[f32]) -> Result<Vec<Complex32>, String> {
    let mut real_planner = RealFftPlanner::<f32>::new();
    let row_plan = real_planner.plan_fft_forward(WIDTH);
    let mut row_input = vec![0.0; WIDTH];
    let mut row_output = row_plan.make_output_vec();
    let mut output = vec![Complex32::new(0.0, 0.0); VALID_SPECTRUM_LEN];
    for y in 0..HEIGHT {
        row_input.copy_from_slice(&input[y * WIDTH..(y + 1) * WIDTH]);
        row_plan
            .process(&mut row_input, &mut row_output)
            .map_err(|error| format!("oracle row forward: {error}"))?;
        for kx in 0..row_output.len() {
            output[kx * HEIGHT + y] = row_output[kx];
        }
    }
    let mut planner = FftPlanner::<f32>::new();
    planner.plan_fft_forward(HEIGHT).process(&mut output);
    Ok(output)
}

fn oracle_inverse(input: &[Complex32]) -> Result<Vec<f32>, String> {
    let mut columns = input.to_vec();
    let mut planner = FftPlanner::<f32>::new();
    planner.plan_fft_inverse(HEIGHT).process(&mut columns);
    let mut real_planner = RealFftPlanner::<f32>::new();
    let row_plan = real_planner.plan_fft_inverse(WIDTH);
    let mut row_input = row_plan.make_input_vec();
    let mut row_output = row_plan.make_output_vec();
    let mut output = vec![0.0; SPATIAL_LEN];
    for y in 0..HEIGHT {
        for kx in 0..row_input.len() {
            row_input[kx] = columns[kx * HEIGHT + y];
        }
        row_input[0].im = 0.0;
        let last = row_input.len() - 1;
        row_input[last].im = 0.0;
        row_plan
            .process(&mut row_input, &mut row_output)
            .map_err(|error| format!("oracle row inverse: {error}"))?;
        output[y * WIDTH..(y + 1) * WIDTH].copy_from_slice(&row_output);
    }
    Ok(output)
}

fn deterministic_input(seed: u64, scale: f32) -> Vec<f32> {
    (0..SPATIAL_LEN)
        .map(|index| {
            let bits = splitmix64(seed ^ index as u64);
            let fraction = ((bits >> 40) as u32) as f32 * (1.0 / 16_777_216.0);
            (fraction * 2.0 - 1.0) * scale
        })
        .collect()
}

fn splitmix64(mut value: u64) -> u64 {
    value = value.wrapping_add(0x9e37_79b9_7f4a_7c15);
    value = (value ^ (value >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
    value = (value ^ (value >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
    value ^ (value >> 31)
}

fn time_forward(config: Config) -> TimingResult {
    let inputs: Vec<Vec<f32>> = (0..TIMING_BLOCK)
        .map(|index| deterministic_input(0x34f0_0000_0000_0000 ^ index as u64, 0.25))
        .collect();
    let mut outputs = vec![PaddedSpectrum::default(); TIMING_BLOCK];
    let mut fft = WholeLayoutFft2::new();
    for iteration in 0..config.warmup {
        let slot = iteration % TIMING_BLOCK;
        fft.forward(black_box(&inputs[slot]), black_box(&mut outputs[slot]));
    }
    measure(config, |sample, calls| {
        let started = Instant::now();
        for slot in 0..TIMING_BLOCK {
            fft.forward(black_box(&inputs[slot]), black_box(&mut outputs[slot]));
        }
        let elapsed = started.elapsed();
        let slot = (sample + calls as usize) % TIMING_BLOCK;
        let kx = (sample * 7 + calls as usize) % 31;
        let ky = (sample * 11 + calls as usize) % HEIGHT;
        let value = outputs[slot].get(kx, ky);
        (elapsed, f64::from(value.re) + f64::from(value.im))
    })
}

fn time_inverse(config: Config) -> TimingResult {
    let inputs: Vec<Vec<f32>> = (0..TIMING_BLOCK)
        .map(|index| deterministic_input(0x34a0_0000_0000_0000 ^ index as u64, 0.25))
        .collect();
    let mut seeds = vec![PaddedSpectrum::default(); TIMING_BLOCK];
    let mut preparation = WholeLayoutFft2::new();
    for slot in 0..TIMING_BLOCK {
        preparation.forward(&inputs[slot], &mut seeds[slot]);
    }
    let mut work = seeds.clone();
    let mut outputs = vec![vec![0.0; SPATIAL_LEN]; TIMING_BLOCK];
    let mut fft = WholeLayoutFft2::new();

    for iteration in 0..config.warmup {
        let slot = iteration % TIMING_BLOCK;
        work[slot] = seeds[slot].clone();
        fft.inverse(black_box(&mut work[slot]), black_box(&mut outputs[slot]));
    }
    measure(config, |sample, calls| {
        work.clone_from(&seeds);
        let started = Instant::now();
        for slot in 0..TIMING_BLOCK {
            fft.inverse(black_box(&mut work[slot]), black_box(&mut outputs[slot]));
        }
        let elapsed = started.elapsed();
        let slot = (sample + calls as usize) % TIMING_BLOCK;
        let index = (sample * 17 + calls as usize) % SPATIAL_LEN;
        (
            elapsed,
            f64::from(outputs[slot][index])
                + f64::from(outputs[slot][(index + WIDTH + 1) % SPATIAL_LEN]),
        )
    })
}

fn measure(config: Config, mut block: impl FnMut(usize, u64) -> (Duration, f64)) -> TimingResult {
    let target = Duration::from_millis(config.sample_ms);
    let mut samples = Vec::with_capacity(config.samples);
    let mut checksum = 0.0;
    for sample in 0..config.samples {
        let mut measured = Duration::ZERO;
        let mut calls = 0_u64;
        while measured < target {
            let (elapsed, contribution) = block(sample, calls);
            measured += elapsed;
            calls += TIMING_BLOCK as u64;
            checksum += black_box(contribution);
        }
        samples.push(measured.as_secs_f64() * 1.0e9 / calls as f64);
    }
    samples.sort_by(f64::total_cmp);
    TimingResult {
        median: samples[samples.len() / 2],
        minimum: samples[0],
        maximum: samples[samples.len() - 1],
        checksum,
        samples,
    }
}

fn print_timing(direction: &str, result: &TimingResult) {
    println!(
        "direction={} median_ns_per_2d={:.3} min_ns={:.3} max_ns={:.3} \
         checksum={:.9e} samples_ns={:?}",
        direction, result.median, result.minimum, result.maximum, result.checksum, result.samples
    );
}
