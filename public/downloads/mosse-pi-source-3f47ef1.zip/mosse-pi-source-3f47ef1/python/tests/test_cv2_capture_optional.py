from __future__ import annotations

import ctypes

import numpy as np
import pytest

from mosse_pi import MosseTracker
from mosse_pi._native import BACKEND_GENERIC_SINGLE, Rect

cv2 = pytest.importorskip("cv2", reason="OpenCV example dependency is optional")


class _CaptureBindings:
    info = None

    def __init__(self) -> None:
        self.init_frame = None

    def create(self, mode: int) -> ctypes.c_void_p:
        return ctypes.c_void_p(1)

    def init(self, handle: ctypes.c_void_p, frame: object, rect: Rect) -> None:
        self.init_frame = frame

    def backend_status(self, handle: ctypes.c_void_p) -> int:
        return BACKEND_GENERIC_SINGLE

    def update(self, handle: ctypes.c_void_p, frame: object) -> tuple[bool, Rect]:
        return True, Rect(8.0, 8.0, 24.0, 16.0)

    def destroy(self, handle: ctypes.c_void_p) -> None:
        return None


def test_cv2_video_capture_bgr_array_is_accepted_zero_copy(tmp_path) -> None:
    video_path = tmp_path / "capture-style.avi"
    writer = cv2.VideoWriter(
        str(video_path),
        cv2.VideoWriter_fourcc(*"MJPG"),
        10.0,
        (64, 48),
    )
    if not writer.isOpened():
        pytest.skip("OpenCV build has no usable MJPG VideoWriter")
    try:
        writer.write(np.full((48, 64, 3), (20, 80, 140), dtype=np.uint8))
    finally:
        writer.release()

    capture = cv2.VideoCapture(str(video_path))
    try:
        ok, frame = capture.read()
    finally:
        capture.release()
    if not ok:
        pytest.skip("OpenCV build could not decode its generated MJPG frame")

    assert frame.dtype == np.uint8
    assert frame.shape == (48, 64, 3)
    bindings = _CaptureBindings()
    with MosseTracker(
        frame,
        (8, 8, 24, 16),
        mode="single",
        _bindings=bindings,
    ) as tracker:
        assert tracker.last_frame_was_zero_copy
        assert bindings.init_frame is not None
        assert bindings.init_frame.array is frame
