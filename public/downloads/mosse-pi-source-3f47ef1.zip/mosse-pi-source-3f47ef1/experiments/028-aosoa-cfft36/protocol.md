# Experiment 028: four-lane AoSoA CFFT36

## Status

The isolated kernel is implemented. Local, Dunamis, and Pi deterministic gates
pass. Dunamis correctly rejects it as an x86 replacement, while the Pi runtime
ceiling is materially faster than the retained AArch64 Good-Thomas columns.
This experiment does not modify the production tracker or its Cargo manifest.

## Purpose

Test the principal kernel needed by a custom fixed 60x36 FFT: four independent
length-36 complex transforms executed together, with each AArch64 NEON lane
holding the same logical element from a different transform.

This result cannot be reported as tracker FPS. It neither changes benchmark
accounting nor omits any of the 4,946 update attempts. Any promotion requires a
separate production integration, exact trace-equivalence gate, and complete
replay.

## Data layout

`Batch4` stores two arrays:

```text
re[logical_index_0_to_35][transform_lane_0_to_3]
im[logical_index_0_to_35][transform_lane_0_to_3]
```

One `re[index]` or `im[index]` is four adjacent `f32` values. AArch64 loads it
as one `float32x4_t`; the four lanes never interact. Dunamis and other
non-AArch64 targets use equivalent four-lane scalar-source arithmetic for
correctness and transfer screening.

The public input and output stay in logical FFT order. Therefore the timed
kernel call includes both Good-Thomas CRT permutations, the intermediate
transpose, and all persistent-scratch traffic. Conversion into this AoSoA
contract is outside the codelet timing and would have to be counted if a later
tracker integration could not produce/consume the layout directly.

## Arithmetic mapping

The transform uses Good-Thomas factors `width=4`, `height=9`, following
RustFFT 6.4.1's public `GoodThomasAlgorithmSmall` mapping:

- input map for staging position `i`, with `x=i mod 4`, `y=floor(i/4)`:
  `(x*9 + y*4) mod 36`;
- output map for staged position `i`, with `y=i mod 9`, `x=floor(i/9)`:
  `(x*9 + y*4*7) mod 36`, because `inv(4 mod 9)=7` and
  `inv(9 mod 4)=1`.

The stages are:

1. gather the CRT-permuted logical input into persistent scratch A;
2. run nine fixed radix-4 codelets;
3. transpose the 9x4 intermediate to 4x9 into persistent scratch B;
4. run four fixed radix-9 codelets;
5. scatter through the CRT output map to logical frequency order.

Each radix-9 codelet is a fixed 3x3 decimation-in-time factorization. With
`n=n1+3*n2` and `k=k2+3*k1`, it performs radix-3 transforms over `n2`,
multiplies the four nontrivial `W9^(n1*k2)` twiddles, then performs radix-3
transforms over `n1`. Forward and inverse are separately monomorphized; both
are unnormalized, matching RustFFT.

## Safety and scratch invariants

- The safe Rust API accepts initialized `Kernel36x4` and `Batch4` references.
- AArch64 intrinsic load/store arithmetic uses valid references to exactly four
  contiguous `f32` values.
- CRT gather/scatter use unchecked array access only after compile-time
  assertions prove both constant maps are permutations of `0..36`; loop
  enumeration independently bounds the other index.
- The two exported C symbols exist only for stable assembly labels and state
  explicit pointer validity requirements.
- Both CRT maps are compile-time arrays and unit-tested as permutations of
  `0..36`.
- Every scratch A element is overwritten by the input gather before use.
- Every scratch B element is overwritten by the transpose before use.
- Validation poisons both workspaces with lane- and index-specific NaNs before
  calls, then requires finite output and bit-identical results across different
  poison patterns.
- No allocation, planning, or scratch sizing occurs in `process_forward` or
  `process_inverse`.

## Correctness gate

Compare complete four-transform batches against four independent RustFFT 6.4
length-36 transforms, in both directions, using:

- all zero;
- lane-specific complex impulses including indices 0 and 35;
- constant/alternating/polynomial structure;
- four complex tones at different exact bins;
- deterministic non-symmetric random inputs at scales `1e-3`, `1`, and `1e3`;
- a nonperiodic complex chirp.

For every component, require finite values and
`abs(error) <= 5e-4 + 5e-5*abs(reference)`. Report maximum absolute error,
RMS-relative error, and the maximum fraction of the tolerance consumed.
Forward-then-inverse round trips must match `36*input`. Two calls made after
different NaN scratch poisons must be bit-identical.

## Lean timing

The harness times blocks of 16 complete in-place kernel calls and resets input
between blocks outside the measured interval. This avoids transform growth
without subtracting timer overhead or timing a synthetic normalization pass.
Each call includes the two CRT permutations, radix-4 stage, transpose,
radix-9 stage, and scratch traffic. It reports median nanoseconds per batch of
four transforms and a data-dependent checksum.

The timing excludes fixture reset and construction of the already-AoSoA
contract. It is labeled a **codelet ceiling**, never tracker FPS or an
end-to-end prediction.

## Commands

```sh
cargo test --manifest-path experiments/028-aosoa-cfft36/Cargo.toml --release
cargo run --manifest-path experiments/028-aosoa-cfft36/Cargo.toml --release -- \
  --correctness-only
cargo run --manifest-path experiments/028-aosoa-cfft36/Cargo.toml --release -- \
  --warmup 1000 --sample-ms 100 --samples 5
```

For AArch64 code generation on Dunamis:

```sh
cargo rustc --manifest-path experiments/028-aosoa-cfft36/Cargo.toml \
  --target aarch64-unknown-linux-gnu --release --lib -- \
  -C target-cpu=cortex-a72 --emit=asm
```

Inspect the `exp028_aosoa_cfft36_forward` and
`exp028_aosoa_cfft36_inverse` symbols for vector `fadd`, `fsub`, `fmul`,
loads, and stores. This is a code-generation gate only; do not run or benchmark
the AArch64 artifact on Dunamis.

## Correctness result

The release test suite and executable oracle passed on both the Windows
development host and Dunamis. The final Dunamis source hashes were:

- `src/lib.rs`:
  `cfe0accaf21694d7ee5cb4ab1d5f6105d510faa8a6b3c2507f99a6327de91fce`;
- `src/main.rs`:
  `2fd3a8ad19229225151f72f1a4e8a73926f823964686e9176d77b337046d22b7`;
- `Cargo.lock`:
  `cff7173253481908d215b830f946c5534ba255e702b3cdd4999440b6560eddff`.

Across eight fixtures, two direct directions, and one round trip per fixture,
the oracle compared 6,912 real-valued components. Final metrics were:

- maximum absolute error: `9.765625000e-3`;
- RMS-relative error: `1.230153087e-7` on Dunamis;
- largest consumed fraction of the component tolerance: `0.191262`;
- non-finite values: zero;
- dirty-scratch differences: zero, including bitwise comparison after
  distinct NaN poison patterns.

The largest absolute value comes from the `1e3` scale round-trip case; the
relative and locked mixed tolerance both remain comfortably inside the gate.

## Dunamis transfer screen

One lean final screen ran on Dunamis after the correctness gate. It used
release mode, `RUSTFLAGS="-C target-cpu=native"`, `taskset -c 0`, and
`flock /tmp/mosse-dunamis-benchmark.lock`, with 1,000 warmup calls and five
100 ms kernel-time samples. The host was the Intel Core i9-14900KF running
Linux 7.1.0 with Rust/Cargo 1.97.1. Intel P-state reported governor
`powersave`, energy-performance preference `performance`, and turbo enabled;
therefore this does not claim a fixed x86 clock.

| Direction | Median ns/batch of four | Min ns | Max ns |
|---|---:|---:|---:|
| Forward | 180.632 | 180.593 | 180.718 |
| Inverse | 180.171 | 180.077 | 180.435 |

The complete sample vectors were:

- forward:
  `[180.593323, 180.623808, 180.632115, 180.633069, 180.718393]`;
- inverse:
  `[180.077345, 180.103269, 180.170980, 180.335985, 180.435275]`.

The native binary SHA-256 was
`45d7b3363f9b1e7a934a7db65e4c9c01bcab0da4ed18734c0ab01cc8e8708da6`.
This is a codelet ceiling and not tracker FPS.

The result is **not an x86 transfer win**. For context, Experiment 024's
separate CPU0 screen measured RustFFT's direct AVX length-36 butterfly at
345.119 ns forward and 345.327 ns inverse for 31 transforms. Normalizing those
separate-screen values gives about 11.133/11.140 ns per transform, versus
45.158/45.043 ns here: this portable-source AoSoA codelet has approximately
4.056x/4.043x the per-transform latency. The comparison is contextual rather
than a same-binary ratio, but the margin is far too large to promote this as a
Dunamis replacement. Dunamis should retain RustFFT's specialized AVX kernel.

## Cortex-A72 code-generation result

Dunamis cross-compiled the library for `aarch64-unknown-linux-gnu` with
`target-cpu=cortex-a72`. The target standard library came from the official
Rust 1.97.1 distribution and its published SHA-256 was verified before
installation.

The generated assembly SHA-256 was
`bc53cf1c152f38a2524ca4b72e99e431db8ce0e438aecce65e17215bfc36a1f8`.
Inspection of each stable forward/inverse symbol found:

- 489 static assembly lines;
- 244 static four-wide vector floating-point instructions in the emitted loop
  bodies, including 108 `fadd`, 96 `fsub`, 20 `fmul`, and 20 `fmla`;
- vector `q` loads/stores and `.4s` arithmetic throughout the codelets;
- zero scalar floating-point arithmetic;
- zero residual bounds-check branches and zero function calls.

This passes the compile-time NEON gate.

## Pi runtime ceiling

The exact isolated sources were copied to the Pi and built with Rust 1.97.1
in `build/cargo-exp028`. No tracker source or benchmark timing boundary was
changed. The release binary SHA-256 was
`966cf3d1eed9eff7e3e0a85eda0eef02370ffbdb9d6b8400e4e57760d4c150e1`.

The native AArch64 oracle passed:

- backend: `aarch64-neon`;
- compared real-valued components: `6,912`;
- maximum absolute error: `7.812500000e-3`;
- RMS-relative error: `1.106264267e-7`;
- maximum tolerance fraction consumed: `0.224768`;
- dirty-scratch and non-finite failures: zero.

One serialized CPU-0 screen used the `performance` governor, 1,000 warmup
calls, five 100 ms kernel-time samples, and the shared Pi benchmark lock.
Temperature moved from `52.5 C` to `53.5 C`, CPU 0 remained at
`1,800,000 kHz`, and firmware throttling remained `0x0`.

| Direction | Median ns/batch of four | Min ns | Max ns |
|---|---:|---:|---:|
| Forward | `700.394` | `700.314` | `701.127` |
| Inverse | `703.752` | `703.510` | `703.974` |

The complete sample vectors were:

- forward:
  `[700.313782, 700.333340, 700.394092, 700.844857, 701.127012]`;
- inverse:
  `[703.510270, 703.704937, 703.752132, 703.949192, 703.974448]`.

This remains a codelet ceiling, not tracker FPS. It excludes construction of
the AoSoA contract, so production integration must emit and consume this
layout directly.

For an honest padded integration comparison, eight calls process 32 columns,
including the dummy column needed to eliminate the 31-column tail:

| Direction | Eight AoSoA calls, 32 columns | Retained RustFFT GT4x9, 31 columns | Ceiling ratio |
|---|---:|---:|---:|
| Forward | `5,603.152 ns` | `12,099.105 ns` | `2.159339x` |
| Inverse | `5,630.016 ns` | `12,076.210 ns` | `2.144969x` |

The separate-screen comparison includes the AoSoA kernel's CRT permutations,
transpose, codelets, and scratch traffic, and charges it for one extra padded
column. It does not include a tracker-side AoS/SoA conversion. The margin is
large enough to pass stop gate 4 and justify a whole-layout integration
experiment; inserting conversions around this isolated call is not justified.

## Stop gate

Stop this direction before production integration if any of these occurs:

1. any direction, fixture, lane, or round trip fails the deterministic oracle;
2. scratch poison changes any result or produces a non-finite value;
3. AArch64 assembly scalarizes the four transform lanes instead of using
   vector floating-point arithmetic;
4. the complete AArch64 kernel ceiling is not plausibly below the retained
   RustFFT Good-Thomas 4x9 column cost after a later Pi measurement.

All four gates pass. This permits a separate whole-layout integration
experiment. It does not retain an optimization or establish tracker speed.
