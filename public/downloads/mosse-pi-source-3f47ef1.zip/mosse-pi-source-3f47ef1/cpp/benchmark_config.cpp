#include "mosse/benchmark_config.hpp"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <string>

#include <opencv2/core/persistence.hpp>

namespace mosse {
namespace {

cv::FileNode find_node(const cv::FileNode &root, const char *flat_name,
                       const char *section_name, const char *nested_name) {
  const cv::FileNode flat = root[flat_name];
  if (!flat.empty()) {
    return flat;
  }

  const cv::FileNode section = root[section_name];
  if (!section.empty() && section.isMap()) {
    return section[nested_name];
  }

  return {};
}

std::string require_string(const cv::FileNode &node,
                           const std::string &field_name) {
  if (node.empty() || !node.isString()) {
    throw std::runtime_error("Configuration field '" + field_name +
                             "' is required and must be a string");
  }

  const std::string value = static_cast<std::string>(node);
  if (value.empty()) {
    throw std::runtime_error("Configuration field '" + field_name +
                             "' must not be empty");
  }
  return value;
}

std::string optional_string(const cv::FileNode &node,
                            const std::string &default_value,
                            const std::string &field_name) {
  if (node.empty()) {
    return default_value;
  }
  return require_string(node, field_name);
}

double require_number(const cv::FileNode &node, const std::string &field_name) {
  if (node.empty() || (!node.isInt() && !node.isReal())) {
    throw std::runtime_error("Configuration field '" + field_name +
                             "' is required and must be numeric");
  }

  const double value = static_cast<double>(node);
  if (!std::isfinite(value)) {
    throw std::runtime_error("Configuration field '" + field_name +
                             "' must be finite");
  }
  return value;
}

std::uint64_t optional_u64(const cv::FileNode &node,
                           const std::uint64_t default_value,
                           const std::string &field_name) {
  if (node.empty()) {
    return default_value;
  }

  const double value = require_number(node, field_name);
  if (value < 0.0 || std::floor(value) != value ||
      value > static_cast<double>(std::numeric_limits<std::uint64_t>::max())) {
    throw std::runtime_error("Configuration field '" + field_name +
                             "' must be a non-negative integer");
  }
  return static_cast<std::uint64_t>(value);
}

int optional_int(const cv::FileNode &node, const int default_value,
                 const std::string &field_name) {
  if (node.empty()) {
    return default_value;
  }

  const double value = require_number(node, field_name);
  if (std::floor(value) != value ||
      value < static_cast<double>(std::numeric_limits<int>::min()) ||
      value > static_cast<double>(std::numeric_limits<int>::max())) {
    throw std::runtime_error("Configuration field '" + field_name +
                             "' must be an integer");
  }
  return static_cast<int>(value);
}

bool optional_bool(const cv::FileNode &node, const bool default_value,
                   const std::string &field_name) {
  if (node.empty()) {
    return default_value;
  }
  if (node.isInt() || node.isReal()) {
    const double value = require_number(node, field_name);
    if (value == 0.0) {
      return false;
    }
    if (value == 1.0) {
      return true;
    }
  }
  if (node.isString()) {
    std::string value = static_cast<std::string>(node);
    std::transform(value.begin(), value.end(), value.begin(),
                   [](const unsigned char character) {
                     return static_cast<char>(std::tolower(character));
                   });
    if (value == "true" || value == "yes" || value == "on") {
      return true;
    }
    if (value == "false" || value == "no" || value == "off") {
      return false;
    }
  }

  throw std::runtime_error("Configuration field '" + field_name +
                           "' must be a boolean (0/1 or true/false)");
}

cv::Rect2d read_roi(const cv::FileNode &node) {
  if (node.empty()) {
    throw std::runtime_error("Configuration field 'roi' is required");
  }

  if (node.isSeq()) {
    if (node.size() != 4U) {
      throw std::runtime_error(
          "Configuration field 'roi' sequence must contain "
          "[x, y, width, height]");
    }
    return {
        require_number(node[0], "roi[0]"), require_number(node[1], "roi[1]"),
        require_number(node[2], "roi[2]"), require_number(node[3], "roi[3]")};
  }

  if (node.isMap()) {
    return {require_number(node["x"], "roi.x"),
            require_number(node["y"], "roi.y"),
            require_number(node["width"], "roi.width"),
            require_number(node["height"], "roi.height")};
  }

  throw std::runtime_error(
      "Configuration field 'roi' must be a mapping or four-value sequence");
}

std::filesystem::path
resolve_config_path(const std::filesystem::path &config_directory,
                    const std::string &value) {
  std::filesystem::path path(value);
  if (path.is_relative()) {
    path = config_directory / path;
  }
  return std::filesystem::absolute(path).lexically_normal();
}

std::filesystem::path resolve_override_path(const std::filesystem::path &path) {
  return std::filesystem::absolute(path).lexically_normal();
}

bool paths_refer_to_same_file(const std::filesystem::path &first,
                              const std::filesystem::path &second) {
  if (first.lexically_normal() == second.lexically_normal()) {
    return true;
  }

  std::error_code error;
  const bool equivalent = std::filesystem::equivalent(first, second, error);
  return !error && equivalent;
}

} // namespace

BenchmarkConfig
load_benchmark_config(const std::filesystem::path &config_path) {
  if (config_path.empty()) {
    throw std::runtime_error("Configuration path must not be empty");
  }

  const std::filesystem::path absolute_config =
      std::filesystem::absolute(config_path).lexically_normal();

  cv::FileStorage storage(absolute_config.string(),
                          cv::FileStorage::READ | cv::FileStorage::FORMAT_AUTO);
  if (!storage.isOpened()) {
    throw std::runtime_error("Unable to open benchmark configuration: " +
                             absolute_config.string());
  }

  const cv::FileNode root = storage.root();
  const std::filesystem::path config_directory = absolute_config.parent_path();

  BenchmarkConfig config;
  config.config_path = absolute_config;
  config.video_path = resolve_config_path(
      config_directory,
      require_string(find_node(root, "video_path", "video", "path"),
                     "video_path"));
  const cv::FileNode video_section = root["video"];
  if (!video_section.empty() && video_section.isMap()) {
    config.expected_video_sha256 =
        optional_string(video_section["sha256"], "", "video.sha256");
    config.expected_width = optional_int(video_section["expected_width"], 0,
                                         "video.expected_width");
    config.expected_height = optional_int(video_section["expected_height"], 0,
                                          "video.expected_height");
    config.expected_decoded_frames =
        optional_u64(video_section["expected_decoded_frames"], 0,
                     "video.expected_decoded_frames");
  }
  const cv::FileNode inline_roi = root["roi"];
  if (!inline_roi.empty()) {
    config.initial_roi = read_roi(inline_roi);
  } else {
    const std::filesystem::path roi_path = resolve_config_path(
        config_directory, require_string(root["roi_file"], "roi_file"));
    config.roi_file_path = roi_path;
    cv::FileStorage roi_storage(roi_path.string(),
                                cv::FileStorage::READ |
                                    cv::FileStorage::FORMAT_AUTO);
    if (!roi_storage.isOpened()) {
      throw std::runtime_error("Unable to open ROI configuration: " +
                               roi_path.string());
    }
    config.initial_roi = read_roi(roi_storage.root());
  }
  config.frames_csv = resolve_config_path(
      config_directory,
      optional_string(find_node(root, "frames_csv", "output", "frames_csv"),
                      "results/frames.csv", "frames_csv"));
  config.summary_json = resolve_config_path(
      config_directory,
      optional_string(find_node(root, "summary_json", "output", "summary_json"),
                      "results/summary.json", "summary_json"));
  config.max_frames =
      optional_u64(find_node(root, "max_frames", "benchmark", "max_frames"), 0,
                   "max_frames");
  config.opencv_threads = optional_int(
      find_node(root, "opencv_threads", "benchmark", "opencv_threads"), -1,
      "opencv_threads");
  config.compute_frame_checksums = optional_bool(
      find_node(root, "frame_checksums", "benchmark", "frame_checksums"), true,
      "frame_checksums");

  validate_config(config);
  return config;
}

void apply_config_overrides(BenchmarkConfig &config,
                            const ConfigOverrides &overrides) {
  if (overrides.frames_csv.has_value()) {
    config.frames_csv = resolve_override_path(*overrides.frames_csv);
  }
  if (overrides.summary_json.has_value()) {
    config.summary_json = resolve_override_path(*overrides.summary_json);
  }
  if (overrides.max_frames.has_value()) {
    config.max_frames = *overrides.max_frames;
  }
  if (overrides.opencv_threads.has_value()) {
    config.opencv_threads = *overrides.opencv_threads;
  }
  if (overrides.compute_frame_checksums.has_value()) {
    config.compute_frame_checksums = *overrides.compute_frame_checksums;
  }
  validate_config(config);
}

void validate_config(const BenchmarkConfig &config) {
  if (config.video_path.empty()) {
    throw std::runtime_error("Video path must not be empty");
  }
  if (!std::filesystem::exists(config.video_path) ||
      !std::filesystem::is_regular_file(config.video_path)) {
    throw std::runtime_error("Video path does not identify a regular file: " +
                             config.video_path.string());
  }
  if (config.frames_csv.empty()) {
    throw std::runtime_error("CSV output path must not be empty");
  }
  if (config.summary_json.empty()) {
    throw std::runtime_error("JSON summary path must not be empty");
  }
  if (config.frames_csv == config.summary_json) {
    throw std::runtime_error("CSV and JSON output paths must be different");
  }
  if (paths_refer_to_same_file(config.frames_csv, config.video_path) ||
      paths_refer_to_same_file(config.summary_json, config.video_path)) {
    throw std::runtime_error("Output paths must not overwrite the input video");
  }
  if (paths_refer_to_same_file(config.frames_csv, config.config_path) ||
      paths_refer_to_same_file(config.summary_json, config.config_path)) {
    throw std::runtime_error(
        "Output paths must not overwrite the benchmark configuration");
  }
  if (config.roi_file_path.has_value() &&
      (paths_refer_to_same_file(config.frames_csv, *config.roi_file_path) ||
       paths_refer_to_same_file(config.summary_json, *config.roi_file_path))) {
    throw std::runtime_error(
        "Output paths must not overwrite the ROI configuration");
  }
  if (config.opencv_threads < -1) {
    throw std::runtime_error(
        "opencv_threads must be -1 (leave default) or zero/positive");
  }
  const bool has_expected_width = config.expected_width != 0;
  const bool has_expected_height = config.expected_height != 0;
  if (has_expected_width != has_expected_height || config.expected_width < 0 ||
      config.expected_height < 0) {
    throw std::runtime_error(
        "video.expected_width and video.expected_height must both be "
        "positive when either is provided");
  }
  if (!config.expected_video_sha256.empty()) {
    const bool valid_sha256 =
        config.expected_video_sha256.size() == 64U &&
        std::all_of(config.expected_video_sha256.begin(),
                    config.expected_video_sha256.end(),
                    [](const unsigned char character) {
                      return std::isxdigit(character) != 0;
                    });
    if (!valid_sha256) {
      throw std::runtime_error(
          "video.sha256 must contain exactly 64 hexadecimal characters");
    }
  }

  if (!std::isfinite(config.initial_roi.x) ||
      !std::isfinite(config.initial_roi.y) ||
      !std::isfinite(config.initial_roi.width) ||
      !std::isfinite(config.initial_roi.height) || config.initial_roi.x < 0.0 ||
      config.initial_roi.y < 0.0 || config.initial_roi.width <= 0.0 ||
      config.initial_roi.height <= 0.0) {
    throw std::runtime_error(
        "ROI must contain finite, non-negative x/y and positive "
        "width/height values");
  }
}

void validate_roi_for_frame(const cv::Rect2d &roi, const cv::Size &frame_size) {
  if (frame_size.width <= 0 || frame_size.height <= 0) {
    throw std::runtime_error("Decoded frame has invalid dimensions");
  }

  const double right = roi.x + roi.width;
  const double bottom = roi.y + roi.height;
  if (right > static_cast<double>(frame_size.width) ||
      bottom > static_cast<double>(frame_size.height)) {
    throw std::runtime_error(
        "ROI extends outside the first decoded frame: ROI right/bottom=" +
        std::to_string(right) + "/" + std::to_string(bottom) +
        ", frame width/height=" + std::to_string(frame_size.width) + "/" +
        std::to_string(frame_size.height));
  }
}

} // namespace mosse
