//! Experiment 044: disjoint fixed-shape MOSSE tail kernels.
//!
//! This crate keeps the experimental kernels isolated from the default
//! tracker build. Default-off tracker experiments may consume the work units,
//! which fit the guarded caller-plus-three-worker runtime:
//!
//! 1. four tasks independently write nine rows of the fixed 60x36
//!    half-pixel-interior BGR-to-log crop;
//! 2. the caller performs the original row-major `f64` sum and
//!    squared-deviation loops;
//! 3. four tasks independently normalize and apply the Hann window to nine
//!    rows each; and
//! 4. eight tasks independently correlate one padded-spectrum batch each.
//!
//! A separate three-way crop binder exposes twelve rows per task for runtimes
//! that publish one task to each parked worker before waking an activity.
//!
//! The task arrays contain only disjoint mutable borrows and implement
//! `Send`, so they can be passed directly to `FourCoreRuntime::dispatch`.
//! No parallel partial reduction is exposed: the only accumulation API is
//! [`reduce_log_values_row_major`], whose addition order matches the serial
//! production expression.

use mosse_exp028_aosoa_cfft36::Batch4 as ColumnBatch4;
pub use mosse_exp034_whole_layout_fft2::PaddedSpectrum;
use mosse_exp034_whole_layout_fft2::{
    COLUMN_BATCHES, HEIGHT, LANES, PADDED_SPECTRUM_WIDTH, SPATIAL_LEN, WIDTH,
};
#[cfg(any(not(target_arch = "aarch64"), test))]
use rustfft::num_complex::Complex32;
use std::{error::Error, fmt};

pub const PATCH_WIDTH: usize = WIDTH;
pub const PATCH_HEIGHT: usize = HEIGHT;
pub const PIXEL_COUNT: usize = SPATIAL_LEN;
pub const ROW_TASK_COUNT: usize = 4;
pub const ROWS_PER_TASK: usize = PATCH_HEIGHT / ROW_TASK_COUNT;
pub const WORKER_CROP_TASK_COUNT: usize = 3;
pub const WORKER_CROP_ROWS_PER_TASK: usize = PATCH_HEIGHT / WORKER_CROP_TASK_COUNT;
pub const CORRELATION_TASK_COUNT: usize = COLUMN_BATCHES;
pub const VALID_SPECTRUM_WIDTH: usize = 31;
pub const DEFAULT_EPSILON: f64 = 1.0e-5;

const ROW_TASK_LEN: usize = PATCH_WIDTH * ROWS_PER_TASK;
const WORKER_CROP_TASK_LEN: usize = PATCH_WIDTH * WORKER_CROP_ROWS_PER_TASK;

const _: () = {
    assert!(PATCH_WIDTH == 60);
    assert!(PATCH_HEIGHT == 36);
    assert!(PIXEL_COUNT == 2160);
    assert!(PATCH_HEIGHT.is_multiple_of(ROW_TASK_COUNT));
    assert!(ROWS_PER_TASK == 9);
    assert!(PATCH_HEIGHT.is_multiple_of(WORKER_CROP_TASK_COUNT));
    assert!(WORKER_CROP_ROWS_PER_TASK == 12);
    assert!(LANES == 4);
    assert!(VALID_SPECTRUM_WIDTH == 31);
    assert!(PADDED_SPECTRUM_WIDTH == 32);
    assert!(CORRELATION_TASK_COUNT == 8);
};

/// A validated, possibly stride-padded BGR8 frame.
#[derive(Clone, Copy, Debug)]
pub struct BgrFrame<'a> {
    data: &'a [u8],
    width: usize,
    height: usize,
    stride: usize,
}

impl<'a> BgrFrame<'a> {
    pub fn new(
        data: &'a [u8],
        width: usize,
        height: usize,
        stride: usize,
    ) -> Result<Self, TailKernelError> {
        if width == 0 || height == 0 {
            return Err(TailKernelError::EmptyFrame);
        }
        let packed_stride = width
            .checked_mul(3)
            .ok_or(TailKernelError::FrameGeometryOverflow)?;
        if stride < packed_stride {
            return Err(TailKernelError::StrideTooSmall {
                stride,
                minimum: packed_stride,
            });
        }
        let required_len = (height - 1)
            .checked_mul(stride)
            .and_then(|row| row.checked_add(packed_stride))
            .ok_or(TailKernelError::FrameGeometryOverflow)?;
        if data.len() < required_len {
            return Err(TailKernelError::FrameStorageTooShort {
                actual: data.len(),
                minimum: required_len,
            });
        }
        Ok(Self {
            data,
            width,
            height,
            stride,
        })
    }

    pub const fn width(self) -> usize {
        self.width
    }

    pub const fn height(self) -> usize {
        self.height
    }

    pub const fn stride(self) -> usize {
        self.stride
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum TailKernelError {
    EmptyFrame,
    FrameGeometryOverflow,
    StrideTooSmall { stride: usize, minimum: usize },
    FrameStorageTooShort { actual: usize, minimum: usize },
    OriginOutsideHalfPixelInterior { origin_x: usize, origin_y: usize },
    WrongSpatialLength { actual: usize, expected: usize },
}

impl fmt::Display for TailKernelError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {
            Self::EmptyFrame => formatter.write_str("BGR frame dimensions must be nonzero"),
            Self::FrameGeometryOverflow => formatter.write_str("BGR frame geometry overflow"),
            Self::StrideTooSmall { stride, minimum } => {
                write!(formatter, "BGR stride {stride} is smaller than {minimum}")
            }
            Self::FrameStorageTooShort { actual, minimum } => {
                write!(
                    formatter,
                    "BGR storage has {actual} bytes but requires at least {minimum}"
                )
            }
            Self::OriginOutsideHalfPixelInterior { origin_x, origin_y } => {
                write!(
                    formatter,
                    "fixed half-pixel crop origin ({origin_x}, {origin_y}) lacks an interior right/bottom neighbor"
                )
            }
            Self::WrongSpatialLength { actual, expected } => {
                write!(
                    formatter,
                    "fixed 60x36 buffer has length {actual}, expected {expected}"
                )
            }
        }
    }
}

impl Error for TailKernelError {}

/// One disjoint group of complete BGR-to-log crop rows.
///
/// The fixed integer origin is the floor of a validated half-pixel crop
/// origin. Each output sample averages the corresponding 2x2 BGR pixels,
/// converts that averaged pixel with OpenCV's fixed-point BT.601 expression,
/// and looks up the resulting `f32` log value.
#[derive(Debug)]
pub struct CropLogRowsTask<'inputs, 'output> {
    frame: BgrFrame<'inputs>,
    log_lut: &'inputs [f32; 256],
    origin_x: usize,
    origin_y: usize,
    first_patch_row: usize,
    output: &'output mut [f32],
}

impl CropLogRowsTask<'_, '_> {
    #[inline]
    pub fn run(&mut self) {
        run_crop_log_rows(
            self.frame,
            self.log_lut,
            self.origin_x,
            self.origin_y,
            self.first_patch_row,
            self.output,
        );
    }

    pub const fn first_patch_row(&self) -> usize {
        self.first_patch_row
    }
}

#[inline]
fn run_crop_log_rows(
    frame: BgrFrame<'_>,
    log_lut: &[f32; 256],
    origin_x: usize,
    origin_y: usize,
    first_patch_row: usize,
    output: &mut [f32],
) {
    #[cfg(target_arch = "aarch64")]
    {
        // SAFETY: both binders validate the complete fixed crop plus its
        // right/bottom interpolation neighbors, and the task supplies one
        // disjoint complete output-row range.
        unsafe {
            crop_log_rows_neon(frame, log_lut, origin_x, origin_y, first_patch_row, output);
        }
    }
    #[cfg(not(target_arch = "aarch64"))]
    {
        crop_log_rows_scalar(frame, log_lut, origin_x, origin_y, first_patch_row, output);
    }
}

/// One fixed crop row group whose output is represented only by a raw pointer.
///
/// Unlike [`CropLogRowsTask`], this type deliberately stores no `&mut [f32]`.
/// Its temporary mutable output slice exists only for the duration of
/// [`Self::run`] and is gone before that call returns. A synchronization-aware
/// composite executor may therefore publish completion and then create a
/// shared view of the complete output without overlapping live Rust mutable
/// references.
#[derive(Debug)]
pub struct RawCropLogRowsTask<'inputs> {
    frame: BgrFrame<'inputs>,
    log_lut: &'inputs [f32; 256],
    origin_x: usize,
    origin_y: usize,
    first_patch_row: usize,
    output: *mut f32,
}

// SAFETY: the unsafe binder requires a valid exclusive complete output
// allocation and assigns each task a disjoint nine-row range. Moving one task
// to its unique executor lane therefore transfers, rather than duplicates,
// access to that range.
unsafe impl Send for RawCropLogRowsTask<'_> {}

impl RawCropLogRowsTask<'_> {
    /// Write this task's disjoint nine-row output range.
    ///
    /// # Safety
    ///
    /// The output allocation supplied to [`bind_raw_crop_log_rows`] must still
    /// be live and exclusive. This task must not run concurrently with itself
    /// or with any other access to its assigned row range.
    #[inline]
    pub unsafe fn run(&mut self) {
        // SAFETY: the raw binder assigns exactly one valid nine-row segment to
        // this task, and the caller upholds its lifetime/exclusivity contract.
        let output = unsafe { std::slice::from_raw_parts_mut(self.output, ROW_TASK_LEN) };
        run_crop_log_rows(
            self.frame,
            self.log_lut,
            self.origin_x,
            self.origin_y,
            self.first_patch_row,
            output,
        );
    }

    pub const fn first_patch_row(&self) -> usize {
        self.first_patch_row
    }
}

/// Bind four disjoint crop tasks without allocation.
///
/// After dispatch returns, drop the task array before reducing `log_values`.
/// This ends the tasks' mutable borrows and makes the required serial
/// row-major accumulation explicit at the call site.
pub fn bind_crop_log_rows<'inputs, 'output>(
    frame: BgrFrame<'inputs>,
    origin_x: usize,
    origin_y: usize,
    log_lut: &'inputs [f32; 256],
    log_values: &'output mut [f32],
) -> Result<[CropLogRowsTask<'inputs, 'output>; ROW_TASK_COUNT], TailKernelError> {
    validate_spatial_len(log_values.len())?;
    validate_fixed_origin(frame, origin_x, origin_y)?;

    let (rows_0, remainder) = log_values.split_at_mut(ROW_TASK_LEN);
    let (rows_1, remainder) = remainder.split_at_mut(ROW_TASK_LEN);
    let (rows_2, rows_3) = remainder.split_at_mut(ROW_TASK_LEN);
    debug_assert_eq!(rows_3.len(), ROW_TASK_LEN);

    Ok([
        CropLogRowsTask {
            frame,
            log_lut,
            origin_x,
            origin_y,
            first_patch_row: 0,
            output: rows_0,
        },
        CropLogRowsTask {
            frame,
            log_lut,
            origin_x,
            origin_y,
            first_patch_row: ROWS_PER_TASK,
            output: rows_1,
        },
        CropLogRowsTask {
            frame,
            log_lut,
            origin_x,
            origin_y,
            first_patch_row: ROWS_PER_TASK * 2,
            output: rows_2,
        },
        CropLogRowsTask {
            frame,
            log_lut,
            origin_x,
            origin_y,
            first_patch_row: ROWS_PER_TASK * 3,
            output: rows_3,
        },
    ])
}

/// Bind four disjoint raw-output crop tasks without storing Rust mutable
/// references in the returned job.
///
/// # Safety
///
/// `log_values` must be non-null, properly aligned, and valid for writable
/// access to `log_values_len` consecutive `f32` values. That allocation must
/// remain live and exclusive until every returned task has finished or been
/// abandoned. Each task may run at most once at a time, and no caller may
/// access any output row while its task is running.
///
/// After every task's `run` call has returned and an appropriate inter-thread
/// release/acquire barrier has been crossed, the owner may read the complete
/// allocation even while the raw task values themselves remain live: they
/// contain pointers, not Rust references, and `run` creates no mutable slice
/// that survives its return.
pub unsafe fn bind_raw_crop_log_rows<'inputs>(
    frame: BgrFrame<'inputs>,
    origin_x: usize,
    origin_y: usize,
    log_lut: &'inputs [f32; 256],
    log_values: *mut f32,
    log_values_len: usize,
) -> Result<[RawCropLogRowsTask<'inputs>; ROW_TASK_COUNT], TailKernelError> {
    validate_spatial_len(log_values_len)?;
    validate_fixed_origin(frame, origin_x, origin_y)?;
    assert!(
        !log_values.is_null(),
        "raw crop output pointer must be non-null"
    );

    Ok(std::array::from_fn(|task| RawCropLogRowsTask {
        frame,
        log_lut,
        origin_x,
        origin_y,
        first_patch_row: task * ROWS_PER_TASK,
        // SAFETY: the caller guarantees one complete writable allocation, and
        // each task offset selects a distinct in-bounds nine-row segment.
        output: unsafe { log_values.add(task * ROW_TASK_LEN) },
    }))
}

/// Bind three disjoint twelve-row crop tasks without allocation.
///
/// Task indices zero, one, and two own patch rows `0..12`, `12..24`, and
/// `24..36` respectively. This shape is intended for a worker-only runtime
/// epoch where lanes one through three each execute exactly one task.
pub fn bind_worker_crop_log_rows<'inputs, 'output>(
    frame: BgrFrame<'inputs>,
    origin_x: usize,
    origin_y: usize,
    log_lut: &'inputs [f32; 256],
    log_values: &'output mut [f32],
) -> Result<[CropLogRowsTask<'inputs, 'output>; WORKER_CROP_TASK_COUNT], TailKernelError> {
    validate_spatial_len(log_values.len())?;
    validate_fixed_origin(frame, origin_x, origin_y)?;

    let (rows_0, remainder) = log_values.split_at_mut(WORKER_CROP_TASK_LEN);
    let (rows_1, rows_2) = remainder.split_at_mut(WORKER_CROP_TASK_LEN);
    debug_assert_eq!(rows_2.len(), WORKER_CROP_TASK_LEN);

    Ok([
        CropLogRowsTask {
            frame,
            log_lut,
            origin_x,
            origin_y,
            first_patch_row: 0,
            output: rows_0,
        },
        CropLogRowsTask {
            frame,
            log_lut,
            origin_x,
            origin_y,
            first_patch_row: WORKER_CROP_ROWS_PER_TASK,
            output: rows_1,
        },
        CropLogRowsTask {
            frame,
            log_lut,
            origin_x,
            origin_y,
            first_patch_row: WORKER_CROP_ROWS_PER_TASK * 2,
            output: rows_2,
        },
    ])
}

#[derive(Clone, Copy, Debug)]
pub struct SerialPreprocessReduction {
    pub sum: f64,
    pub mean: f64,
    pub squared_deviation_sum: f64,
    pub stddev: f64,
    pub mean_f32: f32,
    pub denominator_f32: f32,
}

impl SerialPreprocessReduction {
    pub fn bit_identical(self, other: Self) -> bool {
        self.sum.to_bits() == other.sum.to_bits()
            && self.mean.to_bits() == other.mean.to_bits()
            && self.squared_deviation_sum.to_bits() == other.squared_deviation_sum.to_bits()
            && self.stddev.to_bits() == other.stddev.to_bits()
            && self.mean_f32.to_bits() == other.mean_f32.to_bits()
            && self.denominator_f32.to_bits() == other.denominator_f32.to_bits()
    }
}

/// Perform the two serial production accumulations in original row-major
/// order.
///
/// This function deliberately does not accept or combine per-core partial
/// sums. Floating-point addition is non-associative; keeping these two loops
/// on the caller preserves the original accumulation order exactly.
pub fn reduce_log_values_row_major(
    log_values: &[f32],
    epsilon: f64,
) -> Result<SerialPreprocessReduction, TailKernelError> {
    validate_spatial_len(log_values.len())?;

    let mut sum = 0.0f64;
    for &value in log_values {
        sum += value as f64;
    }
    let mean = sum / PIXEL_COUNT as f64;

    let mut squared_deviation_sum = 0.0f64;
    for &value in log_values {
        let deviation = value as f64 - mean;
        squared_deviation_sum += deviation * deviation;
    }
    let stddev = (squared_deviation_sum / PIXEL_COUNT as f64).sqrt();

    Ok(SerialPreprocessReduction {
        sum,
        mean,
        squared_deviation_sum,
        stddev,
        mean_f32: mean as f32,
        denominator_f32: (stddev + epsilon) as f32,
    })
}

/// One disjoint nine-row normalization/Hann task.
#[derive(Debug)]
pub struct NormalizeHannRowsTask<'window, 'values> {
    hann: &'window [f32],
    values: &'values mut [f32],
    mean: f32,
    denominator: f32,
    first_patch_row: usize,
}

impl NormalizeHannRowsTask<'_, '_> {
    #[inline]
    pub fn run(&mut self) {
        for (value, &window) in self.values.iter_mut().zip(self.hann) {
            *value = ((*value - self.mean) / self.denominator) * window;
        }
    }

    pub const fn first_patch_row(&self) -> usize {
        self.first_patch_row
    }
}

/// Bind four disjoint normalization/Hann tasks without allocation.
pub fn bind_normalize_hann_rows<'window, 'values>(
    log_values: &'values mut [f32],
    hann: &'window [f32],
    reduction: SerialPreprocessReduction,
) -> Result<[NormalizeHannRowsTask<'window, 'values>; ROW_TASK_COUNT], TailKernelError> {
    validate_spatial_len(log_values.len())?;
    validate_spatial_len(hann.len())?;

    let (values_0, remainder) = log_values.split_at_mut(ROW_TASK_LEN);
    let (values_1, remainder) = remainder.split_at_mut(ROW_TASK_LEN);
    let (values_2, values_3) = remainder.split_at_mut(ROW_TASK_LEN);
    let (hann_0, remainder) = hann.split_at(ROW_TASK_LEN);
    let (hann_1, remainder) = remainder.split_at(ROW_TASK_LEN);
    let (hann_2, hann_3) = remainder.split_at(ROW_TASK_LEN);

    Ok([
        NormalizeHannRowsTask {
            hann: hann_0,
            values: values_0,
            mean: reduction.mean_f32,
            denominator: reduction.denominator_f32,
            first_patch_row: 0,
        },
        NormalizeHannRowsTask {
            hann: hann_1,
            values: values_1,
            mean: reduction.mean_f32,
            denominator: reduction.denominator_f32,
            first_patch_row: ROWS_PER_TASK,
        },
        NormalizeHannRowsTask {
            hann: hann_2,
            values: values_2,
            mean: reduction.mean_f32,
            denominator: reduction.denominator_f32,
            first_patch_row: ROWS_PER_TASK * 2,
        },
        NormalizeHannRowsTask {
            hann: hann_3,
            values: values_3,
            mean: reduction.mean_f32,
            denominator: reduction.denominator_f32,
            first_patch_row: ROWS_PER_TASK * 3,
        },
    ])
}

/// One disjoint padded-spectrum batch correlation task.
///
/// Task `batch` owns all 36 rows of four adjacent x-frequency lanes. The
/// eighth task always restores its invalid fourth lane to positive zero.
#[derive(Debug)]
pub struct CorrelationBatchTask<'inputs, 'output> {
    sample: &'inputs ColumnBatch4,
    filter: &'inputs ColumnBatch4,
    response: &'output mut ColumnBatch4,
    batch: usize,
}

impl CorrelationBatchTask<'_, '_> {
    #[inline]
    pub fn run(&mut self) {
        correlate_padded_batch(self.sample, self.filter, self.response, self.batch);
    }

    pub const fn batch(&self) -> usize {
        self.batch
    }
}

/// Correlate one complete padded-spectrum batch with the experiment's exact
/// scalar/NEON arithmetic.
///
/// `batch` identifies the disjoint four-frequency-lane batch owned by the
/// caller. Batch seven's invalid lane three is restored to positive zero
/// before this function returns, so a fused consumer may immediately run its
/// inverse column kernel without a separate padding pass.
#[inline]
pub fn correlate_padded_batch(
    sample: &ColumnBatch4,
    filter: &ColumnBatch4,
    response: &mut ColumnBatch4,
    batch: usize,
) {
    assert!(
        batch < CORRELATION_TASK_COUNT,
        "correlation batch index must be in the fixed padded spectrum"
    );

    #[cfg(target_arch = "aarch64")]
    {
        // SAFETY: AArch64 provides NEON and every load/store is exactly one
        // `[f32; 4]` row owned by this batch.
        unsafe {
            correlate_batch_neon(sample, filter, response);
        }
    }
    #[cfg(not(target_arch = "aarch64"))]
    {
        correlate_batch_scalar(sample, filter, response);
    }

    if batch == CORRELATION_TASK_COUNT - 1 {
        restore_padding_positive_zero(response);
    }
}

/// Bind eight disjoint correlation tasks without allocation.
///
/// Static modulo-four dispatch gives each core two complete batches.
pub fn bind_correlation_batches<'inputs, 'output>(
    sample: &'inputs PaddedSpectrum,
    filter: &'inputs PaddedSpectrum,
    response: &'output mut PaddedSpectrum,
) -> [CorrelationBatchTask<'inputs, 'output>; CORRELATION_TASK_COUNT] {
    let sample_batches = sample.batches.each_ref();
    let filter_batches = filter.batches.each_ref();
    let response_batches = response.batches.each_mut();
    let mut batches = sample_batches
        .into_iter()
        .zip(filter_batches)
        .zip(response_batches);

    std::array::from_fn(|batch| {
        let ((sample, filter), response) = batches.next().expect("fixed correlation batch count");
        CorrelationBatchTask {
            sample,
            filter,
            response,
            batch,
        }
    })
}

#[inline]
fn validate_spatial_len(actual: usize) -> Result<(), TailKernelError> {
    if actual == PIXEL_COUNT {
        Ok(())
    } else {
        Err(TailKernelError::WrongSpatialLength {
            actual,
            expected: PIXEL_COUNT,
        })
    }
}

#[inline]
fn validate_fixed_origin(
    frame: BgrFrame<'_>,
    origin_x: usize,
    origin_y: usize,
) -> Result<(), TailKernelError> {
    let right_neighbor = origin_x.checked_add(PATCH_WIDTH);
    let bottom_neighbor = origin_y.checked_add(PATCH_HEIGHT);
    if right_neighbor.is_some_and(|x| x < frame.width)
        && bottom_neighbor.is_some_and(|y| y < frame.height)
    {
        Ok(())
    } else {
        Err(TailKernelError::OriginOutsideHalfPixelInterior { origin_x, origin_y })
    }
}

#[inline]
#[cfg(not(target_arch = "aarch64"))]
fn crop_log_rows_scalar(
    frame: BgrFrame<'_>,
    log_lut: &[f32; 256],
    origin_x: usize,
    origin_y: usize,
    first_patch_row: usize,
    output: &mut [f32],
) {
    debug_assert!(output.len().is_multiple_of(PATCH_WIDTH));
    let row_count = output.len() / PATCH_WIDTH;
    debug_assert!(first_patch_row + row_count <= PATCH_HEIGHT);
    for local_y in 0..row_count {
        let patch_y = first_patch_row + local_y;
        let row_0 = (origin_y + patch_y) * frame.stride;
        let row_1 = row_0 + frame.stride;
        for x in 0..PATCH_WIDTH {
            let top_left = row_0 + (origin_x + x) * 3;
            let top_right = top_left + 3;
            let bottom_left = row_1 + (origin_x + x) * 3;
            let bottom_right = bottom_left + 3;
            let blue = rounded_quarter_sum(
                frame.data[top_left],
                frame.data[top_right],
                frame.data[bottom_left],
                frame.data[bottom_right],
            );
            let green = rounded_quarter_sum(
                frame.data[top_left + 1],
                frame.data[top_right + 1],
                frame.data[bottom_left + 1],
                frame.data[bottom_right + 1],
            );
            let red = rounded_quarter_sum(
                frame.data[top_left + 2],
                frame.data[top_right + 2],
                frame.data[bottom_left + 2],
                frame.data[bottom_right + 2],
            );
            output[local_y * PATCH_WIDTH + x] = log_lut[bgr_to_gray(blue, green, red) as usize];
        }
    }
}

#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
unsafe fn crop_log_rows_neon(
    frame: BgrFrame<'_>,
    log_lut: &[f32; 256],
    origin_x: usize,
    origin_y: usize,
    first_patch_row: usize,
    output: &mut [f32],
) {
    use core::arch::aarch64::{vld3_u8, vst1_u8};

    const PIXELS_PER_BLOCK: usize = 8;
    const VECTORIZED_WIDTH: usize = PATCH_WIDTH / PIXELS_PER_BLOCK * PIXELS_PER_BLOCK;

    debug_assert!(output.len().is_multiple_of(PATCH_WIDTH));
    let row_count = output.len() / PATCH_WIDTH;
    debug_assert!(first_patch_row + row_count <= PATCH_HEIGHT);
    for local_y in 0..row_count {
        let patch_y = first_patch_row + local_y;
        let row_0 = (origin_y + patch_y) * frame.stride;
        let row_1 = row_0 + frame.stride;
        let mut x = 0usize;
        while x < VECTORIZED_WIDTH {
            let top_left = row_0 + (origin_x + x) * 3;
            let bottom_left = row_1 + (origin_x + x) * 3;

            // SAFETY: both crop binders validate the complete fixed patch plus
            // right/bottom neighbors. Each interleaved load reads eight
            // complete BGR pixels and the final shifted load ends at x=56.
            let (top, top_right, bottom, bottom_right) = unsafe {
                (
                    vld3_u8(frame.data.as_ptr().add(top_left)),
                    vld3_u8(frame.data.as_ptr().add(top_left + 3)),
                    vld3_u8(frame.data.as_ptr().add(bottom_left)),
                    vld3_u8(frame.data.as_ptr().add(bottom_left + 3)),
                )
            };

            // SAFETY: this function and both helpers have NEON enabled.
            let gray = unsafe {
                let blue = rounded_quarter_sum_8_neon(top.0, top_right.0, bottom.0, bottom_right.0);
                let green =
                    rounded_quarter_sum_8_neon(top.1, top_right.1, bottom.1, bottom_right.1);
                let red = rounded_quarter_sum_8_neon(top.2, top_right.2, bottom.2, bottom_right.2);
                bgr_to_gray_8_neon(blue, green, red)
            };
            let mut gray_lanes = [0u8; PIXELS_PER_BLOCK];
            // SAFETY: the destination has exactly eight writable bytes.
            unsafe {
                vst1_u8(gray_lanes.as_mut_ptr(), gray);
            }
            let output_start = local_y * PATCH_WIDTH + x;
            for lane in 0..PIXELS_PER_BLOCK {
                output[output_start + lane] = log_lut[gray_lanes[lane] as usize];
            }
            x += PIXELS_PER_BLOCK;
        }

        for x in VECTORIZED_WIDTH..PATCH_WIDTH {
            let top_left = row_0 + (origin_x + x) * 3;
            let top_right = top_left + 3;
            let bottom_left = row_1 + (origin_x + x) * 3;
            let bottom_right = bottom_left + 3;
            let blue = rounded_quarter_sum(
                frame.data[top_left],
                frame.data[top_right],
                frame.data[bottom_left],
                frame.data[bottom_right],
            );
            let green = rounded_quarter_sum(
                frame.data[top_left + 1],
                frame.data[top_right + 1],
                frame.data[bottom_left + 1],
                frame.data[bottom_right + 1],
            );
            let red = rounded_quarter_sum(
                frame.data[top_left + 2],
                frame.data[top_right + 2],
                frame.data[bottom_left + 2],
                frame.data[bottom_right + 2],
            );
            output[local_y * PATCH_WIDTH + x] = log_lut[bgr_to_gray(blue, green, red) as usize];
        }
    }
}

#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
unsafe fn rounded_quarter_sum_8_neon(
    p00: core::arch::aarch64::uint8x8_t,
    p10: core::arch::aarch64::uint8x8_t,
    p01: core::arch::aarch64::uint8x8_t,
    p11: core::arch::aarch64::uint8x8_t,
) -> core::arch::aarch64::uint8x8_t {
    use core::arch::aarch64::{vaddl_u8, vaddq_u16, vdupq_n_u16, vshrn_n_u16};

    // Widening prevents overflow; the largest sum is 1020.
    let top = vaddl_u8(p00, p10);
    let bottom = vaddl_u8(p01, p11);
    let rounded = vaddq_u16(vaddq_u16(top, bottom), vdupq_n_u16(2));
    vshrn_n_u16::<2>(rounded)
}

#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
unsafe fn bgr_to_gray_8_neon(
    blue: core::arch::aarch64::uint8x8_t,
    green: core::arch::aarch64::uint8x8_t,
    red: core::arch::aarch64::uint8x8_t,
) -> core::arch::aarch64::uint8x8_t {
    use core::arch::aarch64::{
        vaddq_u32, vcombine_u16, vdupq_n_u32, vget_high_u16, vget_low_u16, vmlal_n_u16, vmovl_u8,
        vmovn_u16, vmull_n_u16, vshrn_n_u32,
    };

    const BLUE_TO_Y: u16 = 1_868;
    const GREEN_TO_Y: u16 = 9_617;
    const RED_TO_Y: u16 = 4_899;
    const ROUND: u32 = 1 << 13;

    // The maximum weighted sum plus rounding fits in `u32`.
    let blue = vmovl_u8(blue);
    let green = vmovl_u8(green);
    let red = vmovl_u8(red);

    let mut low = vmull_n_u16(vget_low_u16(blue), BLUE_TO_Y);
    low = vmlal_n_u16(low, vget_low_u16(green), GREEN_TO_Y);
    low = vmlal_n_u16(low, vget_low_u16(red), RED_TO_Y);
    low = vaddq_u32(low, vdupq_n_u32(ROUND));

    let mut high = vmull_n_u16(vget_high_u16(blue), BLUE_TO_Y);
    high = vmlal_n_u16(high, vget_high_u16(green), GREEN_TO_Y);
    high = vmlal_n_u16(high, vget_high_u16(red), RED_TO_Y);
    high = vaddq_u32(high, vdupq_n_u32(ROUND));

    vmovn_u16(vcombine_u16(
        vshrn_n_u32::<14>(low),
        vshrn_n_u32::<14>(high),
    ))
}

#[inline]
fn rounded_quarter_sum(p00: u8, p10: u8, p01: u8, p11: u8) -> u8 {
    let sum = p00 as u16 + p10 as u16 + p01 as u16 + p11 as u16;
    ((sum + 2) / 4) as u8
}

#[inline]
fn bgr_to_gray(blue: u8, green: u8, red: u8) -> u8 {
    const BLUE_TO_Y: u32 = 1_868;
    const GREEN_TO_Y: u32 = 9_617;
    const RED_TO_Y: u32 = 4_899;
    const ROUND: u32 = 1 << 13;
    let value = blue as u32 * BLUE_TO_Y + green as u32 * GREEN_TO_Y + red as u32 * RED_TO_Y + ROUND;
    (value >> 14) as u8
}

#[inline]
#[cfg(not(target_arch = "aarch64"))]
fn correlate_batch_scalar(
    sample: &ColumnBatch4,
    filter: &ColumnBatch4,
    response: &mut ColumnBatch4,
) {
    for ky in 0..PATCH_HEIGHT {
        for lane in 0..LANES {
            let sample = Complex32::new(sample.re[ky][lane], sample.im[ky][lane]);
            let filter = Complex32::new(filter.re[ky][lane], filter.im[ky][lane]);
            let value = sample * filter.conj();
            response.re[ky][lane] = value.re;
            response.im[ky][lane] = value.im;
        }
    }
}

#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
unsafe fn correlate_batch_neon(
    sample: &ColumnBatch4,
    filter: &ColumnBatch4,
    response: &mut ColumnBatch4,
) {
    use core::arch::aarch64::{vaddq_f32, vld1q_f32, vmulq_f32, vnegq_f32, vst1q_f32, vsubq_f32};

    for ky in 0..PATCH_HEIGHT {
        // SAFETY: every source and destination is exactly one `[f32; 4]`.
        unsafe {
            let sample_re = vld1q_f32(sample.re[ky].as_ptr());
            let sample_im = vld1q_f32(sample.im[ky].as_ptr());
            let filter_re = vld1q_f32(filter.re[ky].as_ptr());
            let filter_im = vnegq_f32(vld1q_f32(filter.im[ky].as_ptr()));
            let response_re = vsubq_f32(
                vmulq_f32(sample_re, filter_re),
                vmulq_f32(sample_im, filter_im),
            );
            let response_im = vaddq_f32(
                vmulq_f32(sample_re, filter_im),
                vmulq_f32(sample_im, filter_re),
            );
            vst1q_f32(response.re[ky].as_mut_ptr(), response_re);
            vst1q_f32(response.im[ky].as_mut_ptr(), response_im);
        }
    }
}

#[inline]
fn restore_padding_positive_zero(last_batch: &mut ColumnBatch4) {
    let padding_lane = LANES - 1;
    for ky in 0..PATCH_HEIGHT {
        last_batch.re[ky][padding_lane] = 0.0;
        last_batch.im[ky][padding_lane] = 0.0;
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::thread;

    #[derive(Clone, Copy)]
    struct Lcg(u64);

    impl Lcg {
        fn new(seed: u64) -> Self {
            Self(seed)
        }

        fn next_u32(&mut self) -> u32 {
            self.0 = self
                .0
                .wrapping_mul(6_364_136_223_846_793_005)
                .wrapping_add(1_442_695_040_888_963_407);
            (self.0 >> 32) as u32
        }

        fn next_u8(&mut self) -> u8 {
            self.next_u32() as u8
        }

        fn finite_f32(&mut self) -> f32 {
            let sign = self.next_u32() & 0x8000_0000;
            let exponent = ((self.next_u32() % 240) + 7) << 23;
            let mantissa = self.next_u32() & 0x007f_ffff;
            f32::from_bits(sign | exponent | mantissa)
        }
    }

    fn log_lut() -> [f32; 256] {
        std::array::from_fn(|pixel| (pixel as f32 + 1.0).ln())
    }

    fn hann_window() -> Vec<f32> {
        let mut output = vec![0.0f32; PIXEL_COUNT];
        let width_denominator = (PATCH_WIDTH - 1) as f64;
        let height_denominator = (PATCH_HEIGHT - 1) as f64;
        for y in 0..PATCH_HEIGHT {
            let wy =
                0.5 * (1.0 - (2.0 * std::f64::consts::PI * y as f64 / height_denominator).cos());
            for x in 0..PATCH_WIDTH {
                let wx =
                    0.5 * (1.0 - (2.0 * std::f64::consts::PI * x as f64 / width_denominator).cos());
                output[y * PATCH_WIDTH + x] = (wx * wy) as f32;
            }
        }
        output
    }

    fn reference_crop(
        frame: BgrFrame<'_>,
        origin_x: usize,
        origin_y: usize,
        lut: &[f32; 256],
        output: &mut [f32],
    ) {
        for y in 0..PATCH_HEIGHT {
            let row_0 = (origin_y + y) * frame.stride;
            let row_1 = row_0 + frame.stride;
            for x in 0..PATCH_WIDTH {
                let top_left = row_0 + (origin_x + x) * 3;
                let top_right = top_left + 3;
                let bottom_left = row_1 + (origin_x + x) * 3;
                let bottom_right = bottom_left + 3;
                let blue = rounded_quarter_sum(
                    frame.data[top_left],
                    frame.data[top_right],
                    frame.data[bottom_left],
                    frame.data[bottom_right],
                );
                let green = rounded_quarter_sum(
                    frame.data[top_left + 1],
                    frame.data[top_right + 1],
                    frame.data[bottom_left + 1],
                    frame.data[bottom_right + 1],
                );
                let red = rounded_quarter_sum(
                    frame.data[top_left + 2],
                    frame.data[top_right + 2],
                    frame.data[bottom_left + 2],
                    frame.data[bottom_right + 2],
                );
                output[y * PATCH_WIDTH + x] = lut[bgr_to_gray(blue, green, red) as usize];
            }
        }
    }

    fn reference_reduce_and_normalize(
        values: &mut [f32],
        hann: &[f32],
        epsilon: f64,
    ) -> SerialPreprocessReduction {
        let mut sum = 0.0f64;
        for &value in values.iter() {
            sum += value as f64;
        }
        let mean = sum / values.len() as f64;
        let mut squared_deviation_sum = 0.0f64;
        for &value in values.iter() {
            let deviation = value as f64 - mean;
            squared_deviation_sum += deviation * deviation;
        }
        let stddev = (squared_deviation_sum / values.len() as f64).sqrt();
        let mean_f32 = mean as f32;
        let denominator_f32 = (stddev + epsilon) as f32;
        for (value, &window) in values.iter_mut().zip(hann) {
            *value = ((*value - mean_f32) / denominator_f32) * window;
        }
        SerialPreprocessReduction {
            sum,
            mean,
            squared_deviation_sum,
            stddev,
            mean_f32,
            denominator_f32,
        }
    }

    fn run_crop_tasks_concurrently<const N: usize>(tasks: &mut [CropLogRowsTask<'_, '_>; N]) {
        thread::scope(|scope| {
            for task in tasks {
                scope.spawn(move || task.run());
            }
        });
    }

    fn run_raw_crop_tasks_concurrently(tasks: &mut [RawCropLogRowsTask<'_>; ROW_TASK_COUNT]) {
        thread::scope(|scope| {
            for task in tasks {
                scope.spawn(move || {
                    // SAFETY: the test's raw binder owns one live exclusive
                    // output allocation and assigns every thread disjoint rows.
                    unsafe { task.run() };
                });
            }
        });
    }

    fn run_normalize_tasks_concurrently(
        tasks: &mut [NormalizeHannRowsTask<'_, '_>; ROW_TASK_COUNT],
    ) {
        thread::scope(|scope| {
            for task in tasks {
                scope.spawn(move || task.run());
            }
        });
    }

    fn run_correlation_tasks_concurrently(
        tasks: &mut [CorrelationBatchTask<'_, '_>; CORRELATION_TASK_COUNT],
    ) {
        thread::scope(|scope| {
            for task in tasks {
                scope.spawn(move || task.run());
            }
        });
    }

    fn assert_f32_bits(actual: &[f32], expected: &[f32], label: &str) {
        assert_eq!(actual.len(), expected.len());
        for (index, (&actual, &expected)) in actual.iter().zip(expected).enumerate() {
            assert_eq!(
                actual.to_bits(),
                expected.to_bits(),
                "{label} index {index}: actual={actual:?}, expected={expected:?}"
            );
        }
    }

    #[test]
    fn three_worker_crop_binding_matches_retained_four_way_composition() {
        let lut = log_lut();

        for case in 0..32u64 {
            let mut rng = Lcg::new(0x0580_c20f_91d5_73a1 ^ case.wrapping_mul(0x9e37_79b9));
            let width = PATCH_WIDTH + 1 + (rng.next_u32() as usize % 37);
            let height = PATCH_HEIGHT + 1 + (rng.next_u32() as usize % 29);
            let stride = width * 3 + 1 + (rng.next_u32() as usize % 31);
            let maximum_x = width - PATCH_WIDTH - 1;
            let maximum_y = height - PATCH_HEIGHT - 1;
            let origin_x = match case % 3 {
                0 => 0,
                1 => maximum_x,
                _ => rng.next_u32() as usize % (maximum_x + 1),
            };
            let origin_y = match (case / 3) % 3 {
                0 => 0,
                1 => maximum_y,
                _ => rng.next_u32() as usize % (maximum_y + 1),
            };
            let mut data = vec![0xa5u8; stride * height + 23];
            for byte in &mut data {
                *byte = rng.next_u8();
            }
            let frame = BgrFrame::new(&data, width, height, stride).unwrap();

            let expected_dirty = f32::from_bits(0x7fc1_0000 | (case as u32 + 1));
            let actual_dirty = f32::from_bits(0xffc2_0000 | (case as u32 + 1));
            let mut expected = vec![expected_dirty; PIXEL_COUNT];
            let mut actual = vec![actual_dirty; PIXEL_COUNT];
            {
                let mut tasks =
                    bind_crop_log_rows(frame, origin_x, origin_y, &lut, &mut expected).unwrap();
                run_crop_tasks_concurrently(&mut tasks);
            }
            {
                let mut tasks =
                    bind_worker_crop_log_rows(frame, origin_x, origin_y, &lut, &mut actual)
                        .unwrap();
                assert_eq!(
                    std::array::from_fn(|index| tasks[index].first_patch_row()),
                    [0, 12, 24]
                );
                run_crop_tasks_concurrently(&mut tasks);
            }

            assert_f32_bits(
                &actual,
                &expected,
                &format!(
                    "three-way crop case={case} origin=({origin_x},{origin_y}) stride={stride}"
                ),
            );
        }
    }

    #[test]
    fn raw_crop_tasks_release_temporary_mutable_slices_before_reduction() {
        let lut = log_lut();

        for case in 0..16u64 {
            let mut rng = Lcg::new(0x0640_a11a_5afe_0000 ^ case.wrapping_mul(0x9e37_79b9));
            let width = PATCH_WIDTH + 1 + (rng.next_u32() as usize % 19);
            let height = PATCH_HEIGHT + 1 + (rng.next_u32() as usize % 13);
            let stride = width * 3 + 1 + (rng.next_u32() as usize % 17);
            let maximum_x = width - PATCH_WIDTH - 1;
            let maximum_y = height - PATCH_HEIGHT - 1;
            let origin_x = if case % 2 == 0 { 0 } else { maximum_x };
            let origin_y = if case % 4 < 2 { 0 } else { maximum_y };
            let mut data = vec![0xa5u8; stride * height + 29];
            for byte in &mut data {
                *byte = rng.next_u8();
            }
            let frame = BgrFrame::new(&data, width, height, stride).unwrap();
            let dirty = f32::from_bits(0x7fc6_0000 | (case as u32 + 1));
            let mut expected = vec![dirty; PIXEL_COUNT];
            let mut actual = vec![dirty; PIXEL_COUNT];
            reference_crop(frame, origin_x, origin_y, &lut, &mut expected);

            let mut tasks = unsafe {
                // SAFETY: `actual` stays live and exclusively owned through
                // every task and the complete concurrent run.
                bind_raw_crop_log_rows(
                    frame,
                    origin_x,
                    origin_y,
                    &lut,
                    actual.as_mut_ptr(),
                    actual.len(),
                )
                .unwrap()
            };
            assert_eq!(
                std::array::from_fn(|index| tasks[index].first_patch_row()),
                [0, 9, 18, 27]
            );
            run_raw_crop_tasks_concurrently(&mut tasks);

            // Keep the raw task values alive across this shared read on
            // purpose. They contain no mutable references, and every
            // temporary slice created by `run` ended before the scoped joins.
            assert_f32_bits(&actual, &expected, "raw crop alias handoff");
            let actual_reduction = reduce_log_values_row_major(&actual, DEFAULT_EPSILON).unwrap();
            let expected_reduction =
                reduce_log_values_row_major(&expected, DEFAULT_EPSILON).unwrap();
            assert!(actual_reduction.bit_identical(expected_reduction));
            std::hint::black_box(&tasks);
        }
    }

    #[test]
    fn randomized_padded_stride_crop_and_preprocess_are_bit_exact() {
        let lut = log_lut();
        let hann = hann_window();

        for case in 0..32u64 {
            let mut rng = Lcg::new(0xd1b5_4a32_9c6e_70f1 ^ case.wrapping_mul(0x9e37_79b9));
            let width = PATCH_WIDTH + 1 + (rng.next_u32() as usize % 37);
            let height = PATCH_HEIGHT + 1 + (rng.next_u32() as usize % 29);
            let stride = width * 3 + 1 + (rng.next_u32() as usize % 31);
            let origin_x = rng.next_u32() as usize % (width - PATCH_WIDTH);
            let origin_y = rng.next_u32() as usize % (height - PATCH_HEIGHT);
            let mut data = vec![0u8; stride * height + 19];
            for byte in &mut data {
                *byte = rng.next_u8();
            }
            let frame = BgrFrame::new(&data, width, height, stride).unwrap();

            let dirty = f32::from_bits(0x7fc0_0000 | (case as u32 + 1));
            let mut actual = vec![dirty; PIXEL_COUNT];
            let mut expected = vec![dirty; PIXEL_COUNT];
            reference_crop(frame, origin_x, origin_y, &lut, &mut expected);

            {
                let mut crop_tasks =
                    bind_crop_log_rows(frame, origin_x, origin_y, &lut, &mut actual).unwrap();
                assert_eq!(
                    std::array::from_fn(|index| crop_tasks[index].first_patch_row()),
                    [0, 9, 18, 27]
                );
                run_crop_tasks_concurrently(&mut crop_tasks);
            }
            assert_f32_bits(&actual, &expected, "crop-to-log");

            let expected_reduction =
                reference_reduce_and_normalize(&mut expected, &hann, DEFAULT_EPSILON);
            let actual_reduction = reduce_log_values_row_major(&actual, DEFAULT_EPSILON).unwrap();
            assert!(
                actual_reduction.bit_identical(expected_reduction),
                "serial reduction mismatch in case {case}: actual={actual_reduction:?}, expected={expected_reduction:?}"
            );

            {
                let mut normalize_tasks =
                    bind_normalize_hann_rows(&mut actual, &hann, actual_reduction).unwrap();
                assert_eq!(
                    std::array::from_fn(|index| normalize_tasks[index].first_patch_row()),
                    [0, 9, 18, 27]
                );
                run_normalize_tasks_concurrently(&mut normalize_tasks);
            }
            assert_f32_bits(&actual, &expected, "normalized Hann output");
        }
    }

    #[test]
    fn row_major_reduction_detects_non_associative_partial_sum_order() {
        let mut values = vec![0.0f32; PIXEL_COUNT];
        for chunk in values.chunks_exact_mut(4) {
            chunk.copy_from_slice(&[1.0e30, 1.0, -1.0e30, 1.0]);
        }

        let actual = reduce_log_values_row_major(&values, DEFAULT_EPSILON).unwrap();
        let mut serial_sum = 0.0f64;
        for &value in &values {
            serial_sum += value as f64;
        }
        let mut lane_sums = [0.0f64; ROW_TASK_COUNT];
        for (index, &value) in values.iter().enumerate() {
            lane_sums[index % ROW_TASK_COUNT] += value as f64;
        }
        let combined_partial_sum = lane_sums.into_iter().sum::<f64>();

        assert_eq!(actual.sum.to_bits(), serial_sum.to_bits());
        assert_ne!(
            combined_partial_sum.to_bits(),
            serial_sum.to_bits(),
            "test vector must distinguish partial-combine and row-major order"
        );
    }

    #[test]
    fn crop_binding_rejects_invalid_geometry_without_writing() {
        let lut = log_lut();
        let width = PATCH_WIDTH + 1;
        let height = PATCH_HEIGHT + 1;
        let stride = width * 3 + 7;
        let data = vec![0u8; stride * height];
        let frame = BgrFrame::new(&data, width, height, stride).unwrap();
        let dirty = f32::from_bits(0x7fc1_2345);
        let mut output = vec![dirty; PIXEL_COUNT];

        assert_eq!(
            bind_crop_log_rows(frame, 1, 0, &lut, &mut output).unwrap_err(),
            TailKernelError::OriginOutsideHalfPixelInterior {
                origin_x: 1,
                origin_y: 0,
            }
        );
        assert_eq!(
            bind_worker_crop_log_rows(frame, 1, 0, &lut, &mut output).unwrap_err(),
            TailKernelError::OriginOutsideHalfPixelInterior {
                origin_x: 1,
                origin_y: 0,
            }
        );
        assert!(output
            .iter()
            .all(|value| value.to_bits() == dirty.to_bits()));

        let mut short = vec![dirty; PIXEL_COUNT - 1];
        assert_eq!(
            bind_crop_log_rows(frame, 0, 0, &lut, &mut short).unwrap_err(),
            TailKernelError::WrongSpatialLength {
                actual: PIXEL_COUNT - 1,
                expected: PIXEL_COUNT,
            }
        );
        assert_eq!(
            bind_worker_crop_log_rows(frame, 0, 0, &lut, &mut short).unwrap_err(),
            TailKernelError::WrongSpatialLength {
                actual: PIXEL_COUNT - 1,
                expected: PIXEL_COUNT,
            }
        );
    }

    fn fill_spectrum_random(spectrum: &mut PaddedSpectrum, rng: &mut Lcg) {
        for batch in 0..CORRELATION_TASK_COUNT {
            for ky in 0..PATCH_HEIGHT {
                for lane in 0..LANES {
                    spectrum.batches[batch].re[ky][lane] = rng.finite_f32();
                    spectrum.batches[batch].im[ky][lane] = rng.finite_f32();
                }
            }
        }
    }

    fn reference_correlation(sample: &PaddedSpectrum, filter: &PaddedSpectrum) -> PaddedSpectrum {
        let mut response = PaddedSpectrum::default();
        for kx in 0..VALID_SPECTRUM_WIDTH {
            let batch = kx / LANES;
            let lane = kx % LANES;
            for ky in 0..PATCH_HEIGHT {
                let sample = Complex32::new(
                    sample.batches[batch].re[ky][lane],
                    sample.batches[batch].im[ky][lane],
                );
                let filter = Complex32::new(
                    filter.batches[batch].re[ky][lane],
                    filter.batches[batch].im[ky][lane],
                );
                let value = sample * filter.conj();
                response.batches[batch].re[ky][lane] = value.re;
                response.batches[batch].im[ky][lane] = value.im;
            }
        }
        response
    }

    fn assert_spectrum_bits(actual: &PaddedSpectrum, expected: &PaddedSpectrum) {
        for batch in 0..CORRELATION_TASK_COUNT {
            for ky in 0..PATCH_HEIGHT {
                for lane in 0..LANES {
                    assert_eq!(
                        actual.batches[batch].re[ky][lane].to_bits(),
                        expected.batches[batch].re[ky][lane].to_bits(),
                        "real mismatch at batch={batch}, ky={ky}, lane={lane}"
                    );
                    assert_eq!(
                        actual.batches[batch].im[ky][lane].to_bits(),
                        expected.batches[batch].im[ky][lane].to_bits(),
                        "imag mismatch at batch={batch}, ky={ky}, lane={lane}"
                    );
                }
            }
        }
    }

    #[test]
    fn randomized_batch_partitioned_correlation_matches_oracle() {
        for case in 0..24u64 {
            let mut rng = Lcg::new(0x44e1_903f_8ac2_71d5 ^ case.wrapping_mul(0x517c_c1b7));
            let mut sample = PaddedSpectrum::default();
            let mut filter = PaddedSpectrum::default();
            fill_spectrum_random(&mut sample, &mut rng);
            fill_spectrum_random(&mut filter, &mut rng);

            // Exercise signed zero in valid lanes. These cases are easy to
            // accidentally change by spelling conjugate multiplication with
            // a different add/subtract sequence.
            for &(kx, ky, sample_re, sample_im, filter_re, filter_im) in &[
                (0, 0, 0.0, -0.0, -0.0, 0.0),
                (3, 7, -0.0, 0.0, 0.0, -0.0),
                (17, 23, 1.0, -0.0, -0.0, -1.0),
                (30, 35, -0.0, -1.0, 1.0, 0.0),
            ] {
                let batch = kx / LANES;
                let lane = kx % LANES;
                sample.batches[batch].re[ky][lane] = sample_re;
                sample.batches[batch].im[ky][lane] = sample_im;
                filter.batches[batch].re[ky][lane] = filter_re;
                filter.batches[batch].im[ky][lane] = filter_im;
            }

            // The invalid lane may contain anything on entry; output must
            // never expose it to the inverse transform.
            for ky in 0..PATCH_HEIGHT {
                sample.batches[CORRELATION_TASK_COUNT - 1].re[ky][LANES - 1] =
                    if ky % 2 == 0 { -0.0 } else { f32::NAN };
                sample.batches[CORRELATION_TASK_COUNT - 1].im[ky][LANES - 1] =
                    f32::from_bits(0x7fc0_1000 | ky as u32);
                filter.batches[CORRELATION_TASK_COUNT - 1].re[ky][LANES - 1] =
                    f32::from_bits(0xffc0_2000 | ky as u32);
                filter.batches[CORRELATION_TASK_COUNT - 1].im[ky][LANES - 1] = -0.0;
            }

            let expected = reference_correlation(&sample, &filter);
            let mut actual = PaddedSpectrum::default();
            actual.poison_all(case as u32 + 1);
            {
                let mut tasks = bind_correlation_batches(&sample, &filter, &mut actual);
                assert_eq!(
                    std::array::from_fn(|index| tasks[index].batch()),
                    [0, 1, 2, 3, 4, 5, 6, 7]
                );
                run_correlation_tasks_concurrently(&mut tasks);
            }

            assert_spectrum_bits(&actual, &expected);
            assert!(actual.padding_is_positive_zero());
        }
    }

    #[test]
    fn padding_is_restored_to_positive_zero_from_signed_zero_and_nan() {
        let mut sample = PaddedSpectrum::default();
        let mut filter = PaddedSpectrum::default();
        let mut response = PaddedSpectrum::default();
        let last = CORRELATION_TASK_COUNT - 1;
        let padding = LANES - 1;
        for ky in 0..PATCH_HEIGHT {
            sample.batches[last].re[ky][padding] = -0.0;
            sample.batches[last].im[ky][padding] = f32::from_bits(0x7fc0_0100 | ky as u32);
            filter.batches[last].re[ky][padding] = f32::NEG_INFINITY;
            filter.batches[last].im[ky][padding] = -0.0;
            response.batches[last].re[ky][padding] = -0.0;
            response.batches[last].im[ky][padding] = -0.0;
        }

        {
            let mut tasks = bind_correlation_batches(&sample, &filter, &mut response);
            for task in &mut tasks {
                task.run();
            }
        }

        for ky in 0..PATCH_HEIGHT {
            assert_eq!(response.batches[last].re[ky][padding].to_bits(), 0);
            assert_eq!(response.batches[last].im[ky][padding].to_bits(), 0);
        }
        assert!(response.padding_is_positive_zero());
    }

    #[test]
    fn bgr_frame_validation_accepts_padded_stride_and_rejects_short_storage() {
        let width = PATCH_WIDTH + 5;
        let height = PATCH_HEIGHT + 7;
        let stride = width * 3 + 13;
        let minimum = (height - 1) * stride + width * 3;
        let storage = vec![0u8; minimum];
        let frame = BgrFrame::new(&storage, width, height, stride).unwrap();
        assert_eq!(frame.width(), width);
        assert_eq!(frame.height(), height);
        assert_eq!(frame.stride(), stride);

        assert_eq!(
            BgrFrame::new(&storage[..minimum - 1], width, height, stride).unwrap_err(),
            TailKernelError::FrameStorageTooShort {
                actual: minimum - 1,
                minimum,
            }
        );
        assert_eq!(
            BgrFrame::new(&storage, width, height, width * 3 - 1).unwrap_err(),
            TailKernelError::StrideTooSmall {
                stride: width * 3 - 1,
                minimum: width * 3,
            }
        );
    }
}
